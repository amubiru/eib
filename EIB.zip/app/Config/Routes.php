<?php

namespace Config;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

// Load the system's routing file first, so that the app and ENVIRONMENT
// can override as needed.
if (is_file(SYSTEMPATH . 'Config/Routes.php')) {
    require SYSTEMPATH . 'Config/Routes.php';
}

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Frontend\Dashboard');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);

/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */

// We get a performance increase by specifying the default
// route since we don't have to scan directories.
$routes->get('/', 'Frontend\Dashboard::index');

$routes->get('/login', 'Login::index');
$routes->get('/logout', 'Login::logout');
$routes->post('/login/submit', 'Login::loginSubmit');

$routes->get('authorize', 'Login::authorize');
$routes->post('login/authorizeSubmit', 'Login::authorizeSubmit');

$routes->get('/login/forgotten_password', 'Login::ForgottenPassword');
$routes->post('/login/forgotten_password_submit', 'Login::ForgottenPasswordSubmit');

$routes->get('/frontend/change_pass', 'Frontend\PasswordController::changePassword');
$routes->post('/frontend/change_pass/submit', 'Frontend\PasswordController::submitPassword');

$routes->get('/test/rotate', 'Test::rotate');

$routes->post('/users/login', 'Api\Login::user');
$routes->post('/users/create', 'Api\Users::create');

$routes->get('/frontend/ipps_show', 'Frontend\Ipps::show');
$routes->get('/frontend/ipps_upload', 'Frontend\Ipps::upload');
$routes->post('/frontend/ipps_upload_submit', 'Frontend\Ipps::upload_submit');

//$routes->get('/frontend/subject_records', 'Frontend\SubjectRecordsController::index');
//$routes->get('/frontend/subject_records/add', 'Frontend\SubjectRecordsController::add');
//$routes->get('/frontend/subject_records/edit/(:num)', 'Frontend\SubjectRecordsController::edit/$1');
//$routes->post('/frontend/subject_records/submit', 'Frontend\SubjectRecordsController::submit');
//$routes->post('/frontend/subject_records/search', 'Frontend\SubjectRecordsController::search');
$routes->get('/frontend/subject_records/form20/(:any)', 'Frontend\SubjectRecordsController::form20/$1');
$routes->get('/frontend/subject_records/interpol/(:any)', 'Frontend\SubjectRecordsController::interpol/$1');

$routes->get('/frontend/subject_records/email_pcc/(:any)', 'Frontend\SubjectRecordsController::emailPCC/$1');
$routes->get('/frontend/subject_records/requeue/(:any)', 'Frontend\SubjectRecordsController::requeue/$1');

$routes->get('/frontend/subject_records/image/(:num)', 'Frontend\SubjectRecordsController::image/$1');
$routes->get('/frontend/subject_records/generate_pcc/(:num)', 'Frontend\SubjectRecordsController::generatePCC/$1');
$routes->get('/frontend/subject_records/generate_pcc_queue', 'Frontend\SubjectRecordsController::generatePCCQueue');

$routes->post('/frontend/subject_records/attachment_submit', 'Frontend\SubjectRecordsController::attachmentSubmit');
$routes->post('/frontend/subject_records/add_attachment', 'Frontend\SubjectRecordsController::attachmentAdd');

$routes->get('/frontend/subject_records/civilian', 'Frontend\CivilianSubjectRecordsController::index');
$routes->get('/frontend/subject_records/civilian/add', 'Frontend\CivilianSubjectRecordsController::add');
$routes->get('/frontend/subject_records/civilian/edit/(:num)', 'Frontend\CivilianSubjectRecordsController::edit/$1');
$routes->post('/frontend/subject_records/civilian/submit', 'Frontend\CivilianSubjectRecordsController::submit');
$routes->post('/frontend/subject_records/civilian/search', 'Frontend\CivilianSubjectRecordsController::search');
$routes->get('/frontend/subject_records/civilian/image/(:num)', 'Frontend\CivilianSubjectRecordsController::image/$1');
$routes->get('/frontend/subject_records/civilian/view/(:num)', 'Frontend\CivilianSubjectRecordsController::view/$1');
$routes->get('/frontend/subject_records/civilian/email_cogc/(:num)', 'Frontend\CivilianSubjectRecordsController::emailCOGC/$1');
$routes->post('/frontend/subject_records/civilian/attachment_submit', 'Frontend\CivilianSubjectRecordsController::attachmentSubmit');
//$routes->get('/frontend/subject_records/civilian/add_attachment/(:num)', 'Frontend\CivilianSubjectRecordsController::attachmentAdd/$1');

$routes->post('/frontend/subject_records/civilian/submit_pcc', 'Frontend\CivilianSubjectRecordsController::submitPCC');
$routes->get('/frontend/subject_records/civilian/queue', 'Frontend\CivilianSubjectRecordsController::queue_index');
$routes->match(['GET', 'POST'], '/frontend/subject_records/civilian/queue_search', 'Frontend\CivilianSubjectRecordsController::queue_search');
$routes->get('/frontend/subject_records/civilian/queue_view/(:num)', 'Frontend\CivilianSubjectRecordsController::queue_view/$1');
$routes->get('/frontend/subject_records/civilian/requeue/(:num)', 'Frontend\CivilianSubjectRecordsController::requeue/$1');
$routes->get('/frontend/subject_records/civilian/queue_resolve', 'Frontend\CivilianSubjectRecordsController::queue_resolve');
$routes->post('/frontend/subject_records/civilian/queue_reject', 'Frontend\CivilianSubjectRecordsController::queue_reject');

$routes->get('/frontend/subject_records/criminal', 'Frontend\CriminalSubjectRecordsController::index');
$routes->get('/frontend/subject_records/criminal/add', 'Frontend\CriminalSubjectRecordsController::add');
$routes->get('/frontend/subject_records/criminal/edit/(:num)', 'Frontend\CriminalSubjectRecordsController::edit/$1');
$routes->post('/frontend/subject_records/criminal/submit', 'Frontend\CriminalSubjectRecordsController::submit');
$routes->post('/frontend/subject_records/criminal/search', 'Frontend\CriminalSubjectRecordsController::search');
$routes->get('/frontend/subject_records/criminal/image/(:num)', 'Frontend\CriminalSubjectRecordsController::image/$1');
$routes->get('/frontend/subject_records/criminal/view/(:num)', 'Frontend\CriminalSubjectRecordsController::view/$1');
$routes->post('/frontend/subject_records/criminal/attachment_submit', 'Frontend\CriminalSubjectRecordsController::attachmentSubmit');
$routes->get('/frontend/subject_records/criminal/add_attachment/(:num)', 'Frontend\CriminalSubjectRecordsController::attachmentAdd/$1');

$routes->get('/frontend/subject_records/police', 'Frontend\PoliceSubjectRecordsController::index');
$routes->get('/frontend/subject_records/police/add', 'Frontend\PoliceSubjectRecordsController::add');
$routes->get('/frontend/subject_records/police/edit/(:num)', 'Frontend\PoliceSubjectRecordsController::edit/$1');
$routes->post('/frontend/subject_records/police/submit', 'Frontend\PoliceSubjectRecordsController::submit');
$routes->post('/frontend/subject_records/police/search', 'Frontend\PoliceSubjectRecordsController::search');
$routes->get('/frontend/subject_records/police/image/(:num)', 'Frontend\PoliceSubjectRecordsController::image/$1');
$routes->get('/frontend/subject_records/police/view/(:num)', 'Frontend\PoliceSubjectRecordsController::view/$1');
$routes->post('/frontend/subject_records/police/attachment_submit', 'Frontend\PoliceSubjectRecordsController::attachmentSubmit');
$routes->get('/frontend/subject_records/police/add_attachment/(:num)', 'Frontend\PoliceSubjectRecordsController::attachmentAdd/$1');

$routes->get('/frontend/subject_records/pso', 'Frontend\PSOSubjectRecordsController::index');
$routes->get('/frontend/subject_records/pso/add', 'Frontend\PSOSubjectRecordsController::add');
$routes->get('/frontend/subject_records/pso/edit/(:num)', 'Frontend\PSOSubjectRecordsController::edit/$1');
$routes->post('/frontend/subject_records/pso/submit', 'Frontend\PSOSubjectRecordsController::submit');
$routes->post('/frontend/subject_records/pso/search', 'Frontend\PSOSubjectRecordsController::search');
$routes->get('/frontend/subject_records/pso/image/(:num)', 'Frontend\PSOSubjectRecordsController::image/$1');
$routes->get('/frontend/subject_records/pso/view/(:num)', 'Frontend\PSOSubjectRecordsController::view/$1');
$routes->post('/frontend/subject_records/pso/attachment_submit', 'Frontend\PSOSubjectRecordsController::attachmentSubmit');
$routes->get('/frontend/subject_records/pso/add_attachment/(:num)', 'Frontend\PSOSubjectRecordsController::attachmentAdd/$1');

$routes->get('/frontend/subject_records/unverified', 'Frontend\UnverifiedSubjectRecordsController::index');
$routes->get('/frontend/subject_records/unverified/add', 'Frontend\UnverifiedSubjectRecordsController::add');
$routes->get('/frontend/subject_records/unverified/edit/(:num)', 'Frontend\UnverifiedSubjectRecordsController::edit/$1');
$routes->post('/frontend/subject_records/unverified/submit', 'Frontend\UnverifiedSubjectRecordsController::submit');
$routes->post('/frontend/subject_records/unverified/search', 'Frontend\UnverifiedSubjectRecordsController::search');
$routes->get('/frontend/subject_records/unverified/image/(:num)', 'Frontend\UnverifiedSubjectRecordsController::image/$1');
$routes->get('/frontend/subject_records/unverified/view/(:num)', 'Frontend\UnverifiedSubjectRecordsController::view/$1');
$routes->post('/frontend/subject_records/unverified/attachment_submit', 'Frontend\UnverifiedSubjectRecordsController::attachmentSubmit');
$routes->get('/frontend/subject_records/unverified/add_attachment/(:num)', 'Frontend\UnverifiedSubjectRecordsController::attachmentAdd/$1');

$routes->get('/frontend/', 'Frontend\Login::index');
$routes->get('/frontend/dashboard', 'Frontend\Dashboard::index');
$routes->post('/frontend/dashboard', 'Frontend\Dashboard::index');
$routes->get('/frontend/audit_log', 'Frontend\AuditLogController::index');

$routes->get('/frontend/attachments/(:num)', 'Frontend\AttachmentsController::index/$1');

$routes->get('/frontend/lost_and_found/vehicles', 'Frontend\LostAndFoundVehiclesController::index');
$routes->post('/frontend/lost_and_found/vehicles/submit', 'Frontend\LostAndFoundVehiclesController::submit');
$routes->post('/frontend/lost_and_found/vehicles/attachment_submit', 'Frontend\LostAndFoundVehiclesController::attachmentSubmit');
$routes->get('/frontend/lost_and_found/vehicles/add', 'Frontend\LostAndFoundVehiclesController::add');
$routes->get('/frontend/lost_and_found/vehicles/edit/(:num)', 'Frontend\LostAndFoundVehiclesController::edit/$1');
$routes->get('/frontend/lost_and_found/vehicles/add_attachment/(:num)', 'Frontend\LostAndFoundVehiclesController::attachmentAdd/$1');


$routes->get('/frontend/lost_and_found/phones', 'Frontend\LostAndFoundPhonesController::index');
$routes->post('/frontend/lost_and_found/phones/submit', 'Frontend\LostAndFoundPhonesController::submit');
$routes->post('/frontend/lost_and_found/phones/attachment_submit', 'Frontend\LostAndFoundPhonesController::attachmentSubmit');
$routes->get('/frontend/lost_and_found/phones/add', 'Frontend\LostAndFoundPhonesController::add');
$routes->get('/frontend/lost_and_found/phones/edit/(:num)', 'Frontend\LostAndFoundPhonesController::edit/$1');
$routes->get('/frontend/lost_and_found/phones/add_attachment/(:num)', 'Frontend\LostAndFoundPhonesController::attachmentAdd/$1');

$routes->get('/frontend/lost_and_found/general', 'Frontend\LostAndFoundGeneralController::index');
$routes->post('/frontend/lost_and_found/general/submit', 'Frontend\LostAndFoundGeneralController::submit');
$routes->post('/frontend/lost_and_found/general/attachment_submit', 'Frontend\LostAndFoundGeneralController::attachmentSubmit');
$routes->get('/frontend/lost_and_found/general/add', 'Frontend\LostAndFoundGeneralController::add');
$routes->get('/frontend/lost_and_found/general/edit/(:num)', 'Frontend\LostAndFoundGeneralController::edit/$1');
$routes->get('/frontend/lost_and_found/general/add_attachment/(:num)', 'Frontend\LostAndFoundGeneralController::attachmentAdd/$1');

$routes->get('/frontend/users', 'Frontend\UsersController::index');
$routes->post('/frontend/users/submit', 'Frontend\UsersController::submit');
$routes->get('/frontend/users/add', 'Frontend\UsersController::add');
$routes->get('/frontend/users/edit/(:num)', 'Frontend\UsersController::edit/$1');

/*
$routes->post('/frontend/subject_records/pcc_queue/search', 'Frontend\QueueController::PCCSearch');
$routes->get('/frontend/subject_records/pcc_queue', 'Frontend\QueueController::PCC');
$routes->post('/frontend/subject_records/cogc_queue/search', 'Frontend\QueueController::COGCSearch');
$routes->get('/frontend/subject_records/cogc_queue', 'Frontend\QueueController::COGC');
$routes->get('/frontend/subject_records/pcc_queue/process/(:num)', 'Frontend\QueueController::_PCCView/$1');
$routes->get('/frontend/subject_records/cogc_queue/process/(:num)', 'Frontend\QueueController::PCCView/$1');
*/

$routes->get('/frontend/redlist', 'Frontend\RedListController::index');
$routes->post('/frontend/redlist/modify', 'Frontend\RedListController::modify');
$routes->post('/frontend/redlist/modify_unverified', 'Frontend\RedListController::modifyUnverified');
$routes->post('/frontend/redlist/search', 'Frontend\RedListController::search');
$routes->post('/frontend/redlist/submit', 'Frontend\RedListController::submit');
$routes->post('/frontend/redlist/submit_unverified', 'Frontend\RedListController::submitUnverified');
$routes->get('/frontend/redlist/broadcast/(:num)', 'Frontend\RedListController::broadcast/$1');

$routes->get('login/google', 'Login::googleLogin');
$routes->get('login/google/callback', 'Login::googleCallback');

$routes->get('/frontend/traffic/dashboard', 'Frontend\TrafficDashboardController::index');
$routes->post('/frontend/traffic/dashboard', 'Frontend\TrafficDashboardController::index');
$routes->get('/frontend/traffic/drivers', 'Frontend\DriversController::index');
$routes->post('/frontend/traffic/drivers/submit', 'Frontend\DriversController::submit');
$routes->post('/frontend/traffic/drivers/search', 'Frontend\DriversController::search');
$routes->get('/frontend/traffic/drivers/add', 'Frontend\DriversController::add');
$routes->get('/frontend/traffic/drivers/edit/(:num)', 'Frontend\DriversController::edit/$1');
$routes->get('/frontend/traffic/drivers/view/(:num)', 'Frontend\DriversController::view/$1');

$routes->get('/frontend/traffic/offenses', 'Frontend\TrafficOffensesController::index');
$routes->post('/frontend/traffic/offenses/search', 'Frontend\TrafficOffensesController::search');
$routes->get('/frontend/traffic/offenses/view/(:num)', 'Frontend\TrafficOffensesController::view/$1');

//Search
$routes->get('/frontend/search', 'Frontend\SearchController::index');
$routes->post('/frontend/search/submit', 'Frontend\SearchController::submit');
$routes->match(['GET', 'POST'], '/frontend/search/dashboard', 'Frontend\SearchDashboardController::index');
$routes->get('/frontend/view_record', 'Frontend\ViewRecordController::index');


//Publicly downloadable forms
$routes->get('/pub/cogc', 'Frontend\COGCController::add');
$routes->get('/pub/cogc/index', 'Frontend\COGCController::index');
$routes->post('/pub/cogc/submit', 'Frontend\COGCController::submit');
$routes->get('/pub/cogc/view/(:num)', 'Frontend\COGCController::view/$1');
$routes->get('/frontend/cogc', 'Frontend\COGCController::view');
$routes->post('/frontend/cogc/send', 'Frontend\COGCController::send');
$routes->get('/pub/forms/cogc/(:any)', 'Pub\FormsController::cogc/$1');
$routes->get('/pub/cabis/(:any)', 'Pub\UtilsController::getCabis/$1');

//APIs
$routes->post('/cabis/identification_request', 'Api\Cabis::identification_request', ['filter' => 'apitoken']);
$routes->post('/cabis/submit_fingerprints', 'Api\Cabis::submit_fingerprints', ['filter' => 'apitoken']);
$routes->post('/cabis/formx', 'Api\Cabis::subject_data', ['filter' => 'apitoken']);
$routes->post('/cabis/hit', 'Api\Cabis::hit', ['filter' => 'apitoken']);
$routes->post('/cabis/subject_data', 'Api\Cabis::subject_data', ['filter' => 'apitoken']);
$routes->post('/subject/subject_record', 'Api\Subjects::subject_record', ['filter' => 'apitoken']);
$routes->post('/subject_record/subject', 'Api\Subjects::subject_record', ['filter' => 'apitoken']);
$routes->post('/subject_record/search', 'Api\Subjects::Search', ['filter' => 'apitoken']);
$routes->post('/subject_record/submit', 'Api\Subjects::submit', ['filter' => 'apitoken']);
$routes->post('/police_subject/verify_submit', 'Api\Police::verify_submit', ['filter' => 'apitoken']);
$routes->match(['GET', 'POST'],'/police_subject/query', 'Api\Police::query', ['filter' => 'apitoken']);
$routes->post('/cogc/application', 'Api\Cogc::application', ['filter' => 'apitoken']);
$routes->post('/cogc/get_group_id', 'Api\Cogc::getGroupId', ['filter' => 'apitoken']);



//S5 requests - TODO add authentication
$routes->post('/traffic/query', 'Api\Traffic::query');
$routes->post('/traffic/submit', 'Api\Traffic::submit');
$routes->post('/traffic/driver/enroll', 'Api\Traffic::driverEnroll');
$routes->post('/traffic/person/enroll', 'Api\Traffic::personEnroll');
$routes->get('/traffic/alerts', 'Api\Traffic::alerts');
$routes->get('/traffic/camera_alerts', 'Api\Traffic::cameraAlerts');

$routes->get('/traffic/redlist', 'Api\Traffic::redlist');
$routes->get('/traffic/oosto_image/(:any)', 'Api\Traffic::oostoImage/$1');
$routes->get('/traffic/oosto_image_realtime/(:any)', 'Api\Traffic::oostoImageRealtime/$1');
$routes->get('/traffic/oosto_video_realtime/(:any)', 'Api\Traffic::oostoVideoRealtime/$1');
$routes->get('/traffic/view', 'Api\Traffic::view');

$routes->get('/traffic/criminal_offenses', 'Api\Traffic::criminalOffenses');
$routes->post('/ec/voter_check', 'Api\Ec::check');
$routes->post('/ec/voter_enroll', 'Api\Ec::enroll');


$routes->post('/ec/get_voters', 'Api\Ec::getVoters');
$routes->get('/ec/index', 'Api\Ec::index');
$routes->get('/ec', 'Api\Ec::index');
$routes->get('/ec/add', 'Api\Ec::add');
$routes->post('/ec/submit', 'Api\Ec::submit');
$routes->post('/ec/search', 'Api\Ec::Search');
$routes->get('/ec/view/(:any)', 'Api\Ec::view/$1');
$routes->get('/ec/dashboard', 'Api\Ec::dashboard');
$routes->get('/ec/reset', 'Api\Ec::reset');
$routes->get('/ec/polling_stations', 'Api\Ec::pollingStations');
$routes->post('/ec/polling_stations/search', 'Api\Ec::pollingStationsSearch');
$routes->get('/ec/country', 'Api\Ec::country');
$routes->post('/ec/assign_ballot', 'Api\Ec::assignBallot');
$routes->post('/ec/check_ballot', 'Api\Ec::checkBallot');



$routes->match(['GET', 'POST'],'/ajax/get_cabis', 'Ajax::getCABIS');
$routes->match(['GET', 'POST'],'/ajax/get_cabis_array', 'Ajax::getCABISArray');
$routes->match(['GET', 'POST'],'/ajax/get_cabis_summary', 'Ajax::getCABISSummary');
$routes->match(['GET', 'POST'],'/ajax/check_civilian_cabis', 'Ajax::checkCivilianCABIS');
$routes->match(['GET', 'POST'],'/ajax/get_casetracking', 'Ajax::getCaseTracking');
$routes->match(['GET', 'POST'],'/ajax/get_person', 'Ajax::getPerson');
$routes->match(['GET', 'POST'],'/ajax/get_external_photo', 'Ajax::getExternalPhoto');


$routes->get('/ajax/qrcode/(:any)', 'Ajax::qrCode/$1');
$routes->get('test/finger', 'Test::finger');
$routes->get('test/nira', 'Test::nira');
$routes->get('test/nira_api', 'Test::nira_api');

$routes->get('test/nirapass', 'Test::nirapass');
$routes->get('test/matches', 'Test::findMatches');
$routes->get('/test/export_certificates/(:any)', 'Test::exportCertificates/$1');


$routes->get('test/oosto', 'Test::oosto');
$routes->get('test/face', 'Test::face');
$routes->post('test/face_submit', 'Test::faceSubmit');
$routes->get('test/face_results/(:any)', 'Test::faceResults/$1');
$routes->get('test/upload_oosto', 'Test::uploadOosto');
$routes->get('test/upload_face', 'Test::uploadFace');
$routes->get('test/load_ct', 'Test::loadCT');
$routes->get('test/load_ct_people', 'Test::loadCTP');
$routes->get('test/getface', 'Test::getFace');
$routes->get('test/getcandidate', 'Test::getCandidate');
$routes->get('test/getcard', 'Test::getCard');
$routes->get('test/prn', 'Test::prn');
$routes->get('test/cabis_group/(:any)', 'Test::cabisGroup/$1');
$routes->get('/test/refresh_cabis/(:any)', 'Test::refreshCabis/$1');
$routes->get('test/fix_external', 'Test::fixExternalData');
$routes->cli('test/pso', 'Test::processPSO');


$routes->cli('utils/check_cabis', 'Pub\UtilsController::checkCabis');
$routes->cli('utils/check_cabis_swagger', 'Pub\UtilsController::checkCabisSwagger');
$routes->cli('utils/check_cabis_enroll', 'Pub\UtilsController::checkCabisEnroll');
$routes->cli('utils/check_case_tracking', 'Pub\UtilsController::checkCaseTracking');
$routes->cli('utils/check_certificates', 'Pub\UtilsController::checkCertificates');
$routes->cli('utils/check_nira', 'Pub\UtilsController::checkNira');
$routes->cli('utils/process_camera_broadcasts', 'Pub\UtilsController::processCameraBroadcasts');
$routes->cli('background_tasks/process_certificates', 'BackgroundTasks::processCertificates');
$routes->cli('background_tasks/process_resolved_certificates', 'BackgroundTasks::processResolvedCertificates');
$routes->get('background_tasks/export_certificates', 'BackgroundTasks::exportCertificates');
$routes->cli('background_tasks/export_certificates_cli', 'BackgroundTasks::exportCertificatesCLI');
$routes->cli('background_tasks/export_certificates_daily', 'BackgroundTasks::exportCertificatesDaily');
$routes->cli('background_tasks/review_cogc', 'BackgroundTasks::reviewCOGC');

$routes->get('/background_tasks/save_pcc/(:any)', 'BackgroundTasks::savePCC/$1');
$routes->cli('/background_tasks/pccs', 'BackgroundTasks::pcc');
$routes->cli('/background_tasks/mark_prints', 'BackgroundTasks::markPrints');
$routes->get('/background_tasks/check_cert/(:any)', 'BackgroundTasks::checkCertificate/$1');

$routes->get('/test/create_users', 'Test::create_users');


/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}

<?php 

namespace App\Models;

use CodeIgniter\Model;

class TrafficOffenseModel extends Model
{
	protected $table = 'traffic_offenses';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['first_name', 'last_name', 'dob', 'phone', 'id_type', 'id_number', 'number_plate', 'offense', 'penalty', 'amount', 'location'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Perform a wildcard search for records
	public function search($params)
	{	
		if(isset($params['id_number']) && !empty($params['id_number'])) {
			$this->builder->like('id_number', $params['id_number']);
		}
		if(isset($params['offense']) && !empty($params['offense'])) {
			$this->builder->like('offense', $params['offense']);
		}
		if(isset($params['number_plate']) && !empty($params['number_plate'])) {
			$this->builder->like('number_plate', $params['number_plate']);
		}
		if(isset($params['nin']) && !empty($params['nin'])) {
			$this->builder->like('nin', $params['nin']);
		}
		
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('created_at >=', $params['start_date']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('created_at <=', $params['end_date']);
		}
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Perform a search for related records
	public function getRelated($params)
	{	
		if(isset($params['id_number']) && !empty($params['id_number'])) {
			$this->builder->where('id_number', $params['id_number']);
		}

		if(isset($params['number_plate']) && !empty($params['number_plate'])) {
			$this->builder->orWhere('number_plate', $params['number_plate']);
		}
		if(isset($params['nin']) && !empty($params['nin'])) {
			$this->builder->orWhere('nin', $params['nin']);
		}
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByNin($nin)
	{
		if(strlen($nin)==14) {
			$this->builder->where('id_number', $nin);
			$result=$this->builder->get();
			return($result->getResultArray());
		} else {
			return([]);
		}
	}
	
	public function getByNinOrVehicle($nin, $number_plate)
	{
		//Return empty if fields are not correct lengths
		if(strlen($nin) != 14 && strlen($number_plate<2)) {
			return([]);
		}
		if(strlen($nin) == 14) {
			$this->builder->where('id_number', $nin);
			if($number_plate) {
				$this->builder->orWhere('number_plate', $number_plate);
			}
		} else {
			$this->builder->where('number_plate', $number_plate);
		}
			
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Finds out top 10 offenses and their count
	public function getTop10OffensesCount($start=null, $end=null)
	{
		$this->builder->select("offense, count(*) as num");
		$this->builder->orderBy("num", "DESC");
		if($start) {
			$this->builder->where('created_at>=',$start);
		}
		if($end) {
			$this->builder->where('created_at<=',$end);
		} 
		$this->builder->groupBy("offense");
		$this->builder->limit(10);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Finds out the counts for one offense in a period
	public function getOffenseCount($offense, $start=null, $end=null)
	{
		$this->builder->select("count(*) as num");
		$this->builder->where("offense", $offense);
		if($start) {
			$this->builder->where('created_at>=',$start);
		}
		if($end) {
			$this->builder->where('created_at<=',$end);
		} 
		$result=$this->builder->get();
		$row=$result->getRowArray();
		return($row['num']);
	}
	
	//Finds out the counts for offenses in a period
	public function countOffenses($start=null, $end=null)
	{
		$this->builder->select("count(*) as num");
		if($start) {
			$this->builder->where('created_at>=',$start);
		}
		if($end) {
			$this->builder->where('created_at<=',$end);
		} 
		$result=$this->builder->get();
		$row=$result->getRowArray();
		return($row['num']);
	}
	
	//Finds out the counts for cautions in a period
	public function countCautions($start=null, $end=null)
	{
		$this->builder->select("count(*) as num");
		$this->builder->where('penalty','CAUTION');
		if($start) {
			$this->builder->where('created_at>=',$start);
		}
		if($end) {
			$this->builder->where('created_at<=',$end);
		} 
		$result=$this->builder->get();
		$row=$result->getRowArray();
		return($row['num']);
	}
	
	//Finds out the counts for offenses in a period
	public function countFines($start=null, $end=null)
	{
		$this->builder->select("count(*) as num");
		$this->builder->where('penalty','FINE');
		if($start) {
			$this->builder->where('created_at>=',$start);
		}
		if($end) {
			$this->builder->where('created_at<=',$end);
		} 
		$result=$this->builder->get();
		$row=$result->getRowArray();
		return($row['num']);
	}
	

}

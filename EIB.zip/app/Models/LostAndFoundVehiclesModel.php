<?php 

namespace App\Models;

use CodeIgniter\Model;

class LostAndFoundVehiclesModel extends CrudModel
{
	protected $builder;
	protected $table = 'lost_and_found_vehicles';
	
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['lost_and_found_id', 'number_plate', 'chassis_number', 'engine_number', 'make', 'model', 'color'];


	function __construct()
	{
		parent::__construct();
		$this->builder = $this->db->table($this->table);
	}

	public function getAll($orderBy=null)
	{
		$this->builder->select('lost_and_found.*, lost_and_found_vehicles.id as item_id, lost_and_found_vehicles.number_plate, lost_and_found_vehicles.chassis_number, lost_and_found_vehicles.engine_number, lost_and_found_vehicles.make, lost_and_found_vehicles.model, lost_and_found_vehicles.color');
		if($orderBy!=null) {
			$this->builder->orderBy($orderBy);
		}
		$this->builder->join('lost_and_found', 'lost_and_found.id=lost_and_found_vehicles.lost_and_found_id');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function find($id = null)
	{
		$this->builder->select('lost_and_found.*, lost_and_found_vehicles.id as item_id, lost_and_found_vehicles.number_plate, lost_and_found_vehicles.chassis_number, lost_and_found_vehicles.engine_number, lost_and_found_vehicles.make, lost_and_found_vehicles.model, lost_and_found_vehicles.color');
		$this->builder->where('lost_and_found.id', $id);
		$this->builder->join('lost_and_found', 'lost_and_found.id=lost_and_found_vehicles.lost_and_found_id');
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function insert($data = null, bool $returnID = true) {
		//Separate the data for the lost and found item and for the vehicle and then unset the fields that don't belong
		$lost_and_found_data=$data;
		$vehicle_data=$data;
		unset($lost_and_found_data['engine_number']);
		unset($lost_and_found_data['chassis_number']);
		unset($lost_and_found_data['make']);
		unset($lost_and_found_data['model']);
		unset($lost_and_found_data['color']);
		unset($lost_and_found_data['number_plate']);
		unset($lost_and_found_data['id']);
		unset($lost_and_found_data['item_id']);
		unset($vehicle_data['owner_name']);
		unset($vehicle_data['owner_phone']);
		unset($vehicle_data['lost_date']);
		unset($vehicle_data['lost_location']);
		unset($vehicle_data['status']);
		unset($vehicle_data['find_date']);
		unset($vehicle_data['find_details']);
		unset($vehicle_data['details']);
		unset($vehicle_data['id']);
		unset($vehicle_data['item_id']);
		$lnf_builder=$this->db->table('lost_and_found');
		$lnf_builder->insert($lost_and_found_data);
		$id=$this->db->insertID();
		$vehicle_data['lost_and_found_id']=$id;
		$this->builder->insert($vehicle_data);
		return($id);
	}
	
	public function update($id=null, $data=null): bool {
		//Separate the data for the lost and found item and for the vehicle and then unset the fields that don't belong
		$lost_and_found_data=$data;
		$vehicle_data=$data;
		unset($lost_and_found_data['engine_number']);
		unset($lost_and_found_data['chassis_number']);
		unset($lost_and_found_data['make']);
		unset($lost_and_found_data['model']);
		unset($lost_and_found_data['color']);
		unset($lost_and_found_data['number_plate']);
		unset($lost_and_found_data['id']);
		unset($lost_and_found_data['item_id']);
		$vehicle_id=$vehicle_data['item_id'];
		unset($vehicle_data['owner_name']);
		unset($vehicle_data['owner_phone']);
		unset($vehicle_data['lost_date']);
		unset($vehicle_data['lost_location']);
		unset($vehicle_data['status']);
		unset($vehicle_data['find_date']);
		unset($vehicle_data['find_details']);
		unset($vehicle_data['details']);
		unset($vehicle_data['id']);
		unset($vehicle_data['item_id']);
		var_dump($lost_and_found_data);
		var_dump($vehicle_data);
		$lnf_builder=$this->db->table('lost_and_found');
		$lnf_builder->where('id', $id);
		$lnf_builder->update($lost_and_found_data);
		$vehicle_data['lost_and_found_id']=$id;
		$this->builder->where('id', $vehicle_id);
		$this->builder->update($vehicle_data);
		return(true);
	}


}

<?php 

namespace App\Models;

use CodeIgniter\Model;

class EcModel extends Model
{
	protected $table = 'voters';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['first_name', 'last_name', 'date_of_birth', 'nin', 'cabis_id', 'phone', 'email', 'uploaded', 'polling_station_id', 'voted'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Return new or all records
	public function getNew($polling_station_id, $new=true)
	{
		$this->builder->where('polling_station_id', $polling_station_id);
		if($new) {
			$this->builder->where('uploaded', 0);
		}	
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Find subject by NIN
	public function getByNin($id)
	{	
		$this->builder->where('nin', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	//Find subject by CABIS ID
	public function getByCabisId($id)
	{	
		$this->builder->where('cabis_id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	//Perform a wildcard search for records
	public function search($params)
	{	
		$this->builder->select('*');
		if(isset($params['cabis_id']) && !empty($params['cabis_id'])) {
			$this->builder->where('cabis_id', $params['cabis_id']);
		}

		if(isset($params['polling_station_id']) && $params['polling_station_id']>0) {
			$this->builder->where('polling_station_id', $params['polling_station_id']);
		}
		if(isset($params['nin']) && !empty($params['nin'])) {
			$this->builder->like('nin', $params['nin']);
		}
		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('first_name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['lat_name'])) {
			$this->builder->like('last_name', $params['last_name']);
		}

		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Get voters by polling station
	public function getVoters($polling_station_id, $voted=null)
	{	
		$this->builder->where('polling_station_id', $polling_station_id);
		if($voted!=null) {
			$this->builder->where('voted', $voted);
		}
		$result=$this->builder->get();
		return(count($result->getResultArray()));
	}
	
	
	public function getMaleVoters()
	{	
		$this->builder->where('gender', 'M');
		$result=$this->builder->get();
		return(count($result->getResultArray()));
	}
	
	public function getFemaleVoters()
	{	
		$this->builder->where('gender', 'F');
		$result=$this->builder->get();
		return(count($result->getResultArray()));
	}
	
	public function reset()
	{
		$builder = $this->db->table('ballots');
		$builder->where('id >', 0);
		$builder->update(['status' => 'UNUSED']);
		$builder = $this->db->table('voters');
		$builder->where('id >', 0);
		$builder->update(['voted' => 0]);
		
	}
	
	
	public function getBallot($ballot)
	{
		$builder = $this->db->table('ballots');
		$result=$builder->where('ballot', $ballot)->get();
		return $result->getRowArray();
	}
	
	public function updateBallot($ballot, $status): void
	{
		$builder = $this->db->table('ballots');
		$builder->where('ballot', $ballot);
		$builder->update(['status' => $status]);
	}
	
	public function clearBallot(): void
	{
		$builder = $this->db->table('ballots');
		$builder->where('id >', 0);
		$builder->update(['status' => 'UNUSED']);
	}
	

}

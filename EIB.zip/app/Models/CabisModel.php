<?php 

namespace App\Models;

use CodeIgniter\Model;

class CabisModel extends Model
{
	protected $table = 'cabis';
	protected $db;
	protected $builder;
	protected $cache;

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Creates a record and returns it with the database generated fields added
	public function createRecord($data)
	{
		//First find out if this record exists, so that we can mark this as a copy
		$this->builder = $this->db->table('formx');
		$original=$this->findRecord($data);
		if($original) {
			$data['original_id']=$original['id'];
		} else {
			$data['original_id']=NULL;
		}
		$this->builder->insert($data);
		$id=$this->db->insertID();
		$data['id']=$id;
		return($data);
	}
	
	public function findRecord($data)
	{
		$this->builder = $this->db->table('formx');
		$this->builder->where(['subject_id' => $data['subject_id'], 'nin' => $data['nin'], 'type' => $data['type']]);
		$this->builder->orderBy('id');
		$result=$this->builder->get(1);
		return($result->getRowArray());
	}
	
	public function getNew($data)
	{
		$this->builder = $this->db->table('formx');
		$this->builder->where("access_time is null and original_id is null");
		$result=$this->builder->get(1);
		return($result->getResultArray());
	}
	
	public function getAfter($date)
	{
		$this->builder = $this->db->table('formx');
		$this->builder->where("created_at>", $date);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getBetween($start_date, $end_date)
	{
		$this->builder = $this->db->table('formx');
		$this->builder->where("created_at>", $start_date);
		$this->builder->where("created_at<", $end_date);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Return records that are not accessible after 10 minutes for today
	public function delayedAccess()
	{
		$this->builder = $this->db->table('formx');
		$this->builder->where('access_time is null and original_id is null and DATE_ADD(created_at, INTERVAL 10 MINUTE)<NOW() and DATE(created_at)=DATE(NOW())');
		$result=$this->builder->get(1);
		return($result->getResultArray());
	}
	
	public function addDemographics($data)
	{
		$this->builder = $this->db->table('demographics');
		$this->builder->insert($data);
		$id=$this->db->insertID();
		return($id);
	}
	
	public function addBiometrics($data)
	{
		$this->builder = $this->db->table('biometrics');
		$this->builder->insert($data);
		$id=$this->db->insertID();
		return($id);
	}
}

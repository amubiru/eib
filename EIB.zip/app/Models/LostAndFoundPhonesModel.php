<?php 

namespace App\Models;

use CodeIgniter\Model;

class LostAndFoundPhonesModel extends CrudModel
{
	protected $builder;
	protected $table = 'lost_and_found_phones';
	
    protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['lost_and_found_id', 'imei', 'imei2', 'make', 'model', 'color'];


	function __construct()
	{
		parent::__construct();
		$this->builder = $this->db->table($this->table);
	}

	public function getAll($orderBy=null)
	{
		$this->builder->select('lost_and_found.*, lost_and_found_phones.id as item_id, imei, imei2, make, model, color');
		if($orderBy!=null) {
			$this->builder->orderBy($orderBy);
		}
		$this->builder->join('lost_and_found', 'lost_and_found.id=lost_and_found_phones.lost_and_found_id');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function find($id = null)
	{
		$this->builder->select('lost_and_found.*, lost_and_found_phones.id as item_id, imei, imei2, make, model, color');
		$this->builder->where('lost_and_found.id', $id);
		$this->builder->join('lost_and_found', 'lost_and_found.id=lost_and_found_phones.lost_and_found_id');
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function insert($data = null, bool $returnID = true) {
		//Separate the data for the lost and found item and for the phone and then unset the fields that don't belong
		$lost_and_found_data=$data;
		$item_data=$data;
		unset($lost_and_found_data['imei']);
		unset($lost_and_found_data['imei2']);
		unset($lost_and_found_data['make']);
		unset($lost_and_found_data['model']);
		unset($lost_and_found_data['color']);
		unset($lost_and_found_data['id']);
		unset($lost_and_found_data['item_id']);
		unset($item_data['owner_name']);
		unset($item_data['owner_phone']);
		unset($item_data['lost_date']);
		unset($item_data['lost_location']);
		unset($item_data['status']);
		unset($item_data['find_date']);
		unset($item_data['find_details']);
		unset($item_data['details']);
		unset($item_data['id']);
		unset($item_data['item_id']);
		$lnf_builder=$this->db->table('lost_and_found');
		$lnf_builder->insert($lost_and_found_data);
		$id=$this->db->insertID();
		$item_data['lost_and_found_id']=$id;
		$this->builder->insert($item_data);
		return($id);
	}
	
	public function update($id=null, $data=null): bool {
		//Separate the data for the lost and found record and for the item and then unset the fields that don't belong
		$lost_and_found_data=$data;
		$item_data=$data;
		unset($lost_and_found_data['imei']);
		unset($lost_and_found_data['imei2']);
		unset($lost_and_found_data['make']);
		unset($lost_and_found_data['model']);
		unset($lost_and_found_data['color']);
		unset($lost_and_found_data['id']);
		unset($lost_and_found_data['item_id']);
		unset($item_data['owner_name']);
		unset($item_data['owner_phone']);
		unset($item_data['lost_date']);
		unset($item_data['lost_location']);
		unset($item_data['status']);
		unset($item_data['find_date']);
		unset($item_data['find_details']);
		unset($item_data['details']);
		unset($item_data['id']);
		unset($item_data['item_id']);
		$lnf_builder=$this->db->table('lost_and_found');
		$lnf_builder->where('id', $id);
		$lnf_builder->update($lost_and_found_data);
		$item_data['lost_and_found_id']=$id;
		$this->builder->where('lost_and_found_id', $id);
		$this->builder->update($item_data);
		return(true);
	}


}

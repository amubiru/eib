<?php 

namespace App\Models;

use CodeIgniter\Model;

class CameraBroadcastModel extends Model
{
	protected $table = 'camera_broadcasts';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['cabis_id', 'oosto_id', 'collate_id', 'name', 'camera', 'camera_id', 'frame_timestamp', 'latitude', 'longitude', 'captured_image', 'captured_video', 'subject_image'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Get new records and mark that this device has seen them
	public function getNew($device_id)
	{	
		$this->builder->where('deleted=0');
		$result=$this->builder->get();
		$rows=$result->getResultArray();
		$broadcasts=[];
		foreach($rows as $row) {
			$builder=$this->db->table('camera_broadcast_recipients');
			$builder->where('broadcast_id', $row['id']);
			$builder->where('device_id', $device_id);
			$result=$builder->get();
			$viewed_rows=$result->getResultArray();
			if(!count($viewed_rows)) {
				$broadcasts[]=$row;
				$builder=$this->db->table('camera_broadcast_recipients');
				$builder->insert(['broadcast_id' => $row['id'], 'device_id' => $device_id]);
			}
		}
		return($broadcasts);
	}

	//Temporary function as I debug
	public function getNewTemp($device_id)
	{	
		$this->builder->orderBy('id', 'DESC');
		$this->builder->limit(2);
		$result=$this->builder->get();
		$rows=$result->getResultArray();
		$broadcasts=[];
		foreach($rows as $row) {
			$broadcasts[]=$row;
		}
		log_message('debug', "Broadcasts ".print_r($broadcasts, true));
		return($broadcasts);
	}
	
	public function remove($cabis_id) 
	{
		$this->builder->where('cabis_id', $cabis_id);
		$this->builder->update(['deleted' => 1]);
	}
	
	public function getByNin($id)
	{	
		$this->builder->where('nin', $id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}

}

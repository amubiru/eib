<?php 

namespace App\Models;

use CodeIgniter\Model;

class UnverifiedModel extends Model
{
	protected $table = 'unverified_persons';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['first_name', 'last_name', 'id_number', 'id_type', 'remarks', 'dob', 'photo', 'oosto_id', 'linked_id', 'link_type', 'verified_id', 'red_list', 'red_list_date', 'red_list_reason'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Perform a wildcard search for records
	public function search($params)
	{	
		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('first_name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['last_name'])) {
			$this->builder->like('last_name', $params['last_name']);
		}
		if(isset($params['id_number']) && !empty($params['id_number'])) {
			$this->builder->like('id_number', $params['id_number']);
		}
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('created_at >=', $params['start_date']);
		}
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('created_at <=', $params['end_date']);
		}
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//For linked records, find the first link
	public function getFirstLink($id)
	{
		while($person=$this->find($id)) {
			if(!$person['linked_id']) { //Not linked, so it's the first, return it
				return($person['id']);
			} else {
				$id=$person['linked_id'];
			}
		} 
	}
	
	public function getRelated($id) 
	{
		$first_link=$this->getFirstLink($id);
		$this->builder->where('id', $first_link);
		$this->builder->orWhere('linked_id', $first_link);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByOostoId($id)
	{	
		$this->builder->where('oosto_id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
		

}

<?php 

namespace App\Models;

use CodeIgniter\Model;

class ExternalDataModel extends Model
{
	protected $table = 'external_data';
	protected $db;
	protected $builder;
	protected $cache;
	
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['external_id', 'data_source', 'data', 'data_json', 'large_data_json'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	public function insert($data = null, bool $returnID = true)
	{
		//Don't save null data
		if(!$data['data']) {
			return;
		}
		return parent::insert($data);
	}

	public function getByExternalId($data_source, $id)
	{
		$this->builder->where('external_id', $id);
		if(strlen($data_source)) {
			$this->builder->where('data_source', $data_source);
		}
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	//Returns the actual data
	public function getDataByExternalId($data_source, $id)
	{
		$result=$this->getByExternalId($data_source, $id);
		if($result) {
			log_message('debug', 'Got data from database');
			return(array_merge(json_decode($result['data_json'] ?? '', true) ?? [],json_decode($result['large_data_json'] ?? '', true) ?? []));
		} else {
			return(false);
		}
	}
	
	public function getMultiple($data_source, $id=null)
	{
		if($id!=null) {
			$this->builder->where('external_id', $id);
		}
		$this->builder->where('data_source', $data_source);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getCabisIds()
	{
		$this->builder->select('id');
		$this->builder->where('data_source', 'cabis');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getIds()
	{
		$this->builder->select('id');
		$this->builder->where('data_source', 'nira');
		$this->builder->orWhere('data_source', 'license');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function deleteByExternalId($data_source, $id)
	{
		if(empty($data_source) || empty($id)) {
			return;
		}
		$this->builder->where('external_id', $id);
		$this->builder->where('data_source', $data_source);
		$this->builder->delete();
	}
}

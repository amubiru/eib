<?php 

namespace App\Models;

use CodeIgniter\Model;

class OAGModel extends Model
{
	protected $table = 'police_oag_list';
	protected $db;
	protected $builder;
	protected $cache;

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}


	
	public function findByNin($nin)
	{
		$this->builder->where('nin', $nin);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function findByEmployeeNumber($employee_number)
	{
		$this->builder->where('employee_number', $employee_number);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
}

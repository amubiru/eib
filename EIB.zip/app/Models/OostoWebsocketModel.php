<?php 

namespace App\Models;

use CodeIgniter\Model;

class OostoWebsocketModel extends Model
{
	protected $table = 'oosto_websocket_messages';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['type', 'processed', 'content'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Get new records and mark that this device has seen them
	public function getNew($type)
	{	
		$this->builder->where('processed=0');
		$this->builder->where('type', $type);
		$result=$this->builder->get();
		$rows=$result->getResultArray();
		$this->builder->where('processed=0');
		$this->builder->where('type', $type);
		$this->builder->update(['processed' => 1]);
		return($rows);
	}

}

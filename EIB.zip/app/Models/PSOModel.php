<?php 

namespace App\Models;

use CodeIgniter\Model;

class PSOModel extends SubjectModel
{
	protected $table = 'cogc';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['first_name', 'last_name', 'phone', 'email', 'id_type', 'id_number','issued_by','prn', 'picture','subject_record_id','uuid'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	public function getByUuid($uuid)
	{	
		$this->builder->where('uuid', $uuid);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function getBySubjectId($id)
	{	
		return([]); //TODO remove when data is added
		/*
		$this->builder->select("cogc.*");
		$this->builder->join('subject_records', 'subject_records.id=cogc.subject_record_id');
		$this->builder->where('subject_id', $id);
		$result=$this->builder->get();
		return($result->getRowArray()); */
	}

	//Perform a wildcard search for records
	public function search($params)
	{	
		$this->builder->select('subjects.cabis_id, cogc.id as id, cogc.*, subject_records.subject_id, subject_records.station');
		$this->builder->join('subject_records', 'cogc.subject_record_id = subject_records.id');
		$this->builder->join('subjects', 'subjects.id = subject_records.subject_id');
		if(isset($params['subject_id']) && !empty($params['subject_id'])) {
			$this->builder->like('cabis_id', $params['subject_id']);
		}
		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('cogc.first_name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['last_name'])) {
			$this->builder->like('cogc.last_name', $params['last_name']);
		}
		if(isset($params['station']) && !empty($params['station'])) {
			$this->builder->like('station', $params['station']);
		}
		if(isset($params['id_number']) && !empty($params['id_number'])) {
			$this->builder->like('id_number', $params['id_number']);
		}
		if(isset($params['prn']) && !empty($params['prn'])) {
			$this->builder->like('prn', $params['prn']);
		}
		
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('cogc.created_at >=', $params['start_date']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('cogc.created_at <=', $params['end_date']);
		}
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}
}

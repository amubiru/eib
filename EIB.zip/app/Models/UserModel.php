<?php 

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends CrudModel
{
	protected $table = 'users';
	protected $db;
	protected $builder;
	protected $cache;
	protected $allowedFields = ['name', 'username', 'password', 'salt', 'email', 'phone', 'role_id'];
    
	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

	public function insert($data = null, bool $returnID = true)
	{
		$data['salt']=rand();
		$data['password']=hash("sha512", $data['salt'].$data['password']);
		
		return parent::insert($data);
	}
	
	public function update($id=null, $data=null): bool 
	{
		if($data['password']) {
			$data['salt']=rand();
			$data['password']=hash("sha512", $data['salt'].$data['password']);
		} else {
			unset($data['password']);
		}
		return parent::update($id, $data);
	}
	
	public function getRoles()
	{
		$builder = $this->db->table('roles');
		$result=$builder->get();
		return($result->getResultArray());
	}
	
	public function getRole($role_id)
	{
		$builder = $this->db->table('roles');
		$builder->where('id', $role_id);
		$result=$builder->get();
		return($result->getRowArray());
	}
	
	
	public function getPermissions($user_id)
	{
		$builder = $this->db->table('permissions');
		$builder->select('permissions.*');
		$builder->join('role_permissions', 'role_permissions.permission_id=permissions.id');
		$builder->join('roles', 'role_permissions.role_id=roles.id');
		$builder->join('users', 'roles.id=users.role_id');
		$builder->where('users.id', $user_id);
		$result=$builder->get();
		$permissions=[];
		$rows=$result->getResultArray();
		foreach($rows as $row) {
			$permissions[]=$row['name'];
		}
		return($permissions);
	}
	
	public function getDutyStations()
	{
		$builder = $this->db->table('duty_stations');
		$result=$builder->get();
		return($result->getResultArray());
	}
		
	
	public function getById($id)
	{	
		$this->builder->where('id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}

	public function getByUsername($username)
	{	
		$this->builder->where('username', $username);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function getByEmail($email)
	{
		return $this->builder->where('email', $email)->get()->getRowArray();
	}

	//Returns a user by their token.
	public function getByToken($token)
	{	
		if(!$token) {
			return false;
		}
		if(strstr($token, "Bearer ")) {
			$token = substr($token, 7);
		}
		$userData=$this->cache->get('TOKEN_'.$token);
		if($userData) {
			return($this->getById($userData['id']));
		} else {
			return false;
		}
	}

	//Method to check that this client is active
	function isActive() {
		return(true);
	}
				
	function login($username, $pwd)
	{
		$this->builder->where('username',$username);
		$result = $this->builder->get();
		$row=$result->getRowArray();
		if(!$row) {
			return(false);
		}
		
		$salt=$row['salt'];
		$password=hash("sha512", $salt.$pwd);

		if($password==$row['password']) {
			return($row['id']);
		} else {
			return(false);
		}
	}
	
	public function setPassword($user_id, $password)
	{
		$salt=rand();
		$password=hash("sha512", $salt.$password);

		$data = array(
				'salt' => $salt,
				'password' => $password
			);
		$this->builder->where('id', $user_id);
		$this->builder->update($data);
	}
		
}

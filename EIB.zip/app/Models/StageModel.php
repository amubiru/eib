<?php 

namespace App\Models;

use CodeIgniter\Model;

class StageModel extends Model
{
	protected $table = 'stages';
	protected $db;
	protected $builder;
	protected $cache;

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

	//Creates a record, return the original ID if it exists already
	public function createDivision($data)
	{
		//First find out if this record exists already
		$original=$this->findDvisionbyName($data['name']);
		if($original) {
			return $original['id'];
		} else {
			$builder=$this->db->table('divisions');
			$builder->insert($data);
			$id=$this->db->insertID();
			return($id);
		}
		return($response);
	}
	
	public function findDivisionByName($name)
	{
		$builder=$this->db->table('divisions');
		$builder->where('name', $name);
		$result=$builder->get();
		return($result->getRowArray());
	}
	
	public function findDivisionById($name)
	{
		$builder=$this->db->table('divisions');
		$builder->where('id', $id);
		$result=$builder->get();
		return($result->getRowArray());
	}
	
	public function findParishByName($division_id, $name)
	{
		$builder=$this->db->table('divisions');
		$builder->where('name', $name);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	//Creates a record, return the original ID if it exists already
	public function createStage($data)
	{
		//First find out if this record exists already
		$original=$this->findStageByName($data['name']);
		if($original) {
			return $original['id'];
		} else {
			$this->builder->insert($data);
			$id=$this->db->insertID();
			return($id);
		}
	}
	
	public function findStageByName($name)
	{
		$this->builder->where('name', $name);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	
	public function getStages()
	{
		$this->builder->select('name');
		$this->builder->orderBy('name');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	
}

<?php 

namespace App\Models;

use CodeIgniter\Model;

class CrudModel extends Model
{
	protected $db;
	protected $cache;

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->cache = \Config\Services::cache();
	}

	public function create($data)
	{
		$this->builder->insert($data);
		$id=$this->db->insertID();
		return($id);
	}
	
	public function getById($id)
	{	
		$this->builder->where('id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}

	public function getByField($fieldName, $fieldValue)
	{	
		$this->builder->where($fieldName, $fieldValue);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	

	public function getAll($orderBy=null)
	{
		if($orderBy!=null) {
			$this->builder->orderBy($orderBy);
		}
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getFieldOptions($fieldName) {
                $options=[];
                if(in_array($fieldName, ['station'])) {
                        $builder = $this->db->table('stations');
                        $builder->orderBy('name');
                        $result=$builder->get();
                        $data=$result->getResultArray();
                        foreach($data as $row) {
                                        $options[str_replace("'","", $row['name'])] = str_replace("'","",$row['name'].' - '.$row['description']);
                        }
                        return $options;
                }
                
                if(in_array($fieldName, ['offence'])) {
                        $builder = $this->db->table('offences');
                        $builder->orderBy('name');
                        $result=$builder->get();
                        $data=$result->getResultArray();
                        foreach($data as $row) {
                                        $options[$row['name']] = $row['name'];
                        }
                        return $options;
                }
                
                if(in_array($fieldName, ['role_id'])) {
                        $builder = $this->db->table('roles');
                        $builder->orderBy('name');
                        $result=$builder->get();
                        $data=$result->getResultArray();
                        foreach($data as $row) {
                                        $options[$row['id']] = $row['name'];
                        }
                        return $options;
                }
                
                if(in_array($fieldName, ['station_id'])) {
                        $builder = $this->db->table('stations');
                        $builder->orderBy('name');
                        $result=$builder->get();
                        $data=$result->getResultArray();
                        foreach($data as $row) {
                                        $options[$row['id']] = $row['name'];
                        }
                        return $options;
                }
                return [];
        }

}

<?php 

namespace App\Models;

use CodeIgniter\Model;

class PoliceOfficerModel extends SubjectModel
{
	protected $table = 'police_officers';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['first_name', 'last_name', 'subject_id', 'nin', 'employee_number', 'liveness_verification'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	public function getBySubjectId($subject_id)
	{	
		$this->builder->where('subject_id', $subject_id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	

	//Perform a wildcard search for records
	public function search($params)
	{	
		$this->builder->select('subjects.cabis_id, police_officers.id as id, police_officers.*');
		$this->builder->join('subjects', 'subjects.id = police_officers.subject_id');
		if(isset($params['subject_id']) && !empty($params['subject_id'])) {
			$this->builder->like('cabis_id', $params['subject_id']);
		}
		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('police_officers.first_name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['last_name'])) {
			$this->builder->like('police_officers.last_name', $params['last_name']);
		}
		if(isset($params['nin']) && !empty($params['nin'])) {
			$this->builder->like('nin', $params['nin']);
		}
		if(isset($params['employee_number']) && !empty($params['employee_number'])) {
			$this->builder->like('employee_number', $params['employee_number']);
		}
	
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('police_officers.created_at >=', $params['start_date']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('police_officers.created_at <=', $params['end_date']);
		}
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}
}

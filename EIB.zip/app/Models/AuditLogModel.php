<?php 

namespace App\Models;

use CodeIgniter\Model;

class AuditLogModel extends Model
{
	protected $table = 'audit_log';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['user_id', 'data_id', 'section', 'action', 'data_before', 'data_after'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

}

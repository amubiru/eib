<?php 

namespace App\Models;

use CodeIgniter\Model;

class SubjectRecordModel extends SubjectModel
{
	protected $table = 'subject_records';
	protected $db;
	protected $builder;
	protected $cache;
	
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['name', 'subject_id', 'date_received', 'date_sentence', 'case_result', 'offence', 'remarks', 'name', 'crb_no', 'station', 'date_arrest', 'sentence_type', 'non_custodial_sentence', 'court_place_trial', 'sentence_units', 'sentence_amount', 'father', 'aliases','court_case_number', 'officer_in_charge', 'case_tracking_id'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

	public function create($data)
	{
		$this->builder->insert($data);
		$id=$this->db->insertID();
		return($id);
	}
	
	public function getById($id)
	{	
		$this->builder->where('id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}

	public function getBySubjectId($subject_id, $type=null)
	{	
		$this->builder->where('subject_id', $subject_id);
		if($type=='PERMANENT') {
			$this->builder->where('case_result="SENTENCED"');
		}
		if($type=='TEMPORARY') {
			 $this->builder->where('case_result is null or case_result!="SENTENCED"');
		}
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByCabisId($cabis_id, $type=null)
	{	
		$this->builder->where('cabis_id', $cabis_id);
		$this->builder->join('subjects', 'subjects.id=subject_records.subject_id');
		if($type=='PERMANENT') {
			$this->builder->where('case_result="SENTENCED"');
		}
		if($type=='TEMPORARY') {
			 $this->builder->where('case_result is null or case_result!="SENTENCED"');
		}
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByCabisIds($cabis_ids, $type=null)
	{
		$this->builder->select('cabis_id, subject_records.*');	
		$this->builder->whereIn('cabis_id', $cabis_ids);
		$this->builder->join('subjects', 'subjects.id=subject_records.subject_id');
		if($type=='PERMANENT') {
			$this->builder->where('case_result="SENTENCED"');
		}
		if($type=='TEMPORARY') {
			 $this->builder->where('case_result is null or case_result!="SENTENCED"');
		}
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	
	public function getTemporary()
	{
		$this->builder->where('case_result', 'NOT SENTENCED YET');
		$this->builder->orWhere('case_result is null');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getPermanent()
	{
		$this->builder->where('case_result', 'SENTENCED');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Return if a similar record has been entered within one minute
	public function isDuplicate($subject_id, $offense) {
		$this->builder->select('created_at');
		$this->builder->where('offence', $offense);
		$this->builder->where('subject_id', $subject_id);
		$this->builder->orderBy('created_at', 'DESC');
		$result=$this->builder->get();
		$row=$result->getRowArray();
		if($row) {
			if(time()-strtotime($row['created_at'])<60) {
				return(true);
			}
		}
		return(false);
	}
	
	//Perform a wildcard search for records
	public function search($params)
	{	
		$this->builder->select('subjects.cabis_id, subjects.name as subject_name, subject_records.*');
		$this->builder->join('subjects', 'subjects.id = subject_records.subject_id');
		if(isset($params['subject_id']) && !empty($params['subject_id'])) {
			$this->builder->like('cabis_id', $params['subject_id']);
		}
		if($params['type']=='PERMANENT') {
			$this->builder->where('case_result="SENTENCED"');
		}
		if($params['type']=='TEMPORARY') {
			 $this->builder->where('case_result is null or case_result!="SENTENCED"');
		}
		if(isset($params['name']) && !empty($params['name'])) {
			$this->builder->groupStart();
			$this->builder->like('subject_records.name', $params['name']);
			$this->builder->orLike('subjects.name', $params['name']);
			$this->builder->groupEnd();
		}
		if(isset($params['station']) && !empty($params['station'])) {
			$this->builder->like('station', $params['station']);
		}
		if(isset($params['crb_no']) && !empty($params['crb_no'])) {
			$this->builder->like('crb_no', $params['crb_no']);
		}
		
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('date_sentence >=', $params['start_date']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('date_sentence <=', $params['end_date']);
		}

		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	
	//Retreive additional files/images associated with a criminal record
	public function getAdditionalFiles($id)
	{
		$builder = $this->db->table('subject_record_files');
		$builder->where('record_id', $id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Finds out top 10 offences and their count
	public function getTop10OffencesCount($start=null, $end=null)
	{
		$this->builder->select("offence, count(*) as num");
		$this->builder->orderBy("num", "DESC");
		if($start) {
			$this->builder->where('date_sentence>=',$start);
		}
		if($end) {
			$this->builder->where('date_sentence<=',$end);
		} 
		$this->builder->groupBy("offence");
		$this->builder->limit(10);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Finds out the counts for offences
	public function getOffencesCount($offences, $start=null, $end=null)
	{
		$this->builder->select("offence, count(*) as num");
		$this->builder->whereIn("offence", $offences);
		$this->builder->orderBy("num", "DESC");
		if($start) {
			$this->builder->where('date_sentence>=',$start);
		}
		if($end) {
			$this->builder->where('date_sentence<=',$end);
		} 
		$this->builder->groupBy("offence");
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Finds out the counts for one offence in a period
	public function getOffenceCount($offence, $start=null, $end=null)
	{
		$this->builder->select("count(*) as num");
		$this->builder->where("offence", $offence);
		if($start) {
			$this->builder->where('date_sentence>=',$start);
		}
		if($end) {
			$this->builder->where('date_sentence<=',$end);
		} 
		$result=$this->builder->get();
		$row=$result->getRowArray();
		return($row['num']);
	}
}

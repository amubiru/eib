<?php 

namespace App\Models;

use CodeIgniter\Model;

class CacheModel extends Model
{
	protected $cache;

	function __construct()
	{
		parent::__construct();
		$this->cache = \Config\Services::cache();
	}

    
    function delete($name)
    {
        $this->cache->delete($name);
    }

    function get($name)
    {
        $value=$this->cache->get($name);
        return($value);
    }

    //Save item to cache
    function put($name, $value, $cache_time=YEAR)
    {
        $this->cache->save($name, $value, $cache_time);
    }
    	

}

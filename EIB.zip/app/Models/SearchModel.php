<?php 

namespace App\Models;

use CodeIgniter\Model;

class SearchModel extends Model
{
	protected $table = 'subjects';
	protected $db;
	protected $builder;
	protected $cache;
	protected $fields;

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

	public function search($search_terms)
	{
		$start_time=time();
		$terms=explode(" ", $search_terms);
		$response=[];
		//log_message('debug', 'Search query terms: '.$search_terms);
		$response['criminal']=$this->criminal_search($terms);
		//log_message('debug', 'Search query criminal: '.(time()-$start_time));
		$response['civilian']=$this->civilian_search($terms);
		//log_message('debug', 'Search query civilian: '.(time()-$start_time));
		$response['traffic']=$this->traffic_search($terms);
		//log_message('debug', 'Search query traffic: '.(time()-$start_time));
		$response['case_tracking']=$this->external_data_search($terms, 'case_tracking');
		//log_message('debug', 'Search query case: '.(time()-$start_time));
		$response['case_tracking_person']=$this->external_data_search($terms, 'case_tracking_person');
		//log_message('debug', 'Search query case person: '.(time()-$start_time));
		$response['nira']=$this->external_data_search($terms, 'nira');
		//log_message('debug', 'Search query nira: '.(time()-$start_time));
		$response['vehicle']=$this->external_data_search($terms, 'vehicle');
		//log_message('debug', 'Search query vehicle: '.(time()-$start_time));
		$response['license']=$this->external_data_search($terms, 'license');
		//log_message('debug', 'Search query license: '.(time()-$start_time));
		//log_message('debug', print_r($response, true));
		return($response);
	}
	
	public function criminal_search($terms) {
		$builder=$this->db->table('subject_records');
		$builder->select('subject_records.id as id, subjects.id as subject_id, cabis_id, case_tracking_id, case_tracking_person_id, subjects.first_name as first_name, subjects.last_name as last_name, offence as offense, station, sentence_type, subject_records.created_at as date');
		$builder->join('subjects', 'subjects.id=subject_records.subject_id');
		foreach($terms as $term) {
			//if(strlen($term)<3) { continue; } //Only use search terms over 3 characters
			$builder->orLike('subjects.first_name', $term);
			$builder->orLike('subjects.last_name', $term);
			$builder->orLike('subject_records.name', $term);
			$builder->orWhere('subjects.cabis_id', $term);
		}
		$result=$builder->get();
		return($result->getResultArray());
	}
	
	public function civilian_search($terms) {
		$builder=$this->db->table('cogc');
		$builder->select('cogc.id as id, subjects.id as subject_id, cabis_id,  cogc.first_name as first_name, cogc.last_name as last_name, id_number, prn, cogc.created_at as date');
		$builder->join('subjects', 'subjects.id=cogc.subject_id');
		foreach($terms as $term) {
			//if(strlen($term)<3) { continue; } //Only use search terms over 3 characters
			$builder->orLike('cogc.first_name', $term);
			$builder->orLike('cogc.last_name', $term);
			$builder->orLike('cogc.id_number', $term);
			$builder->orLike('cogc.prn', $term);
			$builder->orLike('cogc.raw_content', $term);
			$builder->orWhere('subjects.cabis_id', $term);
		}
		$result=$builder->get();
		return($result->getResultArray());
	}
	
	public function cabis_criminal_search($cabis_id) {
		$builder=$this->db->table('subject_records');
		$builder->select('subject_records.id as id, subjects.id as subject_id, cabis_id, case_tracking_id, case_tracking_person_id, subjects.first_name as first_name, subjects.last_name as last_name, offence as offense, station, sentence_type, subject_records.created_at as date');
		$builder->join('subjects', 'subjects.id=subject_records.subject_id');
		$builder->where('subjects.cabis_id', $cabis_id);
		$result=$builder->get();
		return($result->getResultArray());
	}
	
	public function traffic_search($terms) {
		$builder=$this->db->table('traffic_offenses');
		foreach($terms as $term) {
			//if(strlen($term)<3) { continue; } //Only use search terms over 3 characters
			$builder->orLike('first_name', $term);
			$builder->orLike('last_name', $term);
			$builder->orLike('id_number', $term);
			$builder->orLike('number_plate', $term);
			$builder->orLike('nin', $term);
			$builder->orLike('offense', $term);
			$builder->orLike('location', $term);
		}
		$result=$builder->get();
		return($result->getResultArray());
	}
	
	public function external_data_search($terms, $data_source)
	{
		$builder=$this->db->table('external_data');
		$builder->select('id, data_json');
		$builder->where('data_source', $data_source);
		$builder->groupStart();
		foreach($terms as $term) {
			$builder->orLike('data', $term);
		}
		$builder->groupEnd();
		$result=$builder->get();
		$rows=$result->getResultArray();
		$return=[];
		foreach($rows as $row) {
			$data=json_decode($row['data_json'], true);
			$data['row_id']=$row['id'];
			$return[]=$data;
		}
		return($return);
	}
	
		
}

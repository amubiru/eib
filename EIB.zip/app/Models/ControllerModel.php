<?php 

namespace App\Models;

use CodeIgniter\Model;

class ControllerModel extends CrudModel
{
	protected $table = 'controllers';
	protected $builder;

	function __construct()
	{
		parent::__construct();
		$this->builder = $this->db->table($this->table);
	}


	public function getByControllerName($name)
	{	
		return $this->getByField('name', $name);
	}
	
	public function getFields($controller_id)
	{
		$builder = $this->db->table('fields');
		$builder->where('controller_id', $controller_id);
		$builder->orderBy('position');
		$result=$builder->get();
		return($result->getResultArray());
	}
	
	public function getFieldOptions($field_id)
	{
		$builder = $this->db->table('field_options');
		$builder->where('field_id', $field_id);
		$builder->orderBy('position');
		$result=$builder->get();
		$db_options=$result->getResultArray();
		$options=[];
		foreach($db_options as $option) {
			$options[$option['option_value']] = $option['option_text'];
		}
		return($options);
	}
}

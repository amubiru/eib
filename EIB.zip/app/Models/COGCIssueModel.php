<?php 

namespace App\Models;

use CodeIgniter\Model;

class COGCIssueModel extends SubjectModel
{
	protected $table = 'cogc_issues';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['cogc_id', 'related_cabis_id', 'type', 'status'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	public function getByCogcId($id)
	{	
		$this->builder->where('cogc_id', $id);
		$this->builder->where('status', 'PENDING');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function deleteByCogcId($id)
	{	
		$this->builder->where('cogc_id', $id);
		$result=$this->builder->delete();
	}
	
	public function getByCogcIdType($id, $type)
	{	
		$this->builder->where('cogc_id', $id);
		$this->builder->where('status', 'PENDING');
		$this->builder->where('type', $type);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function markResolved($id, $type)
	{
		$this->builder->where('cogc_id', $id);
		$this->builder->where('type', $type);
		$this->builder->where('status', 'PENDING');
		$this->builder->update(['status' => 'RESOLVED']);
	}
	
}

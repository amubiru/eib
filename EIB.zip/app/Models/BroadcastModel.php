<?php 

namespace App\Models;

use CodeIgniter\Model;

class BroadcastModel extends Model
{
	protected $table = 'redlist_broadcasts';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['subject_id'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Get new records and mark that this device has seen them
	public function getNew($device_id)
	{	
		$this->builder->select('redlist_broadcasts.id, subject_id');
		$this->builder->where('deleted=0');
		$result=$this->builder->get();
		$rows=$result->getResultArray();
		$ids=[];
		foreach($rows as $row) {
			$builder=$this->db->table('redlist_broadcast_recipients');
			$builder->where('broadcast_id', $row['id']);
			$builder->where('device_id', $device_id);
			$result=$builder->get();
			$rows=$result->getResultArray();
			if(!$rows) {
				$ids[]=$row['subject_id'];
				$builder=$this->db->table('redlist_broadcast_recipients');
				$builder->insert(['broadcast_id' => $row['id'], 'device_id' => $device_id]);
			}
		}
		return($ids);
	}
	
	public function remove($subject_id) 
	{
		$this->builder->where('subject_id', $subject_id);
		$this->builder->update(['deleted' => 1]);
	}

}

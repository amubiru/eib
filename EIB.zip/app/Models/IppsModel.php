<?php 

namespace App\Models;

use CodeIgniter\Model;

class IppsModel extends Model
{
	protected $table = 'ipps';
	protected $db;
	protected $builder;
	protected $cache;

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

	//Creates a record, returns an error and the original ID if it exists already
	public function create($data)
	{
		//First find out if this record exists already, check by both NIN and employee number and return any that match
		$original=$this->findByNin($data['nin']);
		$original2 = $this->findByEmployeeNumber($data['employee_number']);
		$original = $original ? $original : $original2;
		$response=[];
		if($original) {
			$response['original']=$original;
		} else {
			$this->builder->insert($data);
			$id=$this->db->insertID();
			$response['id']=$id;
		}
		return($response);
	}
	
	public function findByNin($nin)
	{
		$this->builder->where('nin', $nin);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function findByEmployeeNumber($employee_number)
	{
		$this->builder->where('employee_number', $employee_number);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
		public function getAll()
	{
		$result=$this->builder->get();
		return($result->getResultArray());
	}
}

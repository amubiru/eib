<?php 

namespace App\Models;

use CodeIgniter\Model;

class DriverModel extends Model
{
	protected $table = 'drivers';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['first_name', 'last_name', 'phone', 'nin', 'cabis_id', 'driving_license', 'stage', 'number_plate'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	//Perform a wildcard search for records
	public function search($params)
	{	
		if(isset($params['cabis_id']) && !empty($params['cabis_id'])) {
			$this->builder->like('cabis_id', $params['cabis_id']);
		}
		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('first_name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['last_name'])) {
			$this->builder->like('last_name', $params['last_name']);
		}
		if(isset($params['nin']) && !empty($params['nin'])) {
			$this->builder->like('nin', $params['nin']);
		}
		if(isset($params['number_plate']) && !empty($params['number_plate'])) {
			$this->builder->like('number_plate', $params['number_plate']);
		}
		if(isset($params['driving_license']) && !empty($params['driving_license'])) {
			$this->builder->like('driving_license', $params['driving_license']);
		}
		if(isset($params['stage']) && !empty($params['stage'])) {
			$this->builder->like('stage', $params['stage']);
		}
	
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('police_officers.created_at >=', $params['start_date']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('police_officers.created_at <=', $params['end_date']);
		}
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}

}

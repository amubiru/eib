<?php 

namespace App\Models;

use CodeIgniter\Model;

class AttachmentModel extends Model
{
	protected $table = 'attachments';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['link_id', 'subject_id', 'type', 'name', 'description', 'file_type', 'file_content'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

	//Get attachments that correspond to a specfic type of record and its ID
	public function retrieve($type, $link_id)
	{
		$this->builder->where('type', $type);
		$this->builder->where('link_id', $link_id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getBySubjectId($id)
	{
		$this->builder->where('subject_id', $id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
		
}

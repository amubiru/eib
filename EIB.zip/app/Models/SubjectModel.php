<?php 

namespace App\Models;

use CodeIgniter\Model;

class SubjectModel extends Model
{
	protected $table = 'subjects';
	protected $db;
	protected $builder;
	protected $cache;
	protected $returnType     = 'array';
    protected $useSoftDeletes = false;

    protected $allowedFields = ['name', 'cabis_id', 'oosto_id', 'case_tracking_person_id', 'red_list', 'nin', 'first_name', 'last_name', 'reason', 'red_list_date', 'broadcast', 'cabis_time'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}

	public function create($data)
	{
		$this->builder->insert($data);
		$id=$this->db->insertID();
		return($id);
	}
	
	public function createPCC($data)
	{
		$builder = $this->db->table('police_clearance_certificate');
		$builder->insert($data);
		$id=$this->db->insertID();
		return($id);
	}
	
	public function getPCCBySubjectId($id)
	{
		$builder = $this->db->table('police_clearance_certificate');	
		$builder->where('subject_id', $id);
		$builder->orderBy('created_at DESC');
		$result=$builder->get();
		return($result->getResultArray());
	}
	
	public function getLatestPCCBySubjectId($id)
	{
		$builder = $this->db->table('police_clearance_certificate');	
		$builder->where('subject_id', $id);
		$builder->orderBy('created_at DESC');
		$result=$builder->get();
		return($result->getRowArray());
	}
	
	public function getPCC($id)
	{
		$builder = $this->db->table('police_clearance_certificate');	
		$builder->where('id', $id);
		$result=$builder->get();
		return($result->getRowArray());
	}
	
	public function getById($id)
	{	
		$this->builder->where('id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}

	public function getByCabisId($id)
	{	
		$this->builder->where('cabis_id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function getByOostoId($id)
	{	
		$this->builder->where('oosto_id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	//Find all subjects with same NIN
	public function getByNin($id)
	{	
		$this->builder->where('nin', $id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByPersonId($id)
	{	
		$this->builder->where('case_tracking_person_id', $id);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	//Returns related records by cabis_id or nin, one or both of which might be empty
	public function getRelated($cabis_id, $nin)
	{
		$this->builder->select($this->table.'.*');
		$this->builder->join('subjects', $this->table.'.subject_id=subjects.id');
		if($cabis_id) {
			$this->builder->where('subjects.cabis_id', $cabis_id); 
			if(strlen($nin ?? '')==14) {
				$this->builder->orWhere('subjects.nin', $nin);
			}
		} else {
			if(strlen($nin)==14) {
				$this->builder->where('subjects.nin', $nin);
			} else {
				return([]);
			}
		}
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Perform a wildcard search for records
	public function search($params)
	{	
		$this->builder->select('*');
		if(isset($params['cabis_id']) && !empty($params['cabis_id'])) {
			$this->builder->like('cabis_id', $params['cabis_id']);
		}

		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('subjects.name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['lat_name'])) {
			$this->builder->like('subjects.name', $params['last_name']);
		}
		if(isset($params['red_list']) && !empty($params['red_list'])) {
			$this->builder->where('red_list', $params['red_list']);
		}
		if(isset($params['broadcast']) && !empty($params['broadcast'])) {
			$this->builder->where('broadcast', $params['broadcast']);
		}
		if(isset($params['station']) && !empty($params['station'])) {
			$this->builder->like('station', $params['station']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('created_at <=', $params['end_date']);
		}

		$result=$this->builder->get();
		return($result->getResultArray());
	}
		
}

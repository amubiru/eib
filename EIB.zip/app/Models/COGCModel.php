<?php 

namespace App\Models;

use CodeIgniter\Model;

class COGCModel extends SubjectModel
{
	protected $table = 'cogc';
	protected $db;
	protected $builder;
	protected $cache;
	protected $primaryKey = 'id';

    protected $useAutoIncrement = true;

    protected $returnType     = 'array';
	protected $allowedFields = ['first_name', 'middle_name', 'last_name', 'phone', 'email', 'id_type', 'id_number','issued_by','prn', 'picture','subject_id','uuid', 'raw_content', 'type', 'status', 'pcc_time', 'cogc_time', 'queue_reason', 'queue_type', 'day_counter', 'total_counter', 'adverse_police_notice', 'application_category', 'fingerprint_date'];

	function __construct()
	{
		parent::__construct();
		$this->db = \Config\Database::connect();
		$this->builder = $this->db->table($this->table);
		$this->cache = \Config\Services::cache();
	}
	
	public function getByUuid($uuid)
	{	
		$this->builder->where('uuid', $uuid);
		$result=$this->builder->get();
		return($result->getRowArray());
	}
	
	public function getUnprocessed()
	{	
		
		$this->builder->where('status', 'PENDING');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getMonthUnprocessed()
	{	
		
		$this->builder->where('status', 'PENDING');
		$this->builder->where('created_at>', date('Y-m-d', strtotime('-1 month')));
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function searchUnprocessed($params)
	{	
		$this->builder->where('status', 'PENDING');
		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('cogc.first_name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['last_name'])) {
			$this->builder->like('cogc.last_name', $params['last_name']);
		}
		if(isset($params['id_number']) && !empty($params['id_number'])) {
			$this->builder->like('id_number', $params['id_number']);
		}
		if(isset($params['prn']) && !empty($params['prn'])) {
			$this->builder->like('prn', $params['prn']);
		}
		
		if(isset($params['status']) && !empty($params['status']) && (($params['status'] ?? '') != 'ALL')) {
			$this->builder->where('status', $params['status']);
		}
		
		if(isset($params['queue_type']) && !empty($params['queue_type']) && (($params['queue_type'] ?? '') != 'ALL')) {
			$this->builder->where('queue_type', $params['queue_type']);
		}
		
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('cogc.created_at >=', $params['start_date']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('cogc.created_at <=', $params['end_date']);
		}
		if(isset($params['application_category']) && !empty($params['application_category']) && (($params['application_category'] ?? '') != 'ALL')) {
			$this->builder->where('cogc.application_category', $params['application_category']);
		}
		$result=$this->builder->get();
		return($result->getReturnArray());
	}
	
	public function getCount($category=null,$status=null,$queue_type=null)
	{	
		$this->builder->select('count(*) as num');
		if($category!=null) {
			$this->builder->where('application_category', $category);
		}
		if($status!=null) {
			$this->builder->where('status', $status);
		}
		if($queue_type!=null) {
			$this->builder->where('queue_type', $queue_type);
		}
		$result=$this->builder->get();
		$row=$result->getRowArray();
		return($row['num']);
	}
	
	public function getBySubjectId($id)
	{	
		$this->builder->where('subject_id', $id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByPRN($id)
	{	
		$this->builder->where('prn', $id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByNIN($id)
	{	
		$this->builder->where('id_number', $id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getFingerprinted()
	{	
		$this->builder->where('status', 'FINGERPRINT');
		$this->builder->orderBy('id', 'DESC');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getQueued()
	{	
		$this->builder->where('status', 'QUEUE');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getResolved()
	{	
		$this->builder->where('status', 'RESOLVED');
		$this->builder->orderBy('id', 'DESC');
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByCabisId($cabis_id)
	{	
		$this->builder->select('cogc.*');
		$this->builder->join('subjects', 'subjects.id = cogc.subject_id');
		$this->builder->where('subjects.cabis_id', $cabis_id);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	public function getByCabisArray($cabis_array)
	{
		if(empty($cabis_array)) { //Also return an empty array
			return([]);
		}	
		$this->builder->select('cogc.*');
		$this->builder->join('subjects', 'subjects.id = cogc.subject_id');
		$this->builder->whereIn('subjects.cabis_id', $cabis_array);
		$result=$this->builder->get();
		return($result->getResultArray());
	}

	//Perform a wildcard search for records
	public function search($params)
	{	
		$this->builder->select('subjects.cabis_id, cogc.id as id, cogc.*');
		$this->builder->join('subjects', 'subjects.id = cogc.subject_id');
		if((isset($params['fp_start_date']) && !empty($params['fp_start_date'])) || (isset($params['fp_end_date']) && !empty($params['fp_end_date']))) {
			$this->builder->join('formx', 'subjects.cabis_id = formx.subject_id');
		}
		if(isset($params['subject_id']) && !empty($params['subject_id'])) {
			$this->builder->like('cabis_id', $params['subject_id']);
		}
		if(isset($params['first_name']) && !empty($params['first_name'])) {
			$this->builder->like('cogc.first_name', $params['first_name']);
		}
		if(isset($params['last_name']) && !empty($params['last_name'])) {
			$this->builder->like('cogc.last_name', $params['last_name']);
		}
		if(isset($params['station']) && !empty($params['station'])) {
			//$this->builder->like('station', $params['station']);
		}
		if(isset($params['id_number']) && !empty($params['id_number'])) {
			$this->builder->like('id_number', $params['id_number']);
		}
		if(isset($params['prn']) && !empty($params['prn'])) {
			$this->builder->like('prn', $params['prn']);
		}
		
		if(isset($params['status']) && !empty($params['status']) && (($params['status'] ?? '') != 'ALL')) {
			$this->builder->where('status', $params['status']);
		}
		
		if(isset($params['queue_type']) && !empty($params['queue_type']) && (($params['queue_type'] ?? '') != 'ALL')) {
			$this->builder->where('queue_type', $params['queue_type']);
		}
		if(isset($params['application_category']) && !empty($params['application_category']) && (($params['application_category'] ?? '') != 'ALL')) {
			$this->builder->where('cogc.application_category', $params['application_category']);
		}
		if(isset($params['start_date']) && !empty($params['start_date'])) {
			$this->builder->where('cogc.created_at >=', $params['start_date']);
		}
		
		if(isset($params['end_date']) && !empty($params['end_date'])) {
			$this->builder->where('cogc.created_at <=', date('Y-m-d', strtotime("+1 day", strtotime($params['end_date']))));
		}
		if(isset($params['fp_start_date']) && !empty($params['fp_start_date'])) {
			$this->builder->where('formx.created_at >=', $params['fp_start_date']);
		}
		
		if(isset($params['fp_end_date']) && !empty($params['fp_end_date'])) {
			$this->builder->where('formx.created_at <=', date('Y-m-d', strtotime("+1 day", strtotime($params['fp_end_date']))));
		}
		if((isset($params['fp_start_date']) && !empty($params['fp_start_date'])) || (isset($params['fp_end_date']) && !empty($params['fp_end_date']))) {
			$this->builder->groupBy('cabis_id');
		}
		
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	//Increments counter for daily and total certs issues
	public function incrementCounter()
	{
		$this->db->query("LOCK TABLES certificates_counter WRITE");
		$builder = $this->db->table('certificates_counter');
		$result=$builder->get();
		$row=$result->getRowArray();
		$response=null;
		if($row['date']!=date('Y-m-d')) { //New date, change date counter
			$response=['day_counter' => 1, 'total_counter' => $row['total_counter']];
			$builder->where('id', $row['id']);
			$builder->update(['date' => date('Y-m-d'), 'day_counter' => 2, 'total_counter' => $row['total_counter']+1]);
		} else {
			$response=['day_counter' => $row['day_counter'], 'total_counter' => $row['total_counter']];
			$builder->where('id', $row['id']);
			$builder->update(['day_counter' => $row['day_counter']+1, 'total_counter' => $row['total_counter']+1]);
		}
		$this->db->query("UNLOCK TABLES");
		return($response);
	}
	
	public function getBetween($start_date, $end_date)
	{
		$this->builder->where("fingerprint_date>", $start_date);
		$this->builder->where("fingerprint_date<", $end_date);
		$result=$this->builder->get();
		return($result->getResultArray());
	}
	
	
}

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= getenv('app.Name'); ?></title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/fontawesome-free/css/all.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>dist/css/adminlte.min.css">
<link rel="shortcut icon" href="<?php echo base_url('images/police_logo.png?ver=1'); ?>" type="image/png" />

</head>
<body class="hold-transition login-page">
<div class="login-box">
			  <!-- Error and success messages  -->
		  <?php
		  if(isset($_SESSION['errorMessage']) || isset($errorMessage)) {
			  $emessage = isset($errorMessage) ? $errorMessage : $_SESSION['errorMessage'];
			  $emessageTitle = isset($errorTitle) ? $errorTitle : $_SESSION['errorTitle'];
			  ?>
			<div class="row">
			<div class="toast bg-danger fade show" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><strong class="mr-auto"><?= $emessageTitle; ?></strong><small></small><button data-dismiss="toast" type="button" class="ml-2 mb-1 close" aria-label="Close"><span aria-hidden="true">×</span></button></div><div class="toast-body"><?= $emessage; ?></div></div>
			</div>
			<?php }
			if(isset($_SESSION['message']) || isset($message)) {
			  $message = isset($message) ? $message : $_SESSION['message'];
			  $messageTitle = isset($messageTitle) ? $messageTitle : $_SESSION['messageTitle'];
			  ?>
			<div class="row">
			<div class="toast bg-success fade show" role="alert" aria-live="assertive" aria-atomic="true"><div class="toast-header"><strong class="mr-auto"><?= $messageTitle; ?></strong><small></small><button data-dismiss="toast" type="button" class="ml-2 mb-1 close" aria-label="Close"><span aria-hidden="true">×</span></button></div><div class="toast-body"><?= $message; ?></div></div>
			</div>
			<?php } ?>
  <!-- /.login-logo -->
  <div class="card card-outline card-primary">
    <div class="card-header text-center">
		<img height="100" src="<?= base_url("images/police_logo.png"); ?>"><br>
      <a href="<?php echo base_url('template/'); ?>" class="h1"><b><?= getenv('app.Name'); ?></b></a><br><p class="h5">Result</p>
    </div>
    <div class="card-body">

      <?php print "Status: ".$result['status']."<br>";
      if($result['status']=='DONE') { // Show table with results
		  print '<table id="results" class="table table-bordered">';
		  print "<tr><td>Submitted photo</td><td>".'<img src="data:image/jpeg;base64,'.$result['submitted_image'].'">'."</td></tr>";
		  print "<tr><td colspan=2>Results</td></tr>";
		  foreach($result['subjects'] as $subject) {
			  print "<tr><td>Name: {$subject['name']}<br>Score: {$subject['score']}<br></td><td>".'<img src="data:image/jpeg;base64,'.$subject['image'].'">'."</td></tr>\n";
		  }
		  print "</table>";
	  }
	  ?>

    </div>
    <!-- /.card-body -->
  </div>
  <!-- /.card -->
</div>
<!-- /.login-box -->

<!-- jQuery -->
<script src="<?php echo base_url('template/'); ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url('template/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('template/'); ?>dist/js/adminlte.min.js"></script>
<script>
  //Initialize toasts
  $('.toast').toast();
</script>
</body>
</html>

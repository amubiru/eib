

 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0"><?= $controller['description']; ?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active"><?= $controller['description']; ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			<!-- Add new record button -->
			<div class="col-lg-1">
			<a href="<?= base_url($controller['route']."/add"); ?>">
			<button type="button" class="btn btn-block btn-primary" >Add  <i class="fa fa-plus"></i></button></a>
			</div>
          <div class="col-lg-12">
			<!-- Card for form goes here
			-->
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?= $controller['description']; ?></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
					  <?php
					  foreach ($fields as $field) {
						  //Skip hidden fields
						  if($field['type']=='hidden' || $field['type']=='password') {
							  continue;
						  }
						print "<th>{$field['name']}</th>\n";  
					  }
					  print "<th>&nbsp;</th>";
					  ?>

                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  //Create a row for each record
                  foreach($data as $record) {
					  print "<tr>";
					  //Create a column for each 
					  foreach($fields as $field) {
						  //Skip hidden fields
						  if($field['type']=='hidden' || $field['type']=='password') {
							  continue;
						  }
						  if(in_array($field['type'], ['text','number'])) {
								print "<td>".$record[$field['db_name']]."</td>\n";
							}
						if($field['type']=='option') {
							if(array_key_exists($record[$field['db_name']], $field['options'])) {
								print "<td>".$field['options'][$record[$field['db_name']]]."</td>\n";
							} else {
								print "<td>&nbsp;</td>\n";
							}
						}
					  }
					  //Show edit and delete options
					  print "<td>&nbsp;";
					  //Escape the quotation marks in the JSON string so as to pass them onto Javascript
					  print "<span title='Edit'><a href=\"".base_url($controller['route']."/edit/".$record['id']).'"><i class="fa fa-pencil-alt" title="Edit" ></i></a><span>';
					  print "&nbsp;&nbsp;";
					  print "<span title='Delete'><a class='red' href='".base_url($controller['route']."/delete/".$record['id'])."' onClick=\"return confirm('Are you sure you want to delete this item');\">".'<i class="fa fa-times" title="Delete" ></i></a></span>';
					  print "</td>";
					print "</tr>\n";
				  }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <?php
					  foreach ($fields as $field) {
						  //Skip hidden fields
						  if($field['type']=='hidden' || $field['type']=='password') {
							  continue;
						  }
						  print "<th>{$field['name']}</th>\n";
					  }
					  print "<th>&nbsp;</th>";
					  ?>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col-md-12 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

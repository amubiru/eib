<!DOCTYPE html>
<html>

<head>
    <title>2FA Authorization</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url('public/assets/css/main.css'); ?>">
</head>

<body>
    <div class="container mt-5 auth-file">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h3 class="text-center">Two-Factor Authentication (2FA) Verification </h3>
                <?php if (session()->getFlashdata('errorMessage')): ?>
                    <div class="alert alert-danger">
                        <strong><?= session()->getFlashdata('errorTitle') ?></strong> <?= session()->getFlashdata('errorMessage') ?>
                    </div>
                <?php endif; ?>
                <form method="post" action="<?= base_url('login/authorizeSubmit') ?>">
                    <div class="mb-3">
                        <label for="2fa_code" class="form-label">Enter the code we sent to your registered phone/email to verify your identity</label>
                        <input type="text" id="2fa_code" name="2fa_code" class="form-control" required>
                    </div>
                    <button type="submit" class="btn submit-btn w-100">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Uganda Districts Heatmap</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <style>
        #map { height: 100vh; }
    </style>
</head>
<body>
    <div id="map"></div>
	<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet.heat/dist/leaflet-heat.js"></script>
    <script src="/eib/js/uganda.js"></script> <!-- Replace with your GeoJSON file -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
    // Initialize the map
    var map = L.map('map').setView([1.3733, 32.2903], 7); // Centered on Uganda

    // Add OpenStreetMap tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    // Function to get color based on some statistic (e.g., population density)
    function getColor(d) {
        return d > 1000 ? '#800026' :
               d > 500  ? '#BD0026' :
               d > 200  ? '#E31A1C' :
               d > 100  ? '#FC4E2A' :
               d > 50   ? '#FD8D3C' :
               d > 20   ? '#FEB24C' :
               d > 10   ? '#FED976' :
                          '#FFEDA0';
    }

    // Function to style the GeoJSON features
    function style(feature) {
        return {
            fillColor: getColor(feature.properties.ttotal2020 || 0),
            weight: 2,
            opacity: 1,
            color: 'white',
            dashArray: '3',
            fillOpacity: 0.7
        };
    }

    // Function to highlight a feature on mouseover
    function highlightFeature(e) {
        var layer = e.target;

        layer.setStyle({
            weight: 5,
            color: '#666',
            dashArray: '',
            fillOpacity: 0.7
        });

        if (!L.Browser.ie && !L.Browser.opera && !L.Browser.edge) {
            layer.bringToFront();
        }
    }

    // Function to reset the highlight on mouseout
    function resetHighlight(e) {
        geojson.resetStyle(e.target);
    }

    // Function to zoom to a feature on click
    function zoomToFeature(e) {
        map.fitBounds(e.target.getBounds());
    }

    // Function to handle feature click events
    function onEachFeature(feature, layer) {
        layer.on({
            mouseover: highlightFeature,
            mouseout: resetHighlight,
            click: function(e) {
                // Show a popup with the district name and statistics
                var popupContent = "<b>" + feature.properties.d + "</b><br/>" +
                                   "Population: " + (feature.properties.ttotal2020 || 'N/A') + " people";
                layer.bindPopup(popupContent).openPopup();
            }
        });
    }

    // Load the GeoJSON data and add it to the map
    var geojson = L.geoJson(districtsData, {
        style: style,
        onEachFeature: onEachFeature
    }).addTo(map);

    // Optionally, you can add a legend
    var legend = L.control({position: 'bottomright'});

    legend.onAdd = function (map) {
        var div = L.DomUtil.create('div', 'info legend'),
            grades = [0, 10, 20, 50, 100, 200, 500, 1000],
            labels = [];

        // loop through our density intervals and generate a label with a colored square for each interval
        for (var i = 0; i < grades.length; i++) {
            div.innerHTML +=
                '<i style="background:' + getColor(grades[i] + 1) + '">&nbsp;&nbsp;&nbsp;&nbsp;</i> ' +
                grades[i] + (grades[i + 1] ? '&ndash;' + grades[i + 1] + '<br>' : '+');
        }

        return div;
    };

    legend.addTo(map);
});
    </script>
</body>
</html>

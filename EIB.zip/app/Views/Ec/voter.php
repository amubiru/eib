
 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Voter</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Voter</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

      
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			<!-- Edit record button -
			<div class="col-lg-1">
			<a href=<?= base_url("frontend/subject_records/civilian/edit/".$record['id']); ?>><button type="button" class="btn btn-block btn-primary" onClick="clearModal();">Edit  <i class="fa fa-plus"></i></button></a>
			</div> -->
          <div class="col-lg-12">
			  <div class="row">
			<div class="col-lg-8">
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#summary" data-toggle="tab">Summary</a></li>
                  <li class="nav-item"><a class="nav-link" href="#nira" data-toggle="tab">NIRA</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
				  <div class="tab-content">
                  <div class="tab-pane active" id="summary">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>First Name</td><td><?= $record['first_name']; ?></td></tr>
					  <tr><td>Last Name</td><td><?= $record['last_name']; ?></td></tr>
					  <tr><td>NIN</td><td><?= $record['nin']; ?></td></tr>'
					  <tr><td>Polling Station</td><td><?= $record['polling_station']; ?></td></tr>
					  <tr><td>Voted</td><td><?= $record['voted'] == 1 ? "YES" : "NO"; ?></td></tr>
                  </tbody>
                </table>
                <p></p>
                
                </div>
                
				  <!-- /.tab-pane -->
				   <div class="tab-pane" id="nira">
					                <!-- /.card-header -->
              <?= $this->include('SubjectRecords/nira', ) ?> 
				  </div>
				
				  <!-- /.tab-pane -->
                 
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
                        <!-- /.card -->
                        

          
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div></div>
	</div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

<script>
var station1Voters = <?php print $station1Voters; ?>;
var station2Voters = <?php print $station2Voters; ?>;
var station1VerifiedVoters = <?php print $station1VerifiedVoters; ?>;
var station2VerifiedVoters = <?php print $station2VerifiedVoters; ?>;
var alreadyVoted = <?php print $alreadyVoted; ?>;
var notFound = <?php print $notFound; ?>;
var incorrectPollingStation = <?php print $incorrectPollingStation; ?>;
var femaleVoters = <?php print $femaleVoters; ?>;
var maleVoters = <?php print $maleVoters; ?>;
var youthVoters = <?php print $youthVoters; ?>;
var middleVoters = <?php print $middleVoters; ?>;
var olderVoters = <?php print $olderVoters; ?>;


</script>
 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Voter dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Voter dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

      
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
			  <div class="row">
				  <div class="col-md-3"></div>
				  <div class="col-md-6">
			<!-- Search form -->
			 <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Search</h3>
              </div>
              <?= form_open(base_url("ec/search"), ['id' => 'searchForm']); ?>
              <div class="card-body">
                <div class="row">
                    <select name="polling_station_id" class="form-control" id="polling_station_id"><option value=0>All Polling Stations</option><option value=1>Police HQ 1</option><option value=2>Police HQ 2</option></select>
                  </div>
                  
                 <button type="submit" class="btn btn-primary">Search</button>
                </div>
              </div>
              </div>
              </div>
              <div class="col-md-3"></div>
              <div class="row">
          <div class="col-md-6">
          
          <!-- DONUT CHART -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Registered voters</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="votersChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
			</div>
			<div class="col-md-6">
            <!-- DONUT CHART -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Verified voters</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="verifiedVotersChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
			</div>
			</div>
			<div class="row">
          <div class="col-md-6">
          
          <!-- DONUT CHART -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Voters by gender</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="votersGenderChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div></div>
            <!-- /.card -->
			<div class="col-md-6">
            <!-- DONUT CHART -->
            <div class="card card-success">
              <div class="card-header">
                <h3 class="card-title">Voters by age</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="votersAgeChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
			</div></div>
			
			<div class="row">
          <div class="col-md-6">			  
            <!-- PIE CHART -->
            <div class="card card-danger">
              <div class="card-header">
                <h3 class="card-title">Errors during voting</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
              </div>
              <div class="card-body">
                <canvas id="voterErrorChart" style="min-height: 250px; height: 250px; max-height: 250px; max-width: 100%;"></canvas>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
<div class="col-md-3"></div>
          </div>				
				  <!-- /.tab-pane -->
                 
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
                        <!-- /.card -->
                        

          
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div></div>
	</div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

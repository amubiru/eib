

 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Voter Records</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Voter Records</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			<!-- Add new record button -->
			<div class="col-lg-1">
			<a href="<?= base_url("ec/add"); ?>">
			<button type="button" class="btn btn-primary" >Add  <i class="fa fa-plus"></i></button></a>
			</div>
          <div class="col-lg-12">
			<!-- Card for form goes here
			-->
			<p></p>
			<!-- Search form -->
			 <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Wildcard search</h3>
              </div>
              <?= form_open(base_url("ec/search"), ['id' => 'searchForm']); ?>
              <div class="card-body">
                <div class="row">
                  <div class="col-2">
                    <input type="text" class="form-control" name="cabis_id" placeholder="CABIS ID">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="nin" placeholder="NIN">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="first_name" placeholder="First Name">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="last_name" placeholder="Last Name">
                  </div>
                  <div class="col-2">
                    <select name="polling_station_id" class="form-control" id="polling_station_id"><option value=0>All Polling Stations</option><option value=1>Police HQ 1</option><option value=2>Police HQ 2</option></select>
                  </div>
                  
                 <button type="submit" class="btn btn-primary">Search</button>
                 </div>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            </form>
            <!-- /.card -->
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title">Voter entries</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Internal ID</th>
                    <th>NIN</th>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Date of birth</th>
                    <th>Polling station</th>
                    <th>Voted</th>
                    <th>&nbsp;</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  
                  foreach($records as $record) {
					  //Set record color
					  //if(!isset($record['scan_file'])) {
					//	  $class='style="background-color:#f2f200"';
					 // } else {
						  $class="";
					  //}
					  print "<tr $class><td>${record['cabis_id']}</td>
					  <td>{$record['nin']}</td>
					  <td>{$record['first_name']}</td>
					  <td>{$record['last_name']}</td>
					  <td>{$record['date_of_birth']}</td>
					  <td>{$record['polling_station']}</td>
					  <td>".($record['voted']==1 ? "YES" : "NO")."</td>\n";

					  print "<td>&nbsp;";
					  print "<a href=\"".base_url("ec/view/".$record['id'])."\">View</a>";
					  print "</td>";
					print "</tr>\n";
				  }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
                     <th>Internal ID</th>
                    <th>NIN</th>
                    <th>First name</th>
                    <th>Last name</th>
                    <th>Date of birth</th>
                    <th>Polling station</th>
                    <th>Voted</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col-md-12 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

<div class="col-sm-6">
  <h1 class="m-0">Add Voter Record</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item active"><a href="<?php echo base_url('ec/index'); ?>">Voter records</a></li>
  </ol>
</div><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->

<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6">
        <!-- Card for form goes here
			-->
        <form method="post" action="<?= base_url('ec/submit'); ?>">
          <div class="form-group">
            <label for="court_place_trial">National ID Number (NIN)</label>
            <div class="row">
              <div class="col-8"><input type=text class="form-control" value="" id="modal_nin" name="nin" placeholder="National ID Number"></div>
              <div class="col-4"><button class="btn btn-primary" type="button" name="nira_search" id="nira_search" onClick="fillFromNIRA();">Retrieve data</button></div>
            </div>
          </div>
          <div class="form-group">
            <label for="name">First name</label>&nbsp;<font color=red>*</font> <input type=text required class="form-control" value="" id="modal_first_name" readonly name="first_name" placeholder="First name">
          </div>
          <div class="form-group">
            <label for="name">Last name</label>&nbsp;<font color=red>*</font> <input type=text required class="form-control" value="" id="modal_last_name" name="last_name" readonly placeholder="Last name">
            <div class="form-group">
              <label for="dob">Date of Birth</label> <input type=text class="form-control" value="" id="modal_date_of_birth" name="date_of_birth" readonly placeholder="YYYY-MM-DD">
              <input type=hidden name="gender" id="modal_gender">
            </div>
            <div class="form-group">
              <label for="polling_station">Polling Station</label>
              <select name="polling_station_id" class="form-control" id="polling_station_id">
                <option value=1>Police HQ 1</option>
                <option value=2>Police HQ 2</option>
              </select>
            </div>

            <div class="form-group">
              <button type="button" class="btn btn-default" onclick="window.history.back();">Cancel</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            <div style="display:none"><label>Fill This Field</label><input type="text" name="honeypot" value="" /></div>
        </form>
        <!-- general form elements -->


      </div>
      <!-- /.col-md-6 -->
    </div>
    <div class="col-lg-6">
      <img id="face_photo">
    </div>
    <!-- /.col-md-6 -->
  </div>
  <!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
  <!-- Control sidebar content goes here -->
  <div class="p-3">
    <h5>Title</h5>
    <p>Sidebar content</p>
  </div>
</aside>
<!-- /.control-sidebar -->
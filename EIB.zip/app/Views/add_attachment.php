
          <div class="col-sm-6">
            <h1 class="m-0">Add attachment</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
             <!-- <li class="breadcrumb-item active"><a href="<?php echo base_url('frontend/subject_records'); ?>">Subject records</a></li> -->
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
			<!-- Card for form goes here
			-->

            <?= form_open_multipart(base_url($controller['route'].'/attachment_submit'), ['id' => 'attachForm']);
            ?>
            <?php
				echo form_hidden('link_id', $link_id);
				echo form_hidden('subject_id', $subject_id);
				echo form_hidden('type', $type);
				echo form_hidden('last_url', $last_url);

            ?>
				<div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Name of attachment">
                  </div>
                  <div class="form-group">
                    <label for="description">Description</label>
                    <textarea rows=3 class="form-control" id="description" name="description" placeholder="Description of attachment"></textarea>
                  </div>
              <div class="form-group">
                    <label for="attachment">Attachment</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="attachment" name="attachment">
                        <label class="custom-file-label" for="attachment">Choose file</label>
                      </div>
                    </div>
                  </div>
			<div class="form-group">
			  <input type="submit" class="btn btn-primary" value="Upload">
              <button type="button" class="btn btn-default" onclick="window.history.back();">Cancel</button>
            </div>
            </form>
			 <!-- general form elements -->
            

          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->


<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>eIB</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="<?php echo base_url('css/google.css'); ?>">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url('css/ionicons.min.css'); ?>">
  <!-- JQuery UI -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/jquery-ui/jquery-ui.min.css">

  <!-- Boxicons -->
  <link rel="stylesheet" href="<?php echo base_url('public/assets/css/boxicons.min.css'); ?>"
  <!-- Fonts -->
  <link rel="stylesheet" href="<?php echo base_url('public/assets/css/gfonts.css'); ?>"


  <!-- Main CSS -->
 <link rel="stylesheet" href="<?php echo base_url('public/assets/css/main.css'); ?>">

  <!-- DataTables -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/datatables-bs4/css/dataTables.bootstrap4.min.css" type="text/css" />
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <!-- Select2 -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">

  <!-- Date picker -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">

  <!-- Theme style -->
  <link rel="stylesheet" href="<?php echo base_url('template/'); ?>dist/css/adminlte.min.css">
  <link rel="shortcut icon" href="<?php echo base_url('images/police_logo.png'); ?>" type="image/png" />
 
  <style>
    .right-photo {
      max-width: 300px;
      max-height: 300px;
    }
  </style>
  <script src="<?php echo base_url('js/'); ?>constants.js"></script>

</head>

<body class="hold-transition sidebar-mini">
  <div class="wrapper">

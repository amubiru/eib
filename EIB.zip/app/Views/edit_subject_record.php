
          <div class="col-sm-6">
            <h1 class="m-0">Add/Edit Subject Records</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active"><a href="<?php echo base_url('frontend/subject_records'); ?>">Subject records</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
			<!-- Card for form goes here
			-->
			<!-- Modal to edit criminal record item -->

            <?= form_open(base_url('/frontend/subject_records/submit'), ['id' => 'modalForm']); ?>
              <?php
              foreach($fields as $field) {
				  //Text number and password fields
				  if(in_array($field['type'], ['text','number', 'password'])) {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <input type=<?= $field['type']; ?> class="form-control" value="<?= $record[$field['db_name']]; ?>" id="modal_<?= $field['db_name'];?>" name="<?= $field['db_name'];?>" <?php if (in_array($field['db_name'], ['name', 'subject_id']) && !empty($record['id'])) { print " readonly "; } ?>placeholder="<?= $field['description'];?>">
                  </div>
                  <?php }
                  if($field['type'] == 'textarea') {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <textarea rows=3 cols=60 class="form-control" id="modal_<?= $field['db_name'];?>" name="<?= $field['db_name'];?>" placeholder="<?= $field['description'];?>"><?= $record[$field['db_name']]; ?></textarea>
                  </div>
                  <?php }
                  if($field['type'] == 'date') {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="bx bx-calendar"></i></span>
                    </div>
                    <input type=text class="form-control" id="modal_<?= $field['db_name'];?>" value="<?= $record[$field['db_name']]; ?>" name="<?= $field['db_name'];?>" placeholder="<?= $field['description'];?>" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                  </div>
                  <?php }
                  //Option fields
                  if($field['type']=='option') {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <?php 
					  //Ensure that there are actual options
					  $options=[];
					  if(array_key_exists('options', $field)) {
						  $options=$field['options'];
					  }
					  //reset($options);
					  echo form_dropdown($field['db_name'], $options, $record[$field['db_name']], ['id' => 'modal_'.$field['db_name'], 'class' => 'form-control select2']);
					  print "</div>\n";
				  }
                  if($field['type']=='hidden') {
					  $hidden_data = [
						'type'  => 'hidden',
						'name'  => $field['db_name'],
						'id'    => 'modal_'.$field['db_name'],
						'value' => $record[$field['db_name']]
					];

					echo form_input($hidden_data);
				   }
			  } 
              ?>
              <!--Add sentence type, units and amount -->
              <div class="form-group">
                    <label for="sentence_type">Sentence type</label>
                    <?php $options = ['NOT SENTENCED YET' => "Not sentenced yet", 'COMMUNITY SERVICE' => "Community Service", 'PROBATION' => "Probation", 'FINE' => "Fine", 'PRISON' => "Imprisonment"];
                    echo form_dropdown('sentence_type', $options, $record['sentence_type'] ? $record['sentence_type'] : "NOT SENTENCED YET", ['id' => 'modal_sentence_type',  'onChange'  => "showSentenceUnits()"]);
                    ?>
              </div>
              <div class="form-group" id="duration_group" style="display: none;">
                    <label for="sentence_type">Sentence duration</label><div class="row">
                  <div class="col-4"><input type="number" class="form-control" id="modal_sentence_amount" placeholder="Enter number" name="sentence_amount" value="<?= $record['sentence_amount']; ?>"></div><div class="col=4">
                    <?php $options = ['HOURS' => "HOURS", 'DAYS' => "DAYS", 'MONTHS' => "MONTHS", 'YEARS' => "YEARS"];
                    echo form_dropdown('sentence_units', $options, $record['sentence_units'], ['id' => 'modal_sentence_units']);
                    ?></div></div>
              </div>
              <div class="form-group" id="fine_group" style="display: none;">
                    <label for="sentence_type">Fine amount</label><div class="row">
                  <div class="col-4"><input type="number" class="form-control" id="modal_fine_amount" placeholder="Enter number" name="fine_amount" value="<?= $record['sentence_amount']; ?>"></div><div class="col=4">
                  </div></div>
              </div>
			<div class="form-group">
              <button type="cancel" class="btn btn-default" >Cancel</button>
              <button type="submit" id="submit" class="btn btn-primary">Save changes</button>
            </div>
            </form>
			 <!-- general form elements -->
            

          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

<script>
//Prevent double entry
document.addEventListener('DOMContentLoaded', function() {
	const form = document.getElementById('modalForm'); // Get the form
    const submitButton = document.getElementById('submit'); // Get the submit button
    
    if (form && submitButton) {
        form.addEventListener('submit', function() {
            // Disable the submit button when form is submitted
            submitButton.disabled = true;
            
            // Optional: Change button text to indicate processing
            submitButton.value = 'Processing...';
        });
    }
});
</script>

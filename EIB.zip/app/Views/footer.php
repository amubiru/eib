</div>
  <!-- Main Footer -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
    </div>
    <strong><?= date('Y'); ?> Kwiksy</strong> All rights reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?php echo base_url('template/'); ?>plugins/jquery/jquery.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/jquery-ui/jquery.blockUI.js"></script>

<!-- jquery-validation -->
<script src="<?php echo base_url('template/'); ?>plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/jquery-validation/additional-methods.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url('template/'); ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Input masks -->
<script src="<?php echo base_url('template/'); ?>plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/inputmask/jquery.inputmask.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="<?php echo base_url('template/'); ?>plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url('template/'); ?>plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url('template/'); ?>plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Select2 -->
<script src="<?php echo base_url('template/'); ?>plugins/select2/js/select2.full.min.js"></script>
<!-- ChartJS -->
<!-- ChartJS -->
<script src="<?php echo base_url('template/'); ?>plugins/chart.js/Chart.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url('template/'); ?>dist/js/adminlte.min.js"></script>

<!-- Set some variables from PHP -->
<script>
var baseURL="<?= base_url() ?>";
var AjaxToken="<?= $_SESSION['AJAX_TOKEN'] ?? '' ?>";

</script>
<?php if(isset($dashboard)) { ?>
<script src="<?php echo base_url('template/'); ?>dist/js/dashboard.js"></script>
<?php } ?>
<?php if(isset($search_dashboard)) { ?>
<script src="<?php echo base_url('template/'); ?>dist/js/search_dashboard.js"></script>
<?php } ?>
<script src="<?php echo base_url('js/'); ?>functions.js?ver=5"></script>

<!-- Process a datatable semi automatically -->
<script>
  $(function () {
	  console.log('run_datatables');
      if( typeof ($.fn.DataTable) === 'undefined'){ return; }
      console.log('init_DataTables');
    
    $("#dataTable").DataTable({
	  dom: 'Bfrtip',
	  "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"],
      "paging": true,
      "lengthChange": false,
      "lengthMenu": [ [100, 500, -1], [100, 500, "All"]],
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
  
  //Initialize toasts
  $('.toast').toast();
  //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    })
    
    //Datemask yyyy-mm-dd
    $('#datemask').inputmask('yyyy-mm-dd', { 'placeholder': 'yyyy-mm-dd' })
    //Money Euro
    $('[data-mask]').inputmask()

    //Date picker
//    $('.date-picker').datetimepicker({
//        format: 'yyyy-mm-dd'
//    });


  //Show file names on upload
  $(document).on('change', '.custom-file-input', function (event) {
	  if (event.target.files.length) {
		$(this).next('.custom-file-label').html(event.target.files[0].name);
	}
})
  //Validate file upload
  $(function () {

  $('#ippsForm').validate({
    rules: {
      subject_id: {
        required: true
      },
      name: {
        required: true
      },
      offence: {
        required: true
      },
      sentence: {
        required: true
      },
      cr_scan: {
        accept: "pdf|png|jpg|jpeg|tiff"
      },
    },
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
});
</script>
<!--   Functions for CRUD forms  -->
<?php if (isset($fields)) { ?>
<script>
var fields_json = '<?= json_encode($fields); ?>';

//Clear the modal form
function clearModal() {
	var fields=JSON.parse(fields_json);
	fields.forEach(function(field) {
		$("#modal_"+field.db_name).val(null);
		});
}

function editModal(record_json) {
	//First clear the form of any previous data
	clearModal();
	//Set fields
	var fields=JSON.parse(fields_json);
	var record=JSON.parse(record_json);
	fields.forEach(function(field) {
		$("#modal_"+field.db_name).val(eval("record."+field.db_name));
		});
}

//Sets value of a form element
function setFormValue(id, value) {
	$("#"+id).val(value);
}

function attachModal(attach_json) {
	var attachments=JSON.parse(attach_json);
	var col=0;
	var output="";
	attachments.forEach(function(attach) {
		if(col==0) {
			output+="<tr style=\"border: none;\">";
		}
		output+="<td style=\"border: none;\">"+"<a target=\”_blank\” href=\"<?= base_url('frontend/attachments/'); ?>"+attach.id+"\">"+"<embed width=100 height=100 name=\"plugin\" src=\"<?= base_url('frontend/attachments/'); ?>"+attach.id+"\" type=\""+attach.type+"\">"+ attach.name+" " + attach.description+"</a></td>";
		if(col==2) {
			output+-"</tr>";
		}
		col++;
	});
	$("#attachTable").html(output);
}

//Perform form validation using JQuery
$(function () {

  $('#modalForm').validate({
    rules: {
		<?php
		$validation="";
		
		foreach($fields as $field) {
			if($field['required'] == 1) {
				//Add comma if adding to an existing validation rule
				if(strlen($validation)>0) {
					$validation.=",";
				}
				$validation.= "\n".$field['db_name'].": { required: true\n";
				if($field['min_length']) {
					$validation.= ",minlength: ".$field['min_length']."\n";
				}
				if($field['max_length']) {
					$validation.= ",maxlength: ".$field['max_length']."\n";
				}
				$validation.="}";
			}
		}
		print $validation."\n},\n";
?>
    errorElement: 'span',
    errorPlacement: function (error, element) {
      error.addClass('invalid-feedback');
      element.closest('.form-group').append(error);
    },
    highlight: function (element, errorClass, validClass) {
      $(element).addClass('is-invalid');
    },
    unhighlight: function (element, errorClass, validClass) {
      $(element).removeClass('is-invalid');
    }
  });
});
</script>
<?php } ?>

<script>
$(function () {
	//Show correct sentence entry based on sentence type
	//Run the function on page load and whenever the type is changed
	showSentenceUnits();
	showSearchTerms();
	<?php foreach ($cabis_checks ?? [] as $check) {
	print "checkCivilianCabis({$check['id']},\"{$check['cabis_id']}\");\n";
	}
	?> 
});
</script>	

<!-- Mark menu items as active -->
<script type="text/javascript">
$(document).ready(function () {
    /** add active class and stay opened when selected */
    var url = window.location;

    // for sidebar menu entirely but not cover treeview
    $('ul.nav-sidebar a').filter(function() {
        return this.href == url;
    }).addClass('active');

    // for treeview
    $('ul.nav-treeview a').filter(function() {
        return this.href == url;
    }).parentsUntil(".nav-sidebar > .nav-treeview").addClass('menu-open').prev('a').addClass('active');
    
    fillFromCabis();
    
});



  //First check that these charts are defined
  if($('#voterErrorChart').get(0)) {
 //-------------
    //- DONUT CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var donutChartCanvas = $('#votersChart').get(0).getContext('2d')
    var donutData        = {
      labels: [
          'Polling Station 1',
          'Poling Station 2',
      ],
      datasets: [
        {
          data: [station1Voters,station2Voters],
          backgroundColor : ['#f56954', '#00a65a', '#f39c12', '#00c0ef', '#3c8dbc', '#d2d6de'],
        }
      ]
    }
    var donutOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(donutChartCanvas, {
      type: 'doughnut',
      data: donutData,
      options: donutOptions
    })
    
     //-------------
    //- DONUT CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var donutChartCanvas = $('#verifiedVotersChart').get(0).getContext('2d')
    var donutData        = {
      labels: [
          'Polling Station 1',
          'Poling Station 2',
      ],
      datasets: [
        {
          data: [station1VerifiedVoters,station2VerifiedVoters],
          backgroundColor : ['#f39c12', '#00c0ef'],
        }
      ]
    }
    var donutOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(donutChartCanvas, {
      type: 'doughnut',
      data: donutData,
      options: donutOptions
    })

    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#votersGenderChart').get(0).getContext('2d')
    var donutData        = {
      labels: [
          'Female',
          'Male',
      ],
      datasets: [
        {
          data: [femaleVoters,maleVoters],
          backgroundColor : ['#f39c12', '#00c0ef'],
        }
      ]
    }
    var pieData        = donutData;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    })
    
        //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#votersAgeChart').get(0).getContext('2d')
    var donutData        = {
      labels: [
          '18-30',
          '30-60',
          '60+',
      ],
      datasets: [
        {
          data: [youthVoters,middleVoters, olderVoters],
          backgroundColor : ['#f39c12', '#00c0ef', '#f56954'],
        }
      ]
    }
    var pieData        = donutData;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    })

    //-------------
    //- PIE CHART -
    //-------------
    // Get context with jQuery - using jQuery's .get() method.
    var pieChartCanvas = $('#voterErrorChart').get(0).getContext('2d')
    var donutData        = {
      labels: [
          'Already voted',
          'Not found',
          'Incorrect polling station',
      ],
      datasets: [
        {
          data: [alreadyVoted,notFound, incorrectPollingStation],
          backgroundColor : ['#f39c12', '#00c0ef', '#f56954'],
        }
      ]
    }
    var pieData        = donutData;
    var pieOptions     = {
      maintainAspectRatio : false,
      responsive : true,
    }
    //Create pie or douhnut chart
    // You can switch between pie and douhnut using the method below.
    new Chart(pieChartCanvas, {
      type: 'pie',
      data: pieData,
      options: pieOptions
    })
}
</script>
</body>
</html>



 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">View IPPS Records</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">IPPS Records</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-12">
			<!-- Card for form goes here
			-->
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title">IPPS entries</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Employee No</th>
                    <th>NIN</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>Title</th>
                    <th>Posting</th>
                    <th>First App</th>
                    <th>Current App</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  foreach($records as $record) {
					  print "<tr><td>{$record['employee_number']}</td>
					  <td>{$record['nin']}</td>
					  <td>{$record['name']}</td>
					  <td>{$record['gender']}</td>
					  <td>{$record['date_of_birth']}</td>
					  <td>{$record['title']}</td>
					  <td>{$record['posting']}</td>
					  <td>{$record['first_application_date']}</td>
					  <td>{$record['current_application_date']}</td>
					  </td></tr>";
				  }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Employee No</th>
                    <th>NIN</th>
                    <th>Name</th>
                    <th>Gender</th>
                    <th>Date of Birth</th>
                    <th>Title</th>
                    <th>Posting</th>
                    <th>First App</th>
                    <th>Current App</th>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col-md-12 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->



 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0"><?= $controller['description']; ?></h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active"><?= $controller['description']; ?></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    
    <!-- Modal to view attachments -->
    <div class="modal fade" id="attachModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">View attachments</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
			<table id="attachTable" style="border-collapse: collapse; border: none;"></table>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->

    <!-- Modal to edit lost and found item -->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add/Edit</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?= form_open(base_url($controller['route'].'/submit'), ['id' => 'modalForm']); ?>
            <div class="modal-body">
              <?php
              foreach($fields as $field) {
				  //Text number and password fields
				  if(in_array($field['type'], ['text','number', 'password'])) {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <input type=<?= $field['type']; ?> class="form-control" id="modal_<?= $field['db_name'];?>" name="<?= $field['db_name'];?>" placeholder="<?= $field['description'];?>">
                  </div>
                  <?php }
                  if($field['type'] == 'textarea') {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <textarea rows=3 cols=60 class="form-control" id="modal_<?= $field['db_name'];?>" name="<?= $field['db_name'];?>" placeholder="<?= $field['description'];?>"></textarea>
                  </div>
                  <?php }
                  if($field['type'] == 'date') {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <input type=text class="form-control" id="modal_<?= $field['db_name'];?>" name="<?= $field['db_name'];?>" placeholder="<?= $field['description'];?>">
                  </div>
                  <?php }
                  //Option fields
                  if($field['type']=='option') {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label><?php if ($field['required'] == true) { print '&nbsp;<font color=red>*</font>';} ?>
                    <?php 
					  //Ensure that there are actual options
					  $options=[];
					  if(array_key_exists('options', $field)) {
						  $options=$field['options'];
					  }
					  //reset($options);
					  echo form_dropdown($field['db_name'], $options, key($options), ['id' => 'modal_'.$field['db_name']]);
					  print "</div>\n";
				  }
                  if($field['type']=='hidden') {
					  $hidden_data = [
						'type'  => 'hidden',
						'name'  => $field['db_name'],
						'id'    => 'modal_'.$field['db_name']
					];

					echo form_input($hidden_data);
				   }
			  } 
              ?>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            </form>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
      
          <!-- Modal to add attachment -->
    <div class="modal fade" id="addAttachModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add attachment</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?= form_open_multipart(base_url($controller['route'].'/attachment_submit'), ['id' => 'attachForm']);
            ?>
            <?php
            $hidden_data = [
				'type'  => 'hidden',
				'name'  => 'lost_and_found_id',
				'id'    => 'lost_and_found_id'
			];
			echo form_input($hidden_data);
            ?>
            <div class="modal-body">
				<div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="name" name="name" placeholder="Name of attachment">
                  </div>
                  <div class="form-group">
                    <label for="description">Description</label>
                    <textarea rows=3 class="form-control" id="description" name="description" placeholder="Description of attachment"></textarea>
                  </div>
              <div class="form-group">
                    <label for="attachment">Attachment</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="attachment" name="attachment">
                        <label class="custom-file-label" for="attachment">Choose file</label>
                      </div>
                    </div>
                  </div>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Submit</button>
            </div>
            </form>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
      
      
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			<!-- Add new record button -->
			<div class="col-lg-1">
			<a href="<?= base_url($controller['route']."/add"); ?>">
			<button type="button" class="btn btn-block btn-primary" >Add  <i class="fa fa-plus"></i></button></a>
			</div>
          <div class="col-lg-12">
			<!-- Card for form goes here
			-->
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title"><?= $controller['description']; ?></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
					  <?php
					  foreach ($fields as $field) {
						  //Skip hidden fields
						  if($field['type']=='hidden' || $field['type']=='password') {
							  continue;
						  }
						print "<th>{$field['name']}</th>\n";  
					  }
					  print "<th>Photos / Attachments</th><th>&nbsp;</th>";
					  ?>

                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  //Create a row for each record
                  foreach($data as $record) {
					  print "<tr>";
					  //Create a column for each 
					  foreach($fields as $field) {
						  //Skip hidden fields
						  if($field['type']=='hidden' || $field['type']=='password') {
							  continue;
						  }
						  if(in_array($field['type'], ['text','number','textarea','date'])) {
								print "<td>".$record[$field['db_name']]."</td>\n";
							}
						if($field['type']=='option') {
							if(array_key_exists($record[$field['db_name']], $field['options'])) {
								print "<td>".$field['options'][$record[$field['db_name']]]."</td>\n";
							} else {
								print "<td>&nbsp;</td>\n";
							}
						}
					  }
					  //Show attachments
					  print "<td>";
					  $num_attach=count($record['attachments']);
					  if($num_attach > 0) {
						  print $num_attach."&nbsp;";
						  print "<span title='View'><a href='#' data-toggle=\"modal\" data-target=\"#attachModal\" onClick='attachModal(\"".str_replace('"', '\\"', json_encode($record['attachments']))."\");'>".'<i class="fa fa-eye" title="View" ></i></a><span>&nbsp;';
					  }
					  print "<span title='Add'><a href=\"". base_url($controller['route']."/add_attachment/".$record['id'])."\" >".'<i class="fa fa-plus" title="Add" ></i></a><span>&nbsp;';
					  print "</td>\n";
					  //Show edit and delete options
					  print "<td>&nbsp;";
					  print "<span title='Edit'><a href=\"".base_url($controller['route']."/edit/".$record['id']).'"><i class="fa fa-pencil-alt" title="Edit" ></i></a><span>';
					  print "&nbsp;&nbsp;";
					  print "<span title='Delete'><a class='red' href='".base_url($controller['route']."/delete/".$record['id'])."' onClick=\"return confirm('Are you sure you want to delete this item');\">".'<i class="fa fa-times" title="Delete" ></i></a></span>';
					  print "</td>";
					print "</tr>\n";
				  }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <?php
					  foreach ($fields as $field) {
						  //Skip hidden fields
						  if($field['type']=='hidden' || $field['type']=='password') {
							  continue;
						  }
						  print "<th>{$field['name']}</th>\n";
					  }
					  print "<th>Photos / Attachments</th><th>&nbsp;</th>";
					  ?>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col-md-12 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

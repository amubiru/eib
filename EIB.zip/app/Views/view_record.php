
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-10">
			<!-- Card for form goes here
			-->
			<?= $this->include($include) ?>
			<?= $this->include('Search/view_record_related') ?>  
			 <!-- general form elements -->
            

          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

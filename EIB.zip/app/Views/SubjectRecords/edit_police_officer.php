<div class="col-sm-6">
  <h1 class="m-0">Add/Edit Police Records</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item active"><a href="<?php echo base_url('frontend/subject_records/police'); ?>">Police records</a></li>
  </ol>
</div>

<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6">
        <!-- Card for form goes here
			-->
        <form method="post" action="<?= base_url('frontend/subject_records/police/submit'); ?>">
          <div class="form-group">
            <label for="subject_id">CABIS ID (AFIS)</label>&nbsp;<font color=red>*</font>
            <div class="row">
              <div class="col-8"><input type=text class="form-control" value="" id="modal_cabis_id" name="cabis_id" placeholder="CABIS ID (AFIS)"></div>
              <div class="col-4"><button class="btn btn-primary" name="cabis_search" type="button" id="cabis_search" onClick="fillFromCabis();">Retrieve data</button></div>
            </div>
          </div>
          <div class="form-group">
            <label for="name">First name</label>&nbsp;<font color=red>*</font> <input type=text required class="form-control" value="" id="modal_first_name" name="first_name" placeholder="First name">
          </div>
          <div class="form-group">
            <label for="name">Last name</label>&nbsp;<font color=red>*</font> <input type=text required class="form-control" value="" id="modal_last_name" name="last_name" placeholder="Last name">
          </div>
          <div class="form-group">
            <label for="court_place_trial">National ID Number (NIN)</label> <input type=text class="form-control" value="" id="modal_nin" name="nin" placeholder="National ID Number">
          </div>
          <div class="form-group">
            <label for="offence">Employee Number</label> <input type=text class="form-control" value="" id="modal_employee_number" name="employee_number" placeholder="Employee number">
          </div>

          <div class="form-group">
            <button type="button" class="btn btn-default" onclick="window.history.back();">Cancel</button>
            <button type="submit" class="btn btn-primary">Save changes</button>
          </div>
          <div style="display:none"><label>Fill This Field</label><input type="text" name="honeypot" value="" /></div>
        </form>
  
      </div>
      <div class="col-lg-6">
        <img id="face_photo">
      </div>
    </div>
  </div>
</div>
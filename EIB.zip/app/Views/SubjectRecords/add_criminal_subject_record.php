<div class="col-sm-6">
  <h1 class="m-0">Add/Edit Criminal Subject Records</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item active"><a href="<?php echo base_url('frontend/subject_records/criminal'); ?>">Criminal Subject records</a></li>
  </ol>
</div><!-- /.col -->


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-6">
        <!-- Card for form goes here
			-->
        <form method="post" id="modalForm" action="<?= base_url('frontend/subject_records/criminal/submit'); ?>">
          <div class="form-group">
            <?php if ($cabis_id ?? null) { ?>
              <label for="subject_id">CABIS ID (AFIS)</label>&nbsp;<font color=red>*</font>
              <div class="row">
                <div class="col-8"><input type=text class="form-control" id="modal_cabis_id" name="cabis_id" value="<?php print $cabis_id; ?>" placeholder="CABIS ID (AFIS)" readonly></div>
                <div class="col-4"></div>
              </div>
            <?php } else { ?>
              <label for="subject_id">CABIS ID (AFIS)</label>&nbsp;<font color=red>*</font>
              <div class="row">
                <div class="col-8"><input type=text class="form-control" id="modal_cabis_id" name="cabis_id" value="<?php if (isset($record)) {
                                                                                                                      print $record['cabis_id'];
                                                                                                                    } ?>" placeholder="CABIS ID (AFIS)" <?php if (isset($record)) {
                                                                                                                                                                                                                print "readonly";
                                                                                                                                                                                                              } ?>></div>
                <div class="col-4"><?php if (!isset($record)) { ?><button class="btn btn-primary" type="button" name="cabis_search" id="cabis_search" onClick="fillFromCabis();">Retrieve data</button><?php } ?></div>
              </div
                <?php } ?>
                </div>
              <div class="form-group">
                <label for="name">First name</label>&nbsp;<font color=red>*</font> <input type=text class="form-control" id="modal_first_name" name="first_name" value="<?php if (isset($record)) {
                                                                                                                                                                          print $record['first_name'];
                                                                                                                                                                        } ?>" readonly placeholder="Subject name">
              </div>
              <div class="form-group">
                <label for="name">Last name</label>&nbsp;<font color=red>*</font> <input type=text class="form-control" id="modal_last_name" name="last_name" value="<?php if (isset($record)) {
                                                                                                                                                                        print $record['last_name'];
                                                                                                                                                                      } ?>" readonly placeholder="Subject name">
              </div>
              <div class="form-group">
                <label for="offence">Offense</label> <input type=text class="form-control" id="modal_offence" name="offence" value="<?php if (isset($record)) {
                                                                                                                                      print $record['offense'];
                                                                                                                                    } ?>" placeholder="Offense (including law and section)">
              </div>
              <div class="form-group">
                <label for="date_received">Date received</label>
                <div class="row">
                  <div class="input-group date" id="date_received" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" name="date_received" data-target="#date_received" placeholder="YYYY-MM-DD" value="<?php if (isset($record)) {
                                                                                                                                                                      print $record['date_received'];
                                                                                                                                                                    } ?>" />
                    <div class="input-group-append" data-target="#date_received" data-toggle="datetimepicker">
                      <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group">
                <label for="court_place_trial">Court and place of trial</label> <input type=text class="form-control" id="modal_court_place_trial" name="court_place_trial" placeholder="Court and place of trial">
              </div>
              <div class="form-group">
                <label for="remarks">Remarks</label> <textarea rows=3 cols=60 class="form-control" id="modal_remarks" name="remarks" placeholder="Remarks"></textarea>
              </div>
              <div class="form-group">
                <label for="station">Station</label> <input type=text class="form-control" id="modal_station" name="station" value="<?php if (isset($record)) {
                                                                                                                                      print $record['station'];
                                                                                                                                    } ?>" placeholder="Station">
              </div>
              <div class="form-group">
                <label for="crb_no">CRB Number</label> <input type=text class="form-control" id="modal_crb_no" name="crb_no" value="<?php if (isset($record)) {
                                                                                                                                      print $record['crb_no'];
                                                                                                                                    } ?>" placeholder="CRB Number">
              </div>

              <input type="hidden" name="id" id="modal_id" />
              <input type="hidden" name="previous_id" id="modal_previous_id" value="<?= $previous_id ?? 0 ?>" />
              <input type="hidden" name="issue_id" id="modal_issue_id" value="<?= $issue_id ?? 0 ?>" />
              <!--Add sentence type, units and amount -->
              <div class="form-group">
                <label for="case_result">Case result</label> <select name="case_result" id="modal_case_result" class="form-control select2" onChange="showSentenceUnits()">
                  <option value="NOT SENTENCED YET">Not yet sentenced</option>
                  <option value="ACQUITTED">Acquitted</option>
                  <option value="PUT AWAY">Put away</option>
                  <option value="NOLE PROSECU">Nole Prosecu</option>
                  <option value="DISMISSED">Dismissed</option>
                  <option value="SENTENCED">Sentenced</option>
                </select>
              </div>
              <div class="form-group" id="sentence_date_group">
                <label for="date_sentence">Date of decision</label>
                <div class="row">
                  <div class="input-group date" id="date_sentence" data-target-input="nearest">
                    <input type="text" class="form-control datetimepicker-input" name="date_sentence" data-target="#date_sentence" placeholder="YYYY-MM-DD" />
                    <div class="input-group-append" data-target="#date_sentence" data-toggle="datetimepicker">
                      <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                    </div>
                  </div>
                </div>
              </div>
              <fieldset id="sentence_fields">
                <div class="form-group">
                  <label for="sentence_type">Sentence type</label> <select name="sentence_type" id="modal_sentence_type" class="form-control select2" onChange="showSentenceUnits()">
                    <option value="CUSTODIAL">Custodial</option>
                    <option value="NON CUSTODIAL">Non Custodial</option>
                  </select>
                </div>
                <div class="form-group" id="non_custodial_group">
                  <label for="non_custodial_sentence">Non custodial sentence type</label> <select name="non_custodial_sentence" id="modal_non_custodial_sentence" class="form-control select2" onChange="showSentenceUnits()">
                    <option value="CAUTION">Caution</option>
                    <option value="COMMUNITY SERVICE">Community Service</option>
                    <option value="FINE">Fine</option>
                    <option value="FINE AND CAUTION">Fine + Caution</option>
                  </select>
                </div>

                <div class="form-group" id="duration_group" style="display: none;">
                  <label for="sentence_type">Sentence duration</label>
                  <div class="row">
                    <div class="col-4"><input type="number" class="form-control" id="modal_sentence_amount" placeholder="Enter number" name="sentence_amount" value=""></div>
                    <div class="col=4">
                      <select name="sentence_units" id="modal_sentence_units">
                        <option value="HOURS">HOURS</option>
                        <option value="DAYS">DAYS</option>
                        <option value="MONTHS">MONTHS</option>
                        <option value="YEARS">YEARS</option>
                      </select>
                    </div>
                  </div>

                </div>
                <div class="form-group" id="fine_group" style="display: none;">
                  <label for="sentence_type">Fine amount</label>
                  <div class="row">
                    <div class="col-4"><input type="number" class="form-control" id="modal_fine_amount" placeholder="Enter number" name="fine_amount"></div>
                    <div class="col=4">
                    </div>
                  </div>
                </div>
              </fieldset>
              <div class="form-group">
                <label for="case_tracking_id">Case Tracking ID</label> <input type=text class="form-control" id="modal_case_tracking_id" name="case_tracking_id" placeholder="Case Tracking ID">
              </div>
              <div class="form-group">
                <label for="case_tracking_person_id">Case Tracking Person ID</label> <input type=text class="form-control" id="modal_case_tracking_person_id" name="case_tracking_person_id" placeholder="Case Tracking Person ID">
              </div>
              <div class="form-group">
                <?php
                print form_hidden('cert_id', $cert_id ?? '');
                ?>
                <button type="button" class="btn btn-default" onclick="window.history.back();">Cancel</button>
                <button type="submit" id="submit" class="btn btn-primary">Save changes</button>
              </div>
              <div style="display:none"><label>Fill This Field</label><input type="text" name="honeypot" value="" /></div>
        </form>
        <!-- general form elements -->
      </div>

      <!-- /.col-md-6 -->
      <div class="col-lg-6">
        <img id="face_photo">
      </div>
      <!-- /.col-md-6 -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->
</div>
<script>
//Prevent double entry
document.addEventListener('DOMContentLoaded', function() {
	const form = document.getElementById('modalForm'); // Get the form
    const submitButton = document.getElementById('submit'); // Get the submit button
    
    if (form && submitButton) {
        form.addEventListener('submit', function() {
            // Disable the submit button when form is submitted
            submitButton.disabled = true;
            
            // Optional: Change button text to indicate processing
            submitButton.value = 'Processing...';
        });
    }
});
</script>

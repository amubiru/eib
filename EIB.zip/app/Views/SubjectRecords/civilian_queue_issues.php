<?php
//if(is_array($_SESSION['queue_data'] ?? null)) {
	//print "<button><a href=\"".base_url</button>
		if(count($civilian_issues)) { ?>
              <!-- /.card -->
              <div class="card">
              <div class="card-header d-flex p-0">
              <h3 class="card-title">Resolve name issues</h3>
              </div><!-- /.card-body -->
              <div class="card-body">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>First Name</td><td>Middle Name</td><td>Last Name</td><td>CABIS ID</td>&nbsp;</td></tr>
					<?php
					foreach($civilian_issues as $issue) {
						log_message('debug', print_r($issue, true));
						print "<tr><td>{$issue['first_name']}</td><td>{$issue['middle_name']}</td><td>{$issue['last_name']}</td><td>".($issue['cabis_id'] ?? $issue['application'])."</td><td><a href=\"".base_url("frontend/subject_records/civilian/queue_resolve/?data=".$issue['uuid'])."\"><button type=\"button\" class=\"btn btn-primary\" >Use this name</button></a></td></tr>\n";
					} 
					?>
                  </tbody>
                </table>
               
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                </div>
                </div>
<?php } ?> 
                       <!-- /.card -->
        <?php
		//if($police_issues) {
		if(0) { //Do not show this ?>
              <!-- /.card -->
              <div class="card">
              <div class="card-header d-flex p-0">
             <h3 class="card-title">Confirm police officer</h3>
              </div><!-- /.card-body -->
              <div class="card-body">
                <a href="<?= base_url("frontend/subject_records/civilian/queue_resolve/?data=".$police_issues['uuid']); ?>"><button type="button" class="btn btn-primary" >Confirm no adverse police matters</button></a>
               
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                </div>
                </div>
<?php } ?>                        <!-- /.card -->
<h3>Offences in eIB</h3>
           				<?php if($offenses) { ?>
           <!-- /.card-header -->
              <div class="card">
              <div class="card-header d-flex p-0">
             
              </div><!-- /.card-body -->
              <div class="card-body">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><th>CABIS ID</th><th>Date decision</th><th>Offense</th></th><th>Sentence</th><th></th></tr>
					  <?php foreach($offenses as $offense) {
						  switch ($offense['case_result']) {
							case 'NOT SENTENCED YET':
								$offense['result']="Not sentenced yet";
								break;
							case 'ACQUITTED':
								$offense['result']="Acquitted";
								break;
							case 'DISMISSED':
								$offense['result']="Dismissed";
								break;
							case 'SENTENCED':
								switch($offense['sentence_type']) {
									case 'CUSTODIAL':
										$offense['result']='Imprisonment for '." ".counted($offense['sentence_amount'], strtolower($offense['sentence_units']));
									break;
									case 'NON CUSTODIAL':
									switch($offense['non_custodial_sentence']) {
										case 'CAUTION':
											$offense['result']='Caution';
											break;
										case 'COMMUNITY SERVICE':
											$offense['result']='Community service for '." ".counted($offense['sentence_amount'], strtolower($offense['sentence_units']));
											break;
										case 'FINE':
											$offense['result']='Fined UGX '.$offense['sentence_amount'];
											break;
									}
									break;
								}
								break;
							default:
								$offense['sentence']=" - ";
						}
						  print "<tr><td>".$offense['cabis_id']."</td><td>".$offense['date_sentence']."</td><td>".$offense['offence']."</td></td><td>".$offense['case_result']."</td><td><a href=".base_url("frontend/subject_records/criminal/edit/".$offense['id']."?cert_id=".$record['id']).">Edit</a></td></tr>\n";
					  }
						  ?>
                  </tbody>
                </table>
               
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                </div>
            </div>
            <?php } else { print "No offences"; } ?>
<?php
		if(count($criminal_issues)) { ?>
			
			 <div class="card">
              <div class="card-header d-flex p-0">
              <h3 class="card-title">CABIS Records</h3>
              </div><!-- /.card-body -->
              <div class="card-body">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>First Name</td><td>Middle Name</td><td>Last Name</td><td>CABIS ID</td><td>Offense</td><td>Date</td><td>&nbsp;</td></tr>
					<?php
					foreach($criminal_issues as $issue) {
						print "<tr><td>{$issue['first_name']}</td><td>{$issue['middle_name']}</td><td>{$issue['last_name']}</td><td>".($issue['cabis_id'])."</td><td>{$issue['offense']} </td><td>{$issue['date']}</td><td><a href=".base_url("frontend/subject_records/criminal/add/?cabis_id=".$subject['cabis_id']."&cert_id=".$record['id'].'&criminal_cabis_id='.$issue['cabis_id']).' <button type="button" class="btn btn-primary" >Add this offense <i class="fa fa-plus"></i></button></a></td></tr>'."\n";
					} 
					?>
                  </tbody>
                </table>
               
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                </div>
               </div>
			
                        <div class="col-lg-4">
			<a href="<?= base_url("frontend/subject_records/criminal/add/?cabis_id=".$subject['cabis_id']."&cert_id=".$record['id']); ?>">
			<button type="button" class="btn btn-primary" >Add offense <i class="fa fa-plus"></i></button></a>
			</div>
			<p></p>
			
           		
            <a href="<?= base_url("frontend/subject_records/civilian/queue_resolve/?data=".$criminal_issues[0]['uuid']); ?>"><button type="button" class="btn btn-primary" >Confirm criminal cases have been added</button></a>
                        <!-- /.card -->   
             <?php } ?>
            <p></p>

            <h3>Internal notes</h3>&nbsp;&nbsp;These are auto generated relevant notes about this application
            <textarea class="form-control" cols=60 rows=5 readonly name="internal_notes" placeholder="Shows any relevant information"><?= $record['internal_notes'] ?? 'NIL' ?></textarea>
            <p></p>
            <?php 
            //If there are no issues, permit the person to submit the adverse notice
            //if(!(count($civilian_issues) || count($criminal_issues))) { 
				if(($_SESSION['role']['name'] ?? '') =='DATA_ENTRY') {
					print "<h3>Complete</h3>&nbsp;&nbsp<br><b>Please contact supervisor to complete submission</b>";
				} else {
					?> 
            <h3>Adverse police notice</h3>&nbsp;&nbsp; <br><b>Posting this will generate the certificate</b><br>
             <?php print form_open(base_url("frontend/subject_records/civilian/submit_pcc"), ['id' => 'pccForm']); 
				   print form_hidden('pcc_uuid', $pcc_uuid);
				   print form_hidden('uuid', $record['uuid']);
				  // print form_hidden('id', $subject['id']);
				   //print form_hidden('source', $source ?? '');
				   //if(isset($civilian_id)) {
				//	   print form_hidden('civilian_id', $civilian_id);
				 //  }
             ?>
              <div class="card-body">
                <div class="row">
                    <textarea class="form-control" cols=60 rows=5 name="adverse_police_notice" placeholder="Enter adverse police notice"><?= $record['adverse_police_notice'] ?? 'NIL' ?></textarea>
                    
                 <button type="submit" class="btn btn-primary">Submit</button>&nbsp;&nbsp; <button name="reject" value="reject" type="submit" class="btn btn-danger" onClick="return confirm('Are you sure you want to reject this application?');">Reject</button>
                 </div>
                </div>
                <br><br>
                 <p>
                 <a class="btn btn-primary" target="_blank" href="<?= base_url('/frontend/subject_records/email_pcc/'.$record['id']); ?>">Preview Police Clearance Certificate</a>
                 &nbsp;&nbsp;
                 <a class="btn btn-primary" onClick="return confirm('Are you sure you want to refresh this application?');" href="<?= base_url('/frontend/subject_records/civilian/requeue/'.$record['id']); ?>">Refresh CABIS records</a>
                 </p>
       
            </form>
            <?php }
           // } ?>
           <!-- <div class="card">
              <div class="card-header d-flex p-0">
              <h3 class="card-title">Reject application</h3>
              </div>
              <div class="card-body">
				<?php print form_open(base_url("frontend/subject_records/civilian/queue_reject"), ['id' => 'pccForm']); 
				   print form_hidden('uuid', $record['uuid']); ?>
               <textarea class="form-control" cols=60 rows=5 name="adverse_police_notice" placeholder="Enter adverse police notice"><?= $record['adverse_police_notice'] ?? '' ?></textarea>
                    
                 <button type="submit" class="btn btn-danger">Reject</button>  
               
                </div>
                <div class="card-footer">
                </div>
               </div>
               -->
               
	
 



 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Police Officer Records</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Police Officer Records</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Modal to view attachments -->
    <div class="modal fade" id="attachModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">View attachments</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
			<table id="attachTable" style="border-collapse: collapse; border: none;"></table>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->

 

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			<!-- Add new record button -->
			<div class="col-lg-1">
			<a href="<?= base_url("frontend/subject_records/police/add"); ?>">
			<button type="button" class="btn btn-primary" >Add  <i class="bx bx-plus"></i></button></a>
			</div>
          <div class="col-lg-12">
			<!-- Card for form goes here
			-->
			<p></p>
			<!-- Search form -->
			 <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Wildcard search</h3>
              </div>
              <?= form_open(base_url("frontend/subject_records/police/search"), ['id' => 'searchForm']); ?>
              <div class="card-body">
                <div class="row">
				  <div class="col-2">
                    <input type="text" class="form-control" name="subject_id" placeholder="CABIS ID">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="first_name" placeholder="First Name">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="last_name" placeholder="Last Name">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="nin" placeholder="NIN">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="employee_number" placeholder="Employee Number">
                  </div>
                   <div class="col-2">
                    <input type="text" class="form-control" name="start_date" placeholder="Start Date">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="end_date" placeholder="End Date">
                  </div>
                 <button type="submit" class="btn btn-primary">Search</button>
                 </div>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            </form>
            <!-- /.card -->
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title">Police Officer entries</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
					<th>CABIS ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Employee No</th>
                    <th>NIN</th>
                    <th>&nbsp;</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  foreach($records as $record) {
					  print "<tr><td>{$record['subject_id']}</td>
					  <td>{$record['first_name']}</td>
					  <td>{$record['last_name']}</td>
					  <td>{$record['employee_number']}</td>
					  <td>{$record['nin']}</td><td>";
					  print "<a href=\"".base_url("frontend/subject_records/police/view/".$record['id'])."\">View</a>";
					  print "</td></tr>";
				  }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>CABIS ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Employee No</th>
                    <th>NIN</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->
            <!-- /.card -->

          </div>
          <!-- /.col-md-12 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

<script>
  //This sets custom code to be run once the page is loaded
  //var pageCode='SubjectRecordLoadCabis("<?php print $record['subject_id']; ?>");
  //SubjectRecordLoadCaseTracking("<?php print $record['case_tracking_id']; ?>");
  //';
</script>

<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Subject Record</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Criminal Subject Record</li>
  </ol>
</div>

<!-- Modal to allow add and edit -->
<div class="modal fade" id="editModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add/Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?= form_open_multipart(base_url("frontend/subject_records/criminal/submit"), ['id' => 'modalForm']); ?>
      <div class="modal-body">
        <?php
        foreach ($fields as $field) {
          if (in_array($field['type'], ['text', 'number'])) {
        ?>
            <div class="form-group">
              <label for="<?= $field['db_name']; ?>"><?= $field['name']; ?></label>
              <input type="text" class="form-control" id="modal_<?= $field['db_name']; ?>" name="<?= $field['db_name']; ?>" placeholder="<?= $field['description']; ?>">
            </div>
        <?php }
          if ($field['type'] == 'hidden') {
            $hidden_data = [
              'type'  => 'hidden',
              'name'  => $field['db_name'],
              'id'    => 'modal_' . $field['db_name']
            ];

            echo form_input($hidden_data);
          }
        }
        ?>
        <div class="form-group">
          <label for="cr_scan">Upload Scan of paper record (pdf,png,jpg,tiff)</label>
          <div class="input-group">
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="cr_scan" name="cr_scan">
              <label class="custom-file-label" for="cr_scan">Choose file</label>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>
      </div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<!-- Modal to add file -->
<div class="modal fade" id="fileModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">Add File</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="http://127.0.0.1/ecro/frontend/subject_records/submit" id="modalForm" enctype="multipart/form-data" method="post" accept-charset="utf-8">
        <div class="modal-body">
          <div class="form-group">
            <label for="name">Name</label>
            <input type="text" class="form-control" id="modal_name" name="name" placeholder="Name of file/document">
          </div>
          <div class="form-group">
            <label for="subject_id">Description</label>
            <input type="text" class="form-control" id="modal_subject_id" name="subject_id" placeholder="Description of file/document">
          </div>
          <div class="form-group">
            <label for="cr_scan">Upload Scan of paper record (pdf,png,jpg,tiff)</label>
            <div class="input-group">
              <div class="custom-file">
                <input type="file" class="custom-file-input" id="cr_scan" name="cr_scan">
                <label class="custom-file-label" for="cr_scan">Choose file</label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer justify-content-between">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save changes</button>
        </div>
        <div style="display:none"><label>Fill This Field</label><input type="text" name="honeypot" value="" /></div>
      </form>
    </div>
    <!-- /.modal-content -->
  </div>
  <!-- /.modal-dialog -->
</div>
<!-- /.modal -->

<!-- Main content -->
  <div class="container-fluid">
    <div class="row">
      <!-- Edit record button -->
      <div class="col-lg-1">
        <a href=<?= base_url("frontend/subject_records/criminal/edit/" . $record['id']); ?>><button type="button" class="btn btn-block btn-primary" onClick="clearModal();">Edit <i class="fa fa-plus"></i></button></a>
      </div>
      <div class="col-lg-12">
        <div class="row">
          <div class="col-lg-8">
            <!-- general form elements -->
            <!-- /.card-header -->
            <div class="card">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#summary" data-toggle="tab">Summary</a></li>
                  <li class="nav-item"><a class="nav-link" href="#cabis" data-toggle="tab">CABIS</a></li>
                  <!-- <li class="nav-item"><a class="nav-link" href="#case" data-toggle="tab">Case Tracking</a></li> -->
                  <li class="nav-item"><a class="nav-link" href="#criminal" data-toggle="tab">Criminal records</a></li>
                  <li class="nav-item"><a class="nav-link" href="#related" data-toggle="tab">Other records</a></li>
                  <li class="nav-item"><a class="nav-link" href="#nira" data-toggle="tab">NIRA</a></li>
                  <li class="nav-item"><a class="nav-link" href="#attachments" data-toggle="tab">Attachments</a></li>

                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="summary">
                    <table id="data" class="table table-bordered table-striped">
                      <tbody>
                        <tr>
                          <td>First Name </td>
                          <td><?= $record['first_name']; ?></td>
                        </tr>
                        <tr>
                          <td>Last Name </td>
                          <td><?= $record['last_name']; ?></td>
                        </tr>
                        <tr>
                          <td>CABIS ID</td>
                          <td><?= $record['subject_id']; ?></td>
                        </tr>
                        <tr>
                          <td>Overview</td>
                          <td><?= $case['details']['description'] ?? ''; ?></td>
                        </tr>
                        <tr>
                          <td>Station</td>
                          <td><?= $record['station'] ?? ''; ?></td>
                        </tr>
                        <tr>
                          <td>Aliases </td>
                          <td><?= $record['aliases']; ?></td>
                          </t


                            </tbody>
                    </table>
                    <p></p>
                    <form action="<?php print base_url('frontend/redlist/modify'); ?>" method="POST">
                      <?php print form_hidden('last_url', $_SERVER['REQUEST_URI']);
                      print form_hidden('subject_id', $subject['id']); ?>
                      <div class="col-sm-2">
                        <?php if ($subject['red_list'] == 1) {
                        ?>
                          <button class="btn btn-danger" type="submit">Remove from Red List</button>
                        <?php } else { ?>
                          <button class="btn btn-danger" type="submit">Add to Red List</button>
                        <?php } ?>
                      </div>
                    </form>
                    <p></p>
                    <p></p>

                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="cabis">

                    <?php
                    if ($cabis_present) { ?>
                      <a class="btn btn-primary" target="_blank" href="<?= base_url('/frontend/subject_records/form20/' . $record['subject_id']); ?>">Download Form 20</a><br>
                      <p></p>
                    <?php } ?>

                  </div>
                  <!-- /.tab-pane -->
                  <!-- <div class="tab-pane" id="case">
					  <?php if ($case != null) {
              if (array_key_exists('investigatingOfficer',  $case['details'])) {
                $officer_name = ($case['details']['investigatingOfficer']['cardDetails']['firstName'] ?? '') . " " . ($case['details']['investigatingOfficer']['cardDetails']['lastName'] ?? '');
              } else {
                $officer_name = "&nbsp;";
              }
              $offenses = "";
              if (array_key_exists('offenses',  $case['details'])) {
                foreach ($case['details']['offenses'] as $offense) {
                  $offenses .= $offense['offenseCode']['label'] . ' ';
                }
              }
              $station = "Not specified";
              if (array_key_exists('group', $case)) {
                $station = $case['group']['label'];
              }

              $case_relation = '&nbsp;';
              if ($person) {
                $case_relation = $person['details']['caseRelationship']['label'] ?? '&nbsp;';
              }

            ?>
				<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>Offense</td><td><?= $offenses ?></td></tr>
					  <tr><td>Description</td><td><?php if (array_key_exists('description',  $case['details'])) {
                                          echo $case['details']['description'];
                                        } else {
                                          echo "&nbsp;";
                                        } ?></td></tr>
					  <tr><td>CRB Number</td><td><?php if (array_key_exists('caseNumber',  $case['details'])) {
                                          echo $case['details']['caseNumber'];
                                        } else {
                                          echo "&nbsp;";
                                        } ?></td></tr>
					  <tr><td>Relation to Case</td><td><?= $case_relation; ?></td></tr>
					  <tr><td>Investigating Officer</td><td><?= $officer_name; ?></td></tr>
					  <tr><td>Originating Station</td><td><?= $station; ?></td></tr>
					  <tr><td>Case Created Date</td><td><?= date('Y-m-d', strtotime($case['createdDate'])); ?></td></tr>
					  <tr><td>Last Modified Date</td><td><?= date('Y-m-d', strtotime($case['modifiedDate'])); ?></td></tr>           
                  </tbody>
                </table>
                <?php } else {
                print "No case data";
              } ?>
				</div> -->
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="criminal">
                    <?= $this->include('SubjectRecords/criminal_records') ?>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="related">
                    <?= $this->include('SubjectRecords/related_records') ?>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="nira">
                    <!-- /.card-header -->
                    <?= $this->include('SubjectRecords/nira') ?>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="attachments">
                    <!-- /.card-header -->
                    <?= $this->include('SubjectRecords/attachments') ?>
                  </div>
                </div>
                <!-- /.tab-content -->
              </div>
            </div>
          </div>

      <div class="col-lg-4">

        <?php
        if ($cabis_present) { ?>
          <img src="<?php print base_url('ajax/get_cabis?token=' . $_SESSION['AJAX_TOKEN'] . '&id=' . $record['subject_id'] . '&tag=705'); ?>" class="right-photo"> <?php } else {
                                                                                                                                                                    print "Picture not available";
                                                                                                                                                                  } ?>
      </div>
  </div>
</div>

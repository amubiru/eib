<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>CABIS ID</td><td><?= $data[CABISID] ?? '-'; ?></td></tr>
					  <tr><td>First Name</td><td><?= $data[FirstName] ?? ''; ?></td></tr>
					  <tr><td>Last Name</td><td><?= $data[LastName] ?? ''; ?></td></tr>
					  <tr><td>Middle Name</td><td><?= $data[MiddleName] ?? ''; ?></td></tr>
					  <tr><td>Date of Birth</td><td><?= $data[DateOfBirth] ?? ''; ?></td></tr>
					  <tr><td>NIN</td><td><?= $data[NINID] ?? ''; ?></td></tr>
					  <tr><td>Date of Record</td><td><?= $data[Date] ?? ''; ?></td></tr>
					  <tr><td>Criminal/Police Record</td><td><?= $data[CriminalRecord] ?? ''; ?></td></tr>
					  <tr><td colspan=2>
					  <?php 
					  			  print '<center><img src="'.base_url('ajax/get_cabis?id='.$data[CABISID].'&tag=705').'"></center>';
					  
					  ?>
					  </td></tr>
					
                  </tbody>
                </table>

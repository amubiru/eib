<!-- Include file for other records -->
<div class="card">
              <div class="card-header">
                <h3 class="card-title"><strong>Cross References</strong></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
				  <!--
				  <select name=type><option>ALL</option><option>Criminal</option><option>Civilain</option><option>Police</option><option>PSO</option></select>
                -->
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
					<th>Date</th>
					<th>Type</th>
                    <th>Details</th>
                    <th>&nbsp;</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  if(count($related_records)) {
                  foreach($related_records as $record) {
					  if($record['type'] == 'CRIMINAL') {
						  continue;
					  }
					  
					  print "<tr><td>{$record['date']}</td>
					  <td>{$record['type']}</td>
					  <td>{$record['details']}</td>
					  <td><a href=\"{$record['link']}\">View</a></td>";

					print "</tr>\n";
				  }
			  } else { print "<tr><td colspan=4><center>No related records</center></td></tr>"; }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
					<th>Date</th>
					<th>Type</th>
                    <th>Details</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->
            </div>

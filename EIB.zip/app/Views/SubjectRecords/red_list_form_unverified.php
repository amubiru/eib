
 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Red List submission</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Add to red list</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

      
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			
          <div class="col-lg-8">

			 <!-- general form elements -->
              <!-- /.card -->
              <div class="card">
              <div class="card-header d-flex p-0">
             
              </div><!-- /.card-body -->
              <div class="card-body">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>First Name</td><td><?= $person['first_name']; ?></td></tr>
					  <tr><td>Last Name</td><td><?= $person['last_name']; ?></td></tr>
                  </tbody>
                </table>
               
                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                </div>
            </div>

            <h3>Remarks</h3>
             <?php print form_open(base_url("frontend/redlist/submit_unverified"), ['id' => 'redListForm']); 
				   print form_hidden('last_url', $last_url);
				   print form_hidden('person_id', $person['id']);
				  
             ?>
              <div class="card-body">
                <div class="row">
					
                    <textarea class="form-control" cols=60 rows=5 name="reason" placeholder="Enter reason"></textarea>
                 <button type="submit" class="btn btn-primary">Submit</button>
                 </div>
                </div>
            </form>

			<div class="col-lg-1">
			
			</div>
          <div class="col-lg-12">

			 <!-- general form elements -->
            
          </div>
          <!-- /.col-md-8 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

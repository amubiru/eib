<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>NIN</td><td><?= $nin['nationalId'] ?? '-'; ?></td></tr>
					  <tr><td>First Name</td><td><?= $nin['givenNames'] ?? ''; ?></td></tr>
					  <tr><td>Last Name</td><td><?= $nin['surname'] ?? ''; ?></td></tr>
					  <tr><td>Date of Birth</td><td><?= $nin['dateOfBirth'] ?? ''; ?></td></tr>
					  <tr><td colspan=2>
					  <?php 
					  if(strlen($nin['photo'] ?? '')>1) {
						  print '<center><img src="data:image/png;base64,'.$nin['photo'].'"></center>';
					  }
					  ?>
					  </td></tr>
					
                  </tbody>
                </table>

<!-- Include file for attachments -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title">Associated files/images</h3>
  </div>
  <!-- Add new attachment button -->
  <div class="col-lg-2">
    <form action="<?= base_url("frontend/subject_records/add_attachment"); ?>" method="POST">
      <?= form_hidden('subject_id', $subject['id']); ?>
      <?= form_hidden('link_id', $record['id']); ?>
      <?= form_hidden('type', $record['type']); ?>
      <?= form_hidden('last_url', $_SERVER['REQUEST_URI']); ?>
      <input type="submit" class="btn btn-primary" value="Add">
    </form>
  </div>
  <div class="card-body">
    <table id="data" class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Name</th>
          <th>Description</th>
          <th>Type</th>
          <th>Added</th>
          <th>Link</th>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach ($attachments as $att) {
          print "<tr><td>{$att['name']}</td><td>{$att['description']}</td><td>{$att['file_type_readable']}</td><td>{$att['created_at']}</td><td><a target=\"_blank\" href=\"" . base_url("/frontend/attachments/" . $att['id']) . "\" >View/download</a></td></tr>\n";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>
<table id="data" class="table table-bordered table-striped">
	<tbody>
		<?php
		foreach ($application ?? [] as $key => $value) {
			print "<tr><td>$key</td><td>$value</td></tr>\n";
		}
		?>
		<tr>
			<td colspan=4>
				<?php
				print '<center><img src="' . base_url('ajax/get_cabis?token=' . $_SESSION['AJAX_TOKEN'] . '&id=' . $extra['cabis_id'] . '&tag=705') . '"></center>';

				?>
			</td>
		</tr>
	</tbody>
</table>
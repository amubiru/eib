<table id="data" class="table table-bordered table-striped">
	<tbody>
		<tr>
			<td>First Name</td>
			<td><?= $data['first_name'] ?? '-'; ?></td>
		</tr>
		<tr>
			<td>Last Name</td>
			<td><?= $data['last_name'] ?? ''; ?></td>
		</tr>
		<tr>
			<td>Offense</td>
			<td><?= $data['offence'] ?? ''; ?></td>
		</tr>
		<tr>
			<td>Date and place of trial</td>
			<td><?= $data['court_place_trial'] ?? ''; ?></td>
		</tr>
		<tr>
			<td>Sentence</td>
			<td><?= $data['sentence_type'] ?? ''; ?></td>
		</tr>
		<tr>
			<td colspan=2>
				<?php
				print '<center><img src=' . base_url('ajax/get_cabis?token=' . $_SESSION['AJAX_TOKEN'] . '&id=' . $extra['cabis_id'] . '&tag=705') . '"></center>';
				?>
			</td>
		</tr>

	</tbody>
</table>
<table id="data" class="table table-bordered table-striped">
	<tbody>
		<?php
		foreach ($application ?? [] as $key => $value) {
			print "<tr><td>$key</td><td>$value</td></tr>\n";
		}
		?>
	</tbody>
</table>
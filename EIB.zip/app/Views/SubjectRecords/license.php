<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>Permit Number</td><td><?= $license['permit_no'] ?? '-'; ?></td></tr>
					  <tr><td>Name</td><td><?= $license['offendersName'] ?? ''; ?></td></tr>
					  <tr><td>Gender</td><td><?= $license['gender'] ?? ''; ?></td></tr>
					  <tr><td>Date of Birth</td><td><?= $license['dob'] ?? ''; ?></td></tr>
					  <tr><td>Permit Expiry</td><td><?= $license['permit_expiry'] ?? ''; ?></td></tr>
					  <tr><td>Permit Class</td><td><?= $license['permitClass'] ?? ''; ?></td></tr>
					  <tr><td>Driver Restriction</td><td><?= $license['drive_restriction'] ?? ''; ?></td></tr>
					  <tr><td>Vehicle Restriction</td><td><?= $license['vehicle_restriction'] ?? ''; ?></td></tr>
					  <tr><td colspan=2>
					  <?php 
					  if(strlen($license['photo'] ?? '')>1) {
						  print '<center><img src="data:image/png;base64,'.$license['photo'].'"></center>';
					  }
					  ?>
					  </td></tr>
					
                  </tbody>
                </table>

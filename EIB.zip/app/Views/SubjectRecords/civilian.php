<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Civilian Record</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Civilian Record</li>
  </ol>
</div><!-- /.col -->
</div><!-- /.row -->
</div><!-- /.container-fluid -->
</div>
<!-- /.content-header -->


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- Edit record button -
			<div class="col-lg-1">
			<a href=<?= base_url("frontend/subject_records/civilian/edit/" . $record['id']); ?>><button type="button" class="btn btn-block btn-primary" onClick="clearModal();">Edit  <i class="fa fa-plus"></i></button></a>
			</div> -->
      <div class="col-lg-12">
        <div class="row">
          <div class="col-lg-8">
            <!-- general form elements -->
            <!-- /.card-header -->
            <div class="card">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#summary" data-toggle="tab">Summary</a></li>
                  <li class="nav-item"><a class="nav-link" href="#application" data-toggle="tab">Application Data</a></li>
                  <li class="nav-item"><a class="nav-link" href="#cabis" data-toggle="tab">CABIS</a></li>
                  <li class="nav-item"><a class="nav-link" href="#related" data-toggle="tab">All records</a></li>
                  <li class="nav-item"><a class="nav-link" href="#nira" data-toggle="tab">NIRA</a></li>
                  <li class="nav-item"><a class="nav-link" href="#attachments" data-toggle="tab">Attachments</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="summary">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>First Name</td><td><?= $record['first_name']; ?></td></tr>
					  <tr><td>Last Name</td><td><?= $record['last_name']; ?></td></tr>
					  <tr><td>Subject ID</td><td><?= $record['subject_id']; ?></td></tr>
					  <tr><td>ID Number</td><td><?= $record['id_number']; ?></td></tr>
					  <tr><td>PRN</td><td><?= $record['prn']; ?></td></tr>
					  <tr><td>Status</td><td><?= $record['status']; ?></td></tr>
					  <tr><td>Adverse police notice</td><td><?= $record['adverse_police_notice']; ?></td></tr>
					 <?php
					if($cabis_present && in_array($record['status'], ['PROCESSED','RESOLVED'])) { ?>
					<tr><td><a class="btn btn-primary" target="_blank" href="<?= base_url('/pub/forms/cogc/'.$record['uuid']); ?>">View Certificate of Good Conduct</a></td><td><a class="btn btn-primary" href="<?= base_url('/frontend/subject_records/civilian/email_cogc/'.$record['id']); ?>">Resend Certificate of Good Conduct</a></td></tr><tr><td>
					<?php 
					if(in_array($record['status'], ['PROCESSED','RESOLVED']) ) { ?>
                <!-- PCC exists, show button to send it -->
                <a class="btn btn-primary" target="_blank" href="<?= base_url('/frontend/subject_records/email_pcc/'.$record['id']); ?>">View Police Clearance Certificate</a>
                <?php if(!$permanent_records) { ?>
				<!-- <br><a class="btn btn-primary" href="<?= base_url('/frontend/subject_records/email_cogc_pcc/'.$record['id']); ?>">Email Combined Police Clearance Certificate and Certificate of Good Conduct</a> -->
                <?php }
					
					}
					} print "</td><td>";
					//Allow people with the correct permissions 
					if(in_array($record['status'], ['PROCESSED','RESOLVED']) || (hasPermission('requeue_rejected_applications') && $record['status'] == 'REJECTED')  ) { ?>
                <!-- PCC exists, show button to return record to queue -->
                <a onClick="return confirm('Are you sure you want to return this record to the queue');" class="btn btn-warning" href="<?= base_url('/frontend/subject_records/requeue/'.$record['id']); ?>">Return to Queue</a>
                <?php } 
					print "</td></tr>" ?>
                  </tbody>
                </table>
                <p></p>
<form action="<?php print base_url('frontend/redlist/modify'); ?>" method="POST">
					<?php print form_hidden('last_url', $_SERVER['REQUEST_URI']);
					print form_hidden('subject_id', $subject['id']); ?>
<div class="col-sm-2">
<?php if($subject['red_list']==1) {
	?>
<button class="btn btn-danger" type="submit">Remove from Red List</button>
<?php } else { ?>
<button class="btn btn-danger" type="submit">Add to Red List</button>
<?php } ?>
</div>
</form>
<p></p><p></p>
                
                </div>
                <!-- /.tab-pane -->
                  <div class="tab-pane" id="application">
                    <?= $this->include('SubjectRecords/civilian_application',) ?>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="cabis">
                    <?php
                    if ($cabis_present) { ?>
                      <a class="btn btn-primary" target="_blank" href="<?= base_url('/frontend/subject_records/form20/' . $record['subject_id']); ?>">Download Form 20</a><br>
                    <?php } ?>

                    <!-- /.tab-content -->
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="related">
                    <?= $this->include('SubjectRecords/related_records',) ?>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="nira">
                    <!-- /.card-header -->
                    <?= $this->include('SubjectRecords/nira',) ?>
                  </div>
                  <!-- /.tab-pane -->
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="attachments">
                    <!-- /.card-header -->
                    <?= $this->include('SubjectRecords/attachments',) ?>
                  </div>
                  <!-- /.tab-pane -->
                  <!-- /.card-body -->

                  <div class="card-footer">
                  </div>
                </div>
                <!-- /.card -->



                <!-- /.row -->
              </div><!-- /.container-fluid -->
            </div>
          </div>

        <div class="col-lg-4">

          <?php
          if ($cabis_present) { ?>
            <img src="<?php print base_url('ajax/get_cabis?token=' . $_SESSION['AJAX_TOKEN'] . '&id=' . $record['subject_id'] . '&tag=705'); ?>" class="right-photo"> <?php } else {
                                                                                                                                                                      print "Picture not available";
                                                                                                                                                                    } ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Generate Police Clearance Certificate</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item"><a href="<?php echo base_url('/subject_records/' . $type . '/view/' . $subject['id']); ?>"><?= ucfirst($type) . ' Subject Records'; ?></a></li>
    <li class="breadcrumb-item active">Generate PCC</li>
  </ol>
</div><!-- /.col -->

<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">

      <div class="col-lg-8">

        <!-- general form elements -->
        <!-- /.card -->
        <div class="card">
          <div class="card-header d-flex p-0">

          </div><!-- /.card-body -->
          <div class="card-body">
            <table id="data" class="table table-bordered table-striped">
              <tbody>
                <tr>
                  <td>First Name</td>
                  <td><?= $subject['first_name']; ?></td>
                </tr>
                <tr>
                  <td>Last Name</td>
                  <td><?= $subject['last_name']; ?></td>
                </tr>
                <tr>
                  <td>ID Number</td>
                  <td><?= $subject['id_number']; ?></td>
                </tr>
                <tr>
                  <td>PRN</td>
                  <td><?= $subject['prn']; ?></td>
                </tr>
                <tr>
                  <td>CABIS ID</td>
                  <td><?= $subject['cabis_id']; ?></td>
                </tr>
                <?php if (strlen($subject['force_number'] ?? '')) { ?>
                  <tr>
                    <td>CABIS ID</td>
                    <td><?= $subject['force_number']; ?></td>
                  </tr>
                <?php } ?>
              </tbody>
            </table>

          </div>
          <!-- /.card-body -->
          <div class="card-footer">
          </div>
        </div>
        <!-- /.card -->
        <div class="col-lg-1">
          <a href="<?= base_url("frontend/subject_records/criminal/add"); ?>">
            <button type="button" class="btn btn-primary">Add offense <i class="bx bx-plus"></i></button></a>
        </div>
        <h3>Offences</h3>
        <?php if ($offenses) { ?>
          <!-- /.card-header -->
          <div class="card">
            <div class="card-header d-flex p-0">

            </div><!-- /.card-body -->
            <div class="card-body">
              <table id="data" class="table table-bordered table-striped">
                <tbody>
                  <tr>
                    <th>Date Sentenced</th>
                    <th>Offense</th>
                    </th>
                    <th>Sentence</th>
                  </tr>
                  <?php foreach ($offenses as $offense) {
                    print "<tr><th>" . $offense['date_sentence'] . "</th><th>" . $offense['offence'] . "</th></th><th>" . $offense['sentence_units'] . ' ' . $offense['sentence_amount'] . "</th></tr>\n";
                  }
                  ?>
                </tbody>
              </table>

            </div>
            <!-- /.card-body -->
            <div class="card-footer">
            </div>
          </div>
          <!-- /.card -->
        <?php } else {
          print "No offences";
        } ?>
        <p></p>
        <h3>Adverse police notice</h3>
        <?php print form_open(base_url("frontend/subject_records/submit_pcc"), ['id' => 'pccForm']);
        print form_hidden('type', $type);
        print form_hidden('id', $subject['id']);
        print form_hidden('source', $source ?? '');
        if (isset($civilian_id)) {
          print form_hidden('civilian_id', $civilian_id);
        }
        ?>
        <div class="card-body">
          <div class="row">
            <div class="col-6">
              Email: <input type="text" class="form-control" name="email" value="<?php echo $subject['email'] ?? ''; ?>" placeholder="Email address">
            </div><br>
            <textarea class="form-control" cols=60 rows=5 name="adverse_police_notice" placeholder="Enter adverse police notice"></textarea>
            <button type="submit" class="btn btn-primary">Submit</button>
          </div>
        </div>
        </form>

        <div class="col-lg-1">

        </div>
        <div class="col-lg-12">

          <!-- general form elements -->

        </div>
        <!-- /.col-md-8 -->
      </div><img src="<?php print base_url('ajax/get_cabis?token=' . $_SESSION['AJAX_TOKEN'] . '&id=' . $subject['cabis_id'] . '&tag=705'); ?>" class="right-photo">
      <!-- /.row -->
    </div>
  </div>
</div>
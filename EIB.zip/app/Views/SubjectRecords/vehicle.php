<?php
$human_readable_keys = array(
  "MVRegNo" => "MV Registration No",
  "ChasisNo" => "Chassis No",
  "Color" => "Color",
  "CountryOfOrigin" => "Country of Origin",
  "DateOfRegistration" => "Date of Registration",
  "EngineNo" => "Engine No",
  "FrontPlateShape" => "Front Plate Shape",
  "backPlateShape" => "Back Plate Shape",
  "Fuel" => "Fuel Type",
  "NetWeight" => "Net Weight (kg)",
  "GrossWeight" => "Gross Weight (kg)",
  "TyreSize" => "Tyre Size",
  "IsUsedVehicle" => "Used Vehicle",
  "Make" => "Make",
  "ManufactureYear" => "Year of Manufacture",
  "ModelName" => "Model Name",
  "BodyDesc" => "Body Description",
  "CategoryName" => "Category Name",
  "VehicleClassification" => "Vehicle Classification",
  "NumberOfAxels" => "Number of Axles",
  "Power" => "Engine Power (cc)",
  "PrevRegCountry" => "Previous Registration Country",
  "PrevregDate" => "Previous Registration Date",
  "PrevRegNo" => "Previous Registration No",
  "Purpose" => "Purpose",
  "SeatCapacity" => "Seat Capacity",
  "OwnerCategory" => "Owner Category",
  "TaxPayerName" => "Tax Payer Name",
  "MobileNumber" => "Mobile Number",
  "Email" => "Email Address",
  "TaxPayerType" => "Tax Payer Type",
  "TinIssueDate" => "TIN Issue Date",
  "TinNo" => "TIN No"
);
?>
<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <?php
					  $keys = array_keys($human_readable_keys);
						for ($i = 0; $i < count($keys); $i += 2) {
						  echo "<tr>";
						  $key1 = $keys[$i];
						  echo "<td>" . $human_readable_keys[$key1] . "</td>";
						  echo "<td>" . (isset($data[$key1]) ? $data[$key1] : "") . "</td>";
						  if (isset($keys[$i + 1])) {
							$key2 = $keys[$i + 1];
							echo "<td>" . $human_readable_keys[$key2] . "</td>";
							echo "<td>" . (isset($data[$key2]) ? $data[$key2] : "") . "</td>";
						  } else {
							echo "<td></td><td></td>";
						  }
						  echo "</tr>";
						}
						?>
					
                  </tbody>
                </table>

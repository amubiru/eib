<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Queue Records</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Queue Records</li>
  </ol>
</div><!-- /.col -->

<!-- /.content-header -->
<!-- Modal to view attachments -->
<div class="modal fade" id="attachModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title">View attachments</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table id="attachTable" style="border-collapse: collapse; border: none;"></table>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">

      <div class="col-lg-12">
        <!-- Card for form goes here
			-->
        <p></p>
        <!-- Search form -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Wildcard search</h3>
          </div>
          <?= form_open(base_url("frontend/subject_records/civilian/queue_search"), ['id' => 'searchForm']); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-2">
                <input type="text" class="form-control" name="first_name" placeholder="First Name">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="last_name" placeholder="Last Name">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="subject_id" placeholder="CABIS no">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="id_number" placeholder="ID Number">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="prn" placeholder="PRN">
              </div>
              <div class="col-2">
                <?= form_dropdown('queue_type', ['ALL' => 'ALL', 'CIVILIAN' => 'CIVILIAN', 'POLICE' => 'POLICE', 'CRIMINAL' => 'CRIMINAL']); ?>
              </div>
              <div class="col-2">
                <div class="input-group date" id="start_date" data-target-input="nearest">
                  <input type="text" class="form-control datetimepicker-input" name="start_date" data-target="#start_date" placeholder="App Start Date" />
                  <div class="input-group-append" data-target="#start_date" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="input-group date" id="end_date" data-target-input="nearest">
                  <input type="text" class="form-control datetimepicker-input" name="end_date" data-target="#end_date" placeholder="App End Date" />
                  <div class="input-group-append" data-target="#end_date" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="input-group date" id="fp_start_date" data-target-input="nearest">
                  <input type="text" class="form-control datetimepicker-input" name="fp_start_date" data-target="#fp_start_date" placeholder="FP Start Date" />
                  <div class="input-group-append" data-target="#fp_start_date" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <div class="input-group date" id="fp_end_date" data-target-input="nearest">
                  <input type="text" class="form-control datetimepicker-input" name="fp_end_date" data-target="#fp_end_date" placeholder="FP End Date" />
                  <div class="input-group-append" data-target="#fp_end_date" data-toggle="datetimepicker">
                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                  </div>
                </div>
              </div>
              <button type="submit" class="btn btn-primary">Search</button>
            </div>
          </div>
        </div>
        <!-- /.card-body -->
      </div>
      </form>
      <!-- /.card -->
      <!-- general form elements -->
      <!-- /.card-header -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Queue entries</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
          <table id="dataTable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>CABIS ID</th>
                <th>ID Number</th>
                <th>PRN</th>
                <th>Queue Type</th>
                <th>Photos / Attachments</th>
                <th>&nbsp;</th>
              </tr>
            </thead>
            <tbody>
              <?php

              foreach ($records as $record) {
                //Set record color
                //if(!isset($record['scan_file'])) {
                //	  $class='style="background-color:#f2f200"';
                // } else {
                $class = "";
                //}
                print "<tr $class><td>{$record['first_name']}</td>
					  <td>{$record['last_name']}</td>
					  <td>{$record['subject_id']}</td>
					  <td>{$record['id_number']}</td>
					  <td>{$record['prn']}</td>
					  <td>{$record['queue_type']}</td>\n";
                //List attachments
                print "<td>";
                $num_attach = count($record['attachments']);
                print $num_attach . "&nbsp;";
                print "</td>\n";
                //Show edit and delete options
                print "<td>&nbsp;";
                print "<a href=\"" . base_url("frontend/subject_records/civilian/queue_view/" . $record['id']) . "\">View</a>";
                print "&nbsp;&nbsp;";
                //print "<span title='Delete'><a class='red' href='".base_url($controller['route']."/delete/".$record['id'])."' onClick=\"return confirm('Are you sure you want to delete this item');\">".'<i class="fa fa-times" title="Delete" ></i></a></span>';
                //if(isset($record['scan_file'])) {
                // print '<a target="_blank" rel="noopener noreferrer" href="'.base_url('frontend/subject_records/image/'.$record['id']).'">Scan</a><br>';
                //}
                print "</td>";
                print "</tr>\n";
              }
              ?>
            </tbody>
            <tfoot>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>CABIS ID</th>
                <th>ID Number</th>
                <th>PRN</th>
                <th>Status</th>
                <th>Photos / Attachments</th>
                <th>&nbsp;</th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Include file for other records -->
<div class="card">
              <div class="card-header">
                <h3 class="card-title"><strong>History</strong></h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
				  <!--
				  <select name=type><option>ALL</option><option>Criminal</option><option>Civilain</option><option>Police</option><option>PSO</option></select>
                -->
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
					<th>Date</th>
					<th>First Name</th>
					<th>Last Name</th>
                    <th>Remarks</th>
                    <th>Photo</th>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  if(count($records)) {
                  foreach($records as $r_record) {
					  
					  print "<tr><td>{$r_record['created_at']}</td>
					  <td>{$r_record['first_name']}</td>
					  <td>{$r_record['last_name']}</td>
					  <td>{$r_record['remarks']}</td>";
					  if(strlen($r_record['photo'] ?? '') > 5) {
						print "<td><img src=\"data:image/png;base64, {$r_record['photo']}\"></td>";
					} else {
						print "<td>&nbsp;</td>";
						}

					print "</tr>\n";
				  }
			  } else { print "<tr><td colspan=4><center>No history</center></td></tr>"; }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
					<th>Date</th>
					<th>Type</th>
                    <th>Details</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->
            </div>

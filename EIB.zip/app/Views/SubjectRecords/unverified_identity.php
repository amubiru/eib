
 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Unverified Identity</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Unverified Identity Record</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

      
    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			
          <div class="col-lg-12">
			  <div class="row">
			<div class="col-lg-8">
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#summary" data-toggle="tab">Summary</a></li>
                  <li class="nav-item"><a class="nav-link" href="#nira" data-toggle="tab">NIRA</a></li>
                  <li class="nav-item"><a class="nav-link" href="#history" data-toggle="tab">History</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
				  <div class="tab-content">
                  <div class="tab-pane active" id="summary">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>First Name</td><td><?= $record['first_name']; ?></td></tr>
					  <tr><td>Last Name</td><td><?= $record['last_name']; ?></td></tr>
					  <tr><td>ID Number</td><td><?= $record['id_number']; ?></td></tr>
					  <tr><td>Remarks</td><td><?= $record['remarks']; ?></td></tr>
					  <tr><td>Created</td><td><?= date('Y-m-d', strtotime($record['created_at'])); ?></td></tr>
                  </tbody>
                </table>
                <p></p>
<form action="<?php print base_url('frontend/redlist/modify_unverified'); ?>" method="POST">
					<?php print form_hidden('last_url', $_SERVER['REQUEST_URI']);
					print form_hidden('type', 'unverified');
					print form_hidden('person_id', $record['id']); ?>
<div class="col-sm-2">
<?php if($record['red_list']==1) {
	?>
<button class="btn btn-danger" type="submit">Remove from Red List</button>
<?php } else { ?>
<button class="btn btn-danger" type="submit">Add to Red List</button>
<?php } ?>
</div>
</form>
<p></p><p></p>
                
                </div>
                
				  <!-- /.tab-pane -->
				   <div class="tab-pane" id="nira">
					                <!-- /.card-header -->
              <?= $this->include('SubjectRecords/nira', ) ?> 
				  </div>
				  <div class="tab-pane" id="history">
					                <!-- /.card-header -->
              <?= $this->include('SubjectRecords/unverified_history', ) ?> 
				  </div>
				  <!-- /.tab-pane -->
				  <!-- /.tab-pane -->
                 
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
                        <!-- /.card -->
                        

          
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div></div>
    <div class="col-lg-4">
    
		<?php
		if($record['photo']) {
			print '<img src="data:image/png;base64, '.$record['photo'].'">'; 
			} else { print "Picture not available"; } ?>
	</div>
	</div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

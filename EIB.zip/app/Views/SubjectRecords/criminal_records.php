<!-- Include file for other records -->
<div class="card">
  <div class="card-header">
    <h3 class="card-title"><strong>Criminal records</strong></h3>
  </div>
  <!-- /.card-header -->
  <div class="card-body">
    <!--
				  <select name=type><option>ALL</option><option>Criminal</option><option>Civilain</option><option>Police</option><option>PSO</option></select>
                -->
    <table id="dataTable" class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Place of Trial</th>
          <th>Date of Sentence</th>
          <th>Case Result</th>
          <th>Offense and section</th>
          <th>Name convicted under</th>
        </tr>
      </thead>
      <tbody>
        <?php
        if (count($related_records)) {
          foreach ($related_records as $record) {
            if ($record['type'] != 'CRIMINAL') {
              continue;
            }

            print "<tr><td>{$record['court_place_trial']}</td>
					  <td>{$record['date_sentence']}</td>
					  <td>{$record['result']}</td>
					  <td>{$record['offence']}</td>
					  <td>{$record['name']}</td>
					  <td><a href=\"{$record['link']}\">View</a></td>";

            print "</tr>\n";
          }
        } else {
          print "<tr><td colspan=4><center>No related records</center></td></tr>";
        }
        ?>
      </tbody>
      <tfoot>
        <tr>
          <th>Place of Trial</th>
          <th>Date of Sentence</th>
          <th>Case Result</th>
          <th>Offense and section</th>
          <th>Name convicted under</th>
        </tr>
      </tfoot>
    </table>
  </div>
</div>
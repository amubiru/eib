<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Criminal Subject Records</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Criminal Subject Records</li>
  </ol>
</div>

<div class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- Add new record button -->
      <div class="col-lg-1">
        <a href="<?= base_url("frontend/subject_records/criminal/add"); ?>">
          <button type="button" class="btn btn-primary">Add <i class="fa fa-plus"></i></button></a>
      </div>
      <div class="col-lg-12">
        <!-- Card for form goes here
			-->
        <p></p>
        <!-- Search form -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">Wildcard search</h3>
          </div>
          <?= form_open(base_url("frontend/subject_records/criminal/search"), ['id' => 'searchForm']); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-2">
                <input type="text" class="form-control" name="crb_no" placeholder="CRB Number">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="name" placeholder="Name">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="subject_id" placeholder="AFIS/CABIS no">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="station" placeholder="Station">
              </div>
              <div class="col-2">
                <select name="type" class="form-control" id="type">
                  <option value='ALL'>ALL</option>
                  <option value='TEMPORARY'>TEMPORARY RECORDS</option>
                  <option value='PERMANENT'>PERMANENT RECORDS</option>
                </select>
              </div>

              <div class="col-2"></div>
              <div class="col-2">
                <input type="text" class="form-control" name="start_date" placeholder="Start Date">
              </div>
              <div class="col-2">
                <input type="text" class="form-control" name="end_date" placeholder="End Date">
              </div>
              <button type="submit" class="btn btn-primary">Search</button>
            </div>
          </div>
        </div>
        <!-- /.card-body -->
      </div>
      </form>
      <!-- /.card -->
      <!-- general form elements -->
      <!-- /.card-header -->
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">Subject record entries</h3>
        </div>
        <!-- /.card-header -->
        <div class="card-body">
          <table id="dataTable" class="table table-bordered table-striped">
            <thead>
              <tr>
                <th>Subject ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Offence</th>
                <th>Case Result</th>
                <th>Date of Sentence</th>
                <th>Station</th>
                <th>Photos / Attachments</th>
                <th>&nbsp;</th>
              </tr>
            </thead>
            <tbody>
              <?php

              foreach ($records as $record) {
                //Set record color
                //if(!isset($record['scan_file'])) {
                //	  $class='style="background-color:#f2f200"';
                // } else {
                $class = "";
                //}
                print "<tr $class><td>{$record['subject_id']}</td>
					  <td>{$record['first_name']}</td>
					  <td>{$record['last_name']}</td>
					  <td>{$record['offence']}</td>
					  <td>{$record['result']}</td>
					  <td>{$record['date_sentence']}</td>
					  <td>{$record['station']}</td>\n";
                //List attachments
                print "<td>";
                $num_attach = count($record['attachments']);
                print $num_attach . "&nbsp;";
                print "</td>\n";
                //Show edit and delete options
                print "<td>&nbsp;";
                print "<a href=\"" . base_url("frontend/subject_records/criminal/view/" . $record['id']) . "\">View</a>";
                print "&nbsp;&nbsp;";
                //print "<span title='Delete'><a class='red' href='".base_url($controller['route']."/delete/".$record['id'])."' onClick=\"return confirm('Are you sure you want to delete this item');\">".'<i class="fa fa-times" title="Delete" ></i></a></span>';
                //if(isset($record['scan_file'])) {
                // print '<a target="_blank" rel="noopener noreferrer" href="'.base_url('frontend/subject_records/image/'.$record['id']).'">Scan</a><br>';
                //}
                print "</td>";
                print "</tr>\n";
              }
              ?>
            </tbody>
            <tfoot>
              <tr>
                <th>Subject ID</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Offence</th>
                <th>Case Result</th>
                <th>Date of Sentence</th>
                <th>Remarks</th>
                <th>Station</th>
                <th>Photos / Attachments</th>
                <th>&nbsp;</th>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
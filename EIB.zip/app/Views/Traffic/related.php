
              <div class="card">
              <div class="card-header">
                <h3 class="card-title">Traffic offense entries</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
					<th>Date</th>
					<th>ID Number</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Age</th>
                    <th>Offense</th>
                    <th>Penalty</th>
                    <th>Fine amount</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  
                  foreach($related as $related_record) {
					  //Set related_record color
					  //if(!isset($related_record['scan_file'])) {
					//	  $class='style="background-color:#f2f200"';
					 // } else {
						  $class="";
					  //}
					  //Don't show the same record in related records
					  if($related_record['id']=$record['id']) {
						  continue;
					  }
					  if($related_record['dob']) {
						  $age=floor((time()-strtotime($related_record['dob']))/YEAR);
					  } else {
						  $age="-";
					  }
					  print "<tr $class><td>".date('Y-m-d', strtotime($related_record['created_at']))."</td>
					  <td>{$related_record['id_number']}</td>
					  <td>{$related_record['first_name']}</td>
					  <td>{$related_record['last_name']}</td>
					  <td>$age</td>
					  <td>{$related_record['offense']}</td>
					  <td>{$related_record['penalty']}</td>
					  <td>"; print $related_record['amount']>0 ? number_format($related_record['amount'], 0) : "-"; print "</td>";

					   //Show edit and delete options
					  print "<td>&nbsp;";
					  print "<a href=\"".base_url("frontend/traffic/offenses/view/".$related_record['id'])."\">View</a>";
					  print "&nbsp;&nbsp;";
					  //print "<span title='Delete'><a class='red' href='".base_url($controller['route']."/delete/".$related_record['id'])."' onClick=\"return confirm('Are you sure you want to delete this item');\">".'<i class="fa fa-times" title="Delete" ></i></a></span>';
					  //if(isset($related_record['scan_file'])) {
						 // print '<a target="_blank" rel="noopener noreferrer" href="'.base_url('frontend/subject_related_records/image/'.$related_record['id']).'">Scan</a><br>';
					  //}
					  print "</td>";
					print "</tr>\n";
				  }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
					<th>Date</th>
					<th>ID Number</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Age</th>
                    <th>Offense</th>
                    <th>Penalty</th>
                    <th>Fine amount</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->

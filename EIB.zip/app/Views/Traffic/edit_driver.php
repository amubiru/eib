
          <div class="col-sm-6">
            <h1 class="m-0">Add/Edit Drivers</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active"><a href="<?php echo base_url('frontend/traffic/drivers'); ?>">Drivers</a></li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
			<!-- Card for form goes here
			-->
			<form method="post" action="<?= base_url('frontend/traffic/drivers/submit'); ?>">
			
            <div class="form-group">
                    <label for="name">First name</label>&nbsp;<font color=red>*</font>                    <input type=text required class="form-control" value="" id="modal_first_name" name="first_name" placeholder="First name">
                  </div>
                  <div class="form-group">
                    <label for="name">Last name</label>&nbsp;<font color=red>*</font>                    <input type=text required class="form-control" value="" id="modal_last_name" name="last_name" placeholder="Last name">
                  </div>                  					
                  					  <div class="form-group">
                    <label for="court_place_trial">National ID Number (NIN)</label>                   <input type=text class="form-control" value="" id="modal_nin" name="nin" placeholder="National ID Number">
                  </div>
                  <div class="form-group">
                    <label for="court_place_trial">Driving license number</label>                   <input type=text class="form-control" value="" id="modal_nin" name="driving_license" placeholder="Driving license Number">
                  </div>
                  					  <div class="form-group">
                    <label for="stage">Stage</label>                   <?php echo form_dropdown('stage', $stages, '', ['id' => 'stages', 'class' => 'form-control select2']); ?>
                  </div>
                  
			<div class="form-group">
              <button type="button" class="btn btn-default" onclick="window.history.back();">Cancel</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            <div style="display:none"><label>Fill This Field</label><input type="text" name="honeypot" value=""/></div></form>
			 <!-- general form elements -->
            

          </div>
          <!-- /.col-md-6 -->
          <div class="col-lg-6">
			  <img id="face_photo">
          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->


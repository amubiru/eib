

 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Traffic offenses</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Offenses</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Modal to view attachments -->
    <div class="modal fade" id="attachModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">View attachments</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
			<table id="attachTable" style="border-collapse: collapse; border: none;"></table>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->

 

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			<!-- Add new record button -->
	<!--		<div class="col-lg-1">
			<a href="<?= base_url("frontend/traffic/drivers/add"); ?>">
			<button type="button" class="btn btn-primary" >Register  <i class="fa fa-plus"></i></button></a>
			</div> -->
          <div class="col-lg-12">
			<!-- Card for form goes here
			-->
			<p></p>
			<!-- Search form -->
			 <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Wildcard search</h3>
              </div>
              <?= form_open(base_url("frontend/traffic/offenses/search"), ['id' => 'searchForm']); ?>
              <div class="card-body">
                <div class="row">
                  <div class="col-2">
                    <input type="text" class="form-control" name="id_number" placeholder="ID Number">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="number_plate" placeholder="Number Plate">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="nin" placeholder="NIN">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="offense" placeholder="Offense">
                  </div>
                   <div class="col-2">
                    <input type="text" class="form-control" name="start_date" placeholder="Start Date">
                  </div>
                  <div class="col-2">
                    <input type="text" class="form-control" name="end_date" placeholder="End Date">
                  </div>
                 <button type="submit" class="btn btn-primary">Search</button>
                 </div>
                </div>
              </div>
              <!-- /.card-body -->
            </div>
            </form>
            <!-- /.card -->
			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title">Traffic offense entries</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="dataTable" class="table table-bordered table-striped">
                  <thead>
                  <tr>
					<th>Date</th>
					<th>ID Number</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Age</th>
                    <th>Offense</th>
                    <th>Penalty</th>
                    <th>Fine amount</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tr>
                  </thead>
                  <tbody>
                  <?php
                  
                  foreach($records as $record) {
					  //Set record color
					  //if(!isset($record['scan_file'])) {
					//	  $class='style="background-color:#f2f200"';
					 // } else {
						  $class="";
					  //}
					  if($record['dob']) {
						  $age=floor((time()-strtotime($record['dob']))/YEAR);
					  } else {
						  $age="-";
					  }
					  print "<tr $class><td>".date('Y-m-d', strtotime($record['created_at']))."</td>
					  <td>{$record['id_number']}</td>
					  <td>{$record['first_name']}</td>
					  <td>{$record['last_name']}</td>
					  <td>$age</td>
					  <td>{$record['offense']}</td>
					  <td>{$record['penalty']}</td>
					  <td>"; print $record['amount']>0 ? number_format($record['amount'], 0) : "-"; print "</td>";

					   //Show edit and delete options
					  print "<td>&nbsp;";
					  print "<a href=\"".base_url("frontend/traffic/offenses/view/".$record['id'])."\">View</a>";
					  print "&nbsp;&nbsp;";
					  //print "<span title='Delete'><a class='red' href='".base_url($controller['route']."/delete/".$record['id'])."' onClick=\"return confirm('Are you sure you want to delete this item');\">".'<i class="fa fa-times" title="Delete" ></i></a></span>';
					  //if(isset($record['scan_file'])) {
						 // print '<a target="_blank" rel="noopener noreferrer" href="'.base_url('frontend/subject_records/image/'.$record['id']).'">Scan</a><br>';
					  //}
					  print "</td>";
					print "</tr>\n";
				  }
                  ?>
                  </tbody>
                  <tfoot>
                  <tr>
					<th>Date</th>
					<th>ID Number</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Age</th>
                    <th>Offense</th>
                    <th>Penalty</th>
                    <th>Fine amount</th>
                    <th>&nbsp;</th>
                  </tr>
                  </tfoot>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->

          </div>
          <!-- /.col-md-12 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

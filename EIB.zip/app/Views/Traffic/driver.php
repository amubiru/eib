<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Driver Record</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Driver Record</li>
  </ol>
</div><!-- /.col -->

<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <!-- Edit record button 
			<div class="col-lg-1">
			<a href=<?= base_url("frontend/traffic/driver/edit/" . $record['id']); ?>><button type="button" class="btn btn-block btn-primary" onClick="clearModal();">Edit  <i class="fa fa-plus"></i></button></a>
			</div> -->
      <div class="col-lg-12">
        <div class="row">
          <div class="col-lg-8">
            <!-- general form elements -->
            <!-- /.card-header -->
            <div class="card">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#summary" data-toggle="tab">Summary</a></li>
                  <li class="nav-item"><a class="nav-link" href="#cabis" data-toggle="tab">CABIS</a></li>
                  <li class="nav-item"><a class="nav-link" href="#related" data-toggle="tab">Cross References</a></li>
                  <li class="nav-item"><a class="nav-link" href="#attachments" data-toggle="tab">Attachments</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="summary">
                    <table id="data" class="table table-bordered table-striped">
                      <tbody>
                        <tr>
                          <td>First Name</td>
                          <td><?= $record['first_name']; ?></td>
                        </tr>
                        <tr>
                          <td>Last Name</td>
                          <td><?= $record['last_name']; ?></td>
                        </tr>
                        <tr>
                          <td>Subject ID</td>
                          <td><?= $record['subject_id']; ?></td>
                        </tr>
                        <tr>
                          <td>Driving license</td>
                          <td><?= $record['driving_license']; ?></td>
                        </tr>
                        <tr>
                          <td>National ID Number (NIN)</td>
                          <td><?= $record['nin']; ?></td>
                        </tr>
                        <tr>
                          <td>Number plate</td>
                          <td><?= $record['number_plate']; ?></td>
                        </tr>
                        <tr>
                          <td>License number</td>
                          <td><?= "UD" . sprintf("%06d", $record['id']); ?></td>
                        </tr>
                        <tr>
                          <td>Stage</td>
                          <td><?= $record['stage']; ?></td>
                        </tr>
                        </tr>

                      </tbody>
                    </table>
                    <form action="<?php print base_url('frontend/redlist/modify'); ?>" method="POST">
                      <?php print form_hidden('last_url', $_SERVER['REQUEST_URI']);
                      print form_hidden('subject_id', $subject['id']); ?>
                      <div class="col-sm-2">
                        <?php if ($subject['red_list'] == 1) {
                        ?>
                          <button class="btn btn-danger" type="submit">Remove from Red List</button>
                        <?php } else { ?>
                          <button class="btn btn-danger" type="submit">Add to Red List</button>
                        <?php } ?>
                      </div>
                    </form>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="cabis">
                    <?php
                    if ($cabis_present) { ?>
                      <a class="btn btn-primary" target="_blank" href="<?= base_url('/frontend/subject_records/form20/' . $record['subject_id']); ?>">Download Form 20</a><br>
                      <!-- PCC and combined form -->
                    <?php
                    } else {
                      print "PENDING";
                    } ?>
                    <!-- /.tab-content -->
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="related">
                    <?= $this->include('SubjectRecords/related_records',) ?>
                  </div>
                  <!-- /.tab-pane -->

                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="attachments">
                    <!-- /.card-header -->
                    <?= $this->include('SubjectRecords/attachments',) ?>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <?php
          if ($cabis_present) { ?>
            <img src="<?php print base_url('ajax/get_cabis?token=' . $_SESSION['AJAX_TOKEN'] . '&id=' . $record['subject_id'] . '&tag=705'); ?>"> <?php } else {
                                                                                                                                          print "Picture not available";
                                                                                                                                        } ?>
        </div>
      </div>
    </div>
  </div>
</div>
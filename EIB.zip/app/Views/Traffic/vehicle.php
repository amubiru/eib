<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>Number Plate</td><td><?= $vehicle['MVRegNo'] ?? '-'; ?></td></tr>
					  <tr><td>Chassis Number</td><td><?= $vehicle['ChasisNo'] ?? ''; ?></td></tr>
					  <tr><td>Body Description</td><td><?= $vehicle['BodyDesc'] ?? ''; ?></td></tr>
					  <tr><td>Color</td><td><?= $vehicle['Color'] ?? ''; ?></td></tr>
					  <tr><td>Make</td><td><?= $vehicle['Make'] ?? ''; ?></td></tr>
					  <tr><td>Model</td><td><?= $vehicle['ModelName'] ?? ''; ?></td></tr>
					  <tr><td>Owner Name</td><td><?= $vehicle['TaxPayerName'] ?? ''; ?></td></tr>
					  <tr><td>Owner Phone</td><td><?= $vehicle['MobileNumber'] ?? ''; ?></td></tr>
					  
					
                  </tbody>
                </table>

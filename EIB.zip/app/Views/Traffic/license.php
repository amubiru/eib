<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>License Number</td><td><?= $license['permit_no'] ?? '-'; ?></td></tr>
					  <tr><td>Name</td><td><?= $license['offendersName'] ?? ''; ?></td></tr>
					  <tr><td>Expiry</td><td><?= $license['permit_expiry'] ?? ''; ?></td></tr>
					  <tr><td>Permit Class</td><td><?= $license['permitClass'] ?? ''; ?></td></tr>
					  <tr><td colspan=2>
					  <?php 
					  if(strlen($license['photo'] ?? '')>1) {
						  print '<center><img src="data:image/png;base64,'.$license['photo'].'"></center>';
					  }
					  ?>
					  </td></tr>
					
                  </tbody>
                </table>

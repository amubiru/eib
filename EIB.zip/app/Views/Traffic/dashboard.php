<script>
  var labelsJSON = '<?= json_encode($labels); ?>';
  var colorsJSON = '<?= json_encode($colors); ?>';
  var pieDataJSON = '<?= json_encode($pieData); ?>';
  var datasetsJSON = '<?= json_encode($datasets); ?>';
  var datasetLabelsJSON = '<?= json_encode($datasetLabels); ?>';
</script>

<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Traffic Dashboard</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Dashboard</li>
  </ol>
</div>


<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <!-- Search card-header -->
    <?= form_open(base_url('/frontend/traffic/dashboard'), ['id' => 'searchForm']); ?>
    <div class="dashboard-card p-2">
      <div class="dashboard-card-header">
        <h3 class="card-title">Display Criteria</h3>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-sm-5">
            <!-- Select multiple-->
            <div class="form-group">
              <label>Search period</label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="bx bx-calendar"></i></span>
                </div>
                <input type="text" name="start_date" value="<?= $start_date; ?>" id="start_date" class="form-control date-picker" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
              </div> to
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="bx bx-calendar"></i></span>
                </div>
                <input type="text" name="end_date" id="end_date" value="<?= $end_date; ?>" class="form-control date-picker" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
              </div>
            </div>
          </div>
          <div class="col-sm-2">
            <div class="form-group">
              <label>&nbsp;<br><label>
                  <button type="submit" class="btn btn-primary">Search</button>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-4">
          <div class="custom-card shadow-sm bg-success">
            <div class="custom-card-body">
              <p class="custom-card-text"><?= $drivers; ?></p>
              <h5 class="custom-card-title">Drivers</h5>
            </div>
            <a href="#" class="custom-card-footer">More info <span><i class="bx bx-right-arrow-circle"></i></span></a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="custom-card shadow-sm bg-danger">
            <div class="custom-card-body">
              <p class="custom-card-text"><?= $offenses; ?></p>
              <h5 class="custom-card-title">Offenses</h5>
            </div>
            <a href="#" class="custom-card-footer">More info <span><i class="bx bx-right-arrow-circle"></i></span></a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="custom-card shadow-sm bg-warning">
            <div class="custom-card-body">
              <p class="custom-card-text"><?= $cautions; ?></p>
              <h5 class="custom-card-title">Cautions</h5>
            </div>
            <a href="#" class="custom-card-footer">More info <span><i class="bx bx-right-arrow-circle"></i></span></a>
          </div>
        </div>
        <div class="col-md-4">
          <div class="custom-card shadow-sm bg-info">
            <div class="custom-card-body">
              <p class="custom-card-text"><?= $fines; ?></p>
              <h5 class="custom-card-title">Fines</h5>
            </div>
            <a href="#" class="custom-card-footer">More info <span><i class="bx bx-right-arrow-circle"></i></span></a>
          </div>
        </div>
      </div>
    </div>
    <?= form_close(); ?>
  </div>
  <!--Card for pie chart -->
  <div class="row p-2">
    <div class="col-lg-4 col-4">
      <div class="card">
        <div class="card-header">
          <h3 class="card-title">
            <i class="bx bx-pie-chart mr-1"></i>
            Relative number
          </h3>
        </div><!-- /.card-header -->
        <div class="card-body">
          <!-- Morris chart -->
          <canvas id="crime-chart-canvas" height="300" style="height: 300px;"></canvas>

        </div><!-- /.card-body -->
        <div class="d-flex flex-row justify-content-end">
          <?php for ($n = 0; $n < count($labels); $n++) {
            print '<span>
                    <i style="color:' . $colors[$n] . '"  class="fas fa-square"></i> ' . $labels[$n] . '
                  </span>';
          } ?>
        </div>
      </div>
      <!-- /.card -->
    </div>
  </div>
  <!-- End of pie chart-->
  <!--Card for trends -->
  <div class="row p-2">
    <div class="col-lg-8 col-8">
      <div class="card">
        <div class="card-header border-0">
          <div class="d-flex justify-content-between">
            <h3 class="card-title">Trends over time</h3>
          </div>
        </div>
        <div class="card-body">
          <!-- /.d-flex -->

          <div class="position-relative mb-4">
            <canvas id="trends-chart" height="200" width="800"></canvas>
          </div>

          <div class="d-flex flex-row justify-content-end">
            <?php for ($n = 0; $n < count($labels); $n++) {
              print '<span>
                    <i style="color:' . $colors[$n] . '"  class="fas fa-square"></i> ' . $labels[$n] . '
                  </span>';
            } ?>
          </div>
        </div>
      </div>
      <!-- /.card -->
    </div>
    <!-- End of trends chart-->
    <!-- /.col-md-12 -->
  </div>
</div>
<?php
$statusMsg = "";
if (isset($_POST['username'], $_POST['password'])) {
	$username = $_POST['username'];
	$password = $_POST['password'];
	if ($username && $password) {

		$statusMsg = $username . "--" . $password;
	} else {
		$statusMsg = "Username and password required!";
	}
}

?>

<!doctype html>
<html lang="en">

<head>

	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400&amp;display=swap" rel="stylesheet">
	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">

	<link rel="stylesheet" href="css/bootstrap.min.css">

	<link rel="stylesheet" href="css/style.css">

	<link rel="stylesheet" href="<?php echo base_url('public/assets/css/main.css'); ?>">

	<title>eIB</title>
	<script nonce="8fa11605-bb23-4580-9139-b4967d145e15">
		(function(w, d) {
			! function(j, k, l, m) {
				j[l] = j[l] || {};
				j[l].executed = [];
				j.zaraz = {
					deferred: [],
					listeners: []
				};
				j.zaraz.q = [];
				j.zaraz._f = function(n) {
					return async function() {
						var o = Array.prototype.slice.call(arguments);
						j.zaraz.q.push({
							m: n,
							a: o
						})
					}
				};
				for (const p of ["track", "set", "debug"]) j.zaraz[p] = j.zaraz._f(p);
				j.zaraz.init = () => {
					var q = k.getElementsByTagName(m)[0],
						r = k.createElement(m),
						s = k.getElementsByTagName("title")[0];
					s && (j[l].t = k.getElementsByTagName("title")[0].text);
					j[l].x = Math.random();
					j[l].w = j.screen.width;
					j[l].h = j.screen.height;
					j[l].j = j.innerHeight;
					j[l].e = j.innerWidth;
					j[l].l = j.location.href;
					j[l].r = k.referrer;
					j[l].k = j.screen.colorDepth;
					j[l].n = k.characterSet;
					j[l].o = (new Date).getTimezoneOffset();
					if (j.dataLayer)
						for (const w of Object.entries(Object.entries(dataLayer).reduce(((x, y) => ({
								...x[1],
								...y[1]
							})), {}))) zaraz.set(w[0], w[1], {
							scope: "page"
						});
					j[l].q = [];
					for (; j.zaraz.q.length;) {
						const z = j.zaraz.q.shift();
						j[l].q.push(z)
					}
					r.defer = !0;
					for (const A of [localStorage, sessionStorage]) Object.keys(A || {}).filter((C => C.startsWith("_zaraz_"))).forEach((B => {
						try {
							j[l]["z_" + B.slice(7)] = JSON.parse(A.getItem(B))
						} catch {
							j[l]["z_" + B.slice(7)] = A.getItem(B)
						}
					}));
					r.referrerPolicy = "origin";
					r.src = "https://preview.colorlib.com/cdn-cgi/zaraz/s.js?z=" + btoa(encodeURIComponent(JSON.stringify(j[l])));
					q.parentNode.insertBefore(r, q)
				};
				["complete", "interactive"].includes(k.readyState) ? zaraz.init() : j.addEventListener("DOMContentLoaded", zaraz.init)
			}(w, d, "zarazData", "script");
		})(window, document);
	</script>
</head>

<body>
	<div class="d-lg-flex half">
		<div class="bg order-1 order-md-2" style="background-color: #FFFFFF; background-image: url('images/forensics.jpg');background-size: 70%;  background-position: center center;  background-repeat: no-repeat; "></div>
		<!-- 
<div class="bg order-1 order-md-2" style="background-color: #283593; background-image: url('images/police-logo-white.png');background-size: 50%;  background-position: center center;  background-repeat: no-repeat; "></div>
-->
		<div class="contents order-2 order-md-1">
			<div class="container">
				<div class="row align-items-center justify-content-center">
					<div class="col-md-7">
						<h3><strong>Electronic Identificiation Bureau</strong></h3>
						<?= form_open(base_url('/login/submit')); ?>
						<div class="form-group first">
							<label for="username">Username</label>
							<input type="text" name="username" class="form-control" placeholder="Your username" id="username">
						</div>
						<div class="form-group last mb-3">
							<label for="password">Password</label>
							<input type="password" name="password" class="form-control" placeholder="Your Password" id="password">
						</div>
						<div class="d-flex mb-5 align-items-center">
							<label class="control control--checkbox mb-0"><span class="caption">Remember me</span>
								<input type="checkbox" checked="checked" />
								<div class="control__indicator"></div>
							</label>
							<span class="ml-auto"><a href="#" class="forgot-pass">Forgot Password</a></span>
						</div>
						<p style="color: red;"><strong><?= $statusMsg; ?></strong></p>
						<input type="submit" value="Log In" class="btn btn-block btn-primary">
						</form>

						<!-- Add Google Login Button -->
						<!--
						<div class="google-login-container text-center mt-3">
							<a href="<?= base_url('login/google'); ?>" class="btn btn-block btn-google">
								<i class="fab fa-google"></i> Login with Google
							</a>
						</div>
						-->
						<div>
							<hr />
							<p>&copy; <?= date("Y"); ?> Kwiksy</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/main.js"></script>
</body>

</html>

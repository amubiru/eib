<style>
  .search-result {
    display: flex;
    align-items: center;
    border: 1px solid #ccc;
    padding: 10px;
    margin-bottom: 10px;
    text-decoration: none;
    color: inherit;
  }

  .search-result:hover {
    background-color: #f0f0f0;
  }

  .result-details {
    flex: 1;
  }

  .result-photo {
    margin-left: 10px;
    max-width: 150px;
    max-height: 150px;
  }

  .category {
    font-weight: bold;
  }

  .identifier {
    color: #555;
  }

  .details {
    margin-top: 5px;
  }

  .date {
    color: #888;
    font-size: 0.9em;
    margin-top: 5px;
  }
</style>

<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Search</h1>
</div><!-- /.col -->
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Search</li>
  </ol>
</div><!-- /.col -->


<!-- Main content -->
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">
        <!-- Card for form goes here
			-->
        <!-- Search form -->
        <div class="card card-primary">
          <div class="card-header">
            <h3 class="card-title">System wide search</h3>
          </div>
          <?= form_open_multipart(base_url("frontend/search/submit"), ['id' => 'searchForm']); ?>
          <div class="card-body">
            <div class="row">
              <div class="col-6">
                <div id="search_photo_label" class="form-group"><label for="photo_file">File input</label></div>
                <div id="search_pdf_label" class="form-group"><label for="pdf_file">File input</label></div>
              </div>
              <div class="col-2">
                <b>Search Type</b>
              </div>
              <div class="col-2">
                &nbsp;
              </div>
            </div>
            <div class="row">
              <div class="col-6">
                <div id="search_terms_div" class="form-group">
                  <input type="text" class="form-control" id="search_terms" name="search_terms" placeholder="Please enter search terms">
                </div>
                <div id="search_photo" class="form-group">
                  <div class="input-group">
                    <div class="custom-file">
                      <input type="file" class="custom-file-input" id="photo_file" name="photo_file">
                      <label class="custom-file-label" for="photo_file">Choose file</label>
                    </div>
                  </div>
                </div>
                <div id="search_pdf" class="form-group">
                  <div class="input-group">
                    <div class="custom-file">
                      <input type="file" class="custom-file-input" id="pdf_file" name="pdf_file">
                      <label class="custom-file-label" for="pdf_file">Choose PDF file</label>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-2">
                <select name="search_type" id="search_type" onChange="showSearchTerms()">
                  <option value="ALL">All</option>
                  <option value="NIN">NIN</option>
                  <option value="VEHICLE">Number plate</option>
                  <option value="LICENSE">Driving permit</option>
                  <option value="PHONE">Phone number</option>
                  <option value="PHOTO">Passport Photograph</option>
                  <option value="PDF">Interpol PDF</option>
                  <option value="FINGERPRINT">Fingerprint</option>
                </select>
              </div>
              <div class="col-2">
                <button type="submit" class="btn btn-primary">Search</button>
              </div>
            </div>
          </div>
          <!-- /.card-body -->
        </div>
        </form>
      </div>
    </div>
    <div class="row">
      <div class="col-12 col-sm-12">
        <div class="card card-primary card-outline card-outline-tabs">
          <div class="card-header p-0 border-bottom-0">
            <ul class="nav nav-tabs" id="search-tabs" role="tablist">
              <li class="nav-item">
                <?php $num = count($records['all']); ?>
                <a class="nav-link active" id="search-all-tab" data-toggle="pill" href="#search-all" role="tab" aria-controls="search-all" aria-selected="true">All <?php if ($num > 0) {
                                                                                                                                                                      print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                    } ?></a>
              </li>
              <?php $num = count($records['criminal']);
              if ($num > 0) { ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-criminal-tab" data-toggle="pill" href="#search-criminal" role="tab" aria-controls="search-criminal" aria-selected="false">Criminal Records <?php if ($num > 0) {
                                                                                                                                                                                              print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                            } ?></a>
                </li>
              <?php }
              $num = count($records['traffic']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-traffic-tab" data-toggle="pill" href="#search-traffic" role="tab" aria-controls="search-traffic" aria-selected="false">Traffic Offenses <?php if ($num > 0) {
                                                                                                                                                                                            print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                          } ?></a>
                </li>
              <?php }
              $num = count($records['civilian']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-civilian-tab" data-toggle="pill" href="#search-civilian" role="tab" aria-controls="search-civilian" aria-selected="false">Certificate of Good Conduct <?php if ($num > 0) {
                                                                                                                                                                                                          print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                                        } ?></a>
                </li>
              <?php }
              $num = count($records['police']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-police-tab" data-toggle="pill" href="#search-police" role="tab" aria-controls="search-police" aria-selected="false">Police <?php if ($num > 0) {
                                                                                                                                                                              print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                            } ?></a>
                </li>
              <?php }
              $num = count($records['pso']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-pso-tab" data-toggle="pill" href="#search-pso" role="tab" aria-controls="search-pso" aria-selected="false">Private Security Operators <?php if ($num > 0) {
                                                                                                                                                                                          print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                        } ?></a>
                </li>
              <?php }
              $num = count($records['lost_found']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-lostfound-tab" data-toggle="pill" href="#search-lostfound" role="tab" aria-controls="search-lostfound" aria-selected="false">Lost and Found <?php if ($num > 0) {
                                                                                                                                                                                                print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                              } ?></a>
                </li>
              <?php }
              $num = count($records['nira']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-nira-tab" data-toggle="pill" href="#search-nira" role="tab" aria-controls="search-nira" aria-selected="false">NIRA <?php if ($num > 0) {
                                                                                                                                                                      print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                    } ?></a>
                </li>
              <?php }
              $num = count($records['vehicle']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-vehicle-tab" data-toggle="pill" href="#search-vehicle" role="tab" aria-controls="search-vehicle" aria-selected="false">Vehicle Registration <?php if ($num > 0) {
                                                                                                                                                                                                print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                              } ?></a>
                </li>
              <?php }
              $num = count($records['license']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-license-tab" data-toggle="pill" href="#search-license" role="tab" aria-controls="search-license" aria-selected="false">Driving Permit <?php if ($num > 0) {
                                                                                                                                                                                          print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                        } ?></a>
                </li>
              <?php }
              $num = count($records['facial']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-facial-tab" data-toggle="pill" href="#search-facial" role="tab" aria-controls="search-nira" aria-selected="false">Facial recognition <?php if ($num > 0) {
                                                                                                                                                                                        print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                      } ?></a>
                </li>
              <?php }
			  $num = count($records['fingerprint']);
              if ($num > 0) {
              ?>
                <li class="nav-item">
                  <a class="nav-link" id="search-fingerprint-tab" data-toggle="pill" href="#search-fingerprint" role="tab" aria-controls="search-fingerprint" aria-selected="false">Fingerprint <?php if ($num > 0) {
                                                                                                                                                                                        print '<span class="badge badge-info right">' . $num . '</span>';
                                                                                                                                                                                      } ?></a>
                </li>
              <?php }
              ?>
            </ul>
          </div>
          <div class="card-body">
            <div class="tab-content" id="search-tabsContent">
              <div class="tab-pane fade show active" id="search-all" role="tabpanel" aria-labelledby="search-all-tab">
                <?php foreach ($records['all'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-criminal" role="tabpanel" aria-labelledby="search-criminal-tab">
                <?php foreach ($records['criminal'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-traffic" role="tabpanel" aria-labelledby="search-traffic-tab">
                <?php foreach ($records['traffic'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-civilian" role="tabpanel" aria-labelledby="search-civilian-tab">
                <?php foreach ($records['civilian'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-police" role="tabpanel" aria-labelledby="search-police-tab">
                <?php foreach ($records['police'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-pso" role="tabpanel" aria-labelledby="search-pso-tab">
                <?php foreach ($records['pso'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-lostfound" role="tabpanel" aria-labelledby="search-lostfound-tab">
                <?php foreach ($records['lost_found'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-nira" role="tabpanel" aria-labelledby="search-nira-tab">
                <?php foreach ($records['nira'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-vehicle" role="tabpanel" aria-labelledby="search-vehicle-tab">
                <?php foreach ($records['vehicle'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-license" role="tabpanel" aria-labelledby="search-license-tab">
                <?php foreach ($records['license'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-facial" role="tabpanel" aria-labelledby="search-facial-tab">
                <?php foreach ($records['facial'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
              <div class="tab-pane fade" id="search-fingerprint" role="tabpanel" aria-labelledby="search-fingerprint-tab">
                <?php foreach ($records['fingerprint'] as $record) {
                ?>
                  <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
                    <div class="result-details">
                      <div class="category"><?= $record['category']; ?></div>
                      <div class="identifier"><?= $record['identifier']; ?></div>
                      <div class="details"><?= $record['details']; ?></div>
                      <div class="date"><?= $record['date']; ?></div>
                    </div>
                    <?php if ($record['photo']) { ?>
                      <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
                    <?php } ?>
                  </a>
                <?php
                }
                ?>
              </div>
            </div>
          </div>
          <!-- /.card -->
        </div>
      </div>
      <!-- /.col-md-12 -->
    </div>
    <!-- /.row -->
  </div><!-- /.container-fluid -->

<script>
  var labelsJSON = '<?= json_encode($labels); ?>';
  var colorsJSON = '<?= json_encode($colors); ?>';
  var pieDataJSON = '<?= json_encode($pieData); ?>';

  var districtLabelsJSON = '<?= json_encode($district_labels); ?>';
  var districtColorsJSON = '<?= json_encode($district_colors); ?>';
  var districtPieDataJSON = '<?= json_encode($district_pieData); ?>';

  var datasetsJSON = '<?= json_encode($datasets); ?>';
  var datasetLabelsJSON = '<?= json_encode($datasetLabels); ?>';
</script>

<!-- Start of page content -->
<div class="col-sm-6">
  <h1 class="m-0">Crime Dashboard</h1>
</div>
<div class="col-sm-6">
  <ol class="breadcrumb float-sm-right">
    <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
    <li class="breadcrumb-item active">Dashboard</li>
  </ol>
</div>



<!-- Main content -->
<div class="content">
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12">

        <!-- Search card-header -->
        <?= form_open(base_url('/frontend/search/dashboard'), ['id' => 'searchForm']); ?>
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">Display Criteria</h3>
          </div>
          <!-- /.card-header -->
          <div class="card-body">
            <div class="row">
              <div class="col-sm-5">
                <!-- Select multiple-->
                <div class="form-group">
                  <label>Search period</label>
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="bx bx-calendar"></i></span>
                    </div>
                    <input type="text" name="start_date" value="<?= $start_date; ?>" id="start_date" class="form-control date-picker" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                  </div> to
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="bx bx-calendar"></i></span>
                    </div>
                    <input type="text" name="end_date" id="end_date" value="<?= $end_date; ?>" class="form-control date-picker" data-inputmask-alias="datetime" data-inputmask-inputformat="yyyy-mm-dd" data-mask>
                  </div>
                </div>
              </div>
              <div class="col-sm-2">
                <div class="form-group">
                  <label>&nbsp;<br><label>
                      <button type="submit" class="btn btn-primary">Search</button>
                </div>
              </div>
            </div>
          </div>
          <!-- /.card -->
          </form>

          <!--Card for pie chart -->
          <div class="row">
            <div class="col-lg-2 col-2"></div>
            <div class="col-lg-8 col-8">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-chart-pie mr-1"></i>
                    By crime category
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <!-- Morris chart -->
                  <canvas id="crime-chart-canvas" height="300" style="height: 300px;"></canvas>

                </div><!-- /.card-body -->
                <div class="d-flex flex-row justify-content-end">
                  <?php for ($n = 0; $n < count($labels); $n++) {
                    print '<span>
                    <i style="color:' . $colors[$n] . '"  class="fas fa-square"></i> ' . $labels[$n] . '
                  </span>';
                  } ?>
                </div>
              </div>
              <!-- /.card -->
            </div>
            <div class="col-lg-2 col-2"></div>
          </div>
          <!-- End of pie chart-->
          <!--Card for pie chart -->
          <div class="row">
            <div class="col-lg-2 col-2"></div>
            <div class="col-lg-8 col-8">
              <div class="card">
                <div class="card-header">
                  <h3 class="card-title">
                    <i class="fas fa-chart-pie mr-1"></i>
                    By district
                  </h3>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <!-- Morris chart -->
                  <canvas id="district-chart-canvas" height="300" style="height: 300px;"></canvas>

                </div><!-- /.card-body -->
                <div class="d-flex flex-row justify-content-end">
                  <?php for ($n = 0; $n < count($district_labels); $n++) {
                    print '<span>
                    <i style="color:' . $district_colors[$n] . '"  class="fas fa-square"></i> ' . $district_labels[$n] . '
                  </span>';
                  } ?>
                </div>
              </div>
              <!-- /.card -->
            </div>
            <div class="col-lg-2 col-2"></div>
          </div>
          <!-- End of pie chart-->

          <!--Card for type of crime -->
          <div class="row">
            <div class="col-lg-2 col-2"></div>
            <div class="col-lg-8 col-8">
              <div class="card">
                <div class="card-header border-0">
                  <div class="d-flex justify-content-between">
                    <h3 class="card-title">Trends over time</h3>
                  </div>
                </div>
                <div class="card-body">
                  <div class="d-flex">

                  </div>
                  <!-- /.d-flex -->

                  <div class="position-relative mb-4">
                    <canvas id="trends-chart" height="200" width="800"></canvas>
                  </div>

                  <div class="d-flex flex-row justify-content-end">
                    <?php for ($n = 0; $n < count($labels); $n++) {
                      print '<span>
                    <i style="color:' . $colors[$n] . '"  class="fas fa-square"></i> ' . $labels[$n] . '
                  </span>';
                    } ?>
                  </div>
                </div>
              </div>
              <!-- /.card -->
              <!-- /.card -->
            </div>
            <!-- End of type of crime chart-->

            <!-- /.col-md-12 -->
          </div>
          <div class="col-lg-2 col-2"></div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
  </div>
</div>
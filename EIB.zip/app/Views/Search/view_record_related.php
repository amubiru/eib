<style>
    .search-result {
        display: flex;
        align-items: center;
        border: 1px solid #ccc;
        padding: 10px;
        margin-bottom: 10px;
        text-decoration: none;
        color: inherit;
    }

    .search-result:hover {
        background-color: #f0f0f0;
    }

    .result-details {
        flex: 1;
    }

    .result-photo {
        margin-left: 10px;
        max-width: 150px;
        max-height: 150px;
    }

    .category {
        font-weight: bold;
    }

    .identifier {
        color: #555;
    }

    .details {
        margin-top: 5px;
    }

    .date {
        color: #888;
        font-size: 0.9em;
        margin-top: 5px;
    }
</style>

<?php foreach (($related ?? []) as $record) {
?>
    <a href="<?= $record['url']; ?>" class="search-result" target="_blank">
        <div class="result-details">
            <div class="category"><?= $record['category']; ?></div>
            <div class="identifier"><?= $record['identifier']; ?></div>
            <div class="details"><?= $record['details']; ?></div>
            <div class="date"><?= $record['date']; ?></div>
        </div>
        <?php if ($record['photo']) { ?>
            <img src="<?= $record['photo']; ?>" alt="Photo" class="result-photo">
        <?php } ?>
    </a>
<?php
}
?>
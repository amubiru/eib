<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="bx bx-menu nav-icon"></i></a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="<?php echo base_url('frontend/dashboard'); ?>" class="nav-link">Home</a>
    </li>
    <li class="nav-item d-none d-sm-inline-block">
      <a href="#" class="nav-link">Contact</a>
    </li>
  </ul>

  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <!-- Navbar Search -->
    <li class="nav-item">
      <a class="nav-link" data-widget="navbar-search" href="#" role="button">
        <i class="bx bx-search"></i>
      </a>
      <div class="navbar-search-block">
        <form class="form-inline">
          <div class="input-group input-group-sm">
            <input class="form-control form-control-navbar" type="search" placeholder="Search" aria-label="Search">
            <div class="input-group-append">
              <button class="btn btn-navbar" type="submit">
                <i class="bx bx-search"></i>
              </button>
              <button class="btn btn-navbar" type="button" data-widget="navbar-search">
                <i class="bx bx-x"></i>
              </button>
            </div>
          </div>
        </form>
      </div>
    </li>



    <li class="nav-item">
      <a class="nav-link" data-widget="fullscreen" href="#" role="button">
        <i class="bx bx-expand-alt"></i>
      </a>
    </li>
  </ul>
</nav>
<!-- /.navbar -->

<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="<?php echo base_url('frontend/dashboard'); ?>" class="brand-link">
    <img src="<?php echo base_url('images/police_logo.png'); ?>" alt="Police Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
    <span class="brand-text font-weight-light">eIB</span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user panel (optional) -->
    <!-- SidebarSearch Form -->
    <div class="form-inline">
      <div class="input-group" data-widget="sidebar-search">
        <input class="form-control form-control-sidebar" type="search" placeholder="Search" aria-label="Search">
        <div class="input-group-append">
          <button class="btn btn-sidebar">
            <i class="bx bx-search"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->

        <li class="nav-item">
          <a href="<?php echo base_url('frontend/dashboard'); ?>" class="nav-link">
            <i class="bx bxs-dashboard"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="bx bxs-user-detail"></i>
            <p>
              Subject Records
              <i class="bx bxs-chevron-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= base_url('frontend/subject_records/civilian'); ?>" class="nav-link">
                <i class="bx bxs-user nav-icon"></i>
                <p>Civilian</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('frontend/subject_records/criminal'); ?>" class="nav-link">
                <i class="bx bx-block nav-icon"></i>
                <p>Criminal</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('frontend/subject_records/police'); ?>" class="nav-link">
                <i class="bx bxs-user-badge nav-icon"></i>
                <p>Police</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="#" class="nav-link">
                <i class="bx bx-shield nav-icon"></i>
                <p>PSO</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('frontend/redlist'); ?>" class="nav-link">
                <i class="bx bx-block nav-icon"></i>
                <p>Red List</p>
              </a>
            </li>
          <!--  <li class="nav-item">
              <a href="<?= base_url('frontend/subject_records/unverified'); ?>" class="nav-link">
                <i class="bx bx-id-card nav-icon"></i>
                <p>Unverified Identities</p>
              </a>
            </li> -->
          </ul>
        </li>
<!--
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="bx bxs-traffic"></i>
            <p>
              Traffic
              <i class="bx bxs-chevron-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= base_url('frontend/traffic/dashboard'); ?>" class="nav-link">
                <i class="bx bxs-dashboard nav-icon"></i>
                <p>Dashboard</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('frontend/traffic/drivers'); ?>" class="nav-link">
                <i class="bx bxs-car nav-icon"></i>
                <p>Drivers</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('frontend/traffic/offenses'); ?>" class="nav-link">
                <i class="bx bxs-file nav-icon"></i>
                <p>Offenses</p>
              </a>
            </li>
          </ul>
        </li>
        -->
<?php 
//Only for dev environments
if(getenv('CI_ENVIRONMENT') == 'development') {
	?>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="bx bxs-user-check"></i>
            <p>
              EC
              <i class="bx bxs-chevron-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= base_url('ec/dashboard'); ?>" class="nav-link">
                <i class="bx bxs-dashboard nav-icon"></i>
                <p>Dashboard</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('ec/polling_stations'); ?>" class="nav-link">
                <i class="bx bxs-box nav-icon"></i>
                <p>Polling stations</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('ec/country'); ?>" class="nav-link">
                <i class="bx bxs-box nav-icon"></i>
                <p>Country activity</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('ec/index'); ?>" class="nav-link">
                <i class="bx bxs-box nav-icon"></i>
                <p>Voters</p>
              </a>
            </li>
          </ul>
        </li>
<?php } ?>
        <li class="nav-item">
          <a href="#" class="nav-link">
            <i class="bx bxs-file-doc nav-icon"></i>
            <p>
              Lost and Found
              <i class="bx bxs-chevron-left right"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="<?= base_url('frontend/lost_and_found/vehicles'); ?>" class="nav-link">
                <i class="bx bxs-car nav-icon"></i>
                <p>Vehicles</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('frontend/lost_and_found/phones'); ?>" class="nav-link">
                <i class="bx bxs-mobile nav-icon"></i>
                <p>Phones</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="<?= base_url('frontend/lost_and_found/general'); ?>" class="nav-link">
                <i class="bx bxs-map nav-icon"></i>
                <p>General</p>
              </a>
            </li>
          </ul>
        </li>
    
        <li class="nav-item">
          <a href="<?= base_url('/frontend/subject_records/civilian/queue'); ?>" class="nav-link">
            <i class="bx bxs-file-doc nav-icon"></i>
            <p>Certificates Queue</p>
          </a>
        </li>
        <li class="nav-item">
          <a href="<?php echo base_url('frontend/users'); ?>" class="nav-link">
            <i class="bx bx-group nav-icon"></i>
            <p>
              Users
            </p>
          </a>
        </li>
        <!--
        <li class="nav-item">
          <a href="<?php echo base_url('frontend/audit_log'); ?>" class="nav-link">
            <i class="bx bxs-book nav-icon"></i>
            <p>
              Audit Log
            </p>
          </a>
        </li>
        -->
        <li class="nav-item">
          <a href="<?php echo base_url('/frontend/change_pass'); ?>" class="nav-link">
            <i class="bx bxs-key nav-icon"></i>
            <p>
              Change Password
            </p>
          </a>
        </li>

        <li class="nav-item">
          <a href="<?php echo base_url('logout'); ?>" class="nav-link">
            <i class="bx bx-log-out nav-icon"></i>
            <p>
              Logout
            </p>
          </a>
        </li>
      </ul>
    </nav>
    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <!-- Error and success messages  -->
      <?php
      if (isset($_SESSION['errorMessage']) || isset($errorMessage)) {
        $emessage = isset($errorMessage) ? $errorMessage : $_SESSION['errorMessage'];
        $emessageTitle = isset($errorTitle) ? $errorTitle : $_SESSION['errorTitle'];
      ?>
        <div class="row">
          <div class="toast bg-danger fade show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header"><strong class="mr-auto"><?= $emessageTitle; ?></strong><small></small><button data-dismiss="toast" type="button" class="ml-2 mb-1 close" aria-label="Close"><span aria-hidden="true">×</span></button></div>
            <div class="toast-body"><?= $emessage; ?></div>
          </div>
        </div>
      <?php }
      if (isset($_SESSION['message']) || isset($message)) {
        $message = isset($message) ? $message : $_SESSION['message'];
        $messageTitle = isset($messageTitle) ? $messageTitle : $_SESSION['messageTitle'];
      ?>
        <div class="row">
          <div class="toast bg-success fade show" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header"><strong class="mr-auto"><?= $messageTitle; ?></strong><small></small><button data-dismiss="toast" type="button" class="ml-2 mb-1 close" aria-label="Close"><span aria-hidden="true">×</span></button></div>
            <div class="toast-body"><?= $message; ?></div>
          </div>
        </div>
      <?php } ?>

      <div class="row mb-2">


          <div class="col-sm-6">
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6">
			<!-- Card for form goes here
			-->
			 <!-- general form elements -->
<table>
<?php 
foreach($alerts as $alert) {
	print "<tr><td colspan=3>{$alert['name']}</td></tr><tr><td><img src=\"{$alert['subject_image']}\"></td><td><img src=\"{$alert['captured_image']}\"></td><td><video width=\"640\" height=\"360\" controls><source src=\"{$alert['captured_video']}\"></video></td></tr>\n";
}
?>
</table>            

          </div>
          <!-- /.col-md-6 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

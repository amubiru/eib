<script>
//This sets custom code to be run once the page is loaded
var pageCode='SubjectRecordLoadCabis("<?php print $record['subject_id']; ?>");
SubjectRecordLoadCaseTracking("<?php print $record['case_tracking_id']; ?>");
';
</script>

 <!-- Start of page content -->
          <div class="col-sm-6">
            <h1 class="m-0">Subject Record</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo base_url(); ?>">Home</a></li>
              <li class="breadcrumb-item active">Subject Record</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
<!-- Modal to allow add and edit -->
    <div class="modal fade" id="editModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add/Edit</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <?= form_open_multipart(base_url("frontend/subject_records/submit"), ['id' => 'modalForm']); ?>
            <div class="modal-body">
              <?php
              foreach($fields as $field) {
				  if(in_array($field['type'], ['text','number'])) {
					  ?>
					  <div class="form-group">
                    <label for="<?= $field['db_name'];?>"><?= $field['name'];?></label>
                    <input type="text" class="form-control" id="modal_<?= $field['db_name'];?>" name="<?= $field['db_name'];?>" placeholder="<?= $field['description'];?>">
                  </div>
                  <?php } 
                  if($field['type']=='hidden') {
					  $hidden_data = [
						'type'  => 'hidden',
						'name'  => $field['db_name'],
						'id'    => 'modal_'.$field['db_name']
					];

					echo form_input($hidden_data);
				   }
			  } 
              ?>
              <div class="form-group">
                    <label for="cr_scan">Upload Scan of paper record (pdf,png,jpg,tiff)</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="cr_scan" name="cr_scan">
                        <label class="custom-file-label" for="cr_scan">Choose file</label>
                      </div>
                    </div>
                  </div>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            </form>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->
      
	  <!-- Modal to add file -->
    <div class="modal fade" id="fileModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Add File</h4>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form action="http://127.0.0.1/ecro/frontend/subject_records/submit" id="modalForm" enctype="multipart/form-data" method="post" accept-charset="utf-8">
            <div class="modal-body">
              					  <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" class="form-control" id="modal_name" name="name" placeholder="Name of file/document">
                  </div>
                  					  <div class="form-group">
                    <label for="subject_id">Description</label>
                    <input type="text" class="form-control" id="modal_subject_id" name="subject_id" placeholder="Description of file/document">
                  </div>
              <div class="form-group">
                    <label for="cr_scan">Upload Scan of paper record (pdf,png,jpg,tiff)</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" id="cr_scan" name="cr_scan">
                        <label class="custom-file-label" for="cr_scan">Choose file</label>
                      </div>
                    </div>
                  </div>
            </div>
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            <div style="display:none"><label>Fill This Field</label><input type="text" name="honeypot" value=""/></div></form>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
      <!-- /.modal -->

    <!-- Main content -->
    <div class="content">
      <div class="container-fluid">
        <div class="row">
			<!-- Edit record button -->
			<div class="col-lg-1">
			<a href=<?= base_url("frontend/subject_records/edit/".$record['id']); ?>><button type="button" class="btn btn-block btn-primary" onClick="clearModal();">Edit  <i class="bx bx-plus"></i></button></a>
			</div>
          <div class="col-lg-12">

			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header d-flex p-0">
                <ul class="nav nav-pills ml-auto p-2">
                  <li class="nav-item"><a class="nav-link active" href="#summary" data-toggle="tab">Summary</a></li>
                  <li class="nav-item"><a class="nav-link" href="#cabis" data-toggle="tab">CABIS</a></li>
                  <li class="nav-item"><a class="nav-link" href="#case" data-toggle="tab">Case Tracking</a></li>
                  
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
				  <div class="tab-content">
                  <div class="tab-pane active" id="summary">
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>Name (from CABIS)</td><td><?= $record['subject_name']; ?></td></tr>
					  <tr><td>Subject ID</td><td><?= $record['subject_id']; ?></td></tr>
					  <tr><td>Father's name </td><td><?= $record['father']; ?></td></tr>
					  <tr><td>Name convicted under </td><td><?= $record['name']; ?></td></tr>
					  <tr><td>Aliases </td><td><?= $record['aliases']; ?></td></tr>
					  <tr><td>Date of arrest</td><td><?= $record['date_arrest']; ?></td></tr>
					  <tr><td>Court and place of trial</td><td><?= $record['court_place_trial']; ?></td></tr>
					  <tr><td>Offence</td><td><?= $record['offence']; ?></td></tr>
					  <tr><td>Date of sentence</td><td><?= $record['date_sentence']; ?></td></tr>
					  <tr><td>Sentence</td><td><?= $record['sentence']; ?></td></tr>
					  <tr><td>Remarks</td><td><?= $record['remarks']; ?></td></tr>
					  <tr><td>Station</td><td><?= $record['station']; ?></td></tr>
					  <tr><td>Officer in Charge</td><td><?= $record['officer_in_charge']; ?></td></tr>
					  <tr><td>CRB No</td><td><?= $record['crb_no']; ?></td></tr>
					  <tr><td>Court Case number</td><td><?= $record['court_case_number']; ?></td></tr>

            
                  </tbody>
                </table>
                <table><tr><td>Front face picture</td><td>Profile picture</td></tr><tr><td><img src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=705');?>"></td><td><img src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=706');?>"></td></tr></table>
                </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="cabis">
					  <table id="data" class="table table-bordered table-striped">
                  <tbody>
					 <tr><td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=720');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=721');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=722');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=723');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=724');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=725');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=726');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=727');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=728');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=729');?>"></td></tr>

            
                  </tbody>
                </table>
                <table id="data" class="table table-bordered table-striped">
                  <tbody>
					 <tr><td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=735');?>"></td>
					 <td><img width=300 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=734');?>"></td>
					 <td><img width=100 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=736');?>"></td>
					 <td><img width=300 src="<?php print base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$record['subject_id'].'&tag=737');?>"></td>
					 </tr>

            
                  </tbody>
                </table>
				</div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="case">
				<table id="data" class="table table-bordered table-striped">
                  <tbody>
					  <tr><td>Offence</td><td>Sample name</td></tr>
					  <tr><td>Added</td><td>2010-01-01</td></tr>
					  <tr><td>Fingerprint data</td><td> PENDING </td></tr>

            
                  </tbody>
                </table>
				</div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
                        <!-- /.card -->
                        
            <p></p>
            <table border=0><tr>
				            <td><button class="btn btn-primary">View Fingerprint Details</button></td><td><button class="btn btn-primary">Post Charge Sheet (PF 53)</button></td><td><button class="btn btn-primary">Post Antecendents (PF-51a)</button></td><td><button class="btn btn-primary">Post Modus Operandi (PF-49)</button></td>
				            </tr></table>

<p></p><p></p>
<!-- Add new record button -->
			<div class="col-lg-1">
			
			</div>
          <div class="col-lg-12">

			 <!-- general form elements -->
              <!-- /.card-header -->
              <div class="card">
              <div class="card-header">
                <h3 class="card-title">Associated files/images</h3>
              </div>
              <!-- Add new attachment button -->
			<div class="col-lg-1">
			<a href="<?= base_url("frontend/subject_records/add_attachment/".$record['id']); ?>">
			<button type="button" class="btn btn-primary" >Add  <i class="bx bx-plus"></i></button></a>
			</div>
              <!-- /.card-header -->
              <div class="card-body">
                <table id="data" class="table table-bordered table-striped">
					<thead><tr><th>Name</th><th>Description</th><th>Added</th><th>Link</th></tr></thead>
                  <tbody>
					  <?php
					  foreach($attachments as $att) {
						  print "<tr><td>{$att['name']}</td><td>{$att['description']}</td><td>{$att['created_at']}</td><td><a target=\"_blank\" href=\"".base_url("/frontend/attachments/".$att['id'])."\" >View/download</a></td></tr>\n";
					  }
					?>
            
                  </tbody>
                </table>
                <!-- /.card-body -->

                <div class="card-footer">
                </div>
            </div>
            <!-- /.card -->
            
          </div>
          <!-- /.col-md-12 -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
    <div class="p-3">
      <h5>Title</h5>
      <p>Sidebar content</p>
    </div>
  </aside>
  <!-- /.control-sidebar -->

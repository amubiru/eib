<?php

//Format a phone number as a local Ugandan number
function format_phone_local($phone) {
        $phone=substr($phone, -9);
        return("0".$phone);
}

//Post a request
function post_url($url, $fields, $headers='') {

    $fields_string='';

//url-ify the data for the POST
    foreach($fields as $key=>$value) { $fields_string .= $key.'='.urlencode($value).'&'; }
    rtrim($fields_string,'&');

//open connection
    $ch = curl_init();
    //trace_log("Posted: $fields_string");
//set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_POST,count($fields));
    curl_setopt($ch,CURLOPT_POSTFIELDS,$fields_string);

    if(!empty($headers)) {
    $header_string=array();

	//url-ify the header for the POST
    $headers_array=array();
    foreach($headers as $key=>$value) { $headers_array[] = $key.': '.$value; }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    
    //Set verbose options
	//curl_setopt($ch, CURLOPT_VERBOSE, true);

	//$streamVerboseHandle = fopen('php://temp','r+');
	//curl_setopt($ch, CURLOPT_STDERR, $streamVerboseHandle);
	//execute post

	$result = curl_exec($ch);

	//rewind($streamVerboseHandle);
	//log_message('debug', stream_get_contents($streamVerboseHandle));
	//log_message('debug', print_r($ch,true));

    
    if(curl_errno($ch)){
        //trace_log('Curl error: '.curl_error($ch));
    }
    curl_close ($ch);


    //trace_log("Received: $result");
    return($result);
}

function hasPermission($permission)
{
	if(in_array($permission, $_SESSION['permissions'] ?? [])) {
		return(true);
	}
	return(false);
}

//Sends raw data 
function post_url_raw($url, $data, $headers='') {

	//open connection
    $ch = curl_init();
	//set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL,$url);
    if(is_array($data)) {
		curl_setopt($ch,CURLOPT_POST,count($data));
	} else {
		curl_setopt($ch,CURLOPT_POST,1);
	}
    curl_setopt($ch,CURLOPT_POSTFIELDS,$data);

    if(!empty($headers)) {
    $header_string=array();

	//url-ify the header for the POST
    $headers_array=array();
    foreach($headers as $key=>$value) { $headers_array[] = $key.': '.$value; }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

	//execute post
    $result = curl_exec($ch);

	$httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);	
    if($httpCode != 200){
        log_message('error', 'Curl error: '.curl_error($ch));
    }
    if(curl_errno($ch)){
        log_message('error', 'Curl error: '.curl_error($ch));
    }
    curl_close ($ch);
    return($result);
}	

//Debug
function post_url_raw_debug($url, $data, $headers='') {

	//open connection
    $ch = curl_init();
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	//set the url, number of POST vars, POST data
    curl_setopt($ch,CURLOPT_URL,$url);
    if(is_array($data)) {
		curl_setopt($ch,CURLOPT_POST,count($data));
	} else {
		curl_setopt($ch,CURLOPT_POST,1);
	}
    curl_setopt($ch,CURLOPT_POSTFIELDS,$data);

    if(!empty($headers)) {
    $header_string=array();

	//url-ify the header for the POST
    $headers_array=array();
    foreach($headers as $key=>$value) { $headers_array[] = $key.': '.$value; }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);

	//execute post
    $result = curl_exec($ch);
	$httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);	
    if($httpCode != 200){
        log_message('error', "Got code $httpCode Curl error: ".curl_error($ch));
    }
    if(curl_errno($ch)){
        log_message('error', 'Curl error: '.curl_error($ch));
    }
    curl_close ($ch);

    return($result);
}

function get_url($url, $headers='') {

        //open connection
    $ch = curl_init();
        //set the url
    curl_setopt($ch,CURLOPT_URL,$url);


    if(!empty($headers)) {
    $header_string=array();

        //url-ify the header for the POST
    $headers_array=array();
    foreach($headers as $key=>$value) { $headers_array[] = $key.': '.$value; }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
    }
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
	//Set verbose options
	//curl_setopt($ch, CURLOPT_VERBOSE, true);

//$streamVerboseHandle = fopen('curl.log', 'w+');
//curl_setopt($ch, CURLOPT_STDERR, $streamVerboseHandle);
        //execute request
    $result = curl_exec($ch);

        $httpCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);  
    if($httpCode != 200){
        log_message('error', 'Curl error: '." HTTP Code $httpCode ".curl_error($ch));
    }
    if(curl_errno($ch)){
        log_message('error', 'Curl error: '.curl_error($ch));
    }
    curl_close ($ch);
    return($result);
}   

function put_url($url, $data, $headers='')
{
	$ch = curl_init($url);
	if(!empty($headers)) {
    $header_string=array();

        //url-ify the header for the POST
    $headers_array=array();
    foreach($headers as $key=>$value) { $headers_array[] = $key.': '.$value; }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
    }
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
	curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($data));
		//Set verbose options
	/*curl_setopt($ch, CURLOPT_VERBOSE, true);

	$streamVerboseHandle = fopen('php://memory','r+');
	curl_setopt($ch, CURLOPT_STDERR, $streamVerboseHandle);
	$response = curl_exec($ch);
	rewind($streamVerboseHandle);
	log_message('debug', stream_get_contents($streamVerboseHandle));
	*/
	fclose($streamVerboseHandle);
	if (!$response) 
	{
		return false;
	} else {
		return $response;
	}
}

function put_url_raw($url, $data, $headers='')
{
	$ch = curl_init($url);
	if(!empty($headers)) {
    $header_string=array();

        //url-ify the header for the POST
    $headers_array=array();
    foreach($headers as $key=>$value) { $headers_array[] = $key.': '.$value; }
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers_array);
    }
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");
	curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
		//Set verbose options
//	curl_setopt($ch, CURLOPT_VERBOSE, true);
//	$streamVerboseHandle = fopen(__DIR__."/../../writable/logs/curl.log", 'w+');
//	curl_setopt($ch, CURLOPT_STDERR, $streamVerboseHandle);
	$response = curl_exec($ch);

	if (!$response) 
	{
		return false;
	} else {
		return $response;
	}
}

//Return unique identifier	
function uuid() {   

	 // Generate 128 bit random sequence
	 $randmax_bits = strlen(base_convert(mt_getrandmax(), 10, 2));  // how many bits is mt_getrandmax()
	 $x = '';
	 while (strlen($x) < 128) {
		 $maxbits = (128 - strlen($x) < $randmax_bits) ? 128 - strlen($x) :  $randmax_bits;
		 $x .= str_pad(base_convert(mt_rand(0, pow(2,$maxbits)), 10, 2), $maxbits, "0", STR_PAD_LEFT);
	 }

	 // break into fields
	 $a = array();
	 $a['time_low_part'] = substr($x, 0, 32);
	 $a['time_mid'] = substr($x, 32, 16);
	 $a['time_hi_and_version'] = substr($x, 48, 16);
	 $a['clock_seq'] = substr($x, 64, 16);
	 $a['node_part'] =  substr($x, 80, 48);
	
	 // Apply bit masks for "random or pseudo-random" version per RFC
	 $a['time_hi_and_version'] = substr_replace($a['time_hi_and_version'], '0100', 0, 4);
	 $a['clock_seq'] = substr_replace($a['clock_seq'], '10', 0, 2);

	// Format output
	return sprintf('%s-%s-%s-%s-%s',
		str_pad(base_convert($a['time_low_part'], 2, 16), 8, "0", STR_PAD_LEFT),
		str_pad(base_convert($a['time_mid'], 2, 16), 4, "0", STR_PAD_LEFT),
		str_pad(base_convert($a['time_hi_and_version'], 2, 16), 4, "0", STR_PAD_LEFT),
		str_pad(base_convert($a['clock_seq'], 2, 16), 4, "0", STR_PAD_LEFT),
		str_pad(base_convert($a['node_part'], 2, 16), 12, "0", STR_PAD_LEFT));
}

	//Returns true if timestamp is current i.e. within 1 minute of current time
	function is_ts_current($ts) {
		return true;
	}
	
	//Used to remove sensitive fields before data is for example saved to a log
	function remove_sensitive_fields(array $data): array
	{
    $sensitive_fields = ['password', 'confirm_password', 'old_password', 'new_password', 'pin', 'confirm_pin', 'otp', 'credit_card'];
    
    foreach ($data as $key => $value) {
        if (in_array($key, $sensitive_fields)) {
            $data[$key] = '***';
        }
        if (is_array($value)) {
            $data[$key] = remove_sensitive_fields($value);
        }
    }
    
    return $data;
	}
	
	function imageCreateFromAny($filepath) {
		switch (exif_imagetype($filepath)) {
			// gif
			case 1:
			return imageCreateFromGif($filepath);
			// jpg
			case 2:
			return imageCreateFromJpeg($filepath);
			// png
			case 3:
			return imageCreateFromPng($filepath);
			// bmp
			case 6:
			return imageCreateFromBmp($filepath);
			// not defined
			default:
			log_message('debug', 'Unknown type');
			return null;
		}
	}
    
    function image_fix_orientation($filename) {
    $exif = exif_read_data($filename);
    if (!empty($exif['Orientation'])) {
        $image = imageCreateFromAny($filename);
        switch ($exif['Orientation']) {
            case 3:
                $image = imagerotate($image, 180, 0);
                log_message('debug','Rotated 180 degrees');
                break;

            case 6:
                $image = imagerotate($image, -90, 0);
                log_message('debug','Rotated 90 degrees');
                break;

            case 8:
                $image = imagerotate($image, 90, 0);
                log_message('debug','Rotated -90 degrees');
                break;
        }
        return($image);
    }
    return(false);
}

function array_unique_multi($array) {
    // Create an array to hold unique serialized elements
    $serializedArray = array_map('serialize', $array);

    // Remove duplicates
    $uniqueSerializedArray = array_unique($serializedArray);

    // Unserialize the array back to its original form
    $uniqueArray = array_map('unserialize', $uniqueSerializedArray);

    return $uniqueArray;
}

//Given a base64 encoded blob of any type will return a base64 encoded png 
function imagetopng($image)
{
	$im = imagecreatefromstring(base64_decode($image));
	$stream = fopen('php://memory','r+');
	imagepng($im, $stream);
	rewind($stream);
	$new_image=base64_encode(stream_get_contents($stream));
	fclose($stream);
	imagedestroy($im);
	return($new_image);
}



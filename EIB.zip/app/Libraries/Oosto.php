<?php

namespace App\Libraries;
use GuzzleHttp\Client;

class Oosto
{
	private $cache;
	private $token = false;
	private $groupId=false;
	private $caseId=false;
	private $featuresUrl=false;
	private $featuresData=false;
	private $featuresQuality=false;
	private $extDataModel;
	
	public function __construct()
        {
			$this->cache = \Config\Services::cache();
			$this->extDataModel = model('App\Models\ExternalDataModel');
			$token =$this->cache->get("OOSTO_TOKEN");
			if($token == false) {
				$token=$this->auth(getenv("oosto.username"), getenv("oosto.password"));
			if($token) {
				$this->token = $token;
				$this->cache->save("OOSTO_TOKEN", $token, HOUR); 
			}
		} else {
			$this->token=$token;
		}
		}
		
	private function auth($username, $password) {
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Content-Type' => 'application/json'];
		$body = ['username' => getenv('oosto.username'), 'password' => getenv('oosto.password')];
		try {
			$http_response=$client->post('api/login', ['headers' => $headers, 'json' => $body]);
		} catch (\Exception $e) {
			return false;
		}
		if($http_response->getStatusCode() == 200) {
			$response_json= (string) $http_response->getBody();
			//log_message('debug', 'Token '.$response_json);
			$response=json_decode($response_json, true);
			if(is_array($response)) {
				if(array_key_exists('token', $response)) {
					//log_message('debug', 'Sending token '.$response['token']);
					return($response['token']);
				}
			}
		}
		return false;
	}

	public function getGroupId($name='Default Group')
	{
		//$group=$this->cache->get('OOSTO_GROUP_ID_'.$name);
		$group='';
		if(!$group) {
			$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
			$headers = ['Content-Type' => 'application/json', 'Authorization' => 'Bearer '.$this->token];
			$http_response=$client->get('api/groups?search='.urlencode($name), ['headers' => $headers]);
			if($http_response->getStatusCode() == 200) {
				$response_json= (string) $http_response->getBody();
				log_message('debug', 'GetGroup ID request '.$name);
				log_message('debug', 'GetGroup ID Response '.$response_json);
				$response=json_decode($response_json, true);
				if(is_array($response['items'][0])) {
					$group=$response['items'][0];
					if(strlen($group['id'] ?? '') >0) {
						$this->cache->save('OOSTO_GROUP_ID_'.$name, $group, DAY);
						$this->groupId=$group['id'];
					}
				}
			}
		} else {
			$this->groupId=$group['id'];
		}
		return($this->groupId);
	}
	
	//Extracts faces from a PNG image
	public function extractFaces($image = null)
	{
		//file_put_contents(__DIR__."\image.png", $image);
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$options = [
		  'multipart' => [
			[
			  'name' => 'file',
			  'contents' => $image,
			  'filename' => substr(uuid(), 0, 8).'.png',
			  'headers'  => [
				'Content-Type' => 'image/png'
			  ]
			]
		], 'headers' => $headers];
		$http_response=$client->post('api/external-functions/extract-faces-from-image', $options);
		if($http_response->getStatusCode() == 200) {
			$response_json= (string) $http_response->getBody();
			//log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			//log_message('debug', 'Response item'.print_r($response['items'], true));
			if(!empty($response['items'])) {
				$features=$response['items'][0];
				log_message('debug', 'Features '.print_r($features, true));
				$this->featuresUrl=$features['url'];
				$this->featuresData=$features['features'];
				$this->featuresQuality=$features['featuresQuality'];
			}
		}
	}
	
	
	//Change a subjects group
	public function changeGroup($subject_id, $new_group)
	{
		$group_id=$this->getGroupId($new_group);
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$body=['groups' => [$group_id]];
		log_message('debug', print_r($body, true));
		$http_response=$client->patch('api/subjects/'.$subject_id, ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			return($response['id']);
			} else {
				return(false);	
		}
	}
	
	//Returns a subject if they exist, otherwise returns
	public function getSubject($subject_id)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$http_response=$client->get('api/subjects/'.$subject_id, ['headers' => $headers, 'http_errors' => false]);
		//log_message('debug', 'Get subject response for '.$subject_id.' as '.$http_response->getStatusCode());
		if($http_response->getStatusCode() == 200) {
			$response_json= (string) $http_response->getBody();
			//log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			return($response['id']);
		} elseif($http_response->getStatusCode() == 400) { //Does not exist
				return(-1);	
		} else {
				return(false);
		}
	}
	
	//Last stage of creating a subject
	public function createSubject($name, $externalId=null, $description='')
	{
		$description = $description ?? ''; //Prevent the null string
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$body=['name' => $name, 'groups' => [$this->groupId], 'description' => $description, 'images' => [['isPrimary' => true, 'featuresQuality' => $this->featuresQuality, 'objectType' => 1, 'url' => $this->featuresUrl, 'features' => $this->featuresData]]];
		log_message('debug', print_r($body, true));
		if(!$this->featuresUrl) {
			return(null);
		}
		$http_response=$client->post('api/subjects', ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			return($response['id']);
		}	
	}
	
	//Encapsulates all the steps of adding a subject
	public function addSubject($name, $image, $externalId=null, $description=null, $group='Default Group') 
	{
		$this->getGroupId($group);
		$this->extractFaces($image);
		$id=$this->createSubject($name,$externalId,$description);
		return($id);
	}
	
	//Creates an inquiry, the first step of inquiring about a subject
	public function createInquiry($inquiryName)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$body = [
			"eventDate" => date('c'),
			"name" => $inquiryName,
			"configuration" => [
				"webRTC" => false,
				"preview" => false,
				"frameSkip" => [
					"percent" => 0,
					"autoSkipEnabled" => true
				],
				"cameraMode" => [1],
				"captureDate" => date('c'),
				"stopSeconds" => 0,
				"startSeconds" => 0,
				"cameraPadding" => [
					"top" => "0",
					"left" => "0",
					"right" => "0",
					"bottom" => "0"
				],
				"ffmpegOptions" => "",
				"frameRotation" => -1,
				"livenessThreshold" => 1,
				"enableFrameStorage" => true,
				"trackBodyMaxLength" => 200,
				"trackBodyMinLength" => 4,
				"trackFaceMaxLength" => 200,
				"trackFaceMinLength" => 4,
				"detectionMaxBodySize" => -1,
				"detectionMaxFaceSize" => -1,
				"detectionMinBodySize" => 20,
				"detectionMinFaceSize" => 48,
				"trackerBodySeekTimeOut" => 45,
				"trackerFaceSeekTimeOut" => 45
			]
		];

		$http_response=$client->post('api/inquiry', ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			return($response['id']);
		}
	}
	
	//Gets Oosto ready to receive an image/video
	public function prepareForensic($fileName)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$body=['name' => $fileName, 'withAnalysis' => true];

		$http_response=$client->post('api/upload/prepare/forensic', ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			return($response['uploadId']);
		}	
	}
	
	//Informs Oosto of the file to be uploaded
	public function preUpload($uploadId, $fileName, $inquiryId, $type='png', $size=0, $duration=null)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		if($duration) {
			$file_type=1; //Video
		} else {
			$file_type=2; //Image
		}
		$body = [
			"files" => [
				[
					"uploadId" => $uploadId,
					"filename" => $fileName,
					"captureDate" => date('c'),
					"fileType" => $file_type,
					"size" => $size,
					"mimeType" => $type
				]
			], "threshold" => 0.5, "configuration" => ["cameraMode" => [1]]
		];
		if($duration) {
			$body['files'][0]['duration'] = $duration;
		}
		log_message('debug', json_encode($body));
		$http_response=$client->post('api/inquiry/'.$inquiryId.'/add-files', ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
		}	
	}
	
	//Upload file to be analyzed
	public function uploadFile($uploadId, $file_content, $file_extension, $file_type='image')
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$options = [
		  'multipart' => [
			[
			  'name' => 'file',
			  'contents' => $file_content,
			  'filename' => uuid().'.'.$file_extension,
			  'headers'  => [
				'Content-Type' => 'image/png'
			  ]
			]
		]];
		$options['headers'] = $headers;

		$http_response=$client->post('api/upload/file/'.$uploadId.'?type='.$file_type, $options);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Upload file response '.$response_json);
			$response=json_decode($response_json, true);
		}	
	}
	
	public function analyzeFile($file, $type) 
	{
		$inquiryName=uuid();
		$fileName=$inquiryName.'.'.$type;
		$inquiryId=$this->createInquiry($inquiryName);
		$uploadId=$this->prepareForensic($fileName, $type);
		$this->preUpload($uploadId, $fileName, $inquiryId, $type, $size=strlen(base64_decode($file)));
		$this->uploadFile($uploadId, $file, $type, 'image');
		return($inquiryId);
	}
	
	public function getMatches($face_image)
	{
		//Convert file into PNG
		$image = new \Imagick();
		$image->readImageBlob($face_image);
        // convert the output to tiff
        $image->setImageFormat('png');
        $face_image = $image->getImageBlob();
        $inquiryId=$this->analyzeFile($face_image, 'png');
        $results=[];
        for($count=0;$count<10;$count++) { //Wait for up to 10 seconds
			sleep(1);
			$result=$this->getInquiryResults($inquiryId);
			log_message('debug', 'OOSTO '.print_r($result, true));
			if($result['status'] == 'DONE') {
				foreach($result['subjects'] as $oosto_subject) {
					$results[]=['identifier' => $oosto_subject['name'], 'details' => $oosto_subject['description'], 'id' => $oosto_subject['id'], 'photo' => 'data:image/jpeg;base64,'.$oosto_subject['image'], 'date' => $oosto_subject['date']];
				}
				break;
			}
		}
		return($results);
	}
	
	public function getInquiryResults($inquiryId)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$http_response=$client->get('api/inquiry/'.$inquiryId, ['headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			$file=$response['files'][0];
			$status=$file['status'];
			$cameraId=$file['cameraId'];
		}
		$api_response=['status' => $status, 'subjects' => []];
		if($status!='DONE') {
			return $api_response;
		}
		$matches=null;
		//Now get tracks for this cameraId
		$body=['camera' => $cameraId, 'excludeFilters' => []];
		$http_response=$client->post('api/tracks', ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			if(is_array($response['items']) && count($response['items'])>0) {
				$item=$response['items'][0];
				$api_response['submitted_image']=$this->getImage($item['images'][0]['url']);
				$matches=$item['closeMatches'];
			}
		}
		if($matches) { //Get more information about the matches
			foreach($matches as $match) {
				$subject=['id' => $match['subjectId'], 'score' => $match['score']];
				$http_response=$client->get('api/subjects/'.$subject['id'], ['headers' => $headers]);
				if(in_array($http_response->getStatusCode(), [200])) {
					$response_json= (string) $http_response->getBody();
					log_message('debug', 'Response '.$response_json);
					$response=json_decode($response_json, true);
					$subject['name']=$response['name'];
					$subject['description']=$response['description'];
					$subject['image']=$this->getImage($response['image']['url']);
					$subject['date']=$response['createdAt'];
					$large_data=[];
					$save_data=$subject;
					$large_data['photo']=$subject['image'];
					unset($save_data['image']);
					$this->extDataModel->insert(['data_source' => 'oosto', 'external_id' => $subject['id'], 'large_data_json' => json_encode($large_data), 'data_json' => json_encode($save_data), 'data' => print_r($save_data, true)]);
					$api_response['subjects'][]=$subject;
				}
			}
		}
		return($api_response);
	}
	
	//Returns the actual image or video for a URL
	public function getImage($url) 
	{
		if(!$url) {
			return(null);
		}
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$http_response=$client->get($url, ['headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200])) {
			
			return(base64_encode((string) $http_response->getBody()));
		} else {
			return null;
		}
	}
	
	//Returns track video link for a specific track
	public function getTrackVideoLink($id, $frame_timestamp)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Content-Type' => 'application/json', 'Authorization' => 'Bearer '.$this->token];
		$s3path="crops_".date("YmdHi".$id);
		$http_response=$client->get("api/tracks/$id?frameTimeStamp=$frame_timestamp", ['headers' => $headers]);
		if($http_response->getStatusCode() == 200) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			$img_path=$response['images'][0]['url'];
			$img_path=preg_replace("/\/storage\//", "", $img_path);
			$s3path=preg_replace("/\/Crop.*/", "", $img_path);
			$camera=$response['camera']['id'];

			$http_response=$client->get("api/tracks/$id/video?camera=$camera&frameTimeStamp=$frame_timestamp&s3path=$s3path&objectType=1", ['headers' => $headers]);
			if($http_response->getStatusCode() == 200) {
				$response_json= (string) $http_response->getBody();
				log_message('debug', 'Response '.$response_json);
				$response=json_decode($response_json, true);
				return($response['videoUrl'] ?? '');
			}
		}
	}
	
	//Gets tracks
	public function getTracks($cameras)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$body=['camera' => $cameras];

		$http_response=$client->post('api/tracks', ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Track Response '.$response_json);
			$response=json_decode($response_json, true);
			return($response['data']);
		}	
	}
	
	//Gets alerts
	public function getAlerts($cameras)
	{
		$client = new Client(['base_uri' => getenv('oosto.url'), 'verify' => false]);
		$headers = ['Authorization' => 'Bearer '.$this->token];
		$body=["operationName" => "alerts","variables" => ["filters" => ["cameras" => ["b935d693-93e8-4192-8132-2b85d3062778","62f47e90-0a95-4add-ac53-07842aa586a0","940bad89-39ac-42cc-9092-f21552615b27","fe55c2be-0cf5-4ca2-bed4-3e04bd68ffe5","c00d2b3a-c3bc-411a-92e7-0143c6459b93"],"ack" => false]],"query" => "query alerts(\$filters: AlertFilters!) {\n  alerts(filters: \$filters) {\n    items {\n      id\n      trackId\n      collateId\n      frameTimeStamp\n      camera {\n        title\n        id\n        streamType\n        cameraGroupId\n      }\n      extraData\n      acknowledged\n      subject {\n        name\n        id\n        groups {\n          title\n          id\n          color\n        }\n        image {\n          url\n        }\n      }\n      images {\n        url\n      }\n      status\n      subType\n    }\n    total\n    unread\n  }\n}\n"];

		//$body=['camera' => $cameras];

		$http_response=$client->post('api/graphql', ['json' => $body, 'headers' => $headers]);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Graphql Response '.$response_json);
			$response=json_decode($response_json, true);
			return($response['data']['alerts']['items']);
		}	
	}	
	
}
    


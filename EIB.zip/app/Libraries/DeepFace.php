<?php

namespace App\Libraries;

use GuzzleHttp\Client;

class DeepFace
{
	private $cache;
	private $token = false;
	private $auth_tries=0;
	
	public function __construct()
        {
			$this->cache = \Config\Services::cache();
		}

	//Takes two base64 encoded images and returns if they match
	public function verify($img1, $img2) {
		$client = new Client(['base_uri' => "http://172.16.11.24:5000", 'verify' => false]);
		$headers = ['Content-Type' => 'application/json'];
		$body = ['img1_path' => $img1, 'img2_path' => $img2];
		try {
			$http_response=$client->post('/verify', ['headers' => $headers, 'json' => $body]);
		} catch (\Exception $e) {
			return (['error' => 1, 'message' => $e->getMessage()]);
		}
		if($http_response->getStatusCode() == 200) {
			$response_json= (string) $http_response->getBody();
			return json_decode($response_json, true);
		} else {
			return (['error' => 1, 'message' => "HTTP response $http_response"]);
		}
	}
}

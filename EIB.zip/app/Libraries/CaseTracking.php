<?php

namespace App\Libraries;

class CaseTracking
{
	private $cache;
	
	public function __construct()
        {
			$this->cache = \Config\Services::cache();
		}
	private function auth()
	{
		$url=getenv('casetracking.url').'app/api/authenticate';
		$headers=['authenticationtoken' => getenv('casetracking.token'), 'Content-Type' => "application/json"];
		$data=json_encode(['serverId' => "externalAccessUPF"]);
		$output_json= put_url_raw($url, $data, $headers);
		log_message('debug', 'Crimepad token '.$output_json);
		$output=json_decode($output_json, true);
		if($output) {
			return($output['token']);
		} else {
			return(false);
		}
	}

	public function query($data, $cache=true)
	{
		global $cache;
		//Confirm if data is cached first
		$cache_hash='CASE_TRACKING'.md5(print_r($data,true));
		if($cache==true) {
			$case_data=$this->cache->get($cache_hash);
		} else {
			$case_data=false;
		}
		if($case_data == false) {
			//Get cached token if possible, else get new token and cache it
			$token =$this->cache->get("CASE_TRACKING_TOKEN");
			if($token == false) {
				$token=$this->auth();
				if($token==false) {
					return(false);
				}
				$this->cache->save("CASE_TRACKING_TOKEN", $token, 20*MINUTE);
			}
			$url=getenv('casetracking.url').'client/api/search';
			$headers=['authenticationtoken' => getenv('casetracking.token'), 'server' => $token, 'Content-Type' => "application/json"];
			log_message('debug', json_encode($data));
			$output_json= post_url_raw($url, json_encode($data), $headers);
			log_message('debug', json_encode($output_json));
			$output=json_decode($output_json, true);
			$this->cache->save($cache_hash, $output, 20*MINUTE);
			return($output);
		} else {
			return($case_data);
		}
	}
}

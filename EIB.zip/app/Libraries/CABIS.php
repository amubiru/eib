<?php

namespace App\Libraries;
use GuzzleHttp\Client;

class CABIS
{
	private $cache;
	private $soap_params;
	private $extDataModel;
	
	public function __construct()
        {
			$this->cache = \Config\Services::cache();
			$this->extDataModel = model('App\Models\ExternalDataModel');
			$opts = array(
				'ssl' => array('verify_peer'=>false, 'verify_peer_name'=>false)
			);
			// SOAP 1.1 client
			$this->soap_params = array ('login' => 'opuser', 'password' => 'qwerty', 'encoding' => 'UTF-8', 'verifypeer' => false, 'verifyhost' => false, 'soap_version' => SOAP_1_1, 'trace' => 1, 'exceptions' => 0, "connection_timeout" => 180, 'stream_context' => stream_context_create($opts) );

		}
		
	private function auth($username, $password) {
		$json=json_encode(['username' => $username, 'password' => $password]);
		$response_json=post_url_raw(getenv('cabis.url').'user/auth', $json, ['Content-Type' => 'application/json']);
		$response=json_decode($response_json, true);
		if(is_array($response)) {
			if(array_key_exists('token', $response)) {
				return($response['token']);
			}
		}
		return false;
	}
	
	private function submit_auth($username, $password) {
		$json=json_encode(['username' => $username, 'password' => $password]);
		$response_json=post_url_raw(getenv('cabis.submit_url').'user/auth', $json, ['Content-Type' => 'application/json']);
		$response=json_decode($response_json, true);
		if(is_array($response)) {
			if(array_key_exists('token', $response)) {
				return($response['token']);
			}
		}
		return false;
	}
	
	//Submits a new subject to be enrolled
	public function submit($data)
	{
		global $cache;
		//Get cached token if possible, else get new token and cache it
		$token =$this->cache->get("CABIS_SUBMIT_TOKEN");
		if($token == false) {
			$token=$this->submit_auth(getenv("cabis.username"), getenv("cabis.password"));
			if(!$token) {
				return false;
			}
			$this->cache->save("CABIS_SUBMIT_TOKEN", $token, 20*MINUTE);
		}
		$response=post_url_raw(getenv('cabis.submit_url')."regobj/new", $data, ['Content-Type' => 'application/app.v0+json', 'Authorization' => "FRSToken ".$token]);
		//$response=json_decode($response_json, true);
		log_message('debug', 'CABIS submit '.$data);
		log_message('debug', 'CABIS response '.$response);
		return($response);
	}

	public function getInfoByTag($tag, $value, $strict="false", $single=true)
	{
		//Change the tags when cache criteria changes
		$cabis_cache_tag='CABIS_DATA_'.$tag.'_'.preg_replace("/[^a-z0-9]/i", "_", $value);
		$data=$this->cache->get($cabis_cache_tag);
		if($data) {
			return($data);
		}
		//Get cached token if possible, else get new token and cache it
		$token =$this->cache->get("CABIS_TOKEN");
		if($token == false) {
			$token=$this->auth(getenv("cabis.username"), getenv("cabis.password"));
			if(!$token) {
				return false;
			}
			$this->cache->save("CABIS_TOKEN", $token, 20*MINUTE);
		}
		$response_json=get_url(getenv('cabis.url')."regobj/getByTag?tag=".urlencode($tag)."&v=".urlencode($value)."&strict=$strict&photos=true", ['Content-Type' => 'application/app.v1+json', 'Authorization' => "FRSToken ".$token]);
		log_message('debug', "Attempt CABIS $value ".strlen($response_json));
		$response=json_decode($response_json, true);
		if($single) {
			//Return the last one, however we might also get a null
			if(is_array($response)) {
				//Iterate and find the newest
				$newest_record=$response[0];
				foreach($response as $record) {
					if(strtotime($record['dbDate'])>strtotime($newest_record['dbDate'])) {
						$newest_record=$record;
					}
				}
				return($newest_record);
			}
			return($response);
		} else {
			return($response);
		}
	}
	
	//Returns a minimal newest record - without images
	public function getNewestRecord($cabis_id)
	{
		//Get cached token if possible, else get new token and cache it
		$token =$this->cache->get("CABIS_TOKEN");
		if($token == false) {
			$token=$this->auth(getenv("cabis.username"), getenv("cabis.password"));
			if(!$token) {
				return false;
			}
			$this->cache->save("CABIS_TOKEN", $token, 20*MINUTE);
		}
		$response_json=get_url(getenv('cabis.url')."regobj/getByTag?tag=".urlencode(CABISID)."&v=".urlencode($cabis_id)."&strict=false&photos=false", ['Content-Type' => 'application/app.v1+json', 'Authorization' => "FRSToken ".$token]);
		log_message('debug', "Attempt text only CABIS $cabis_id ".strlen($response_json));
		$response=json_decode($response_json, true);
		//Return the last one, however we might also get a null
		if(is_array($response)) {
			//Iterate and find the newest
			$newest_record=$response[0];
			foreach($response as $record) {
				if(strtotime($record['dbDate'])>strtotime($newest_record['dbDate'])) {
					$newest_record=$record;
				}
			}
			return($newest_record);
		}
		return($response);
	}
	
	//Returns a particular CABIS tag or the entire dataset if tag is null
	public function getTag($cabis_id, $tagRequested=null, $cache=true)
	{
		if(!$cabis_id) { return false; };
		//Remove special characters from cache string
		$cache_cabis_id=preg_replace("/[^a-zA-Z0-9]/", "_", $cabis_id);
		//See if this CABIS ID is already cached
		$data=false;
		if($cache==true) {
			$data=$this->extDataModel->getDataByExternalId('cabis', $cache_cabis_id);
			if($data) {
				//Check if this is the latest data
				$newest_item=$this->getNewestRecord($cabis_id);
				if(strtotime($newest_item['dbDate'] ?? '')>strtotime($data['dbDate'] ?? '')) { //Invalidate data if it's not the newest
					log_message('debug', "Got newer item than cached for $cabis_id");
					$data=false;
				}
			}
		}
		if($data == false) {
			$data=$this->getInfoByTag(CABISID, $cabis_id);
			if($data) {
				$save_data=$data;
				unset($save_data['imageData']);
				$this->extDataModel->where(['data_source' => 'cabis', 'external_id' => $cache_cabis_id])->delete();
				$this->extDataModel->insert(['data_source' => 'cabis', 'external_id' => $cache_cabis_id, 'data_json' => json_encode($save_data), 'data' => print_r($save_data, true)]); 
			}
		}
		if($data) {
			if($tagRequested!=null) { //Requesting a particular tag
				//If it's an image tag, then retrieve the full data from CABIS
				$image_tags = array(FacePhoto, RTHUMB, RINDEX, RMIDDLE, RRING, RLITTLE, LTHUMB, LINDEX, LMIDDLE, LRING, LLITTLE, LFULLPALM, RFULLPALM, LFOURFINGERS, LTHUMBPLAIN, RTHUMBPLAIN, RFOURFINGERS, LWRITERSPALM, RWRITERSPALM, LUPPERPALM, RUPPERPALM, LLOWERPALM, RLOWERPALM, LRTTHUMBS);
				if(in_array($tagRequested, $image_tags)) {
					$data=$this->getInfoByTag(CABISID, $cabis_id);
				}
				return($this->getTagFromData($data, $tagRequested));
			}
		}
		return($data);
		
	}
	
	//Returns a particular item from CABIS
	public function getItem($cabis_id, $item, $cache=true)
	{
		if(!$cabis_id) { return false; };
		//Remove special characters from cache string
		$cache_cabis_id=preg_replace("/[^a-zA-Z0-9]/", "_", $cabis_id);
		//See if this CABIS ID is already cached
		$data=false;
		if($cache==true) {
			$data=$this->cache->get('CABIS_DATA_'.$cache_cabis_id);
		}
		if($data == false) {
			$data=$this->getInfoByTag('105', $cabis_id);
			if($data) {
				$this->cache->save('CABIS_DATA_'.$cache_cabis_id, $data, DAY);
			}
		}
		if($data) {
			return($data[$item]);
		}
		return(false);		
	}
	
	function getTagFromData($data, $tagRequested)
	{
		foreach($data['textData'] as $tag) {
			//Skip tag 723 in text
			if($tagRequested == 723) {
				continue;
			}
			if($tag['tagNum'] == $tagRequested) {
				return($tag['tagValue']);
			}
		}
		foreach($data['imageData'] ?? [] as $tag) {				
			if($tag['tagNum'] == $tagRequested) {
				return(base64_decode($tag['tagValue']));
			}
		}
		
	}
	
	function getArray($cabis_id)
	{
		$data=$this->getInfoByTag(CABISID, $cabis_id);
		$response=$data;
		unset($response['textData']);
		unset($response['imageData']);
		foreach($data['textData'] as $tag) {
			$response[$tag['tagNum']]= $tag['tagValue']; 
		}
		foreach($data['imageData'] ?? [] as $tag) {				
			$response[$tag['tagNum']]= base64_decode($tag['tagValue']); 

		}
		return($response);
	}
	
	//The tags from the new UI are formatted differently
	function getTagFromDataSwagger($data, $tagRequested)
	{
		foreach($data['textData'] as $tag) {
			//Skip tag 723 in text
			if($tagRequested == 723) {
				continue;
			}
			if($tag['tag'] == $tagRequested) {
				return($tag['value']);
			}
		}
		foreach($data['imageData'] as $tag) {				
			if($tag['tag'] == $tagRequested) {
				return(base64_decode($tag['value']));
			}
		}
		
	}
	
	public function findFinger($finger, $value) 
	{
		$expressId = new \SoapClient(__DIR__."/../../writable/uploads/OpenWS.wsdl", $this->soap_params);
		$expressId->__setLocation('https://172.16.11.16:8181/OPServer/OpenWS');

		//$params= new \stdClass();
		//$params->RThumbFinger = $value;
		//$result=$expressId->findFingers($params);
		//print "Started\n";
		log_message('debug',"Started");
		ob_flush();
		$response=$expressId->findFingers([$finger => $value]);
		//var_dump($response);
		log_message('debug', print_r($response, true));
		ob_flush();
		if(is_soap_fault($response)) {
			return(false);
		}
		if($response->return->errorCode!=0) {
			print $response->return->errorMess;
			exit(0);
		}
		//Get token and ID
		$token=$response->return->token;
		$id=$response->return->id;
		
		while(true) {
			$cb_response=$expressId->checkStatus(['vrfid' => $id, 'token' => $token]);
			log_message('debug', print_r($cb_response, true));
			if(is_soap_fault($cb_response)) {
				return(false);
			}
			if($cb_response->return->status==9) { //Get completed one
				$ret=[];
				$ret['matches']=[];
				for($n=0; $n < $cb_response->return->complete; $n++) {
					$response=$expressId->getCandidate(['vrfid' => $id, 'token' => $token, 'num' => $n]);
					if(!property_exists($response->return, 'textTags')) {
						log_message('debug', "Match not found");
						return false;
					}
					log_message('debug', print_r($response->return->textTags, true));
					$match=[];
					foreach($response->return->textTags as $tag) {
						if($tag->id==105) {
							$match['cabis_id']=$tag->value;
						}
						if($tag->id==111) {
							$match['first_name']=$tag->value;
						}
						if($tag->id==110) {
							$match['last_name']=$tag->value;
						}
					}
					$match['category']=$response->return->afisCategory;
					$ret['matches'][]=$match;
					//print $expressId->__getLastRequest();
				}
				return($ret);
			}
			log_message('debug', print_r($response, true));
			ob_flush();
			sleep(2);
		}
		
		return(false);
	}
	
	//Find candidate from PNG faces and/or fingers
	//File names are:   -F 'leftIndexFile=' \
   //'rightRingFile=' 'leftThumbFile=' 'rightMiddleFile='  'rightLittleFile=' 'rightIndexFile=' 'leftRingFile=' 'rightThumbFile=' 'leftMiddleFile='  'leftLittleFile='  'faceFile=@file.png;type=image/png'
	public function findCandidate($data)
	{
		log_message('debug', 'API details URL '.getenv('cabis.swagger_url').' Username: '.getenv('cabis.swagger_username').' Password: '.getenv('cabis.swagger_password'));
		//file_put_contents(__DIR__."\image.png", $image);
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		//$headers = ['Authorization' => 'Bearer '.$this->token];
		$files=[];
		$cardUID=false;
		foreach($data as $file) {
			$files[]=[
			  'name' => $file['name'],
			  'contents' => $file['content'],
			  'filename' => substr(uuid(), 0, 8).'.png',
			  'headers'  => [
				'Content-Type' => 'image/png'
			  ]
			  ];
		  }
			
		$options = [
		  'multipart' => 
			$files
			
		, 'auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ]];
		//log_message('debug', print_r($options, true));
		$http_response=$client->post('/card/search', $options);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			//log_message('debug', 'Response item'.print_r($response['items'], true));
			if(empty($response['cardUID'])) {
				return([]);
			} else {
				$cardUID=$response['cardUID'];
			}
		} else {
			log_message('debug', "Got status code ".$http_response->getStatusCode()." and body ".$http_response->getBody());
			return([]);
		}
		$candidates=[];
		return(['matches' => $this->getCandidates($cardUID)]);
	}
	
	//Finds candidate from Interpol PDF
	public function findCandidatePDF($pdf)
	{
		//file_put_contents(__DIR__."\image.png", $image);
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		//$headers = ['Authorization' => 'Bearer '.$this->token];
		$cardUID=false;

			
		$options = [
		  'multipart' => 
			[['name' => 'cardFile', 'contents' => $pdf, 'filename' => substr(uuid(), 0, 8).'.pdf', 'headers'  => [
				'Content-Type' => 'application/pdf'
			  ]
			  ]]
		, 'auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ]];
		//log_message('debug', print_r($options, true));
		$http_response=$client->post('/card/upload', $options);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			//log_message('debug', 'Response item'.print_r($response['items'], true));
			if(empty($response['cardUID'])) {
				return([]);
			} else {
				$cardUID=$response['cardUID'];
			}
		} else {
			log_message('debug', "Got status code ".$http_response->getStatusCode()." and body ".$http_response->getBody());
			return([]);
		}
		$candidates=[];
		return(['matches' => $this->getCandidates($cardUID)]);
	}
	
	
	//Finds candidate from latent fingerprint
	public function findCandidatesLatent($latent)
	{
		//file_put_contents(__DIR__."\image.png", $image);
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		//$headers = ['Authorization' => 'Bearer '.$this->token];
		$cardUID=false;

			
		$options = [
		  'multipart' => 
			[['name' => 'latentFile', 'contents' => $latent, 'filename' => substr(uuid(), 0, 8).'.pdf', 'headers'  => [
				'Content-Type' => 'image/png'
			  ]
			  ]]
		, 'auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ]];
		//log_message('debug', print_r($options, true));
		$http_response=$client->post('/card/latent?type=finger', $options);
		if(in_array($http_response->getStatusCode(), [200,201])) {
			$response_json= (string) $http_response->getBody();
			log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			//log_message('debug', 'Response item'.print_r($response['items'], true));
			if(empty($response['cardUID'])) {
				return([]);
			} else {
				$cardUID=$response['cardUID'];
			}
		} else {
			log_message('debug', "Got status code ".$http_response->getStatusCode()." and body ".$http_response->getBody());
			return([]);
		}
		$candidates=[];
		return(['matches' => $this->getLatentCandidates($cardUID)]);
	}
	
	//Given a CABIS ID, searches for fingerprints that match it
	public function findGroupMembersDEPRECATED($cabis_id, $return_original=true)
	{
		$fileNames=['rightThumbFile', 'rightIndexFile' ,  'rightMiddleFile', 'rightRingFile', 'rightLittleFile', 'leftThumbFile', 'leftIndexFile', 'leftMiddleFile','leftRingFile', 'leftLittleFile'];
		$tagNames=[RTHUMB, RINDEX, RMIDDLE, RRING, RLITTLE, LTHUMB, LINDEX, LMIDDLE, LRING, LLITTLE];
		$cabis_search_data=[];
		for($n=0;$n<10; $n++) {
			$finger=$this->getTag($cabis_id, $tagNames[$n]);
			if(strlen($finger ?? '')) {
				$image = new \Imagick();
				$image->readImageBlob($finger);
				$image->setImageFormat("png");
				$image->setImageUnits(\Imagick::RESOLUTION_PIXELSPERINCH);
				$image->setImageResolution(500,500);
				$newFinger= $image->getImageBlob();
				$cabis_search_data[]=['name' => $fileNames[$n], 'content' => $newFinger];
			}
		}
		//Gotten all fingers we can get, now run search
		//var_dump($cabis_search_data);
		log_message('debug', "COUNT SEARCH DATA ".count($cabis_search_data));
		if(count($cabis_search_data)) {
			$cabis_response=$this->findCandidate($cabis_search_data);
			if($cabis_response!=false) {
				if(is_array($cabis_response['matches'])) {
					if($return_original==false) { //Remove the original record
						$response=[];
						foreach($cabis_response['matches'] as $match) {
							if($match['cabis_id']!=$cabis_id) {
								$response[]=$match;
							}
						}
						return($response);
					} else {
						return($cabis_response['matches']);
					}
				}
			}
		}
		return [];
	}
	
	public function getMatchingCandidates($cabis_id)
	{
		$candidates_bio=$this->getMatchingCandidatesBiometric($cabis_id);
		$candidates_group=$this->getMatchingCandidatesGroup($cabis_id);
		$candidates=array_merge($candidates_bio, $candidates_group);
		$candidates=array_unique_multi($candidates);
		return($candidates);
	}
	
	
	//Gets matching candidates given a cabis ID
	//Uses the group ID and manual hits
	public function getMatchingCandidatesGroup($cabis_id)
	{
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		$matches=[];
		$cabisIds=[];
		$waited =0;
		while($waited<30) {
			try {
				$http_response=$client->request('GET', "/card/$cabis_id/groups", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ], 'http_errors' => false]);
				if($http_response->getStatusCode() == 200) {
					$response_json= (string) $http_response->getBody();
					//log_message('debug', 'MC Response '.$response_json);
					$response=json_decode($response_json, true);
					foreach($response['cards'] as $cards) {
						if(array_key_exists('groupNew', $cards)) {
							foreach($cards['groupNew']['cardIDs'] as $cardId) {
								$cabisIds[]=$cardId['num'];
							}
						}
					}
					$cabisIds=array_unique($cabisIds);
					log_message('debug', 'cabisIds '.print_r($cabisIds, true));
					foreach($cabisIds as $cabisId) {
						$matches[]=['cabis_id' => $cabisId, 'last_name' => $this->getTag($cabisId, LastName), 'first_name' => $this->getTag($cabisId, FirstName), 'category' => $this->getItem($cabisId, 'afisCategory')];
					}
					//log_message('debug', print_r($matches, true));
					return($matches);
				}
			} catch (GuzzleHttp\Exception\ClientException $e) {
				log_message('debug', 'Got exception trying again');
			}
			sleep(1);
			$waited++;
		}
		return($matches);
	}
	
	//Get group members
	public function getGroupMembers($group_id)
	{
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		$matches=[];
		$cabisIds=[];
		$waited =0;
		while($waited<30) {
			try {
				$http_response=$client->request('GET', "/card/group/$group_id?gtype=new", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ], 'http_errors' => false]);
				if($http_response->getStatusCode() == 200) {
					$response_json= (string) $http_response->getBody();
					log_message('debug', 'MC Response '.$response_json);
					$response=json_decode($response_json, true);
					foreach($response['cardIDs'] as $card) {
						$cabisIds[]=$card['num'];
					}
					$cabisIds=array_unique($cabisIds);
					log_message('debug', 'cabisIds '.print_r($cabisIds, true));
					foreach($cabisIds as $cabisId) {
						$matches[]=['cabis_id' => $cabisId, 'last_name' => $this->getTag($cabisId, LastName), 'first_name' => $this->getTag($cabisId, FirstName), 'category' => $this->getItem($cabisId, 'afisCategory')];
					}
					//log_message('debug', print_r($matches, true));
					return($matches);
				}
			} catch (GuzzleHttp\Exception\ClientException $e) {
				log_message('debug', 'Got exception trying again');
			}
			sleep(1);
			$waited++;
		}
		return($matches);
	}
	
	
	//Gets matching candidates given a cabis ID
	//Uses matches based on biometrics
	public function getMatchingCandidatesBiometric($uid, $face_search='false')
	{
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		$matches=[];
		$waited =0;
		while($waited<30) {
			try {
				$http_response=$client->request('GET', "/card/$uid/candidates", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ], 'http_errors' => false]);
				if($http_response->getStatusCode() == 200) {
					$response_json= (string) $http_response->getBody();
					//log_message('debug', 'MCOLD Response '.$response_json);
					$response=json_decode($response_json, true);
					foreach($response['candidates'] as $candidate) {
						if($face_search==true && !in_array($candidate['matchType'],  ['PHOTO_MATCH', 'FINGER_MATCH'])) {
							continue;
						} elseif(!in_array($candidate['matchType'], ['DUPLICATE','FINGER_MATCH'])) {
							continue;
						}
						$card=$this->getCard($candidate['cardAddr'], true);
						if(strlen($this->getTagFromDataSwagger($card, LastName) ?? '') || strlen($this->getTagFromDataSwagger($card, FirstName) ?? '')) { //Not a search card if it has at least first or last 
							$afisCategory=-1;
							$cardType=$this->getTagFromDataSwagger($card, TypeOfContact);
							if($cardType=='CAR') {
								$afisCategory=0;
							}
							if($cardType=='LEO') {
								$afisCategory=1;
							}
							if($cardType=='MAP') {
								$afisCategory=2;
							}
							log_message('debug', print_r("Category ".$afisCategory, true));
							//IF not category set - newer records, then use the afisCategory
							if($afisCategory==-1) {
								$afisCategory=$this->getItem($this->getTagFromDataSwagger($card, CABISID), 'afisCategory');
							}
							$matches[]=['cabis_id' => $this->getTagFromDataSwagger($card, CABISID), 'last_name' => $this->getTagFromDataSwagger($card, LastName), 'first_name' => $this->getTagFromDataSwagger($card, FirstName), 'category' => $afisCategory];
						}
					}
				}
				return($matches);
			} catch (GuzzleHttp\Exception\ClientException $e) {
				log_message('debug', 'Got exception trying again');
			}
			sleep(1);
			$waited++;
		}
		return($matches);
	}
		
	//Gets search candidates given a search card UID. 
	public function getCandidates($uid)
	{
		//Retry since sometimes the API returns an error
		$waited=0;
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		$matches=[];
		while($waited<30) {
			try {
			$http_response=$client->request('GET', "/card/$uid/candidates", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ], 'http_errors' => false]);
			if($http_response->getStatusCode() == 200) {
				$response_json= (string) $http_response->getBody();
				log_message('debug', 'Response '.$response_json);
				$response=json_decode($response_json, true);
				foreach($response['candidates'] as $candidate) {
					$card=$this->getCard($candidate['cardAddr'], true);
					if(strlen($this->getTagFromDataSwagger($card, LastName) ?? '')!=0) { //Not a search card
						$afisCategory=$this->getItem(CABISID, 'afisCategory');
						$matches[]=['cabis_id' => $this->getTagFromDataSwagger($card, CABISID), 'last_name' => $this->getTagFromDataSwagger($card, LastName), 'first_name' => $this->getTagFromDataSwagger($card, FirstName), 'category' => $afisCategory];
					}
				}
				return($matches);
			}
			} catch (GuzzleHttp\Exception\ClientException $e) {
				log_message('debug', 'Got exception trying again');
			}
			sleep(1);
			$waited++;
		}
		return($matches);
	}
	
	
		//Gets search candidates given a search card UID produced by the card/latent API. 
	public function getLatentCandidates($uid)
	{
		//Retry since sometimes the API returns an error
		$waited=0;
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		$matches=[];
		while($waited<30) {
			try {
			$http_response=$client->request('GET', "/card/$uid/lcandidates?ltype=latent&lnum=1", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ], 'http_errors' => false]);
			log_message('debug', 'Response '.$http_response->getBody());
			if($http_response->getStatusCode() == 404) { //Not yet processed
				//return([]);
			}
			if($http_response->getStatusCode() == 200) {
				$response_json= (string) $http_response->getBody();
				log_message('debug', 'Response '.$response_json);
				$response=json_decode($response_json, true);
				foreach($response['candidates'] as $candidate) {
					//Discard poor matches
					if($candidate['matchIndex'] < 3000) {
						continue;
					}
					$card=$this->getCard($candidate['cardAddr'], true);
					if(strlen($this->getTagFromDataSwagger($card, LastName) ?? '')!=0) { //Not a search card
						$afisCategory=$this->getItem(CABISID, 'afisCategory');
						$matches[]=['cabis_id' => $this->getTagFromDataSwagger($card, CABISID), 'last_name' => $this->getTagFromDataSwagger($card, LastName), 'first_name' => $this->getTagFromDataSwagger($card, FirstName), 'category' => $afisCategory];
					}
				}
				return($matches);
			}
			} catch (GuzzleHttp\Exception\ClientException $e) {
				log_message('debug', 'Got exception trying again');
			}
			sleep(4);
			$waited++;
		}
		return(array_unique_multi($matches));
	}
		
	public function getCard($uid, $textOnly=true)
	{
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false]);
		$card=[];
		$http_response=$client->request('GET', "/card/$uid/text?ctype=card", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ], 'http_errors' => false]);
		if($http_response->getStatusCode() == 200) {
			$response_json= (string) $http_response->getBody();
			//log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			if(array_key_exists('tags', $response)) {
				$card['textData']=$response['tags'];
			}
		}
		if($textOnly) {
			$card['imageData']=[];
			return($card);
		}
		$tags=FacePhoto.",".RTHUMB . "," . RINDEX . "," . RMIDDLE . "," . RRING . "," . RLITTLE . "," . LTHUMB . "," . LINDEX . "," . LMIDDLE . "," . LRING . "," . LLITTLE . "," . LFULLPALM . "," . RFULLPALM . "," . LFOURFINGERS . "," . LTHUMBPLAIN . "," . RTHUMBPLAIN . "," . RFOURFINGERS . "," . LWRITERSPALM . "," . RWRITERSPALM . "," . LUPPERPALM . "," . RUPPERPALM . "," . LLOWERPALM . "," . RLOWERPALM . "," . LRTTHUMBS;

		$http_response=$client->get("/card/$uid/image/$tags", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password') ]]);
		if($http_response->getStatusCode() == 200) {
			$response_json= (string) $http_response->getBody();
			//log_message('debug', 'Response '.$response_json);
			$response=json_decode($response_json, true);
			if(array_key_exists('tags', $response)) {
				$card['imageData']=$response['tags'];
			}
		}
		return($card);
	}
	
	//Check that Swagger service is running
	public function checkSwagger()
	{
		$client = new Client(['base_uri' => getenv('cabis.swagger_url'), 'verify' => false, 'http_errors' => false]);
		$card=[];
		try {
			$http_response=$client->request('GET', "/info", ['auth' => [getenv('cabis.swagger_username'), getenv('cabis.swagger_password')]]);
			if($http_response->getStatusCode() == 200) {
				return true;
			}
			return false;
		//}catch (\GuzzleHttp\Exception\ConnectException $e) {
		}catch (\Exception $e) {
			return false;
		}
	}
			
}
    


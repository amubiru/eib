<?php

namespace App\Libraries;

class NIRA
{
	private $cache;
	private $token = false;
	private $extDataModel;
	private $auth_tries=0;
	
	public function __construct()
        {
			$this->cache = \Config\Services::cache();
			$this->extDataModel = model('App\Models\ExternalDataModel');
			$token =$this->cache->get("NIRA_TOKEN");
			if($token == false) {
				$token=$this->auth();
			if($token) {
				$this->token = $token;
				$this->cache->save("NIRA_TOKEN", $token, 4*MINUTE);
			}
		} else {
			$this->token=$token;
		}
		}
	public function set_pass() {
		$pass=getenv("nira.password.prefix").date('yW', strtotime("-7 days"));
		//$pass=getenv("nira.password.prefix")."2432";
		$this->cache->save("NIRA_PASSWORD", $pass, MONTH);
	}
	
	private function auth() {
		if($this->auth_tries>2) { //Prevent a loop here for whatever reason
			log_message('debug', 'Too many auth retries');
			return false;
		}
		$this->auth_tries++;
		$nira_pass=$this->cache->get("NIRA_PASSWORD");
		if(!$nira_pass) { //Maybe redis rebooted, we will assume the password suffix current
			$nira_pass=getenv("nira.password.prefix").date('yW');
			$this->cache->save("NIRA_PASSWORD", $nira_pass, MONTH);
		}
		$current_pass=getenv("nira.password.prefix").date('yW'); //Password prefix plus 2 digit year and week of the year
		if(getenv('CI_ENVIRONMENT') == 'development') {
			$nira_pass=$current_pass;
		}
		//log_message('debug', 'Current_pass '.$current_pass);
		log_message('debug', "NIRA pass: $nira_pass and encoded: ".base64_encode($nira_pass ?? ''));
		$post_data=['username' => getenv("nira.username"), 'password' => base64_encode($nira_pass ?? ''), 'grant_type' => 'password'];
		$response_json=post_url(getenv('nira.url').'/token', $post_data, ['Content-Type' => 'application/x-www-form-urlencoded']);
		log_message('debug', 'Token '.$response_json);
		$response=json_decode($response_json, true);
		if(strlen($response['access_token'] ?? '') > 1) { //Must be a valid token
			//if(true) {
			if($current_pass==$nira_pass) { //Password is not yet due to change
				return($response['access_token']);
			} else { //Change password
				if(getenv('CI_ENVIRONMENT') == 'production') {
					log_message('debug', 'Changing NIRA password');
					$post_data=['username' => getenv("nira.username"), 'oldPassword' => base64_encode($nira_pass), 'newPassword' => base64_encode($current_pass)];
					$pass_response_json=post_url(getenv('nira.url').'/api/ChangePassword', $post_data, ['Authorization' => 'Bearer '.$response['access_token']]);
					log_message('debug', print_r($post_data, true));
					//log_message('debug', 'Auth '.$response['access_token']);
					log_message('debug', 'Pass change '.$pass_response_json);
					$pass_response=json_decode($pass_response_json, true);
					if(strstr($pass_response['errorDescrition'] ?? '', 'Changed')) {
						 $this->cache->save("NIRA_PASSWORD", $current_pass, MONTH);
						 return $this->auth(); //Renew token
					 }
				 }
			 }
		}
		
		return false;
	}
	
	public function changePass() {
		$nira_pass=$this->cache->get("NIRA_PASSWORD");
		$current_pass=getenv("nira.password.prefix").date('yW'); //Password prefix plus 2 digit year and week of the year
		print 'Current_pass '.$current_pass.'<br>';
		$post_data=['username' => getenv("nira.username"), 'oldPassword' => base64_encode($nira_pass), 'newPassword' => base64_encode($current_pass)];
		$pass_response_json=post_url(getenv('nira.url').'/api/ChangePassword', $post_data, ['Authorization' => 'Bearer '.$this->token]);
		print print_r($post_data, true).'<br>';
		//log_message('debug', 'Auth '.$response['access_token']);
		print 'Pass change '.$pass_response_json.'<br>';
		$pass_response=json_decode($pass_response_json, true);
		if(strstr($pass_response['errorDescrition'] ?? '', 'Changed')) {
			 $this->cache->save("NIRA_PASSWORD", $current_pass, MONTH);
			 return $this->auth; //Renew token
		 }

	}
	

	//{"transactionstate":{"transactionStatus":200,"transactionDescription":"Transaction has executed successfully"},"PersonDetails":{"nationalId":"CMNNNNNN","surname":"AAAA","givenNames":"BBBB","maidenNames":null,"previousSurnames":null,"dateOfBirth":"dd/mm/yyyy","dateOfBirthEstimated":"False","gender":"M","nationality":"Uganda (UGA)","livingStatus":"Alive","maritalStatus":null,"photo":"/
	//Gets a person details from National ID
	public function getPerson($id, $cache=true)
	{
		if(strlen($id ?? '') != 14) {
			return(null);
		}
		$id=strtoupper($id); //Uppercase is requiired
		$data=null;
		if($cache==true) {
			$data=$this->extDataModel->getDataByExternalId('nira', $id);
		}
		if(!$data) {
			$response_json=get_url(getenv('nira.url')."/api/GetPInfo?id=".urlencode($id), ['Authorization' => 'Bearer '.$this->token]);
			log_message('debug', "Attempt NIRA $id ".$response_json);
			$data=json_decode($response_json, true);
			if($data['transactionstate']['transactionStatus'] ?? 0 ==200) {
				$save_data=$data=$data['PersonDetails'];
				if(!$data) {
					return(null);
				}
				$large_data=[];
				$large_data['photo']=$data['photo'];
				$save_data=$data;
				unset($save_data['photo']);
				$this->extDataModel->insert(['data_source' => 'nira', 'external_id' => $id, 'large_data_json' => json_encode($large_data), 'data_json' => json_encode($save_data), 'data' => print_r($save_data, true)]); 
			} else {
				$data=[];
			}
		}
			return($data);
	}
	
	//"{\"permit_no\":\"1111111 01\",\"offendersName\":\"AAA BBB\",\"gender\":\"Male\",\"permit_expiry\":\"dd/mm/yyyy\",\"drive_restriction\":\"None\",\"permitClass\":\"A\",\"vehicle_restriction\":\"None\",\"issuing_authority\":\"Kampala\",\"photo\" \"dob\":\"dd/mm/yyyy\"
	//Retrieve a driving permit
	public function getLicense($id, $cache=true)
	{
		//Licenses can be issued multiple times with the suffix number changing, so check till we find a non expired one
		$data='';
		$cache_data=[];
		if($cache==true) {
			$cache_data=$this->extDataModel->getDataByExternalId('license', $id);
			if($cache_data) {
				return($cache_data);
			}
		}
		for($n=1;$n<100;$n++) {
			$license=$id." ".sprintf("%02d", $n);
			if($cache==true) {
				$cache_data=$this->extDataModel->getDataByExternalId('license', $license);
			} else {
				$cache_data=null;
			}
			if(!$cache_data) {
				$response_json=get_url(getenv('nira.url')."/api/DriverLicenceDetails?PermitNo=".urlencode($license), ['Authorization' => 'Bearer '.$this->token]);
				log_message('debug', "Attempt NIRA $license ".$response_json);
				//$nira_json=json_decode($response_json, true);
				//if(is_array($nira_json)) {
				//	return(false);
				//}
				$nira_data=json_decode($response_json, true); //Double JSON encoded - this was fixed so only need to decode once
				//log_message('debug', 'DDDD '.print_r($nira_data, true));
				if(strlen($nira_data['permit_expiry'] ?? '') > 0) {
					$data=$nira_data;
					$expiry=explode("/",$data['permit_expiry']);
					$expiry_date=$expiry[2].'-'.$expiry[1].'-'.$expiry[0];
					if($data && (strlen($data['photo'] ?? '') > 10)) { //If photo exists
						//Convert BMP image to PNG. Use a memory file to avoid outputting directly
						$im = imagecreatefromstring(base64_decode($data['photo']));
						$stream = fopen('php://memory','r+');
						imagepng($im, $stream);
						rewind($stream);
						$data['photo']=base64_encode(stream_get_contents($stream));
						fclose($stream);
						imagedestroy($im);
					}
					$large_data=[];
					$large_data['photo']=$data['photo'];
					unset($data['photo']);
					$save_data=$data;
					$this->extDataModel->insert(['data_source' => 'license', 'external_id' => $license, 'large_data_json' => json_encode($large_data), 'data_json' => json_encode($data), 'data' => print_r($save_data, true)]);
					//Also save it without the numbered offset
					//$this->extDataModel->insert(['data_source' => 'license', 'external_id' => $id, 'data_json' => json_encode($data), 'data' => print_r($save_data, true)]); 
					if(strtotime($expiry_date) > time()) { //Valid ID
						log_message('debug', "Expiry date $expiry_date is in the future");
						break;
					}
					log_message('debug', "Expiry date $expiry_date is in the past");
				} else { //Didn't get any data, have tried all applicable suffixes
					break;
				}
			} else {
				$data=$cache_data;
				if(strlen($data['permit_expiry'] ?? '') > 0) {
					$expiry=explode("/",$data['permit_expiry']);
					$expiry_date=$expiry[2].'-'.$expiry[1].'-'.$expiry[0];
					if(strtotime($expiry_date) > time()) { //Valid ID
						log_message('debug', "Expiry date $expiry_date is in the future");
						break;
					}
				}
			}
		}
		//log_message('debug', print_r($data, true));
		return($data);
	}
	
	//"{\"AttachmentSideBar\":\"Nil\",\"backPlateShape\":\"RECTANGL\",\"BodyDesc\":\"Pickup Double cabin\",\"CategoryName\":\"Ordinary Vehicles\",\"ChasisNo\":\"AAAA\",\"Color\":\"SILVER\",\"CountryOfOrigin\":\"THAILAND\",\"DateOfRegistration\":\"dd/mm/yyyy\",\"Email\":\"AAAA\",\"EngineNo\":\"AAA\",\"ErrorDesc\":\"SUCCESS\",\"ExtensionData\":\"System.Runtime.Serialization.ExtensionDataObject\",\"FrontPlateShape\":\"RECTANGL\",\"Fuel\":\"Diesel\",\"GrossWeight\":\"3250\",\"InssuranceComp\":\"\",\"IsUsedVehicle\":\"Y\",\"Make\":\"TOYOTA\",\"ManufactureYear\":\"2008\",\"MobileNumber\":\"NNNNN\",\"ModelName\":\"KUN25R\",\"MVRegNo\":\"AAA,\"NetWeight\":\"1850\",\"NumberOfAxels\":\"4\",\"NumberOfWheels\":null,\"OtherPurpose\":\"\",\"OwnerCategory\":\"UGANDAN\",\"PolicyNo\":\"\",\"Power\":\"2500\",\"PrevRegCountry\":\"THAILAND\",\"PrevregDate\":\"18/02/2009\",\"PrevRegNo\":\"THAILAND\",\"Purpose\":\"COMMVHCL\",\"SeatCapacity\":\"5\",\"TaxPayerName\":\"AAAAA\",\"TaxPayerType\":\"INDI\",\"TinIssueDate\":\"dd/mm/yyyy\",\"TinNo\":\"NNNN\",\"TyreSize\":\"265/65R17\",\"VehicleClassification\":\"Commercial Vehicle or Goods Vehicles, light goods, medium goods, heavy goods, vans, Prime Movers/Tractor Heads\"}"
	//Get Motor Vehicle details
	public function getVehicle($id, $cache=true)
	{
		$id=strtoupper($id); //Uppercase is requiired
		$data=null;
		if($cache==true) {
			$data=$this->extDataModel->getDataByExternalId('vehicle', $id);
		}
		
		if(trim($data['ErrorDesc'] ?? '') != 'SUCCESS') {
			$data=null;
		}
		if(!$data) {
			$response_json=get_url(getenv('nira.url')."/api/MotorVehicleDetails?CarRegNo=".urlencode($id), ['Authorization' => 'Bearer '.$this->token]);
			log_message('debug', "Attempt NIRA vehicle 1st pos $id ".$response_json);
			$data_json=json_decode($response_json, true);
			if(is_array($data_json)) {
				if($data_json['ErrorDesc'] ?? '' == 'SUCCESS') {
					$this->extDataModel->insert(['data_source' => 'vehicle', 'external_id' => $id, 'data_json' => json_encode($data_json), 'data' => json_encode($data_json)]);
				} 
				return($data_json);
			}
			log_message('debug', "Attempt NIRA vehicle 2nd pos $id ".$data_json);
			$data=json_decode($data_json, true); //String is sent double JSON encoded
			//log_message('debug', 'DDDD '.print_r($data, true));
			if(trim($data['ErrorDesc'] ?? '') == 'SUCCESS') {
				$this->extDataModel->insert(['data_source' => 'vehicle', 'external_id' => $id, 'data_json' => json_encode($data), 'data' => print_r($data, true)]); 
			} else {
				$data=false;
			}
		}
			//log_message('debug', 'YYYY returning '.print_r($data, true));
			return($data);
	}
	/*
	 * {
  "Firstname": "LAPYEM",
  "MiddleName": "ATIM",
  "LastName": "JACQUELINE",
  "TelephoneNo": "0772832811",
  "NIN": "CF87110102FGDL",
  "DOB": "10/14/1987 12:00:00 AM",
  "Gender": "Female",
  "PassportNo": "A00039622",
  "Pass_IssuingAuthority": "GOVT UGANDA KAMPALA",
  "Occupation": "BUSINESS WOMAN",
  "EmailAddress": "iinterpol619@gmail.com",
  "MaritalStatus": "SINGLE",
  "RefugeeCardNo": "N/A",
  "ApplicantType": "Ugandan",
  "LengthOfStay": "",
  "DistinguishingFeature": "",
  "Nationality": "UGANDA",
  "VisaNumber": "",
  "PlaceOfResidence": "MULAGO",
  "ReasonForCert": "Periodic Criminal Background Check",
  "Title": "MRS",
  "Height": "143",
  "Service_Type": "Certificate of Good Conduct",
  "prn": "2240014238930",
  "payment_status": "Paid",
  "payment_date": "4/4/2024 12:00:00 AM",
  "Amount": "76000",
  "Booked_Date": "4/5/2024 12:00:00 AM",
  "ApplicationNumber": "NETJPOOFBVMXVYY"
}*/
	public function getApplicant($id, $cache=true)
	{
		$data=null;
		$id=strtoupper($id); //Uppercase is requiired
		if($cache==true) {
			$data=$this->cache->get('POLICE_APPLICANT_'.$id);
		}
		
		if(strlen($data['FirstName'] ?? '') ==0) {
			$data=null;
		}
		if(!$data) {
			$response_json=get_url(getenv('nira.url')."/api/GetApplicantDetails?AppNum=".urlencode($id), ['Authorization' => 'Bearer '.$this->token]);
			$data=json_decode($response_json, true);
			log_message('debug', "Attempt NIRA applicant $id ".print_r($data, true));
			if(strlen($data['Firstname'] ?? '')>0) {
				$this->cache->save('POLICE_APPLICANT_'.$id, $data, 1*DAY);
			} else {
				$data=false;
			}
		}
			log_message('debug', 'YYYY returning '.print_r($data, true));
			return($data);
	}
	
	public function checkPRN($nin, $prn) {
		$post_data=['NIN' => $nin, 'prn' => $prn];
		$response_json=post_url(getenv('nira.url').'/api/Chkprn', ['NIN' => $nin, 'prn' =>$prn], ['Authorization' => 'Bearer '.$this->token]);
		//log_message('debug', 'Auth '.$response['access_token']);
		log_message('debug', 'Prn check '.print_r($response_json, true));
		$response=json_decode($response_json, true);
		if($response['trxResponse']['errorCode'] ?? 0 == 200) {
			if($response['prnChkRespone']['Status'] ?? 0 == 1) {
				return(true);
			}
		}
		return false;
	}
	
	public function postPhoto($applicationNo, $prn, $photo) 
	{
		$response_json=post_url(getenv('nira.url').'/api/COGCPhoto', ['photo' => base64_encode($photo), 'prn' =>$prn, 'applicationNum' => $applicationNo], ['Authorization' => 'Bearer '.$this->token]);
		//log_message('debug', 'Auth '.$response['access_token']);
		log_message('debug', 'Post photo '.print_r($response_json, true));
		$response=json_decode($response_json, true);
		if($response['trxResponse']['errorCode'] ?? 0 == 200) {
			return(true);
		}
		return false;
	}
	
	public function postCertificate($applicationNo, $cert, $type) 
	{
		$response_json=post_url(getenv('nira.url').'/api/SavePrintedCert', ['Certificate' => base64_encode($cert), 'applicationNum' =>$applicationNo, 'applicationNum' => $applicationNo, 'CrtTyp' => $type], ['Authorization' => 'Bearer '.$this->token]);
		//log_message('debug', 'Auth '.$response['access_token']);
		log_message('debug', 'Post certificate '.print_r($response_json, true));
		$response=json_decode($response_json, true);
		if($response['trxResponse']['errorCode'] ?? 0 == 200) {
			return(true);
		}
		return false;
	}
	
}
    


<?php

namespace App\Libraries;

class Utils
{
	private $cache;
	
	public function __construct()
	{
		$this->cache = \Config\Services::cache();
	}
	
	//Sharpens and then stores image for reference, returns a PNG image
	public static function sharpenImage($input)
	{
		$input_file=__DIR__."/../../writable/images/input_".date('Ymdhis').".png";
		file_put_contents($input_file, $input);
		$type=exif_imagetype($input_file);
		$image = new \Imagick();
		if(in_array($type, [2,6])) { //JPEG and BMP that support EXIF
			log_message('debug', "Found JPG");
			$new_image=static::image_fix_orientation($input_file);
			if($new_image!=false) {
				log_message('debug', "Found EXIF");
				$fileout = tmpfile();
				$pathout = stream_get_meta_data($fileout)['uri'];
				imagejpeg($new_image, $pathout, 90); 
				$image->readImage($pathout);
			}
		} else {
			log_message('debug', 'Read from non EXIF file');
			$image->readImage($input_file);
		}
        // convert the output to png
        $image->setImageFormat('png');
		$image->adaptiveSharpenImage(0,5);
		$output=$image->getImageBlob();
		$output_file=__DIR__."/../../writable/images/output_".date('Ymdhis').".png";
		file_put_contents($output_file, $output);
		return($output);
	}
	
	private static function image_fix_orientation($filename) {
		$exif = exif_read_data($filename);
		if (!empty($exif['Orientation'])) {
			$image = imageCreateFromAny($filename);
			switch ($exif['Orientation']) {
				case 3:
					$image = imagerotate($image, 180, 0);
					log_message('debug','Rotated 180 degrees');
					break;

				case 6:
					$image = imagerotate($image, -90, 0);
					log_message('debug','Rotated 90 degrees');
					break;

				case 8:
					$image = imagerotate($image, 90, 0);
					log_message('debug','Rotated -90 degrees');
					break;
			}
			return($image);
		}
		return(false);
	}
	
	
	
}
    


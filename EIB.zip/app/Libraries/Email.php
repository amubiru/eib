<?php

namespace App\Libraries;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

class Email
{
	public function send($address, $subject, $text, $cc=NULL, $attachment=NULL, $attachmentName=NULL)
    {
        // Check address
        if(!filter_var($address, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        try {
            $mail = new PHPMailer(true);
            // ...existing code...
            $mail->IsSMTP(); // telling the class to use SMTP
            $mail->SMTPAuth = true; // enable SMTP authentication
            $mail->SMTPSecure = "ssl";                 
            $mail->Host = getenv('smtp.host'); // SMTP server
            $mail->Port = getenv('smtp.port'); // SMTP port
            $mail->Username = getenv('smtp.username'); // username
            $mail->Password = getenv('smtp.password'); // password

            $mail->SetFrom(getenv('smtp.from'), getenv('smtp.from_name'));
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = $subject;
            $mail->Body = "<html><body>$text</body></html>";
            $mail->AddAddress($address);

            if($cc != NULL) {
                foreach($cc as $rc) {
                    $mail->AddCC($rc);
                }
            }
            if($attachment) {
                $mail->addAttachment($attachment, $attachmentName);
            }
            if(!$mail->Send()) {
                log_message('error', "Mailer Error: " . $mail->ErrorInfo);
                return false;
            }
        } catch(Exception $e) {
            log_message('error', "Message could not be sent. Mailer Error: {$mail->ErrorInfo}");
            return false;
        }
        return true;
    }
}



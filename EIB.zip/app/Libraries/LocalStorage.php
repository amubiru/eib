<?php

namespace App\Libraries;

class LocalStorage
{
	private $cache;

	public function __construct() {}

	public function store($type, $id) {}
}

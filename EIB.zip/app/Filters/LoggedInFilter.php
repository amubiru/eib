<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

//Implements security checks to make sure that user has a valid session ID
class LoggedInFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
		$session= \Config\Services::session();
		$userModel = model('App\Models\UserModel');
		if(!isset($_SESSION['user_id'])) {
			return redirect()->to(base_url('login'));
		}
        $user = $userModel->getById($_SESSION['user_id'], true);
		if(!$user) {
			return redirect()->to(base_url('login'));
		}
		
		//Do additional checks on whether the user actually has the rights to this module
		//Remove all sensitive info from request and then log it
		log_message('debug', $request->getServer('REQUEST_URI')." ".print_r(remove_sensitive_fields($_POST), true));
		
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}

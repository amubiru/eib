<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

//Implements security checks that Ajax requests come from a valid user
class AjaxTokenFilter implements FilterInterface
{
	private $controllerName;
	private $methodName;
	
    public function before(RequestInterface $request, $arguments = null)
    {
		helper("ecro");
		$cache = \Config\Services::cache();
		//Allow all requests from localhost
		if(in_array($request->getIPAddress(), ['127.0.0.1', '172.16.11.14', '172.16.40.54', '172.16.41.14'])) {
			log_message('debug', 'Local host AJAX request');
			return;
		}
		
		$token=$request->getVar('token');
		if(!$token) {
			return \Config\Services::response()->setStatusCode(403)->setJSON(['message' => 'No token supplied']);
		}
		$token_user=$cache->get('AJAX_TOKEN_'.$token);
		if(!$token_user) {
			return \Config\Services::response()->setStatusCode(403)->setJSON(['message' => 'Invalid token supplied']);
		}
		$router = service('router');
		$this->controllerName  = str_replace('\\App\\Controllers\\', '', $router->controllerName());
		$this->methodName = $router->methodName();
		log_message('debug', "In ".$this->controllerName." and method ".$this->methodName);
		log_message('debug', 'User ID: '.$token_user." ".print_r(remove_sensitive_fields($_POST), true));
		
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}

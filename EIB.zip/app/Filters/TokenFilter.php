<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

//Implements security checks to make sure that user has a valid token
class TokenFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
		helper("ecro");
		$userModel = model('App\Models\UserModel');
		if(!$request->header('Authorization')) {
			return \Config\Services::response()->setStatusCode(403)->setJSON(['message' => 'Invalid or no token supplied']);
		}
        $user = $userModel->getByToken($request->header('Authorization')->getValue());
		if(!$user) {
			return \Config\Services::response()->setStatusCode(403)->setJSON(['message' => 'Invalid or no token supplied']);
		}
		//Remove all sensitive info from request and then log it
		log_message('debug', print_r(remove_sensitive_fields($_POST), true));
		
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}

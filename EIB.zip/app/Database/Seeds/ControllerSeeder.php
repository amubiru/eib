<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class ControllerSeeder extends Seeder
{
    public function run()
    {
        $data = [['controller' => ['name' => 'Admin\AdminsController', 'description' => 'Admins', 'route' => '/admin/admins', 'model' =>'AdminModel'],
            'fields' => [
            ['position' => 1, 'type' => 'text', 'required' => true, 'db_name' => 'name', 'name' => 'Name', 'description' => 'Name of admin'],
            ['position' => 2, 'type' =>'password', 'required' => false, 'db_name' => 'password', 'name' => 'Password', 'description' => 'Leave blank to keep existing'],
            ['position' => 3, 'type' =>'text', 'required' => true, 'db_name' => 'email', 'name' => 'Email', 'description' => 'Email address'],
            ['position' => 4, 'type' =>'text', 'required' => false, 'db_name' => 'phone', 'name' => 'Phone', 'description' => 'Phone number'],
            ['position' => 5, 'type' =>'option', 'required' => true, 'db_name' => 'role_id', 'name' => 'Role', 'description' => 'Role'],
            ['position' => 100, 'type' => 'hidden', 'required' => false, 'db_name' => 'id', 'name' => 'id', 'description' => 'Row ID']
            ]],
            ['controller' => ['name' => 'Admin\CreatorsController', 'description' => 'Music Creators', 'route' => '/admin/creators', 'model' =>'CreatorModel'],
            'fields' => [
            ['position' => 1, 'type' => 'text', 'required' => true, 'db_name' => 'name', 'name' => 'Name', 'description' => 'Name of creator'],
            ['position' => 2, 'type' =>'checkbox', 'required' => false, 'db_name' => 'is_singer', 'name' => 'Singer', 'description' => 'Singer'],
            ['position' => 3, 'type' =>'checkbox', 'required' => false, 'db_name' => 'is_songwriter', 'name' => 'SongWriter', 'description' => 'SongWriter'],
            ['position' => 4, 'type' =>'checkbox', 'required' => false, 'db_name' => 'is_producer', 'name' => 'Producer', 'description' => 'Producer'],
            ['position' => 5, 'type' =>'lookup', 'required' => false, 'db_name' => 'revenue', 'name' => 'Revenue Today', 'description' => 'Revenue Today'],
            ['position' => 100, 'type' => 'hidden', 'required' => false, 'db_name' => 'id', 'name' => 'id', 'description' => 'Row ID']
            ]],
            ['controller' => ['name' => 'Admin\SongsController', 'description' => 'Songs', 'route' => '/admin/songs', 'model' =>'SongModel'],
            'fields' => [
            ['position' => 1, 'type' => 'text', 'required' => true, 'db_name' => 'name', 'name' => 'Name', 'description' => 'Name of client'],
            ['position' => 2, 'type' =>'option', 'required' => false, 'db_name' => 'singer_id', 'name' => 'Singer', 'description' => 'Singer'],
            ['position' => 3, 'type' =>'option', 'required' => false, 'db_name' => 'songwriter_id', 'name' => 'Song Writer', 'description' => 'Song Writer'],
            ['position' => 4, 'type' =>'option', 'required' => false, 'db_name' => 'producer_id', 'name' => 'Producer', 'description' => 'Producer'],
            ['position' => 100, 'type' => 'hidden', 'required' => false, 'db_name' => 'id', 'name' => 'id', 'description' => 'Row ID']
            ]],
        ];
        //Remove existing data
        $this->db->query("delete from field_options");
        $this->db->query("delete from fields");
        $this->db->query("delete from controllers");
		foreach($data as $controller) {
			$this->db->table('controllers')->insert($controller['controller']);
			echo "Adding ".$controller['controller']['name']."\n";
			$controller_id=$this->db->insertID();
			if(array_key_exists('fields', $controller)) {
				foreach ($controller['fields'] as $field) {
					$field['controller_id']=$controller_id;
					//Remove options since it's an array
					$field_insert = $field;
					if(array_key_exists('options', $field)) {
							unset($field_insert['options']);
					} 
					$this->db->table('fields')->insert($field_insert);
					$field_id=$this->db->insertID();
					if(array_key_exists('options', $field)) {
						foreach($field['options'] as $option) {
							$option['field_id']=$field_id;
							$this->db->table('field_options')->insert($option);
							$option_id=$this->db->insertID();
						}
					}
				}
			}
		}
    }
}

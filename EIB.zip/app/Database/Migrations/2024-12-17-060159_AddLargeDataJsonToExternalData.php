<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddLargeDataJsonToExternalData extends Migration
{
    public function up()
    {
        // Add the new 'large_data_json' field
        $fields = [
            'large_data_json' => [
                'type'       => 'LONGTEXT',
                'null'       => true, // Allow NULL values
                'default'    => null,
            ],
        ];

        // Modify the 'external_data' table
        $this->forge->addColumn('external_data', $fields);
    }

    public function down()
    {
        // Drop the 'large_data_json' column if the migration is rolled back
        $this->forge->dropColumn('external_data', 'large_data_json');
    }
}


<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class UpdateSubjectRecordsTable extends Migration
{
    public function up()
    {
        // Modify the existing columns and add new ones
        $this->forge->modifyColumn('subject_records', [
            'sentence_type' => [
                'type'       => 'ENUM',
                'constraint' => ['CUSTODIAL', 'NON CUSTODIAL'],
                'null'       => false,
                'default'    => 'NON CUSTODIAL',
            ],
        ]);

        $this->forge->addColumn('subject_records', [
            'case_result' => [
                'type'       => 'ENUM',
                'constraint' => ['NOT SENTENCED YET', 'ACQUITTED', 'DISMISSED', 'SENTENCED'],
                'null'       => false,
                'default'    => 'NOT SENTENCED YET',
            ],
            'non_custodial_sentence' => [
                'type'       => 'ENUM',
                'constraint' => ['FINE', 'CAUTION', 'COMMUNITY SERVICE'],
                'null'       => true,
            ],
        ]);
    }

    public function down()
    {
        // Reverse the changes made in the up method
        $this->forge->modifyColumn('subject_records', [
            'sentence_type' => [
                'type'       => 'ENUM',
                'constraint' => ['NOT SENTENCED YET', 'PROBATION', 'PRISON', 'COMMUNITY SERVICE', 'FINE'],
                'null'       => false,
                'default'    => 'NOT SENTENCED YET',
            ],
        ]);

        $this->forge->dropColumn('subject_records', 'case_results');
        $this->forge->dropColumn('subject_records', 'non_custodial_sentence');
    }
}


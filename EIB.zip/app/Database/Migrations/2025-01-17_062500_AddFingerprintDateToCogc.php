<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class AddFingerprintDateToCogc extends Migration
{
    public function up()
    {
        $this->forge->addColumn('cogc', [
            'fingerprint_date' => [
                'type'       => 'DATETIME',
                'null'       => true,
                'after'      => null, // You can specify the column order if needed (optional)
            ],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('cogc', 'fingerprint_date');
    }
}


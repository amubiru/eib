<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

/**
 * Class CrudController
 *
 * Provides semi automated CRUD capabilities
 *
 * For security be sure to declare any new methods as protected or private.
 */
abstract class CrudController extends BaseController
{
    protected $controller;
    protected $controllerName;
    protected $methodName;
    protected $controllerModel;
    protected $dataModel;
    protected $dbData;
    protected $fields;
    /**
     * Constructor.
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        $router = service('router');
		$this->controllerName  = str_replace('\\App\\Controllers\\', '', $router->controllerName());
		$this->methodName = $router->methodName();
		log_message('debug', "In ".$this->controllerName." and method ".$this->methodName);
		
		
		//Now get controller and field data
		$this->controllerModel = model('App\Models\ControllerModel');
		$this->controller=$this->controllerModel->getByControllerName($this->controllerName);
		$this->fields=$this->controllerModel->getFields($this->controller['id']);
		$this->dataModel = model('App\\Models\\'.$this->controller['model']);
		//Fill in option fields
		$field_count=count($this->fields);
		for($n=0;$n<$field_count; $n++) {
			if($this->fields[$n]['type']=='option') {
				$options=$this->controllerModel->getFieldOptions($this->fields[$n]['id']);
				//If there are no option fields, check if options can be obtained by checking the data Model
				if(empty($options)) {
					$options=$this->dataModel->getFieldOptions($this->fields[$n]['db_name']);
				}
				$this->fields[$n]['options'] = $options;
			}
		}
		$this->dbData=$this->dataModel->getAll($this->fields[0]['db_name']); //Order by the first field returned
    }
    
    public function add()
    {
		$data=['fields' => $this->fields, 'controller' => $this->controller];
		return view('header', $data)
			. view('menu', $data)
			. view('edit_crud', $data)
			. view('footer', $data);
	}
	
	public function edit($id)
    {
		$record=$this->dataModel->find($id);
		$data=['record' => $record, 'fields' => $this->fields, 'controller' => $this->controller];
		return view('header', $data)
			. view('menu', $data)
			. view('edit_crud', $data)
			. view('footer', $data);
	}
	
    //Shows the default text
    public function index() {
		$data=['data' => $this->dbData, 'fields' => $this->fields, 'controller' => $this->controller];
		return view('header', $data)
			. view('menu', $data)
			. view('crud', $data)
			. view('footer', $data);
	}
	
	//Saves/edit data to the database
	public function submit() {
		$dbData=[];
		foreach($this->fields as $field) {
			$dbData[$field['db_name']] = $this->request->getVar($field['db_name']);
		}
		log_message('debug', print_r($dbData));
		if(empty($dbData['id'])) { //New record
			unset($dbData['id']);
			$this->dataModel->insert($dbData);
		} else { //Updating
			$id=$dbData['id'];
			unset($dbData['id']);
			$this->dataModel->update($id, $dbData);
		}
		$this->session->setFlashdata('message', 'Data has been saved'); 
		$this->session->setFlashdata('messageTitle', 'Saved');
		return redirect()->to($this->controller['route']);
	}
	
	//Deletes a row from the DB
	public function delete($id) {
		$this->dataModel->delete($id);
		$this->session->setFlashdata('message', 'Record deleted'); 
		$this->session->setFlashdata('messageTitle', 'Deleted');
		return redirect()->to($this->controller['route']);
	}
}

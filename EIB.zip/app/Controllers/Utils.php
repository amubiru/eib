<?php namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;


class Utils extends ResourceController
{

	use ResponseTrait;
	
	protected $cache;
	protected $userModel;
	protected $smsModel;

	function __construct()
	{
	}

	//index
	public function options()
	{
      header('Access-Control-Allow-Origin: *');
      header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
      header('Access-Control-Max-Age: 1000');
      header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
	
	}
	
}

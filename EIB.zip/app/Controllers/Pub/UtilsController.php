<?php 

namespace App\Controllers\Pub;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use App\Libraries\Oosto;
use App\Libraries\NIRA;
use App\Libraries\Email;


//This class runs various utilities especially those run from CRON/Task scheduler
class UtilsController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	private $controller;
	protected $cache;
	protected $cabisModel;
	protected $cogcModel;
	protected $oostoWebsocketModel;
	protected $cameraBroadcastModel;
	protected $subjectModel;


	function __construct()
	{
		$this->controller=[];
		$this->cabisModel = model('App\Models\CabisModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->oostoWebsocketModel = model('App\Models\OostoWebsocketModel');
		$this->cameraBroadcastModel = model('App\Models\CameraBroadcastModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->cache = \Config\Services::cache();
		session_write_close(); //In case CABIS is unavailable, other requests should keep running
	}
	
	//Find CABIS records that are not yet accessible
	public function cabisNotAccessible()
	{
		$cabis=new CABIS();
		$notaccessed=$this->cabisModel->getNew();
		foreach($notaccessed as $record) {
			$data=$cabis->getTag($record['subject_id'], '105', false);
			if($data) { //Mark that this record is now available
				$this->cabisModel->update($record['id'], ['access_time' => date('Y-m-d h:i:s')]);
			}
		}
	}
	
	public function checkCabisEnroll()
	{
		$records=$this->cabisModel->delayedAccess();
		$ids="";
		foreach($records as $record) {
			$ids.=$record['subject_id'].' ';
		}
		if($ids) {
			print "WARINING - CABIS ID(s) $ids not accessible after 10 minutes";
			exit(1);
		}else {
			print "OK";
			exit(0);
		}
	}
	
	public function checkCertificates()
	{
		log_message('debug', 'NAGIOS start check');
		$certs=$this->cogcModel->getFingerprinted();
		log_message('debug', 'NAGIOS checked');
		if(count($certs)>30) {
			print "CRITICAL - Certificates are not being processed ".count($certs)." pending";
			exit(2);
		}else {
			print "OK ".count($certs)." pending";
			exit(0);
		}
	}
	
	public function checkCabis()
	{
		$cabis=new CABIS();
		$data=$cabis->getTag(40, '105', false);
		if(!$data) {
			print "CRITICAL - CABIS is not available";
			exit(2);
		}else {
			print "OK";
			exit(0);
		}
	}
	
	public function checkCabisSwagger()
	{
		$cabis=new CABIS();
		$data=$cabis->checkSwagger();
		if($data == false) {
			print "CRITICAL - CABIS Swagger is not available";
			exit(2);
		}else {
			print "OK";
			exit(0);
		}
	}
	
	public function checkNira()
	{
		$nira = new NIRA;
		$applicant=$nira->getApplicant('NETJPOOFBVMXVYY', false);
		if(!strstr(json_encode($applicant ?? ''), 'NETJPOOFBVMXVYY')) { //Can't find applicatant number
			print "CRITICAL - NIRA is not available";
			exit(2);
		}else {
			print "OK";
			exit(0);
		}
	}
	
	public function getCabis($id)
	{
		$cabis=new CABIS();
		$data=$cabis->getTag($id, '105', false);
		if(!$data) {
			print "No CABIS data for record $id";
		}else {
			print "CABIS data found";
			$data=$cabis->getTag($id, '705', false);
			if(!$data) {
				print "<br>No image data found";
			} else {
				print "<br>Image data found";
			}
		}
	}
	public function checkCaseTracking()
	{
		$ct= new CaseTracking();
		$cases=$ct->query(['query' => ['type' => "Case"], 'pageSize' => 1]);
		$case_data=null;
		if($cases) {
			if(is_array($cases)) {
				if(!array_key_exists('errorCode', $cases)) {
					$case_data=$cases[0];
					if(array_key_exists('details', $case_data)) {
						print "OK";
						exit(0);
					}
				}
			}
		}
		print "CRITICAL - Case Tracking is not available";
			exit(2);
	}
	
	public function processCameraBroadcasts()
	{
		$cabis = new CABIS();
		$oosto = new Oosto();
		
		$recognitions=$this->oostoWebsocketModel->getNew("recognition:created");
		foreach($recognitions as $recognition_json) {
			$recognition=json_decode($recognition_json['content'], true);
			$recognition=$recognition[0];
			//Get subject info
			$record=[];
			$record['collate_id']=$recognition['collateId'];
			$record['camera']=$recognition['camera']['title'];
			$record['camera_id']=$recognition['camera']['id'];
			$record['frame_timestamp']=$recognition['frameTimeStamp'];
			$record['latitude']=$recognition['camera']['location'][1];
			$record['longitude']=$recognition['camera']['location'][0];
			$record['captured_image']=$recognition['images'][0]['url'];
			$record['oosto_id']=$recognition['subject']['id'];
			$record['name']=$recognition['subject']['name'];
			$record['subject_image']=$recognition['subject']['image']['url'];
			$subject=$this->subjectModel->getByOostoId($record['oosto_id']);
			if($subject) {
				$record['ca(bis_id']=$subject['cabis_id'];
			}
			$this->cameraBroadcastModel->insert($record);
		}
		/*
		$tracks=$this->oostoWebsocketModel->getNew("track:created");
		foreach($tracks as $track_json) {
			$track=json_decode($track_json['content'], true);
			$track=$track[0];
			$broadcasts=$this->cameraBroadcastModel->getByCollateId($track['collateId']);
			foreach($broadcasts as $broadcast) {
				//Get track video
				$captured_video=$oosto->getTrackVideoLink($track['id'], $broadcast['camera_id'], $broadcast['frame_timestamp']);
				$this->cameraBroadcastModel->update($broadcast['id'], ['captured_video' => $captured_video]);
			}
		}
		*/
	}
	
	public function sendEmail($to, $subject, $body)
	{
		$email = new Email();
		$email->send($to, $subject, $body);
	}
}

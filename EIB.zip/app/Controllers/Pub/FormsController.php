<?php 

namespace App\Controllers\Pub;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;

use \setasign\Fpdi\Fpdf;
use \setasign\Fpdi\Fpdi;
use \chillerlan\QRCode\QRCode;


class FormsController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	private $controller;
	protected $cache;
	protected $subjectRecordModel;
	protected $subjectModel;
	protected $controllerModel;
	protected $attachmentModel;
	protected $controllerName;

	function __construct()
	{
		$this->controller=[];
		$this->controller['route']='/frontend/subject_records/civilian';
		$this->COGCModel = model('App\Models\COGCModel');
		$this->cache = \Config\Services::cache();
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->controllerModel = model('App\Models\ControllerModel');
		$this->attachmentModel = model('App\Models\AttachmentModel');
		$this->auditLogModel = model('App\Models\AuditLogModel');
		$this->crudModel = model('App\Models\CrudModel');
	}
	
	
	public function cogc($uuid)
	{
		$data=[];
		$cabis=new CABIS();
		$barcode = new \Picqer\Barcode\BarcodeGeneratorPNG();
		$record=$this->COGCModel->getByUUID($uuid);
		$cert_content=json_decode($record['raw_content'], true);
		$subject=$this->subjectModel->getById($record['subject_id']);
		$subjectRecords=$this->subjectRecordModel->getBySubjectId($record['subject_id']);
		if(count($subjectRecords)>0) {
			$subjectRecord=$subjectRecords[0];
			$record['station']=$subjectRecord['station'];
			$record['remarks']=$subjectRecord['remarks'];
		} else {
			$subjectRecord=null;
			$record['station']='';
			$record['remarks']='';
		}
		$record['subject_id']=$subject['cabis_id'];
		
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$record['status']= ($data['cabis_present'] != null) ? "COMPLETED" : "PENDING";

		$pdf = new Fpdi();

		$pdf->AddPage(); 

		$pdf->setSourceFile(__DIR__.'/../../../images/COGC.pdf'); 
		// import page 1 
		$this->tplIdx = $pdf->importPage(1); 
		//use the imported page and place it at point 0,0; calculate width and height
		//automaticallay and adjust the page size to the size of the imported page 
		$pdf->useTemplate($this->tplIdx, 0, 0, 827, 1169, true); 

		// now write some text above the imported page 
		$pdf->SetFont('Helvetica', 'B', '30'); 
		$pdf->SetTextColor(0,0,0);
		//set position in pdf document
		$xoff=77;
		$yoff=420;
		$text_size='50';
		$line_height=30;	
		$pdf->SetLeftMargin(77);
		$pdf->SetRightMargin(80);
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write(10, "Date: ".date("d F, Y", strtotime($record['created_at']))."\nTime: ".date("g:i A", strtotime($record['created_at'])));
		$yoff=480;
		$pdf->SetXY($xoff, $yoff);
		$pdf->AddFont('AppleChancery','','apple-chancery-regular.php');
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, "\n\n");
		$pdf->Write($line_height, "This is to certify that according to the criminal records maintained in Uganda. ");
		$pdf->SetFont('Helvetica', '', $text_size);
		$pdf->SetFont('', 'B', $text_size);
		$pdf->Write($line_height, strtoupper($record['first_name'].' '.$record['last_name']));
		$pdf->SetFont('', '', $text_size);
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, ", holder of ");
		$pdf->SetFont('Helvetica', 'B', $text_size);
		$document_type= ($record['id_type'] == 'NIN') ? "Identity Card" : "PASSPORT";
		$pdf->Write($line_height, $document_type);
		$pdf->SetFont('', '', $text_size);
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, " number ");
		$pdf->SetFont('Helvetica', 'B', $text_size);
		$pdf->Write($line_height, $record['id_number']);
		$pdf->SetFont('Helvetica', '', $text_size);
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, " issued by the ");
		$pdf->SetFont('Helvetica', 'B', $text_size);
		$pdf->Write($line_height, $record['issued_by']);
		$pdf->SetFont('Helvetica', '', $text_size);
		$text=" has never been convicted of any criminal offense or come to adverse Police notice. The information on this certificate is as of the date of issue. The certificate is issued without any alteration or erasure and it is valid for six (6) months from the date of issue.";
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, $text);
		$yoff=1000;
		$pdf->SetXY($xoff, $yoff);
		$pdf->SetFont('Helvetica', 'B', $text_size*2/3);
		$pdf->Write(20, 'DIRECTOR INTERPOL AND INTERNATIONAL RELATIONS');
		
		//Output images
		//Photograph
		if(file_get_contents(base_url('/ajax/get_cabis?id='.$record['subject_id'].'&tag=705'))) {
			$pdf->Image(base_url('ajax/get_cabis?id='.$record['subject_id'].'&tag=705'), 620,270,150,0,'PNG');
		}
		//Application number barcode
		$barcode_file=tmpfile();
		fwrite($barcode_file, $barcode->getBarcode($cert_content['ApplicationNumber'], $barcode::TYPE_CODE_128));
		$file_name=stream_get_meta_data($barcode_file)['uri'];
		$pdf->Image($file_name, 77,1050,170,0,'PNG');
		$pdf->SetXY(77, 1065);
		$pdf->SetFont('Arial', 'B', $text_size*2/3);
		$pdf->Write(20, $cert_content['ApplicationNumber']);
		
		$qrCode=new QRCode();
		$pdf->Image($qrCode->render("https://upf.go.ug/public/verify-cogc/".$record['uuid']), 600,1000,100,0,'PNG');
		$this->response->setHeader('Content-Type', 'application/pdf');
		$pdf->Output('I', 'Certificate_of_good_conduct '.$record['first_name'].' '.$record['last_name'].'.pdf'); //D to download
	}
}

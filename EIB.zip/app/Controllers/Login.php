<?php 

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;
use App\Libraries\Email;
use Google_Client; // Add this line to import the Google Client library
use Google_Service_Oauth2; // Add this line to import the Google OAuth2 service

class Login extends BaseController
{
	use ResponseTrait;
	
	private $userModel;
	private $emailModel;
	private $smsModel;
	protected $cache;
	private $googleClient;

	public function __construct()
	{
		$this->userModel = model('App\Models\UserModel');
		$this->emailModel = new Email(); // Update this line to use the Email library
		$this->cache = \Config\Services::cache();
		$this->googleClient = new Google_Client();
		$this->googleClient->setClientId(getenv('GOOGLE_CLIENT_ID'));
		$this->googleClient->setClientSecret(getenv('GOOGLE_CLIENT_SECRET'));
		$this->googleClient->setRedirectUri(getenv('GOOGLE_REDIRECT_URI'));
		$this->googleClient->addScope('email');
		$this->googleClient->addScope('profile');
	}
	
	public function index()
	{
		//Show login page
		$data=[];
		return view('login', $data);
	}
		
	//user login
	public function loginSubmit()
	{
		$ret = $this->userModel->login($this->request->getVar('username'), $this->request->getVar('password'));
		if($ret == FALSE) {
			$this->session->setFlashdata('errorMessage', 'Please check username and password'); 
			$this->session->setFlashdata('errorTitle', 'Invalid credentials'); 
			return redirect()->to('login');
		}
		
		$user = $this->userModel->getById($ret);
		$_SESSION['user_id'] = $ret;
		$_SESSION['user'] = $user;
		$_SESSION['role'] = $this->userModel->getRole($user['role_id']);
		$_SESSION['permissions'] = $this->userModel->getPermissions($user['id']);
		// Create unique token per user for AJAX requests;
		$_SESSION['AJAX_TOKEN'] = uuid();
		log_message('debug', 'AJAX TOKEN '.$_SESSION['AJAX_TOKEN']);
		$this->cache->save('AJAX_TOKEN_'.$_SESSION['AJAX_TOKEN'], $_SESSION['user_id'], 24*HOUR); 
		
		$this->session->setFlashdata('message', 'Successfully logged in.'); 
		$this->session->setFlashdata('messageTitle', 'Success');
		return redirect()->to('frontend/dashboard');
		//2FA code was bypassed since police wasn't ready to implement
		
		// Generate and send 2FA code
		$twoFactorCode = rand(100000, 999999);
		$_SESSION['2FA_CODE'] = $twoFactorCode;
		$this->emailModel->send($user['email'], 'Your 2FA Code', "Your 2FA code is: $twoFactorCode");

		$this->session->setFlashdata('message', 'Successfully logged in. Please check your email for the 2FA code.'); 
		$this->session->setFlashdata('messageTitle', 'Success');
		return redirect()->to('authorize');
	}
	
	public function authorize()
	{
		// Show 2FA authorization page
		$data = [];
		return view('authorize', $data);
	}

	public function authorizeSubmit()
	{
		$inputCode = $this->request->getVar('2fa_code');
		if ($inputCode == $_SESSION['2FA_CODE']) {
			unset($_SESSION['2FA_CODE']);
			return redirect()->to('frontend/dashboard');
		} else {
			$this->session->setFlashdata('errorMessage', 'Invalid 2FA code'); 
			$this->session->setFlashdata('errorTitle', 'Authorization failed'); 
			return redirect()->to('authorize');
		}
	}
	
	public function logout()
	{
		unset($_SESSION['user_id']);
		$this->session->setFlashdata('message', 'Successfully logged out'); 
		$this->session->setFlashdata('messageTitle', 'Success');
		return redirect()->to('login');
	}
	
	public function forgottenPassword()
	{
		//Show forgot password page page
		$data=[];
		return view('forgot_password', $data);
	}
	
	public function forgottenPasswordSubmit()
	{
		$user = $this->userModel->getbyEmail($this->request->getVar('email'));
		if($user == FALSE) {
			$this->session->setFlashdata('errorMessage', 'Email address not recognized'); 
			$this->session->setFlashdata('errorTitle', 'Invalid email'); 
			return redirect()->to('/login/forgotten_password');
		}
		$this->emailModel->send($user['email'], 'New password link', 'Please click this link to reset your password: TODO');
		$this->session->setFlashdata('message', 'Reset link has been sent'); 
		$this->session->setFlashdata('title', 'Link sent');
		return redirect()->to('/login');
	}

	public function googleLogin()
	{
		$authUrl = $this->googleClient->createAuthUrl();
		return redirect()->to($authUrl);
	}

	public function googleCallback()
	{
		$code = $this->request->getVar('code');
		if ($code) {
			$this->googleClient->authenticate($code);
			$token = $this->googleClient->getAccessToken();
			$this->googleClient->setAccessToken($token);

			$googleService = new Google_Service_Oauth2($this->googleClient);
			$googleUser = $googleService->userinfo->get();

			// Check if user exists in your database
			$user = $this->userModel->getByEmail($googleUser->email);
			if (!$user) {
				// Register the user if not exists
				$userData = [
					'email' => $googleUser->email,
					'name' => $googleUser->name,
					'google_id' => $googleUser->id,
					// ...other user data...
				];
				$this->userModel->save($userData);
				$user = $this->userModel->getByEmail($googleUser->email);
			}

			// Log the user in
			$_SESSION['user_id'] = $user['id'];
			$_SESSION['user'] = $user;
			$_SESSION['role'] = $this->userModel->getRole($user['role_id']);
			$_SESSION['AJAX_TOKEN'] = uuid();
			$this->cache->save('AJAX_TOKEN_'.$_SESSION['AJAX_TOKEN'], $_SESSION['user_id'], 24*HOUR);

			return redirect()->to('frontend/dashboard');
		} else {
			$this->session->setFlashdata('errorMessage', 'Google login failed');
			$this->session->setFlashdata('errorTitle', 'Login failed');
			return redirect()->to('login');
		}
	}
}

<?php 

namespace App\Controllers;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\NIRA;
use App\Libraries\CaseTracking;
use \chillerlan\QRCode\QRCode;


class Ajax extends BaseController
{
	use ResponseTrait;
	
	protected $cache;
	protected $cogcModel;
	protected $subjectModel;
	protected $extDataModel;

	public function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->extDataModel = model('App\Models\ExternalDataModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->cogcModel = model('App\Models\COGCModel');
	}
	
	public function getCABIS()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis = new CABIS();
		if($this->request->getVar('tag')) { //Requesting a particular tag
			$data = $cabis->getTag($this->request->getVar('id'), $this->request->getVar('tag'));
			//If it's an image, process it
			$image_tags = array(FacePhoto, RTHUMB, RINDEX, RMIDDLE, RRING, RLITTLE, LTHUMB, LINDEX, LMIDDLE, LRING, LLITTLE, LFULLPALM, RFULLPALM, LFOURFINGERS, LTHUMBPLAIN, RTHUMBPLAIN, RFOURFINGERS, LWRITERSPALM, RWRITERSPALM, LUPPERPALM, RUPPERPALM, LLOWERPALM, RLOWERPALM, LRTTHUMBS);

		if(in_array($this->request->getVar('tag'), $image_tags)) {
				if($this->request->getVar('thumbnail')==1) {
					if(strlen($data)) {
						$image = new \Imagick();
						$image->readImageBlob($data);
						$image->scaleImage(150,150, true);
						return($image->getImageBlob());
					} else {
						return(base64_decode('iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAYElEQVR4nO3XIQ6AUAwFQUq4/5U/FoGZQAJix9U0a9+stbb/2b8OuFeWKEuUJcoSZYmyRFmiLFGWKEuUJY7nL2bmer4yPKf5CsoSZYmyRFmiLFGWKEuUJcoSZYmyxE+zTipCCV8YmfU4AAAAA'));
					}
				} else {
					return($data);
				}
			} else {
				return($data);
			}
		} else {
			$data=$cabis->getInfoByTag('105', $this->request->getVar('id'));
			return($data);
		}
	}
	
	//Returns the CABIS data as a simple array
	public function getCABISArray()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis = new CABIS();
		$data=$cabis->getInfoByTag('105', $this->request->getVar('id'));
		if(is_array($data)) {
			$response=[];
			$response['result']='OK';
			foreach($data['textData'] as $item) {
				$response[$item['tagNum']]=$item['tagValue'];
			}
			return $this->respond($response);
		}
		return $this->respond([]);
	}
	
	public function checkCivilianCABIS()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis = new CABIS();
		$data=$cabis->getInfoByTag('105', $this->request->getVar('cabis_id'));
		if(is_array($data)) {
			$response=[];
			$response['result']='OK';
			$this->cogcModel->update($this->request->getVar('id'), ['status' => 'FINGERPRINT', 'fingerprint_date' => date('Y-m-d H:i:s')]);
			foreach($data['textData'] as $item) {
				$response[$item['tagNum']]=$item['tagValue'];
			}
			return $this->respond($response);
		}
		//Also check if this user might have another record by checking their PRN
		$cogc=$this->cogcModel->find($this->request->getVar('id'));
		log_message('debug', print_r($cogc, true));
		if(!$cogc) {
			return $this->respond([]);
		}
		$record=$cabis->getInfoByTag(PRN, $cogc['prn']);
		log_message('debug', "Checking PRN {$cogc['prn']}");
		if($record && strlen($cogc['prn'] ?? '') >5) {
			$cabis_id=$cabis->getTagFromData($record, CABISID);
			$first_name=$cabis->getTagFromData($record, FirstName);
			$last_name=$cabis->getTagFromData($record, LastName);
			log_message('debug', "PRN matched $cabis_id $first_name $last_name {$cogc['first_name']} {$cogc['last_name']}\n");
			$this->subjectModel->update($cogc['subject_id'], ['cabis_id' => $cabis_id]);
			$this->cogcModel->update($cogc['id'], ['status' => 'FINGERPRINT', 'fingerprint_date' => date('Y-m-d H:i:s')]);
			$response=[];
			$response['result']='OK';
			foreach($record['textData'] as $item) {
				$response[$item['tagNum']]=$item['tagValue'];
			}
			return $this->respond($response);
		}
		return $this->respond([]);	
	}
	
	
	public function getCABISSummary()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis = new CABIS();
		$cabis_id=$cabis->getTag($this->request->getVar('cabis_id'), SubjectID);
		if(!$cabis_id) {
			return $this->respond(['error' => 'CABIS ID '.$this->request->getVar('cabis_id').' not found']);
		} else {
			return $this->respond(['firstName' => $cabis->getTag($this->request->getVar('cabis_id'), FirstName), 'lastName' => $cabis->getTag($this->request->getVar('cabis_id'), LastName)]);
		}
	}
	
	public function getCaseTracking()
	{
		session_write_close(); //In case Case tracking is unavailable, other services should keep running
		$ct = new CaseTracking();
		$data=$this->cache->get('CASETRACKING_'.$this->request->getVar('type').'_'.$this->request->getVar('id'));
		if($data == false) {
			$data=$ct->query(['query' => ['type' => $this->request->getVar('type'), 'id' => $this->request->getVar('id')]]);
			if($data) {
				$this->cache->save('CASETRACKING_'.$this->request->getVar('type').'_'.$this->request->getVar('id'), $data, DAY);
			}
		}
		log_message('debug',print_r($data, true));
		return($data);
	}
	
	public function qrCode($data)
	{
		$qr = new QRCode;
		print $qr->render($data);
	}
	
	public function getPerson()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$nira = new NIRA();
		$person=$nira->getPerson($this->request->getVar('nin'));
		return $this->respond($person);
	}
	
	public function getExternalPhoto()
	{
		if(strlen($this->request->getVar('id') ?? '')) {
			$ext=$this->extDataModel->find($this->request->getVar('id'));
		}
		if(strlen($this->request->getVar('external_id') ?? '')) {
			$ext=$this->extDataModel->getByExternalId($this->request->getVar(''), $this->request->getVar('external_id'));
		}
		$data=json_decode($ext['large_data_json'] ?? '', true);
		log_message('debug', $ext['large_data_json']);
		if($this->request->getVar('thumbnail')==1) {
			if(strlen($data['photo'])) {
				$image = new \Imagick();
				$image->readImageBlob(base64_decode($data['photo']));
				$image->scaleImage(150,150, true);
				return($image->getImageBlob());
			} else {
				return(base64_decode('iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAYElEQVR4nO3XIQ6AUAwFQUq4/5U/FoGZQAJix9U0a9+stbb/2b8OuFeWKEuUJcoSZYmyRFmiLFGWKEuUJY7nL2bmer4yPKf5CsoSZYmyRFmiLFGWKEuUJcoSZYmyxE+zTipCCV8YmfU4AAAAA'));
			}
		}
		return base64_decode($data['photo'] ?? '');
		
	}

}

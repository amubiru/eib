<?php

namespace App\Controllers;
use CodeIgniter\API\ResponseTrait;
use App\Libraries\CABIS;
use App\Libraries\NIRA;
use App\Libraries\Oosto;
use App\Libraries\CaseTracking;
use \PhpOffice\PhpSpreadsheet\Spreadsheet;
use \PhpOffice\PhpSpreadsheet\Writer\Xlsx;

use GuzzleHttp\Client;


class Test extends BaseController
{
	use ResponseTrait;
		
	private $userModel;
	private $emailModel;
	private $smsModel;
	private $subjectModel;
	private $extDataModel;
	private $ecModel;
	private $cogcModel;
	private $cache;

	public function __construct()
	{
		$this->cache= \Config\Services::cache();
		$this->userModel = model('App\Models\UserModel');
		$this->smsModel = model('App\Models\SmsModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->emailModel = model('App\Models\EmailModel');
		$this->ecModel = model('App\Models\EcModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->extDataModel = model('App\Models\ExternalDataModel');
		session_write_close();
	}
	
    public function create_users()
    {
        $this->userModel->create(['name' => 'Paul Mugabi', 'phone' => '256777788290', 'email' => 'pmugabi@gmail.com', 'password' => 'password', 'role' => 'USER', 'partner_id' => 1]);
        $this->userModel->create(['name' => 'David Mugisha', 'phone' => '256784210858', 'email' => 'mugishadavidsibo@gmail.com', 'password' => 'password123!', 'role' => 'USER', 'partner_id' => 1]);
        return $this->respond('Users created');
    }
    
    //Tests a fingerprint against CABIS
    public function finger()
    {
		$cabis=new CABIS();
		$finger=file_get_contents("/var/www/html/eib/writable/uploads/rindex.data");
		$response=$cabis->findFinger('RIndexFinger', $finger);
		var_dump($response);
	}
	
	public function getCandidate()
    {
		$cabis=new CABIS();
		$response=$cabis->getCandidates('4c4993c6-10b7-428a-a6ef-e6b2be225040');
		var_dump($response);
	}
	
	public function getCard()
    {
		$cabis=new CABIS();
		$response=$cabis->getCard('46cf.0001.00010028');
		var_dump($response);
	}
	
	public function loadCT()
	{
		$ct=new CaseTracking();
		//Get 50 cases at a time
		$count=0;
		while(true) {
			$case_data=$ct->query(['query' => ['type' => 'Case'], 'pageSize' => 50, 'page' => $count]);
			if(count($case_data)==0) {
				var_dump($case_data);
				print "Got all data";
				break;
			}
			print "Got ".count($case_data)." records<br>";
			foreach($case_data as $case) {
				$this->extDataModel->insert(['data_source' => 'case_tracking', 'external_id' => $case['id'], 'data_json' => json_encode($case), 'data' => print_r($case, true)]);
			}
			$count++;
		}
	}
	
	//Load case tracking people
	public function loadCTP()
	{
		$ct=new CaseTracking();
		//Get 50 people at a time
		$count=0;
		while(true) {
			$case_data=$ct->query(['query' => ['type' => 'Person'], 'pageSize' => 50, 'page' => $count]);
			if(count($case_data)==0) {
				var_dump($case_data);
				print "Got all data";
				break;
			}
			print "Got ".count($case_data)." records<br>";
			foreach($case_data as $case) {
				$this->extDataModel->insert(['data_source' => 'case_tracking_person', 'external_id' => $case['id'], 'data_json' => json_encode($case), 'data' => print_r($case, true)]);
			}
			$count++;
		}
	} 
	
	public function rotate()
    {
		helper('ecro');
		//Correct rotation of input image to CABIS
		$image=file_get_contents(__DIR__."/../../writable/uploads/image.txt");
		if($image) {
			log_message('debug', 'Found image data');
			$file = tmpfile();
			fwrite($file, base64_decode($image));
			$path = stream_get_meta_data($file)['uri'];
			$type=exif_imagetype($path);
			if(in_array($type, [2,6])) { //JPEG and BMP that support EXIF
				log_message('debug', "Found JPG");
				$new_image=image_fix_orientation($path);
				if($new_image!=false) {
					log_message('debug', "Found EXIF");
					$fileout = tmpfile();
					$pathout = stream_get_meta_data($fileout)['uri'];
					imagejpeg($new_image, $pathout, 90);
					$new=base64_encode(file_get_contents($pathout));
					log_message('debug',"Before\n".$image);
					log_message('debug',"After\n".$new);
				}
				
			}
		}
	}
	
	function fixSubjectIds()
	{
		$cogcModel = model('App\Models\COGCModel');
		$subjectRecordModel = model('App\Models\SubjectRecordModel');
		$cogcs=$cogcModel->findAll();
		foreach($cogcs as $cogc) {
			$sr=$subjectRecordModel->find($cogc['subject_id']);
			$cogcModel->update($cogc['id'],['subject_id' => $sr['subject_id']]);
		}
		print "Done";
	}
	
	public function loadStages()
	{
		$stageModel=model('App\Models\StageModel');
		$fh=fopen(__DIR__."/../../writable/stages.csv", "r");
		while($line=fgetcsv($fh)) {
			print $line[2];
			$stageModel->createStage(['name' => $line[2], 'latitude' => $line[5], 'longitude' => $line[4]]);
		}
	}
	
	public function nira()
	{
		$nira = new NIRA;
		
		//$nira->set_pass();
		
		$person=$nira->getPerson('CM80012107N12L', false);
		
		//$vehicle=$nira->getVehicle('UBF015D', false);
		//$permit=$nira->getLicense('12670101', false);
		//print "Person ".$person['surname']."<br>";
		//print "Vehicle ".$vehicle['ModelName']."<br>";
		//print "Permit ".$permit['offendersName']."<br>";
		
		//$applicant=$nira->getApplicant('NETJPOOFBVMXVYY', false);
		//print "Applicant ".$applicant['Firstname']."<br>";
		print json_encode($person);
	}
	
	public function nira_api()
	{
		$nira = new NIRA;
		if($this->request->getVar('password') != '054qBb3et4EU') {
			print json_encode(['status' => 'PASSWORD']);
			return;
		}
		//$nira->set_pass();
		
		$person=$nira->getPerson($this->request->getVar('nin'), false);
		
		//$vehicle=$nira->getVehicle('UBF015D', false);
		//$permit=$nira->getLicense('12670101', false);
		//print "Person ".$person['surname']."<br>";
		//print "Vehicle ".$vehicle['ModelName']."<br>";
		//print "Permit ".$permit['offendersName']."<br>";
		
		//$applicant=$nira->getApplicant('NETJPOOFBVMXVYY', false);
		//print "Applicant ".$applicant['Firstname']."<br>";
		print json_encode($person);
	}
	
	public function nirapass()
	{
		$nira = new NIRA;
		$nira->set_pass();
	}
	
	public function prn()
	{
		$nira = new NIRA;
		$nira->checkPRN('N/A', '2250002182178');
	}
	
	public function oosto()
	{
		session_write_close();
		$oosto = new Oosto();
		
		//$oosto->analyzeFile('', 'png');
		print json_encode($oosto->getInquiryResults('06592183-026b-47a8-8357-1f1da885b504'));
	}
	
	public function face()
	{
			$data=[];
		
		return view('submit_face', $data);
	}
	
	public function faceSubmit()
	{
		$data=[];
		$oosto = new Oosto();
		$attachment = $this->request->getFile('attachment');
		$file_content='';
		if($attachment->isValid()) {
			$type=$attachment->getMimeType();
			$filepath = WRITEPATH . 'uploads/' . $attachment->store();
			$file_content=file_get_contents($filepath);
			$inquiryId=$oosto->analyzeFile($file_content, 'png');
			sleep(2); //Give analysis time to complete
			return redirect()->to('test/face_results/'.$inquiryId);
		} else {
			$this->session->setFlashdata('errorMessage', 'Data upload failed'); 
			$this->session->setFlashdata('errorTitle', 'Failed'); 
			return redirect()->to('test/face');
		}
	}
	
	public function faceResults($inquiryId)
	{
		$data=[];
		$oosto = new Oosto();
		$result=$oosto->getInquiryResults($inquiryId);
		$data['result']=$result;
		return view('face_results', $data);
	}
	
	//Updates CABIS PICS to Oosto
	public function uploadOosto()
	{
		$count=0;
		$subjects=$this->subjectModel->findAll();
		foreach($subjects as $subject) {
			
			$oosto=new Oosto(); //Instantiate a new object since data seems to get mixed up
			if($subject['cabis_id'] && !$subject['oosto_id']) {
				$count++;
			if($count>1) {
				//break;
			}
				$image=file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705'));
				log_message('debug', 'IMAGEURL '.'ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705');
				if($image) {
					//file_put_contents(__DIR__."\images\\".$count.".png", $image);
					//continue;
					$oosto_id=$oosto->addSubject($subject['name'], $image, 'CABIS:'.$subject['cabis_id']);
					$this->subjectModel->update($subject['id'], ['oosto_id' => $oosto_id ?? 'FAILED']);
					$this->ecModel->update($subject['id'], ['oosto_id' => $oosto_id ?? 'FAILED']);
				}
			}
		}
	}
	
	//Updates CABIS PICS to Oosto
	public function uploadFace()
	{
		$count=0;
		$subjects=$this->subjectModel->findAll();
		foreach($subjects as $subject) {
			
			$image=file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705'));
			log_message('debug', 'IMAGEURL '.'ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705');
			if($image) {
				$client = new Client(['base_uri' => 'http://172.16.11.24:5000/', 'verify' => false]);
				$headers = ['Content-Type' => 'application/json'];
				$body = ['id' => $subject['cabis_id'], 'file' => base64_encode($image)];
				try {
					$http_response=$client->post('/upload', ['headers' => $headers, 'json' => $body]);
				} catch (\Exception $e) {
					return false;
				}
				
			}
		}
	}
	
	//Updates CABIS PICS to Oosto
	public function getFace()
	{
		$count=0;
		$subjects=$this->subjectModel->findAll();
		foreach($subjects as $subject) {
			
			$image=file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705'));
			log_message('debug', 'IMAGEURL '.'ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705');
			if($image) {
				file_put_contents(__DIR__."\\..\\..\\faces\\". $subject['cabis_id'].".png", $image);
				
			}
		}
	}
	
	public function cabisGroup($cabis_id)
	{
		$data=[];
		$cabis = new CABIS();
		$result= $cabis->findGroupMembers($cabis_id);
		var_dump($result);
	}
	
	public function redo_cabis()
	{
		$certs=$this->cogcModel->findAll();
		$cert_type='';
		foreach($certs as $cert) {
			$input=json_decode($cert['raw_content'], true);
			if($input['Service_Type'] != $cert['type']) {
				if($input['Service_Type'] == 'COGC' || strstr($input['Service_Type'], 'Good Conduct')) {
					$cert_type='COGC';
				} else {
					$cert_type='PCC';
				}
				$this->cogcModel->update($cert['id'], ['type' => $cert_type]);
			}
			if($cert['id_number']=='N/A') {
				$cabis_data=[];
				$id_type='';
				$id_number='';
				$cabis_data['textData']=[['tagNum' => LastName, 'tagValue' => trim($input['LastName'])],['tagNum' => FirstName, 'tagValue' => trim($input['FirstName'])],['tagNum' => MiddleName, 'tagValue' => trim($input['MiddleName'])],['tagNum' => '3319', 'tagValue' => 'CIVILIAN'],['tagNum' => '3309','tagValue' => trim($input['prn'])],['tagNum' => '3320', 'tagValue' => trim($input['ApplicationNumber'])], ['tagNum' => Contact, 'tagValue' => trim($input['TelephoneNo'])], ['tagNum' => ApplicationType, 'tagValue' => $cert_type]];
				if(strlen($input['NIN'] ?? '') > 5) {
					$cabis_data['textData'][]=['tagNum' => NINID, 'tagValue' => trim($input['NIN'])];
					$id_type='NIN';
					$id_number=trim($input['NIN']);
				}
				if(($input['Gender'] ?? '') == 'Male') {
					$cabis_data['textData'][]=['tagNum' => Sex, 'tagValue' => 1];
				}
				if(($input['Gender'] ?? '') == 'Female') {
					$cabis_data['textData'][]=['tagNum' => Sex, 'tagValue' => 2];
				}
				$dob_only=explode(' ', $input['DOB']);
				$dob_parts=explode('/', $dob_only[0]);
				if(count($dob_parts)==3) {
					$date_of_birth=$dob_parts[2].'-'.$dob_parts[0].'-'.$dob_parts[1];
					$cabis_data['textData'][]=['tagNum' => DateOfBirth, 'tagValue' => $date_of_birth];
				}
				if(strlen($input['PassportNo']) > 4) {
					$cabis_data['textData'][]=['tagNum' => DocumentType, 'tagValue' => 'PASSPORT'];
					$cabis_data['textData'][]=['tagNum' => DocumentNumber, 'tagValue' => trim($input['PassportNo'])];
					if(!$id_type) {
						$id_type='PASSPORT';
						$id_number=trim($input['PassportNo']);
					}
				} elseif(strlen($input['RefugeeCardNo']) > 4) {
					$cabis_data['textData'][]=['tagNum' => DocumentType, 'tagValue' => 'REFUGEE CARD'];
					$cabis_data['textData'][]=['tagNum' => DocumentNumber, 'tagValue' => $input['RefugeeCardNo']];
					if(!$id_type) {
						$id_type='PASSPORT';
						$id_number=trim($input['RefugeeCardNo']);
					}
				}
				$cabis_data['textData'][]=['tagNum' => Nationality, 'tagValue' => $input['Nationality']];
				$cabis_data['textData'][]=['tagNum' => Address, 'tagValue' => $input['PlaceOfResidence']];
				$cabis_data['textData'][]=['tagNum' => Height, 'tagValue' => $input['Height']];
				
				$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '']];
				$cabis_data['afisCategory'] = 2;
				$cabis = new CABIS();
				//var_dump($cabis_data);
				//var_dump($cert);
			
				$cabis_id=$cabis->submit(json_encode($cabis_data));
				if($cabis_id) {
					$subject=$this->subjectModel->find($cert['subject_id']);
					$this->subjectModel->update($subject['id'], ['cabis_id' => $cabis_id]);
					$this->cogcModel->update($cert['id'], ['id_type' => $id_type, 'id_number' => $id_number]);
				}

			}
		}
	}
	
	public function fixExternalData()
	{
		$cabis_ids=$this->extDataModel->getCabisIds();
		foreach($cabis_ids as $cabis_id) {
			$cabis_row=$this->extDataModel->find($cabis_id['id']);
			$cabis_data=json_decode($cabis_row['data_json'], true);
			if(is_array($cabis_data['imageData'] ?? null)) {
				unset($cabis_data['imageData']);
				$this->extDataModel->update($cabis_id['id'], ['data_json' => json_encode($cabis_data)]);
			}
		}
		print "Completed";
	}
	
	public function processPSO()
	{
		$file=fopen(__DIR__."/../../writable/uploads/pso.csv", "r");
		if(!$file) {
			print "File not found\n";
			return;
		}
		while($entry=fgetcsv($file)) {
			$cogcs=$this->cogcModel->getByNIN($entry[2]);
			if(!count($cogcs)) {
				$cabis_id="Not found";
			} else {
				$cogc=$cogcs[count($cogcs)-1]; //Get the latest
				$input=json_decode($cogc['raw_content'], true);
				$subject=$this->subjectModel->find($cogc['subject_id']);
				
				//Save the record
				$cabis_data=[];
				$cert_type='';
				if($input['Service_Type'] == 'COGC' || strstr($input['Service_Type'], 'Good Conduct')) {
					$cert_type='COGC';
				} else {
					$cert_type='PCC';
				}
				$cabis_data['textData']=[['tagNum' => LastName, 'tagValue' => trim($input['LastName'])],['tagNum' => FirstName, 'tagValue' => trim($input['FirstName'])],['tagNum' => MiddleName, 'tagValue' => trim($input['MiddleName'])],['tagNum' => '3319', 'tagValue' => 'CIVIL'],['tagNum' => '3309','tagValue' => trim($input['prn'])],['tagNum' => '3320', 'tagValue' => trim($input['ApplicationNumber'])], ['tagNum' => Contact, 'tagValue' => trim($input['TelephoneNo'])], ['tagNum' => ApplicationType, 'tagValue' => 'PSO']];
				$id_type='';
				$id_number='';
				if(strlen($input['NIN'] ?? '') > 4) {
					$cabis_data['textData'][]=['tagNum' => NINID, 'tagValue' => trim($input['NIN'])];
					$id_type='NIN';
					$id_number=trim($input['NIN']);
				}
				if(($input['Gender'] ?? '') == 'Male') {
					$cabis_data['textData'][]=['tagNum' => Sex, 'tagValue' => 1];
				}
				if(($input['Gender'] ?? '') == 'Female') {
					$cabis_data['textData'][]=['tagNum' => Sex, 'tagValue' => 2];
				}
				$dob_only=explode(' ', $input['DOB']);
				$dob_parts=explode('/', $dob_only[0]);
				if(count($dob_parts)==3) {
					$date_of_birth=$dob_parts[2].'-'.$dob_parts[0].'-'.$dob_parts[1];
					$cabis_data['textData'][]=['tagNum' => DateOfBirth, 'tagValue' => $date_of_birth];
				}
				if(strlen($input['PassportNo']) > 4) {
					$cabis_data['textData'][]=['tagNum' => DocumentType, 'tagValue' => 'PASSPORT'];
					$cabis_data['textData'][]=['tagNum' => DocumentNumber, 'tagValue' => trim($input['PassportNo'])];
					if(!$id_type) {
						$id_type='PASSPORT';
						$id_number=trim($input['PassportNo']);
					}
				} elseif(strlen($input['RefugeeCardNo']) > 4) {
					$cabis_data['textData'][]=['tagNum' => DocumentType, 'tagValue' => 'REFUGEE CARD'];
					$cabis_data['textData'][]=['tagNum' => DocumentNumber, 'tagValue' => $input['RefugeeCardNo']];
					if(!$id_type) {
						$id_type='PASSPORT';
						$id_number=trim($input['RefugeeCardNo']);
					}
				}
				$cabis_data['textData'][]=['tagNum' => Nationality, 'tagValue' => $input['Nationality']];
				$cabis_data['textData'][]=['tagNum' => Address, 'tagValue' => $input['PlaceOfResidence']];
				$cabis_data['textData'][]=['tagNum' => Height, 'tagValue' => $input['Height']];
				$cabis_data['textData'][]=['tagNum' => Height, 'tagValue' => $input['Height']];
				
				$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '']];
				$cabis_data['afisCategory'] = 1;
				$cabis = new CABIS();
				log_message('debug', print_r($cabis_data, true));				
				$cabis_id=$cabis->submit(json_encode($cabis_data));
				if($cabis_id) {
					$this->subjectModel->update($subject['id'], ['cabis_id' => $cabis_id]);
				}
			}
			print '"'.$entry[0].'","'.$entry[1].'","'.$entry[2].'","'.$cabis_id."\"\n";
		}
	}
	
	public function fix_external()
	{
		$ids=$this->extDataModel->getIds();
		foreach($ids as $id) {
			$ext=$this->extDataModel->find($id['id']);
			if(strlen($ext['data_json'] ?? '')) {
				$data=json_decode($ext['data_json'], true);
				if(array_key_exists('photo', $data)) {
					$large_data=[];
					$large_data['photo']=$data['photo'];
					unset($data['photo']);
					$this->extDataModel->update($ext['id'], ['data_json' => json_encode($data), 'large_data_json' => json_encode($large_data)]);
				}
			}
		}
		print "Done";	
	}
	
	public function refreshCabis($id)
	{
		$this->extDataModel->deleteByExternalId('cabis', $id);
		$cabis_cache_tag='CABIS_DATA_'.'105'.'_'.preg_replace("/[^a-z0-9]/i", "_", $id);
		$this->cache->delete($cabis_cache_tag);
	}
	
	public function findMatches()
	{
		$orig_id="CONV00286442";
		$cabis = new CABIS();
		/*
		$cabis_records=$cabis->getMatchingCandidatesOLD($orig_id, false);
		//$cabis_records = array_unique_multi($cabis_records);
		foreach($cabis_records as $record) {
			print print_r($record, true).'<br>';
		} */
		print "<br>GROUP<br>";
		$cabis_records=$cabis->getMatchingCandidatesBiometric($orig_id, false);
		//$cabis_records = array_unique_multi($cabis_records);
		foreach($cabis_records as $record) {
			print print_r($record, true).'<br>';
		}
	}
	
	
	public function exportCertificates($date)
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		//$certs=$this->cogcModel->getPending();
		$line_array=explode(",", "Transaction No,Last Name,First Name,Middle Name,FP Date,Gender,Date of Birth,Nationality,Document Number,NIN ID,Address  and POB,Certificate Type,PRN No.,COGC No.,Offence(s),Results of Case/trail,Date (mm/dd/yy,Adverse Police Notice,Signing Officer,Enroll Location");
		$lines=[$line_array];
		$cogcs=$this->cogcModel->getBetween(date('Y-m-d', strtotime($date)), date('Y-m-d', strtotime('+1 day', strtotime($date))));
		foreach($cogcs as $cogc) {
			$c=$cert=$res=$cogc;
			$s=$subject=$this->subjectModel->find($cogc['subject_id']);

			$c=json_decode($cert['raw_content'], true);
			$s=$subject=$this->subjectModel->find($cert['subject_id']);
			if($cabis->getTag($s['cabis_id'], CABISID)) {
				$txn_no=$cabis->getTag($s['cabis_id'], NewGroupId);
				$dob_parts=explode(' ', $c['DOB']);
				$doc_number='';
				if(strlen(trim($c['PassportNo'] ?? ''))>4) {
					$doc_number=$c['PassportNo'];
				} else {
					$doc_number=$c['RefugeeCardNo'];
				}
				$line_array= [$txn_no,$c['LastName'],$c['FirstName'],$c['MiddleName'],$cabis->getTag($s['cabis_id'], Date),$c['Gender'],$dob_parts[0],$c['Nationality'],$doc_number,$c['NIN'],$c['PlaceOfResidence'],$c['Service_Type'],$c['prn'],"","","","","",'Andrew Mubiru', $cabis->getTag($s['cabis_id'], EnrolLocation)];
				$lines[]=$line_array;
			}
		}
		$date=date('Y-m-d', strtotime('-1 day'));
		$save_path='/tmp/'.$date;
		if(!is_dir($save_path)) {
			mkdir($save_path);
			chmod($save_path, 0755);
		}
		$file= $save_path.'/'.$date.'.xlsx';
		$this->csvToExcel($lines, $file);
		$data=file_get_contents($file);
		unlink($file);
		return $this->response->download($date.'.xlsx', $data);

	}
		
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class PasswordController extends \App\Controllers\BaseController
{
	use ResponseTrait;
	
	protected $userModel;

	public function __construct()
	{
		$this->userModel = model('App\Models\UserModel');
	}
	
	public function changePassword()
	{
		$data=[];
		return view('header', $data)
			. view('menu', $data)
			. view('change_password', $data)
			. view('footer', $data);
	}
	
	public function submitPassword()
	{
		$user=$this->userModel->find($_SESSION['user_id']);
		if(!$this->userModel->login($user['username'], $this->request->getVar('current_password'))) {
			$this->session->setFlashdata('errorTitle', 'Incorrect password'); 
			$this->session->setFlashdata('errorMessage', 'Incorrent current password entered'); 
		} elseif(strlen($this->request->getVar('new_password'))<8) {
			$this->session->setFlashdata('errorTitle', 'Password too short'); 
			$this->session->setFlashdata('errorMessage', 'Password should be at least 8 characters long');
		} elseif($this->request->getVar('new_password') != $this->request->getVar('repeat_new_password')) {
			$this->session->setFlashdata('errorTitle', 'Passwords do not match'); 
			$this->session->setFlashdata('errorMessage', 'Entered passwords do not match');
		} else {
			$this->session->setFlashdata('messageTitle', 'Success'); 
			$this->session->setFlashdata('message', 'Password changed successfully');
			$this->userModel->setPassword($_SESSION['user_id'], $this->request->getVar('new_password'));
		}

		$data=[];
		return view('header', $data)
			. view('menu', $data)
			. view('change_password', $data)
			. view('footer', $data);
	}
}

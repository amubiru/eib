<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class LostAndFoundVehiclesController extends LostAndFoundController
{
        use ResponseTrait;
        

        public function __construct()
        {
                
        }
        
}


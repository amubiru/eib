<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class LostAndFoundPhonesController extends LostAndFoundController
{
        use ResponseTrait;
        

        public function __construct()
        {
                
        }
        
}


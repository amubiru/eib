<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;
use App\Libraries\Oosto;
use App\Libraries\CABIS;


class RedListController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $subjectModel;
	protected $unverifiedModel;
	protected $broadcastModel;



	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->broadcastModel = model('App\Models\BroadcastModel');
		$this->unverifiedModel = model('App\Models\UnverifiedModel');
	}
	
	public function index()
	{
		$data=[];
		$data['records']=[];
		
		return view('header', $data)
			. view('menu', $data)
			. view('redlist', $data)
			. view('footer', $data);
	}
	
	public function modify()
	{
		$subject=$this->subjectModel->find($this->request->getVar('subject_id'));
		if($subject) {
			if($subject['red_list']==1) {
				//Remove from redlist
				$this->removeRedList($this->request->getVar('subject_id'));
				$subject['red_list']=0;
			} else { //Show the redlist form
				$data=[];
				$data['last_url']=$this->request->getVar('last_url');
				$data['subject_id']=$this->request->getVar('subject_id');
				$data['subject']=$subject;
				return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/red_list_form', $data)
			. view('footer', $data);
			}
			//log_message('SUB id '.$this->request->getVar('subject_id'));
			//log_message('RED list'.print_r(['red_list' => $subject['red_list']], true));
			$this->subjectModel->update($this->request->getVar('subject_id'), ['red_list' => $subject['red_list']]);
			$this->session->setFlashdata('message', 'Red list status changed'); 
			$this->session->setFlashdata('messageTitle', 'Red list data changed'); 
		} else {
			$this->session->setFlashdata('errorMessage', 'Missing subject record, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
		}
		$last_url=str_replace('/eib', '', $this->request->getVar('last_url'));
		return redirect()->to($last_url);
	}
	
	public function modifyUnverified()
	{
		$person=$this->unverifiedModel->find($this->request->getVar('person_id'));
		if($person) {
			if($person['red_list']==1) {
				$person['red_list']=0;
			} else { //Show the redlist form
				$data=[];
				$data['last_url']=$this->request->getVar('last_url');
				$data['person_id']=$this->request->getVar('person_id');
				$data['person']=$person;
				return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/red_list_form_unverified', $data)
			. view('footer', $data);
			}
			//log_message('SUB id '.$this->request->getVar('subject_id'));
			//log_message('RED list'.print_r(['red_list' => $subject['red_list']], true));
			$this->unverifiedModel->update($this->request->getVar('person_id'), ['red_list' => $person['red_list']]);
			$this->session->setFlashdata('message', 'Red list status changed'); 
			$this->session->setFlashdata('messageTitle', 'Red list data changed'); 
		} else {
			$this->session->setFlashdata('errorMessage', 'Missing person record, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
		}
		$last_url=str_replace('/eib', '', $this->request->getVar('last_url'));
		return redirect()->to($last_url);
	}
	
	public function broadcast($id)
	{
		$subject=$this->subjectModel->find($id);
		if($subject) {
			if($subject['broadcast']==1) {
				$subject['broadcast']=0;
				$this->broadcastModel->remove($id);
			} else { //Show the redlist form
				$subject['broadcast']=1;
				//Add to broadcast list
				$this->broadcastModel->insert(['subject_id' => $id]);
			}
			//log_message('SUB id '.$this->request->getVar('subject_id'));
			//log_message('RED list'.print_r(['red_list' => $subject['red_list']], true));
			$this->subjectModel->update($id, ['broadcast' => $subject['broadcast']]);
			$this->session->setFlashdata('message', 'Broadcast status changed'); 
			$this->session->setFlashdata('messageTitle', 'Broadcast data changed'); 
		} else {
			$this->session->setFlashdata('errorMessage', 'Missing subject record, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
		}
		$subject=$this->subjectModel->find($id);
		$data['records'][]=$subject;
		
		return view('header', $data)
			. view('menu', $data)
			. view('redlist', $data)
			. view('footer', $data);
	}
	
	public function submit()
	{
		$subject=$this->subjectModel->find($this->request->getVar('subject_id'));
		if($subject) {
			$this->subjectModel->update($this->request->getVar('subject_id'), ['red_list' => 1, 'reason' => $this->request->getVar('reason'), 'redlist_date' => date('Y-m-d')]);
			$this->addRedList($this->request->getVar('subject_id'));
			$this->session->setFlashdata('message', 'Red list status changed'); 
			$this->session->setFlashdata('messageTitle', 'Red list data changed'); 
		} else {
			$this->session->setFlashdata('errorMessage', 'Missing subject record, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
		}
		$last_url=str_replace('/eib', '', $this->request->getVar('last_url'));
		return redirect()->to($last_url);
	}
	
	public function submitUnverified()
	{
		$person=$this->unverifiedModel->find($this->request->getVar('person_id'));
		if($person) {
			$this->unverifiedModel->update($this->request->getVar('person_id'), ['red_list' => 1, 'red_list_reason' => $this->request->getVar('reason'), 'red_list_date' => date('Y-m-d')]);
			$this->session->setFlashdata('message', 'Red list status changed'); 
			$this->session->setFlashdata('messageTitle', 'Red list data changed'); 
		} else {
			$this->session->setFlashdata('errorMessage', 'Missing subject record, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
		}
		$last_url=str_replace('/eib', '', $this->request->getVar('last_url'));
		return redirect()->to($last_url);
	}
	
	public function search()
	{
		$data=[];
		$subject_data=$this->subjectModel->search(['cabis_id' => $this->request->getVar('cabis_id'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date'), 'red_list' => 1]);
		$data['records']=$subject_data;
		
		return view('header', $data)
			. view('menu', $data)
			. view('redlist', $data)
			. view('footer', $data);
	}
	
	function removeRedList($subject_id)
	{
		$subject=$this->subjectModel->find($subject_id);
		if(strlen($subject['oosto_id'] ?? '')==36) {
			$oosto= new Oosto();
			//Confirm that the subject exists on Oosto before we attempt to remove
			$oosto_subject=$oosto->getSubject($subject['oosto_id']);
			if($oosto_subject==-1) { //Oosto subject could have been removed
				$this->subjectModel->update($subject_id, ['oosto_id' => NULL]);
				return;
			}
			$oosto->changeGroup($subject['oosto_id'], 'Default Group');
		}
	}
	
	function addRedList($subject_id)
	{
		$subject=$this->subjectModel->find($subject_id);
		$oosto = new Oosto();
		//Confirm that the oosto subject exists before we attempt to modify it
		if(strlen($subject['oosto_id'] ?? '')==36) {
			$oosto_subject=$oosto->getSubject($subject['oosto_id']);
			if($oosto_subject==-1) { //Oosto subject could have been removed
				$this->subjectModel->update($subject_id, ['oosto_id' => NULL]);
			}
		}
		$subject=$this->subjectModel->find($subject_id);
		if(strlen($subject['oosto_id'] ?? '')!=36) { //Add the person to the Oosto list
			$image=file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705'));
			$oosto_id=$oosto->addSubject($subject['first_name'].' '.$subject['last_name'], $image, 'CABIS:'.$subject['cabis_id']);
			$this->subjectModel->update($subject['id'], ['oosto_id' => $oosto_id ?? 'FAILED']);
			//Refresh Oosto ID
			$subject=$this->subjectModel->find($subject_id);
		}
		$oosto->changeGroup($subject['oosto_id'], 'RED LIST');
	}
	
}

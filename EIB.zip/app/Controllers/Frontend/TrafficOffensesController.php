<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\Email;
use App\Libraries\NIRA;


class TrafficOffensesController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;
	protected $driverModel;
	protected $stageModel;
	protected $auditLogModel;
	protected $policeOfficerModel;
	protected $cogcModel;
	protected $subjectModel;
	protected $subjectRecordModel;
	protected $trafficOffenseModel;

	function __construct()
	{
		$this->controller=[];
		parent::__construct();
		$this->stageModel = model('App\Models\StageModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->auditLogModel = model('App\Models\AuditLogModel');
		$this->trafficOffenseModel = model('App\Models\TrafficOffenseModel');
	}
	
	
	
	public function index()
	{
		$data=[];
		$data['records']=[];
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/offenses', $data)
			. view('footer', $data);
	}
	
	
		public function search()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$offense_data=$this->trafficOffenseModel->search(['id_number' => $this->request->getVar('id_number'), 'number_plate' => $this->request->getVar('number_plate'), 'offense' => $this->request->getVar('offense'), 'nin' => $this->request->getVar('nin'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($offense_data as $record) {
			$data['records'][]=$record;
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/offenses', $data)
			. view('footer', $data);
	}
	
	public function view($id)
	{
		$data=[];
		$nira=new NIRA();
		session_write_close();
		$data['record']=$this->trafficOffenseModel->find($id);
		if($data['record']['number_plate']) {
			$data['vehicle']=$nira->getVehicle($data['record']['number_plate']);
		} else {
			$data['vehicle']=null;
		}
		if($data['record']['id_number']) {
			$data['license']=$nira->getLicense($data['record']['id_number']);
		} else {
			$data['license']=null;
		}
		if($data['record']['nin']) {
			$data['nin']=$nira->getPerson($data['record']['nin']);
		} else {
			$data['nin']=null;
		}

		$data['attachments'] = []; //$this->attachmentModel->retrieve('subject_record', $subjectRecord['id']);
		$data['related']=$this->trafficOffenseModel->getRelated(['id_number' => $this->request->getVar('id_number'), 'number_plate' => $this->request->getVar('number_plate'), 'nin' => $this->request->getVar('nin')]);
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/offense', $data)
			. view('footer', $data);
	}
	
}

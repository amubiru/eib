<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\Email;
use App\Libraries\NIRA;
use App\Libraries\Utils;
use App\Libraries\Oosto;
use GuzzleHttp\Client;

require_once(__DIR__."/../../Libraries/YoAPI.php");

class SearchController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;
	protected $driverModel;
	protected $stageModel;
	protected $searchModel;
	protected $policeOfficerModel;
	protected $cogcModel;
	protected $subjectModel;
	protected $subjectRecordModel;

	function __construct()
	{
		$this->controller=[];
		parent::__construct();
		$this->stageModel = model('App\Models\StageModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->searchModel = model('App\Models\SearchModel');
	}

	public function index()
	{
		$data=[];
		$data['records']=[];
		$data['records']=[];
		$data['records']['all']=$data['records']['criminal']=$data['records']['case_tracking']=$data['records']['civilian']=$data['records']['police']=$data['records']['pso']=$data['records']['lost_found']=$data['records']['nira']=$data['records']['vehicle']=$data['records']['license']=$data['records']['traffic']=$data['records']['facial']=$data['records']['fingerprint']=[];
		return view('header', $data)
			. view('menu', $data)
			. view('Search/search_form', $data)
			. view('footer', $data);
	}
	
	
	public function submit()
	{
		$data=[];
		session_write_close(); //Prevent blocking other requests
		$cabis = new CABIS();
		$data['records']=[];
		$start_time=time();
		$data['records']['all']=$data['records']['criminal']=$data['records']['case_tracking']=$data['records']['civilian']=$data['records']['police']=$data['records']['pso']=$data['records']['lost_found']=$data['records']['nira']=$data['records']['vehicle']=$data['records']['license']=$data['records']['traffic']=$data['records']['facial']=$data['records']['fingerprint']=[];
		//If there is one search term and it matches one of the predefined patterns, search for a NIN, vehicle or license
		$search_term=trim($this->request->getVar('search_terms') ?? '');
		//No response is gotten here since the record will be available in the external_data table
		if(!strstr($search_term, " ")) { //No spaces, find if it matches any of the search formats
			if(strlen($search_term) == 14) { //NIN
				$nira= new NIRA();
				$nira->getPerson($search_term);
				//log_message('debug', 'Search NIRA person: '.(time()-$start_time));
			}
			if(strlen($search_term) == 8 || strlen($search_term) == 11) { //Driving licenses can have a -NN appended to it
				$nira= new NIRA();
				$nira->getLicense($search_term);
				//log_message('debug', 'Search NIRA license: '.(time()-$start_time));
			}
			if(stripos($search_term, "U")===0) { //Presumed vehicle number plate
				$nira = new NIRA();
				$nira->getVehicle($search_term);
				//log_message('debug', 'Search NIRA vehicle: '.(time()-$start_time));
			}
			/*
			if((strpos($search_term, "0")===0 && strlen($search_term)==10) || (strpos($search_term, "256")===0 && strlen($search_term)==12)) { //Presumed phone number
				log_message('debug', "Checking phone number");
				$yo = new \YoAPI(getenv('yo.username'), getenv('yo.password'));
				$msisdn="256".substr($search_term, -9);
				$info=$yo->ac_get_msisdn_kyc_info($msisdn);
				if($info['Status'] == 'OK') {
					$to_save=['phoneInternational' => $msisdn, 'phoneLocal' => "0".substr($search_term, -9), 'firstName' => $info['FirstName'], 'middleName' => $info['MiddleName'], 'surname' => $info['Surname']];
					$this->extDataModel->insert(['data_source' => 'phone', 'external_id' => $msisdn, 'data_json' => json_encode($to_save), 'data' => print_r($to_save, true)]);
				}
				log_message('debug', print_r($info, true));
			} 
			*/
			
		}
		//Search the different areas
		//log_message('debug', 'YYYYYYYYY Search'.$this->request->getVar('search_terms'));
		if(strlen($this->request->getVar('search_terms') ?? '')) {
			$records=$this->searchModel->search($this->request->getVar('search_terms'));
			$data['records']=array_merge($data['records'], $records);
			//log_message('debug', 'Search records: '.(time()-$start_time));
		}
		
		//Search by photograph if one was supplied
		$photo_file = $this->request->getFile('photo_file');
		if($photo_file && $photo_file->isValid() && $this->request->getVar('search_type') == 'PHOTO') {
			// validation
			$validated = $this->validate([
            'photo_file' => [
                'uploaded[photo_file]',
                'mime_in[photo_file,image/jpg,image/jpeg,image/bmp,image/png]'
				],
			]);
			if(!$validated) {
				$data['errorTitle']='Incorrect file type';
				$data['errorMessage']='The uploaded file should be a valid PNG, JPEG or BMP file';
			} else {
				$filepath = WRITEPATH . 'uploads/' . $photo_file->store();
				log_message('debug' , "Opening Photo file $filepath");
				//Convert image to PNG. 
				$data['photo']=imagetopng(base64_encode(file_get_contents($filepath)));
				unlink($filepath);
				//Search for image
				$cabis_search_data=[];
				$cabis_search_data[]=['name' => 'faceFile', 'content' => 
			base64_decode($data['photo'])];
				$matches=$cabis->findCandidate($cabis_search_data);
				log_message('debug', print_r($matches, true));
					foreach($matches['matches'] as  $response) {
							log_message('debug', print_r($response, true));
							$id=$response['cabis_id'];
							$subject=$this->searchModel->cabis_criminal_search($id);
							if(count($subject)) {
								log_message('debug', 'Subject match');
								$data['records']['criminal'][]=$subject[0];
							}
							$subject=$this->subjectModel->getByCabisId($id);
							if($subject) {
								$record=$this->cogcModel->getBySubjectId($subject['id']);
								if(count($record)) {
									$record[0]['cabis_id']=$subject['cabis_id'];
									$record[0]['date']=$record[0]['created_at'];
									$data['records']['civilian'][]=$record[0];
								}
							}
						}
					}
					
			//Now check in Oosto
			log_message('debug', 'Checking photo in Oosto');
			$oosto = new Oosto();
			$inquiryId=$oosto->analyzeFile(base64_decode($data['photo']), 'png');
			for($count=0;$count<10;$count++) { //Wait for up to 10 seconds
				sleep(1);
				$result=$oosto->getInquiryResults($inquiryId);
				log_message('debug', print_r($result, true));
				if($result['status'] == 'DONE') {
					foreach($result['subjects'] as $oosto_subject) {
						$subject=$this->subjectModel->getByOostoId($oosto_subject['id']);
						if($subject) {
							$record=$this->cogcModel->getBySubjectId($subject['id']);
								if(count($record)) {
									$record[0]['cabis_id']=$subject['cabis_id'];
									$record[0]['date']=$record[0]['created_at'];
									$data['records']['civilian'][]=$record[0];
								}
						} else { //No subject ID, save as an oosto record
							$data['records']['facial'][]=['url' => '#', 'identifier' => $oosto_subject['name'], 'details' => $oosto_subject['description'], 'id' => $oosto_subject['id'], 'photo' => 'data:image/jpeg;base64,'.$oosto_subject['image'], 'category' => 'Facial recognition', 'date' => $oosto_subject['date']];
						}
					}
					break;
				}
			}
			

				}
				log_message('debug', 'Search photo end: '.(time()-$start_time));
				
				//Search by PDF if one was supplied
		$pdf_file = $this->request->getFile('pdf_file');
		if($pdf_file && $pdf_file->isValid()) {
			// validation
			$validated = $this->validate([
            'pdf_file' => [
                'uploaded[pdf_file]',
                'mime_in[pdf_file,application/pdf]'
				],
			]);
			if(!$validated) {
				$data['errorTitle']='Incorrect file type';
				$data['errorMessage']='The uploaded file should be a valied PDF file';
			} else {
				$filepath = WRITEPATH . 'uploads/' . $pdf_file->store();
				log_message('debug' , "Opening PDF file $filepath");
				$pdf = file_get_contents($filepath);

				//Search for PDF
				$matches=$cabis->findCandidatePDF($pdf);
				log_message('debug', print_r($matches, true));
					foreach($matches['matches'] as  $response) {
							log_message('debug', print_r($response, true));
							$id=$response['cabis_id'];
							$subject=$this->searchModel->cabis_criminal_search($id);
							if(count($subject)) {
								log_message('debug', 'Subject match');
								$data['records']['criminal'][]=$subject[0];
							}
							$subject=$this->subjectModel->getByCabisId($id);
							if($subject) {
								$record=$this->cogcModel->getBySubjectId($subject['id']);
								if(count($record)) {
									$record[0]['cabis_id']=$subject['cabis_id'];
									$record[0]['date']=$record[0]['created_at'];
									$data['records']['civilian'][]=$record[0];
								}
							}
						}
					}
				}
				log_message('debug', 'Search pdf end: '.(time()-$start_time));
		
		//Search for fingerprint
		//Search by photograph if one was supplied
		$photo_file = $this->request->getFile('photo_file');
		if($photo_file && $photo_file->isValid() && $this->request->getVar('search_type') == 'FINGERPRINT') {
			// validation
			$validated = $this->validate([
            'photo_file' => [
                'uploaded[photo_file]',
                'mime_in[photo_file,image/jpg,image/jpeg,image/bmp,image/png]'
				],
			]);
			if(!$validated) {
				$data['errorTitle']='Incorrect file type';
				$data['errorMessage']='The uploaded file should be a valid PNG, JPEG or BMP file';
			} else {
				$filepath = WRITEPATH . 'uploads/' . $photo_file->store();
				log_message('debug' , "Opening Fingerprint file $filepath");
				//Convert image to PNG with 500dpi
				$fingerprint=imagetopng(base64_encode(file_get_contents($filepath)));
				unlink($filepath);
				$image = new \Imagick();
				$image->readImageBlob(base64_decode($fingerprint));
				$image->setImageUnits(\Imagick::RESOLUTION_PIXELSPERINCH);
				$image->setImageResolution(500, 500);
				// Trim any white space around the image
				$image->trimImage(0.1);
				$fingerprint= $image->getImageBlob();
				$image_name=uuid();
				$filepath = WRITEPATH . 'uploads/' .$image_name.'.png';
				file_put_contents($filepath, $fingerprint);
				log_message('debug', 'IMAGE SAVED as '.$filepath);
				$matches=$cabis->findCandidatesLatent($fingerprint);
				foreach($matches['matches'] as  $response) {
					$data['records']['fingerprint'][]=['url' => base_url('/frontend/view_record/?type=cabis&id='.$response['cabis_id']), 'date' => $cabis->getTag($response['cabis_id'], Date), 'details' => 'CABIS ID '.$response['cabis_id'].', '.($cabis->getTag($response['cabis_id'], CriminalRecord) ?? ''), 'category' => 'CABIS Record', 'identifier' => $response['first_name'].' '.$response['last_name'], 'photo' => base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$response['cabis_id'].'&tag=705&thumbnail=1')];
				}
			}
		}
				
			
		//Create a formatted entry for each type
		for($n=0;$n<count($data['records']['criminal']);$n++) {
			//Copy by reference to shorten length of data entry
			$entry=&$data['records']['criminal'][$n];
			$entry['url']=base_url('/frontend/view_record/?type=criminal&id='.$entry['cabis_id']);
			$entry['category']='Criminal Record';
			$entry['identifier']=$entry['first_name'].' '.$entry['last_name'];
			$entry['details']="Offense: ".$entry['offense']. "<br>Sentence Type: ".$entry['sentence_type']."<br>Station: ".$entry['station'];
			$entry['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$entry['cabis_id'].'&tag=705&thumbnail=1');
		}
		//log_message('debug', 'Search end criminal: '.(time()-$start_time));
		for($n=0;$n<count($data['records']['civilian']);$n++) {
			//Copy by reference to shorten length of data entry
			$entry=&$data['records']['civilian'][$n];
			$entry['url']=base_url('/frontend/view_record/?type=civilian&id='.$entry['id']);
			$entry['category']='Civilian Record';
			$entry['identifier']=$entry['first_name'].' '.$entry['last_name'];
			$entry['details']="NIN: ".$entry['id_number']. "<br>PRN: ".$entry['prn']."<br>";
			$entry['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$entry['cabis_id'].'&tag=705&thumbnail=1');
		}
		//log_message('debug', 'Search end civilian: '.(time()-$start_time));
		for($n=0;$n<count($data['records']['case_tracking']);$n++) {
			//Copy by reference to shorten length of data entry
			$entry=&$data['records']['case_tracking'][$n];
			$officer_name="&nbsp;";
			if(array_key_exists('investigatingOfficer',  $entry['details'])) {
				$officer_name=($entry['details']['investigatingOfficer']['cardDetails']['firstName'] ?? '')." ".($entry['details']['investigatingOfficer']['cardDetails']['lastName'] ?? '');
			}
			
			  $offenses="";
			  if(array_key_exists('offenses',  $entry['details'])) {
				  foreach($entry['details']['offenses'] as $offense) {
					  $offenses.=$offense['offenseCode']['label'].' ';
				  }
			  }
			  $station="Not specified";
			  if(array_key_exists('group', $entry)) {
				  $station=$entry['group']['label'];
			  }
			  $date=$entry['sort']['date'];
			  $description=$entry['details']['description'] ?? '';
			  $location=$entry['group']['label'] ?? '';
			  
			  //Show case numbers
			  $extra_details='';
			  if(strlen($entry['details']['sdrNumber'] ?? '')) {
				  $extra_details.='SDR Number: '.$entry['details']['sdrNumber'].'<br>';
			  }
			  if(strlen($entry['details']['caseNumber'] ?? '')) {
				  $extra_details.='CRB Number: '.$entry['details']['caseNumber'].'<br>';
			  }
			  if(strlen($entry['details']['incidentNumber'] ?? '')) {
				  $extra_details.='Incident Number: '.$entry['details']['incidentNumber'].'<br>';
			  }
			 
				$new_entry=[];
				$new_entry['url']=base_url('/frontend/view_record/?type=case_tracking&id='.$entry['id']);
				$new_entry['category']='Criminal Record';
				$new_entry['identifier']="Offense: ".$offenses;
				$new_entry['details']=$extra_details."Station: $station<br>Investigating officer: $officer_name<br>Description: $description<br>Location: $location";
				$new_entry['date']=$date;
				$new_entry['photo']=false;
				$data['records']['criminal'][]=$new_entry;
			}
			//log_message('debug', 'Search end case tracking: '.(time()-$start_time));
			
			for($n=0;$n<count($data['records']['nira']);$n++) {
			//Copy by reference to shorten length of data entry
			$entry=&$data['records']['nira'][$n];
			//log_message('debug', print_r($entry, true));
			$entry['url']=base_url('/frontend/view_record/?type=nira&id='.$entry['nationalId']);
			$entry['category']='National ID';
			$entry['identifier']='NIN: '.$entry['nationalId'];
			$entry['details']=$entry['givenNames'].' '.$entry['surname'];
			$entry['date']=$entry['dateOfBirth'];
			$entry['photo']=base_url('ajax/get_external_photo?token='.$_SESSION['AJAX_TOKEN'].'&id='.$entry['row_id'].'&thumbnail=1');
			}
			for($n=0;$n<count($data['records']['vehicle']);$n++) {
			//Copy by reference to shorten length of data entry
			$entry=&$data['records']['vehicle'][$n];
			$entry['url']=base_url('/frontend/view_record/?type=vehicle&id='.$entry['MVRegNo']);
			$entry['category']='Vehicle registration';
			$entry['identifier']=$entry['MVRegNo'];
			$entry['details']=$entry['Make'].' '.$entry['ModelName'].' '.$entry['BodyDesc'].'<br>Owner: '.$entry['TaxPayerName'].' Phone: '.$entry['MobileNumber'].'<br>Vehicle purpose: '.$entry['VehicleClassification'];
			$entry['date']='Registration Date: '.$entry['DateOfRegistration'];
			$entry['photo']=false;
			}
			for($n=0;$n<count($data['records']['license']);$n++) {
			//Copy by reference to shorten length of data entry
			$entry=&$data['records']['license'][$n];
			//log_message('debug', print_r($entry, true));
			$entry['url']=base_url('/frontend/view_record/?type=license&id='.$entry['permit_no']);
			$entry['category']='Driving permit';
			$entry['identifier']='License no: '.$entry['permit_no'];
			$entry['details']=$entry['offendersName'].'<br>Class: '.$entry['permitClass'].'<br>Vehicle Restriction: '.$entry['vehicle_restriction'];
			$entry['date']='Expiry: '.$entry['permit_expiry'];
			$entry['photo']=base_url('ajax/get_external_photo?token='.$_SESSION['AJAX_TOKEN'].'&id='.$entry['row_id'].'&thumbnail=1');
			}
			
			for($n=0;$n<count($data['records']['traffic']);$n++) {
			//Copy by reference to shorten length of data entry
			$entry=&$data['records']['traffic'][$n];
			if($entry['penalty']=='FINE') {
				$penalty=$entry['penalty'].' UGX '.$entry['amount'];
			} else {
				$penalty=$entry['penalty'];
			}
			$entry['url']=base_url('/frontend/view_record/?type=traffic&id='.$entry['id']);
			$entry['category']='Traffic Offense';
			$entry['identifier']=$entry['first_name'].' '.$entry['last_name'];
			$entry['details']="Offense: ".$entry['offense']. "<br>Penalty: ".$penalty."<br>Number plate: ".$entry['number_plate']."<br>ID: ".$entry['id_number'];
			$entry['photo']=false;
			$entry['date']=date('Y-m-d h:ia', strtotime($entry['created_at']));
		}
		//log_message('debug', 'Search display: '.(time()-$start_time));
			//log_message('debug', print_r($data['records'], true));
			$data['records']['all']=array_merge($data['records']['criminal'], $data['records']['traffic'], $data['records']['nira'], $data['records']['vehicle'], $data['records']['license'], $data['records']['civilian'], $data['records']['police'], $data['records']['pso'], $data['records']['lost_found'], $data['records']['facial'], $data['records']['fingerprint']);
			//log_message('debug', print_r($data['records']['all'], true));
		return view('header', $data)
			. view('menu', $data)
			. view('Search/search_form', $data)
			. view('footer', $data);
	}
	

	
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class UsersController extends \App\Controllers\CrudController
{
        use ResponseTrait;
        

        public function __construct()
        {
                
        }
        
}


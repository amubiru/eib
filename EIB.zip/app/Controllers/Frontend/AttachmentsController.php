<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class AttachmentsController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $attachmentModel;



	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->attachmentModel = model('App\Models\AttachmentModel');
	}

	function index($id) {
		$attachment=$this->attachmentModel->find($id);
		return $this->response->setHeader("Content-Type", $attachment['file_type'])
		->setBody(base64_decode($attachment['file_content']));
	}
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class TrafficDashboardController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $crModel;
	protected $controllerModel;
	protected $offenseModel;
	protected $driverModel;
	protected $trafficOffenseModel;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->crModel = model('App\Models\SubjectRecordModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->trafficOffenseModel = model('App\Models\TrafficOffenseModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->controllerModel = model('App\Models\ControllerModel');
		$this->crudModel = model('App\Models\CrudModel');
	}
	
	public function index()
	{
		$data=[];
		$colors=["#FF5733", "#F39C12", "#3498DB", "#2ECC71", "#E74C3C", "#9B59B6", "#1ABC9C", "#E67E22", "#27AE60", "#2980B9"];

		$data['dashboard']=1; //Set the variable to permit loading of the dashboard Javascript
		if($this->request->getVar('start_date')) {
			$start_date=$data['start_date']=$this->request->getVar('start_date');			
		} else {
			$start_date=$data['start_date']=date('Y-m-d', strtotime('-1 year'));
		}
		if($this->request->getVar('end_date')) {
			$end_date=$data['end_date']=$this->request->getVar('end_date');
		} else {
			$end_date=$data['end_date']=date('Y-m-d');
			
		}
		//Decide what type of report to show
		$offense_type="top10";
		if($this->request->getVar('offense_type')) {
			if($this->request->getVar('offense_type') == 'select') {
				$offense_type="select";
			}
		}
		//Get the fields to be shown
		if($offense_type=="select") {
			$offenses = $this->crModel->getOffensesCount($this->request->getVar('offenses'), $start_date, $end_date);
		} else { //Top 10
			$offenses=$this->trafficOffenseModel->getTop10OffensesCount($start_date, $end_date);
		}
		$offense_list=[];
		$offense_count=[];
		foreach($offenses as $offense) {
			$offense_list[]=$offense['offense'];
			$offense_count[]=$offense['num'];
		}
		$data['colors']=array_slice($colors, 0, count($offense_list));
		$data['pieData']=$offense_count;
		$data['labels']=$offense_list;

		$data['drivers']=$this->driverModel->countAll();;
		$data['offenses']=$this->trafficOffenseModel->countOffenses($start_date,$end_date);
		$data['cautions'] = $this->trafficOffenseModel->countCautions($start_date, $end_date);
		$data['fines'] = $this->trafficOffenseModel->countFines($start_date, $end_date);
		//$data['offenses']=$this->crudModel->getFieldOptions('offense');
		
		//Prepare line graph
		//First decide whether to show by month or by year
		$divisions=[];
		$data['datasetLabels']=[];
		if((strtotime($end_date)-strtotime($start_date))/MONTH > 24) {
			$start_division=$start_date;
			//End division is the end of that year
			$end_division=date("Y-12-31", strtotime($start_division));
			//Division by year
			while($end_date>$end_division) {
				$label=date('Y', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_division];
				//Now move to next year
				$start_division=$end_division=date("Y-m-d", strtotime("+1 day", strtotime($end_division)));
				$end_division=date("Y-12-31", strtotime($start_division));
			}
			if($end_date>$start_division) { //Catch the end case
				$label=date('Y', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_date];
			}
		} else { // Group by months
			$start_division=$start_date;
			//End division is the end of that month
			$end_division=date("Y-m-t", strtotime($start_division));
			//Division by month
			while($end_date>$end_division) {
				$label=date('Y M', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_division];
				//Now move to next month
				$start_division=$end_division=date("Y-m-d", strtotime("+1 day", strtotime($end_division)));
				$end_division=date("Y-m-t", strtotime($start_division));
			}
			if($end_date>$start_division) { //Catch the end case
				$label=date('Y M', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_date];
			}
		}

		$data['datasets']=[];
		for($n=0; $n<count($offenses); $n++) {
			$points=[];
			for($x=0;$x<count($divisions); $x++) {
				$points[]=$this->trafficOffenseModel->getOffenseCount($offenses[$n]['offense'], $divisions[$x]['start'], $divisions[$x]['end']);
			}
			$data['datasets'][]=(object) ['type' => 'line', 'data' => $points,
        'backgroundColor' => 'transparent',
        'borderColor' => $colors[$n],
        'pointBorderColor' => $colors[$n],
        'pointBackgroundColor' => $colors[$n],
        'cubicInterpolationMode' => 'monotone',
        'tension' => 0,
        'fill' => false];
      }
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/dashboard', $data)
			. view('footer', $data);
	}
	
}

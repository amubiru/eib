<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class SearchDashboardController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $crModel;
	protected $extDataModel;
	protected $offenseModel;
	protected $driverModel;
	protected $trafficOffenseModel;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->crModel = model('App\Models\SubjectRecordModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->trafficOffenseModel = model('App\Models\TrafficOffenseModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->extDataModel = model('App\Models\ExternalDataModel');
	}
	
	public function index()
	{
		$data=[];
		$colors=["#FF5733", "#F39C12", "#3498DB", "#2ECC71", "#E74C3C", "#9B59B6", "#1ABC9C", "#E67E22", "#27AE60", "#2980B9"];

		$data['search_dashboard']=1; //Set the variable to permit loading of the dashboard Javascript
		if($this->request->getVar('start_date')) {
			$start_date=$data['start_date']=$this->request->getVar('start_date');			
		} else {
			$start_date=$data['start_date']=date('Y-m-d', strtotime('-1 year'));
		}
		if($this->request->getVar('end_date')) {
			$end_date=$data['end_date']=$this->request->getVar('end_date');
		} else {
			$end_date=$data['end_date']=date('Y-m-d');
			
		}
		$cases=$this->extDataModel->getMultiple('case_tracking');
		//Remove cases that don't match the start and end dates
		log_message('debug', print_r($cases, true));
		for($n=0;$n<count($cases); $n++) {
			$case_info=json_decode($cases[$n]['data_json'], true);
			$case_date=strtotime($case_info['sort']['date']);
			if(!($case_date>=strtotime($start_date) && $case_date<=strtotime($end_date))) {
				unset($cases[$n]);
			}
		}
		$cases=array_values($cases);
		//Now bin the cases by offense, district and month
		//Create the predefined monthly bins
		$case_offenses=[];
		$case_districts=[];
		log_message('debug', print_r($cases, true));
		for($n=0;$n<count($cases); $n++) {
			$case_info=json_decode($cases[$n]['data_json'], true);
			log_message('debug', print_r($case_info, true));
			$offense=$case_info['details']['offenses'][0]['offenseCode']['label'] ?? '';
			if(array_key_exists('district', $case_info['details'])) { 
				$district=trim($case_info['details']['district']['other'] ?? $case_info['details']['district']['label']);
			} else {
				$district=null;
			}
			//print $district;
			//print_r($case_info['details']);
			//return;
			//print_r($case_info['details']['district']);
			if($offense) {
				if(array_key_exists($offense, $case_offenses)) {
					$case_offenses[$offense]['num']++;
				} else {
					$case_offenses[$offense]=['num' => 1];
				}
			}
			if($district) {
				if(array_key_exists($district, $case_districts)) {
					$case_districts[$district]['num']++;
				} else {
					$case_districts[$district]=['num' => 1];
				}
			}
		}
		
		//Sort the offenses by number
		uasort($case_offenses, function($a, $b) { return($b['num'] - $a['num']); });
		uasort($case_districts, function($a, $b) { return($b['num'] - $a['num']); });
		
		if(count($case_offenses) > 10) { //Label the rest as others
			$new_case_offenses=[];
			$n=0;
			foreach($case_offenses as $key => $val) {
				if($n<8) {
					$new_case_offenses[$key]=['num' => $val['num']];
				}
				if($n==9) {
					$new_case_offenses['Others']=['num' => $val['num']];
				}
				if($n>10) {
					$new_case_offenses['Others']['num']+= $val['num'];
				}
				$n++;
			}
			$case_offenses=$new_case_offenses;
		}
		
		if(count($case_districts) > 10) { //Label the rest as others
			$new_case_districts=[];
			$n=0;
			foreach($case_districts as $key => $val) {
				if($n<8) {
					$new_case_districts[$key]=['num' => $val['num']];
				}
				if($n==9) {
					$new_case_districts['Others']=['num' => $val['num']];
				}
				if($n>10) {
					$new_case_districts['Others']['num']+= $val['num'];
				}
				$n++;
			}
			$case_districts=$new_case_districts;
		}
		//print print_r($case_offenses, true);
		//print print_r($case_districts, true);
		log_message('debug', print_r($case_offenses, true));
		$offense_list=[];
		$offense_count=[];
		foreach($case_offenses as $key => $val) {
			$offense_list[]=$key;
			$offense_count[]=$val['num'];
		}
		$district_list=[];
		$district_count=[];
		foreach($case_districts as $key => $val) {
			$district_list[]=$key;
			$district_count[]=$val['num'];
		}
		$data['colors']=array_slice($colors, 0, count($offense_list));
		$data['pieData']=$offense_count;
		$data['labels']=$offense_list;
		
		$data['district_colors']=array_slice($colors, 0, count($district_list));
		$data['district_pieData']=$district_count;
		$data['district_labels']=$district_list;
		
		//Prepare line graph
		//First decide whether to show by month or by year
		$divisions=[];
		$data['datasetLabels']=[];

			$start_division=$start_date;
			//End division is the end of that month
			$end_division=date("Y-m-t", strtotime($start_division));
			//Division by month
			while($end_date>$end_division) {
				$label=date('Y M', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_division];
				//Now move to next month
				$start_division=$end_division=date("Y-m-d", strtotime("+1 day", strtotime($end_division)));
				$end_division=date("Y-m-t", strtotime($start_division));
			}
			if($end_date>$start_division) { //Catch the end case
				$label=date('Y M', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_date];
			}

		$data['datasets']=[];
		$offenses=[];
		for($n=0; $n<count($offense_list); $n++) {
			$points=[];
			for($x=0;$x<count($divisions); $x++) {
				$points[]=$this->getOffenseCount($cases, $offense_list[$n], $divisions[$x]['start'], $divisions[$x]['end']);
			}
			//print print_r($points);
			$data['datasets'][]=(object) ['type' => 'line', 'data' => $points,
        'backgroundColor' => 'transparent',
        'borderColor' => $colors[$n],
        'pointBorderColor' => $colors[$n],
        'pointBackgroundColor' => $colors[$n],
        'cubicInterpolationMode' => 'monotone',
        'tension' => 0,
        'fill' => false];
      }
		return view('header', $data)
			. view('menu', $data)
			. view('Search/dashboard', $data)
			. view('footer', $data);
	}
	
	private function getOffenseCount($cases, $offense, $start, $end)
	{
		$count=0;
		//print $offense." $start"." $end"."<br>";
		for($n=0;$n<count($cases); $n++) {
			$case_info=json_decode($cases[$n]['data_json'], true);
			$case_date=strtotime($case_info['sort']['date']);
			if(!$case_date) {
				print $case_info['sort']['date'];
				exit();
			}
			$case_offense=$case_info['details']['offenses'][0]['offenseCode']['label'] ?? '';
			//print "Start $start End $end compare $offense $case_offense ".date('Y-m-d', $case_date)."<br>";
			if($case_date>=strtotime($start) && $case_date<=strtotime($end) && $offense==$case_offense) {
				$count++;
				//print "Match";
			}
		}
		return($count);
	}
	
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;
use App\Libraries\CABIS;

class Dashboard extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $crModel;
	protected $crudModel;
	protected $controllerModel;
	protected $offenceModel;
	protected $cogcModel;
	protected $policeOfficerModel;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->crModel = model('App\Models\SubjectRecordModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->controllerModel = model('App\Models\ControllerModel');
		$this->trafficOffenseModel = model('App\Models\TrafficOffenseModel');
		$this->crudModel = model('App\Models\CrudModel');
		helper('inflector');
	}
	
	public function index()
	{
		$data=[];
		$colors=["#FF5733", "#F39C12", "#3498DB", "#2ECC71", "#E74C3C", "#9B59B6", "#1ABC9C", "#E67E22", "#27AE60", "#2980B9"];

		$data['dashboard']=1; //Set the variable to permit loading of the dashboard Javascript
		if($this->request->getVar('start_date')) {
			$start_date=$data['start_date']=$this->request->getVar('start_date');			
		} else {
			$start_date=$data['start_date']=date('2023-01-01');
		}
		if($this->request->getVar('end_date')) {
			$end_date=$data['end_date']=$this->request->getVar('end_date');
		} else {
			$end_date=$data['end_date']=date('Y-m-d');
			
		}

		$offences=$this->crModel->getTop10OffencesCount($start_date, $end_date);
		
		$offence_list=[];
		$offence_count=[];
		foreach($offences as $offence) {
			$offence_list[]=$offence['offence'];
			$offence_count[]=$offence['num'];
		}
		$data['colors']=array_slice($colors, 0, count($offence_list));
		$data['pieData']=$offence_count;
		$data['labels']=$offence_list;
		$temp_data=$this->crModel->getTemporary();
		$perm_data=$this->crModel->getPermanent();
		$data['temporary_criminal_records']=count($temp_data);
		$data['permanent_criminal_records']=count($perm_data);
		$data['police_records'] = $this->policeOfficerModel->countAll();
		$data['civilian_records'] = $this->cogcModel->countAll();
		$data['pso_records'] = $this->cogcModel->getCount('PSO', 'PROCESSED');
		$data['traffic_records'] = $this->trafficOffenseModel->countAll();
		$redlist_data=$this->subjectModel->search(['start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date'), 'red_list' => 1]);
		$data['redlist_records']=count($redlist_data);
		$data['offences']=$this->crudModel->getFieldOptions('offence');
		$data['task_queue']=0;
		$cabis=new CABIS();
		$records=$this->cogcModel->getUnprocessed();
		$data['task_queue']=$this->cogcModel->getCount(null,'QUEUE');
		
		//Prepare line graph
		//First decide whether to show by month or by year
		$divisions=[];
		$data['datasetLabels']=[];
		if((strtotime($end_date)-strtotime($start_date))/MONTH > 24) {
			$start_division=$start_date;
			//End division is the end of that year
			$end_division=date("Y-12-31", strtotime($start_division));
			//Division by year
			while($end_date>$end_division) {
				$label=date('Y', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_division];
				//Now move to next year
				$start_division=$end_division=date("Y-m-d", strtotime("+1 day", strtotime($end_division)));
				$end_division=date("Y-12-31", strtotime($start_division));
			}
			if($end_date>$start_division) { //Catch the end case
				$label=date('Y', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_date];
			}
		} else { // Group by months
			$start_division=$start_date;
			//End division is the end of that month
			$end_division=date("Y-m-t", strtotime($start_division));
			//Division by month
			while($end_date>$end_division) {
				$label=date('Y M', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_division];
				//Now move to next month
				$start_division=$end_division=date("Y-m-d", strtotime("+1 day", strtotime($end_division)));
				$end_division=date("Y-m-t", strtotime($start_division));
			}
			if($end_date>$start_division) { //Catch the end case
				$label=date('Y M', strtotime($start_division));
				$data['datasetLabels'][]=$label;
				$divisions[]=['start' => $start_division, 'end' => $end_date];
			}
		}

		$data['datasets']=[];
		for($n=0; $n<count($offences); $n++) {
			$points=[];
			for($x=0;$x<count($divisions); $x++) {
				$points[]=$this->crModel->getOffenceCount($offences[$n]['offence'], $divisions[$x]['start'], $divisions[$x]['end']);
			}
			$data['datasets'][]=(object) ['type' => 'line', 'data' => $points,
        'backgroundColor' => 'transparent',
        'borderColor' => $colors[$n],
        'pointBorderColor' => $colors[$n],
        'pointBackgroundColor' => $colors[$n],
        'cubicInterpolationMode' => 'monotone',
        'tension' => 0,
        'fill' => false];
      }
		return view('header', $data)
			. view('menu', $data)
			. view('dashboard', $data)
			. view('footer', $data);
	}
	
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use App\Libraries\NIRA;


class CriminalSubjectRecordsController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	
	protected $cache;
	protected $subjectRecordModel;
	protected $subjectModel;
	protected $cogcModel;
	protected $policeOfficerModel;
	protected $psoModel;
	protected $controllerModel;
	protected $attachmentModel;
	protected $controllerName;


	public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        $router = service('router');
		$this->controllerName  = str_replace('\\App\\Controllers\\', '', $router->controllerName());
		$this->methodName = $router->methodName();
	}

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->controllerModel = model('App\Models\ControllerModel');
		$this->attachmentModel = model('App\Models\AttachmentModel');
		$this->auditLogModel = model('App\Models\AuditLogModel');
		$this->crudModel = model('App\Models\CrudModel');
	}
	
	function image($id) {
		$record=$this->subjectRecordModel->find($id);
		return $this->response->setHeader("Content-Type", $record['scan_type'])
		->setBody(base64_decode($record['scan_file']));
	}
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if(!$this->request->getVar('cabis_id')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items (specifically CABIS ID), record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('frontend/subject_records/criminal');
		}
		
		//Does this subject have an existing subject_id
		$subject=$this->subjectModel->getByCabisId($this->request->getVar('cabis_id'));
		if($subject) {
			$subject_id=$subject['id'];
			$this->subjectModel->update($subject['id'], ['case_tracking_person_id' => $this->request->getVar('case_tracking_person_id')]);
		} else {
			$subject_id=$this->subjectModel->insert(['first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('first_name'), 'cabis_id' => $this->request->getVar('cabis_id'), 'case_tracking_person_id' => $this->request->getVar('case_tracking_person_id')]);
		}
		
		//Setup the proper sentence_amount
		if($this->request->getVar('non_custodial_sentence') == 'FINE') {
			$sentence_units='CURRENCY';
			$sentence_amount=$this->request->getVar('fine_amount');
		} else {
			$sentence_units=$this->request->getVar('sentence_units');
			$sentence_amount=$this->request->getVar('sentence_amount');
		}
		
		//All good add, the record
		$db_data=['subject_id' => $subject_id, 'court_place_trial' => $this->request->getVar('court_place_trial'), 'offence' => $this->request->getVar('offence'),  'case_result' => $this->request->getVar('case_result'), 'non_custodial_sentence' => $this->request->getVar('non_custodial_sentence'), 'sentence_type' => $this->request->getVar('sentence_type'), 'sentence_units' => $sentence_units, 'sentence_amount' => $sentence_amount,  'date_sentence' => $this->request->getVar('date_sentence'), 'date_received' => $this->request->getVar('date_received'),  'remarks' => $this->request->getVar('remarks'),  'name' => $this->request->getVar('name'), 'station' => $this->request->getVar('station'), 'crb_no' => $this->request->getVar('crb_no'), 'date_arrest' => $this->request->getVar('date_arrest'), 'father' => $this->request->getVar('father'), 'aliases' => $this->request->getVar('aliases'), 'court_case_number' => $this->request->getVar('court_case_number'), 'officer_in_charge' => $this->request->getVar('officer_in_charge'), 'case_tracking_id' => $this->request->getVar('case_tracking_id'), 'source' => $this->request->getVar('source'), 'aliases' => $this->request->getVar('aliases')];
	
		
		if(!$this->request->getVar('id')) {
			//Don't create if it's a duplicate
			if($this->subjectRecordModel->isDuplicate($db_data['subject_id'], $db_data['offence'])) {
				$this->session->setFlashdata('errorMessage', 'Record is a duplicate'); 
				$this->session->setFlashdata('errorTitle', 'Duplicate record ignored'); 
				if($this->request->getVar('cert_id')) {
					return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$this->request->getVar('cert_id'));
				}
				return redirect()->to('frontend/subject_records/');
			} 
			$record_id=$this->subjectRecordModel->create($db_data);
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $record_id, 'section' => 'CRIMINAL RECORDS', 'action' => 'CREATE', 'data_before' => '', 'data_after' => json_encode($audit_data)]);
		} else {
			$record_id=$this->request->getVar('id');
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$before_data=$this->subjectRecordModel->find($this->request->getVar('id'));
			$subject=$this->subjectModel->find($db_data['subject_id']);
			$before_data['subject_id']=$subject['cabis_id'];
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $this->request->getVar('id'), 'section' => 'SUBJECT RECORDS', 'action' => 'UPDATE', 'data_before' => json_encode($before_data), 'data_after' => json_encode($audit_data)]);
			$this->subjectRecordModel->update($this->request->getVar('id'), $db_data);
		}
		$this->session->setFlashdata('message', 'Record saved for '.$this->request->getVar('first_name').' '.$this->request->getVar('last_name')); 
		$this->session->setFlashdata('messageTitle', 'Record saved');
		
		if($this->request->getVar('cert_id')) {
			if($this->request->getVar('issue_id') > 0) { //Mark the issue as fixed
				$this->cogcIssueModel->update($issue['id'], ['status' => 'RESOLVED']);
			}
			return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$this->request->getVar('cert_id'));
		} else {
			return redirect()->to('frontend/subject_records/criminal/view/'.$record_id);
		}
	}

	
	public function index()
	{
		$data=[];
		$cr_data=$this->subjectRecordModel->findAll();
		$data['records']=[];
		$cr_data=[];
		foreach($cr_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$record['attachments'] = $this->attachmentModel->retrieve('subject_record', $record['id']);
			
			switch ($record['case_result']) {
				case 'NOT SENTENCED YET':
					$record['result']="Not sentenced yet";
					break;
				case 'ACQUITTED':
					$record['result']="Acquitted";
					break;
				case 'DISMISSED':
					$record['result']="Dismissed";
					break;
				case 'SENTENCED':
					switch($record['sentence_type']) {
						case 'CUSTODIAL':
							$record['result']='Imprisonment for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
						break;
						case 'NON CUSTODIAL':
						switch($record['non_custodial_sentence']) {
							case 'CAUTION':
								$record['result']='Caution';
								break;
							case 'COMMUNITY SERVICE':
								$record['result']='Community service for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
								break;
							case 'FINE':
								$record['result']='Fined UGX '.$record['sentence_amount'];
								break;
						}
						break;
					}
					break;
				default:
					$record['result']=" - ";
			}
			$data['records'][]=$record;
		}
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') {
				$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
			}
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/criminals', $data)
			. view('footer', $data);
	}
	
		public function search()
	{
		$data=[];
		$cr_data=$this->subjectRecordModel->search(['subject_id' => $this->request->getVar('subject_id'), 'crb_no' => $this->request->getVar('crb_no'), 'name' => $this->request->getVar('name'), 'station' => $this->request->getVar('station'), 'type' => $this->request->getVar('type'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($cr_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$record['first_name']=$subject['first_name'];
			$record['last_name']=$subject['last_name'];
			$record['attachments'] = $this->attachmentModel->retrieve('subject_record', $record['id']);
			switch ($record['case_result']) {
				case 'NOT SENTENCED YET':
					$record['result']="Not sentenced yet";
					break;
				case 'ACQUITTED':
					$record['result']="Acquitted";
					break;
				case 'DISMISSED':
					$record['result']="Dismissed";
					break;
				case 'SENTENCED':
					switch($record['sentence_type']) {
						case 'CUSTODIAL':
							$record['result']='Imprisonment for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
						break;
						case 'NON CUSTODIAL':
						switch($record['non_custodial_sentence']) {
							case 'CAUTION':
								$record['result']='Caution';
								break;
							case 'COMMUNITY SERVICE':
								$record['result']='Community service for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
								break;
							case 'FINE':
								$record['result']='Fined UGX '.$record['sentence_amount'];
								break;
						}
						break;
					}
					break;
				default:
					$record['result']=" - ";
			}
			$data['records'][]=$record;
		}
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/criminals', $data)
			. view('footer', $data);
	}
	
	public function view($id)
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$ct=new CaseTracking();
		$nira = new NIRA();
		$data['record']=$this->subjectRecordModel->find($id);
		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['subject']=$subject;
		$data['record']['type']='CRIMINAL';
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['record']['case_tracking_person_id']=$subject['case_tracking_person_id'];
		$data['record']['subject_name']=$subject['name'];
		$data['record']['first_name']=$subject['first_name'];
		$data['record']['last_name']=$subject['last_name'];
		$data['record']['aliases']="";
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$data['permanent_records']= $this->subjectRecordModel->getBySubjectId($subject['id'], 'PERMANENT');
		$data['cogc']=$this->cogcModel->getBySubjectId($subject['id']);
		$data['related_records']=$this->generateOtherRecords($subject['id'], 'CRIMINAL', $id);
		//Populate aliases
		foreach($data['related_records'] as $related) {
			if(array_key_exists('first_name', $related) && array_key_exists('last_name', $related)) {
				if(strcmp($related['first_name'], $subject['first_name']) || strcmp($related['last_name'], $subject['last_name'])) {
					$data['record']['aliases'].=$related['first_name']." ".$related['last_name']."<br>";
				}
			}
		}
		if($subject['nin']) {
			$data['nin']=$nira->getPerson($subject['nin']);
		}
		
		$data['case']=null;
		if($data['record']['case_tracking_id']) {
			$case_data=$ct->query(['query' => ['type' => 'Case', 'id' => $data['record']['case_tracking_id']]]);
			log_message('debug', print_r($case_data, true));
			if(is_array($case_data)) {
				if(array_key_exists(0, $case_data)) {
					$data['case']=$case_data[0];
				}
			}
	
		log_message('debug', 'Case Tracking: '.print_r($data['case'], true));
		}
		$data['person']=null;
		if($data['record']['case_tracking_person_id']) {
			$person_data=$ct->query(['query' => ['type' => 'Person', 'id' => $data['record']['case_tracking_person_id']]]);
			if($person_data) {
				if(is_array($person_data)) {
					if(!array_key_exists('errorCode', $person_data)) {
						$data['person']=$person_data[0];
					}
				}
			}
	
		log_message('debug', 'Case Tracking: '.print_r($data['case'], true));
		}

		switch ($data['record']['case_result']) {
				case 'NOT SENTENCED YET':
					$data['record']['result']="Not sentenced yet";
					break;
				case 'ACQUITTED':
					$data['record']['result']="Acquitted";
					break;
				case 'DISMISSED':
					$data['record']['result']="Dismissed";
					break;
				case 'SENTENCED':
					switch($data['record']['sentence_type']) {
						case 'CUSTODIAL':
							$data['record']['result']='Imprisonment for '." ".counted($data['record']['sentence_amount'], strtolower($data['record']['sentence_units']));
						break;
						case 'NON CUSTODIAL':
						switch($data['record']['non_custodial_sentence']) {
							case 'CAUTION':
								$data['record']['result']='Caution';
								break;
							case 'COMMUNITY SERVICE':
								$data['record']['result']='Community service for '." ".counted($data['record']['sentence_amount'], strtolower($data['record']['sentence_units']));
								break;
							case 'FINE':
								$data['record']['result']='Fined UGX '.$data['record']['sentence_amount'];
								break;
						}
						break;
					}
					break;
				default:
					$data['record']['result']=" - ";
			}
		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		$data['attachments'] = $this->attachmentModel->getBySubjectId($subject['id']);
		for($n=0; $n<count($data['attachments']); $n++) {
			$data['attachments'][$n]['file_type_readable']=\JCoded\FriendlyMime\FriendlyMime::getFriendlyName($data['attachments'][$n]['file_type']);
		}
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') {
				$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
			}
		}
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/criminal', $data)
			. view('footer', $data);
	}
	
	public function edit($id)
	{
		$data=[];
		$data['record']=$this->subjectRecordModel->find($id);
		$data['edit_subject_record']=1;

		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['subject']=$subject;
		$data['cert_id']=$this->request->getVar('cert_id');
		$data['record']['cabis_id']=$subject['cabis_id'];
		$data['record']['subject_name']=$subject['name'];
		$data['record']['case_tracking_person_id']=$subject['case_tracking_person_id'];
		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') {
				$options=$this->controllerModel->getFieldOptions($data['fields'][$n]['id']);
				if($options) {
					$data['fields'][$n]['options']=$options;
				} else {
					$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
				}
			}
		}
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/edit_criminal_subject_record', $data)
			. view('footer', $data);
	}
	
	
	public function add()
	{
		$data=[];
		$data['edit_subject_record']=1;
		if(strlen($this->request->getVar('cabis_id') ?? '')>0) {
			$data['original_cabis_id']=$this->request->getVar('cabis_id');
			if(strlen($this->request->getVar('criminal_cabis_id') ?? '')) {
				$data['criminal_cabis_id']=$data['cabis_id']=$this->request->getVar('criminal_cabis_id');
			} else {
				$data['criminal_cabis_id']=$data['cabis_id']=$this->request->getVar('cabis_id');
			}
			$data['issue_id']=$this->request->getVar('issue_id');
			$data['cert_id']=$this->request->getVar('cert_id');
			session_write_close(); //In case CABIS is unavailable, other services should keep running
			$cabis=new CABIS();
			//Get data of the current CABIS id as well as the previous criminal record to fill in the court case
			$data['record']=['first_name' => $cabis->getTag($data['criminal_cabis_id'], FirstName) ?? '', 'last_name' => $cabis->getTag($data['criminal_cabis_id'], LastName) ?? '', 'offense' => $cabis->getTag($data['criminal_cabis_id'], CriminalRecord) ?? '', 'crb_no' => $cabis->getTag($data['criminal_cabis_id'], CRBID) ?? '', 'station' => $cabis->getTag($data['criminal_cabis_id'], PoliceStation), 'date_received' => $cabis->getTag($data['criminal_cabis_id'], Date) ?? '', ];
			log_message('debug', print_r($data['record'], true));
		}
		$this->controller=$this->controllerModel->getByControllerName('Frontend\CriminalSubjectRecordsController');

		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/add_criminal_subject_record', $data)
			. view('footer', $data);
	}
}

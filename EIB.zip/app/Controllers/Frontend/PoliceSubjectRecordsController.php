<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use App\Libraries\NIRA;
use App\Libraries\Email;

class PoliceSubjectRecordsController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;

	function __construct()
	{
		parent::__construct();
		$this->controller=[];
		$this->controller['route']='/frontend/subject_records/police';
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->psoModel = model('App\Models\PSOModel');
		$this->ippsModel = model('App\Models\ippsModel');
	}
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if( !$this->request->getVar('first_name') || !$this->request->getVar('last_name')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('frontend/subject_records/police');
		}
		
		//Does this subject have an existing subject_id
		$subject=$this->subjectModel->getByCabisId($this->request->getVar('cabis_id'));
		if($subject) {
			$subject_id=$subject['id'];
		} else {
			$subject_id=$this->subjectModel->insert(['name' => $this->request->getVar('first_name').' '.$this->request->getVar('last_name'), 'cabis_id' => $this->request->getVar('cabis_id')]);
		}
		
		
		//All good add, the record
		$db_data=['subject_id' => $subject_id, 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'employee_number' => $this->request->getVar('employee_number'), 'nin' => $this->request->getVar('nin')];
	
		
		if(!$this->request->getVar('id')) { 
			$record_id=$this->policeOfficerModel->insert($db_data);
			
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $record_id, 'section' => 'POLICE RECORDS', 'action' => 'CREATE', 'data_before' => '', 'data_after' => json_encode($audit_data)]);
		} else {
			$record_id=$this->request->getVar('id');
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$before_data=$this->policeOfficerModel->find($this->request->getVar('id'));
			$subject=$this->subjectModel->find($db_data['subject_id']);
			$before_data['subject_id']=$subject['cabis_id'];
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $this->request->getVar('id'), 'section' => 'POLICE RECORDS', 'action' => 'UPDATE', 'data_before' => json_encode($before_data), 'data_after' => json_encode($audit_data)]);
			$this->policeOfficerModel->update($this->request->getVar('officer_id'), $db_data);
		}
		$this->session->setFlashdata('message', 'Record saved for '.$this->request->getVar('first_name').' '.$this->request->getVar('last_name')); 
		$this->session->setFlashdata('messageTitle', 'Record saved'); 
		return redirect()->to('frontend/subject_records/police/view/'.$record_id);
	}

	
	public function index()
	{
		$data=[];
		$data['records']=[];
		$data['controllerName']=$this->controllerName;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/police_officers', $data)
			. view('footer', $data);
	}
	
		public function search()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$police_data=$this->policeOfficerModel->search(['cabis_id' => $this->request->getVar('cabis_id'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'employee_number' => $this->request->getVar('employee_number'), 'nin' => $this->request->getVar('nin'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($police_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$cabis_present=$cabis->getTag($subject['cabis_id'], '105');
			$record['status']= ($cabis_present != null) ? "COMPLETED" : "PENDING";
			$record['attachments'] = []; //$this->attachmentModel->retrieve('subject_record', $record['id']);
			$data['records'][]=$record;
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/police_officers', $data)
			. view('footer', $data);
	}
	
	public function view($id)
	{
		$data=[];
		session_write_close();
		$cabis=new CABIS();
		$nira=new NIRA();
		$data['record']=$this->policeOfficerModel->find($id);
		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['subject']=$subject;
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$data['record']['status']= ($data['cabis_present'] != null) ? "COMPLETED" : "PENDING";
		$data['permanent_records']= $this->subjectRecordModel->getBySubjectId($subject['id'], 'PERMANENT');
		$data['related_records']=$this->generateOtherRecords($subject['id'], 'POLICE', $id);

		$data['attachments'] = []; //$this->attachmentModel->retrieve('subject_record', $subjectRecord['id']);
		if($subject['nin']) {
			$data['nin']=$nira->getPerson($subject['nin']);
		}
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/police_officer', $data)
			. view('footer', $data);
	}
	
	
	public function edit($id)
	{
		$data=[];
		$data['record']=$this->policeOfficerModel->find($id);
		$data['edit_police_officer']=1;

		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['record']['subject_id']=$subject['cabis_id'];
		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/edit_police_officer', $data)
			. view('footer', $data);
	}
	
	public function add()
	{
		$data=[];
		$data['edit_police_officer']=1;
		$data['record']=[];
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/edit_police_officer', $data)
			. view('footer', $data);
	}
}

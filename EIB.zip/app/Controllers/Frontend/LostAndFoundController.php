<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;
use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class LostAndFoundController extends \App\Controllers\CrudController
{
        use ResponseTrait;
        protected $attachmentModel;

        public function __construct()
        {
			$this->attachmentModel = model('App\Models\AttachmentModel');
                
        }
        
        /**
     * Constructor. This adds attachments
     */
    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);
        $this->attachmentModel = model('App\Models\AttachmentModel');
        $num_records=count($this->dbData);
        for($n=0;$n<$num_records;$n++) {
			$this->dbData[$n]['attachments'] = $this->attachmentModel->retrieve('lost_and_found', $this->dbData[$n]['id']);
		}
	}
	
	//Shows the default text
    public function index() {
		$data=['data' => $this->dbData, 'fields' => $this->fields, 'controller' => $this->controller];
		return view('header', $data)
			. view('menu', $data)
			. view('lostandfound', $data)
			. view('footer', $data);
	}
	
	public function attachmentSubmit()
	{
		$attachment = $this->request->getFile('attachment');
		if($attachment->isValid()) {
			$type=$attachment->getMimeType();
			$filepath = WRITEPATH . 'uploads/' . $attachment->store();
			$file_content=file_get_contents($filepath);
			$post_data=['lost_and_found_id' => $this->request->getVar('lost_and_found_id'), 'name' => $this->request->getVar('name'), 'description' => $this->request->getVar('description'), 'file_type' => $type, 'file_content' => $file_content];
			$this->attachmentModel->insert($post_data);
		}
		$router = service('router');
		$controllerName  = str_replace('\\App\\Controllers\\', '', $router->controllerName());
		return redirect()->route($controllerName.'::index');
	}
	
	public function attachmentAdd($id)
	{
		$data=[];
		$data['lost_and_found_id']=$id;
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('add_attachment', $data)
			. view('footer', $data);
	}
}


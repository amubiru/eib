<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use App\Libraries\Email;
use App\Libraries\NIRA;


class CivilianSubjectRecordsController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;

	function __construct()
	{
		parent::__construct();
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->cogcIssueModel = model('App\Models\COGCIssueModel');
		$this->psoModel = model('App\Models\PSOModel');
		$this->controller=[];
		$this->controller['route']='/frontend/subject_records/civilian';
	}
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if(!$this->request->getVar('subject_id') || !$this->request->getVar('name')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('frontend/subject_records/civilian');
		}
		
		//Does this subject have an existing subject_id
		$subject=$this->subjectModel->getByCabisId($this->request->getVar('subject_id'));
		if($subject) {
			$subject_id=$subject['id'];
		} else {
			$subject_id=$this->subjectModel->create(['name' => $this->request->getVar('name'), 'cabis_id' => $this->request->getVar('subject_id'), ]);
		}
		
		
		//All good add, the record
		$db_data=['subject_id' => $subject_id, 'remarks' => $this->request->getVar('remarks'),  'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'station' => $this->request->getVar('station'),  'source' => 'CIVILIAN'];
	
		
		if(!$this->request->getVar('id')) { 
			$record_id=$this->subjectRecordModel->create($db_data);
			$uuid=substr(uuid(),0,8);
			//Add the data specific to a certificate of good conduct
			$this->cogcModel->insert(['first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'id_type' => $this->request->getVar('id_type'), 'prn' => $this->request->getVar('prn'), 'id_number' => $this->request->getVar('id_number'), 'issued_by' => $this->request->getVar('issued_by'), 'uuid' => $uuid, 'subject_record_id' => $record_id, 'picture' => base64_encode($file_content)]);
			
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $record_id, 'section' => 'CIVILIAN RECORDS', 'action' => 'CREATE', 'data_before' => '', 'data_after' => json_encode($audit_data)]);
		} else {
			$record_id=$this->request->getVar('id');
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$before_data=$this->subjectRecordModel->find($this->request->getVar('id'));
			$subject=$this->subjectModel->find($db_data['subject_id']);
			$before_data['subject_id']=$subject['cabis_id'];
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $this->request->getVar('id'), 'section' => 'CIVILIAN RECORDS', 'action' => 'UPDATE', 'data_before' => json_encode($before_data), 'data_after' => json_encode($audit_data)]);
			$this->subjectRecordModel->update($this->request->getVar('subject_record_id'), $db_data);
			$this->cogcModel->update($this->request->getVar('id'), ['first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'id_type' => $this->request->getVar('id_type'), 'prn' => $this->request->getVar('prn'), 'id_number' => $this->request->getVar('id_number'), 'issued_by' => $this->request->getVar('issued_by'), 'uuid' => $uuid, 'subject_record_id' => $record_id, 'picture' => base64_encode($file_content)]);
		}
		$this->session->setFlashdata('message', 'Record saved for '.$this->request->getVar('name')); 
		$this->session->setFlashdata('messageTitle', 'Record saved'); 
		return redirect()->to('frontend/subject_records/civilian/view/'.$record_id);
	}

	
	public function index()
	{
		$data=[];
		$data['records']=[];
		$data['controllerName']=$this->controllerName;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilians', $data)
			. view('footer', $data);
	}
	
	//Adds a queue reason if it's not been used yet
	private function addQueueReason($reason, $new_reason)
	{
		if(!strstr($reason, $new_reason)) {
			$reason.="$new_reason\n";
		}
		return($reason);
	}
	
	//Puts this record back in the queue after checking for new matches
	public function requeue($cert_id) 
	{
		$cabis = new CABIS();
		$cert=$this->cogcModel->find($cert_id);
		$subject=$this->subjectModel->find($cert['subject_id']);
		log_message('debug', "Reprocessing {$subject['cabis_id']}");
		//Confirm that this information has hit CABIS
		if(!strlen($cabis->getTag($subject['cabis_id'], FirstName) ?? '')) {
			
			log_message('debug', $subject['cabis_id']. ' not yet in CABIS');
			$this->session->setFlashdata('errorMessage', 'Unknown record submitted, does not seem to be in CABIS'); 
			$this->session->setFlashdata('errorTitle', 'Missing data');
			return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$cert['id']);
		}
		
		//Remove existing COGC issues
		$this->cogcIssueModel->deleteByCogcId($cert['id']);
		
		$criminal=false;
		//Look for criminal records
		$cabis_records = $cabis->getMatchingCandidates($subject['cabis_id'], false);
		//Remove duplicates - using a helper function since the PHP one does not work with multi dimensional arrays
		$cabis_records = array_unique_multi($cabis_records);
		log_message('debug', 'Got matches: for '.$subject['cabis_id']. " as " .print_r($cabis_records, true));
		$queue_reason='';
		$queue_type='';
		//Police
		if($cabis->getItem($subject['cabis_id'], 'afisCategory') ==1 && $cabis->getTag($subject['cabis_id'], ForceNumber)) {
			//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
		}
		foreach($cabis_records as $record) {
			if($record['category']==AFIS_CRIMINAL) {
				$queue_type='CRIMINAL';
				$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'CRIMINAL']);
				$queue_reason=$this->addQueueReason($queue_reason, 'Criminal record CABIS: '.$record['cabis_id']);
			}
			if($record['category']==AFIS_LAW_ENFORCEMENT) {
				if($queue_type!='CRIMINAL') {
					$queue_type='POLICE';
				}
				//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
				$queue_reason=$this->addQueueReason($queue_reason, 'Police officer CABIS: '.$record['cabis_id']);
			}
			//Check for NIRA names
			if($cert['id_type']=='NIN') {
				$nira = new NIRA();
				$nin=$nira->getPerson($cert['id_number']);
				if(strlen($nin['surname'] ?? '')) {
					if($cert['last_name'] != $nin['surname']) {
						if(!in_array($queue_type, ['CRIMINAL','POLICE'])) {
						$queue_type='CIVILIAN';
					}
					$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => null, 'type' => 'NAME']);
					$queue_reason=$this->addQueueReason($queue_reason, 'Different names NIRA: '.' First name: '.$nin['givenNames'].' Last name: '.$nin['surname']);
					}
				}
			}
			if($cert['first_name'] != $record['first_name'] || $cert['last_name'] != $record['last_name']) {
				if(!in_array($queue_type, ['CRIMINAL','POLICE'])) {
					$queue_type='CIVILIAN';
				}
				$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'NAME']);
				$queue_reason=$this->addQueueReason($queue_reason, 'Different names CABIS: '.$record['cabis_id'].' First name: '.$record['first_name'].' Last name: '.$record['last_name']);
			}
			
		}
		//Will always end up in queue
		$this->cogcModel->update($cert['id'], ['queue_type' => $queue_type, 'internal_notes' => $cert['internal_notes']."\n".$queue_reason."\nRequeued on ".date('Y-m-d'), 'queue_reason' => $queue_reason, 'status' => 'QUEUE']);
		$this->session->setFlashdata('message', 'Record has been rechecked'); 
		$this->session->setFlashdata('messageTitle', 'Success');
		return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$cert['id']);
	}
	
	public function queue_index()
	{
		$data=[];
		$data['records']=[];
		$data['controllerName']=$this->controllerName;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilians_queue', $data)
			. view('footer', $data);
	}
	
	public function search()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis= new CABIS();
		//Check if a group ID has been specified and check in CABIS
		if(!empty($this->request->getVar('group_id'))) {
			$members=$cabis->getGroupMembers($this->request->getVar('group_id'));
			$cabis_ids=[];
			foreach($members as $member) {
				$cabis_ids[]=$member['cabis_id'];
			}
			$cogc_data=$this->cogcModel->getByCabisArray($cabis_ids);
		} else {
			$cogc_data=$this->cogcModel->search(['subject_id' => $this->request->getVar('subject_id'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'station' => $this->request->getVar('station'), 'prn' => $this->request->getVar('prn'), 'id_number' => $this->request->getVar('id_number'), 'status' => $this->request->getVar('status'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date'), 'fp_start_date' => $this->request->getVar('fp_start_date'), 'fp_end_date' => $this->request->getVar('fp_end_date'), 'application_category' => $this->request->getVar('application_category')]);
		}
		$data['records']=[];
		$data['cabis_checks']=[];
		foreach($cogc_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$record['cabis_id']=$subject['cabis_id'];
			$record['attachments'] = $this->attachmentModel->retrieve('subject_record', $record['id']);
			$data['records'][]=$record;
			if($record['status']=='PENDING') {
				$data['cabis_checks'][]=['id' => $record['id'], 'cabis_id' => $record['cabis_id']];
			}
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilians', $data)
			. view('footer', $data);
	}
	
	public function queue_search()
	{
		$data=[];
		$search_data=[];
		if($this->request->getVar('resume_search')) {
			$search_data=$_SESSION['queue_data'];
		} else {
			$search_data=['subject_id' => $this->request->getVar('subject_id'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'station' => $this->request->getVar('station'), 'prn' => $this->request->getVar('prn'), 'id_number' => $this->request->getVar('id_number'), 'status' => 'QUEUE', 'queue_type' => $this->request->getVar('queue_type'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date'),  'fp_start_date' => $this->request->getVar('fp_start_date'), 'fp_end_date' => $this->request->getVar('fp_end_date'), ];
			$_SESSION['queue_data']=$search_data;
		}

		$cogc_data=$this->cogcModel->search($search_data);
		$data['records']=[];
		foreach($cogc_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$record['cabis_id']=$subject['cabis_id'];
			$record['status']= $record['status'];
			$record['attachments'] = $this->attachmentModel->retrieve('subject_record', $record['id']);
			$data['records'][]=$record;
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilians_queue', $data)
			. view('footer', $data);
	}
	
	public function submitPCC()
	{
		if($this->request->getVar('reject') == 'reject') {
			return $this->queue_reject();
		}
		$cert=$this->cache->get('QUEUE_'.$this->request->getVar('pcc_uuid'));
		if(!$cert) {
			$this->session->setFlashdata('errorMessage', 'Unknown record submitted, no changes have been made'); 
			$this->session->setFlashdata('errorTitle', 'Missing data');
			return redirect()->to('/frontend/subject_records/civilian/queue');
		}
		$this->cogcModel->update($cert['id'], ['status' => 'RESOLVED', 'adverse_police_notice' => $this->request->getVar('adverse_police_notice')]);
		$this->session->setFlashdata('message', 'Certificate will be generated within 5 minutes'); 
		$this->session->setFlashdata('messageTitle', 'Success');
		return redirect()->to('/frontend/subject_records/civilian/queue_search?resume_search=1');			
	}
	
	
	public function view($id)
	{
		$data=[];
		session_write_close();
		$cabis=new CABIS();
		$nira = new NIRA();
		
		$data['record']=$this->cogcModel->find($id);
		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['subject']=$subject;
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['record']['type']='CIVILIAN';
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$data['permanent_records']= $this->subjectRecordModel->getBySubjectId($data['record']['subject_id'], 'PERMANENT');
		$data['cogc']=$this->cogcModel->find($id);
		$data['related_records']=$this->generateOtherRecords($subject['id'], 'CIVILIAN', $id);
		$data['application']=json_decode($data['record']['raw_content'] ?? '', true);

		$data['attachments'] = $this->attachmentModel->getBySubjectId($subject['id']);
		for($n=0; $n<count($data['attachments']); $n++) {
			$data['attachments'][$n]['file_type_readable']=\JCoded\FriendlyMime\FriendlyMime::getFriendlyName($data['attachments'][$n]['file_type']);
		}
		if($data['record']['id_number']) {
			$data['nin']=$nira->getPerson($data['record']['id_number']);
		}
		if($data['record']['status']=='PENDING' && $data['cabis_present']) {
			$this->cogcModel->update($data['record']['id'], ['status' => 'FINGERPRINT', 'fingerprint_date' => date('Y-m-d H:i:s')]);
		}
			
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilian', $data)
			. view('footer', $data);
	}
	
		public function queue_view($id)
	{
		$data=[];
		$cabis_ids=[];
		
		session_write_close();
		$cabis=new CABIS();
		$nira = new NIRA();
		$data['civilian_issues']=$data['criminal_issues']=[];
		$data['police_issues']=null;
		$data['record']=$this->cogcModel->find($id);
		$data['pcc_uuid']=uuid();
		$this->cache->save('QUEUE_'.$data['pcc_uuid'],$data['record'], 30*MINUTE);
		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['subject']=$subject;
		$data['record']['subject_id']=$subject['cabis_id'];
		
		//Get all matching CABIS IDs
		$cabis_ids[]=$subject['cabis_id'];
		$cabis_records = $cabis->getMatchingCandidates($subject['cabis_id'], false);
		foreach($cabis_records as $rec) {
			$cabis_ids[]=$rec['cabis_id'];
		}
		$cabis_ids=array_unique($cabis_ids);
		log_message('debug', "MATCHING {$subject['cabis_id']} ".print_r($cabis_ids, true));
		
		//Load offenses since we have all the CABIS Ids
		$data['offenses']= $this->subjectRecordModel->getByCabisIds($cabis_ids);
		$data['eib_offense_cabis_ids']=[];
		foreach($data['offenses'] as $offense) {
			$data['eib_offense_cabis_ids'][]=$offense['cabis_id'];
		}
		
		$data['record']['type']='CIVILIAN';
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$data['cogc']=$this->cogcModel->find($id);
		$data['related_records']=$this->generateOtherRecords($subject['id'], 'CIVILIAN', $id);
		$data['application']=json_decode($data['record']['raw_content'] ?? '', true);

		$data['attachments'] = $this->attachmentModel->getBySubjectId($subject['id']);
		for($n=0; $n<count($data['attachments']); $n++) {
			$data['attachments'][$n]['file_type_readable']=\JCoded\FriendlyMime\FriendlyMime::getFriendlyName($data['attachments'][$n]['file_type']);
		}
		$data['nin']=[];
		if($data['record']['id_type'] == 'NIN' && $data['record']['id_number']) {
			$data['nin']=$nira->getPerson($data['record']['id_number']);
		}
		//Get current and previous police interactions
		$civilian_issues=[];
		$police_issues=null;
		$criminal_issues=[];
		$issues=$this->cogcIssueModel->getByCogcIdType($data['record']['id'], 'NAME');
		if(count($issues)) {
			//First put NIRA name
			if(count($data['nin'] ?? [])) {
				$uuid=uuid();
				$rec=['type'=> 'NAME', 'first_name' => $data['nin']['givenNames'], 'middle_name' => '', 'cabis_id' => 0, 'last_name' => $data['nin']['surname'], 'cabis_id' => null, 'application' => 'NIRA details', 'uuid' => $uuid, 'id' => $id];
				$this->cache->save('QUEUE_'.$uuid, $rec, 30*MINUTE);
				$civilian_issues[]=$rec;
			}
			//The name submitted on the form is the second name to put
			$uuid=uuid();
			$rec=['type'=> 'NAME', 'first_name' => $data['record']['first_name'], 'middle_name' => $data['record']['middle_name'], 'cabis_id' => 0, 'last_name' => $data['record']['last_name'], 'cabis_id' => null, 'application' => 'Application details', 'uuid' => $uuid, 'id' => $id];
			$this->cache->save('QUEUE_'.$uuid, $rec, 30*MINUTE);
			$civilian_issues[]=$rec;
			foreach($issues as $issue) {
				if($issue['related_cabis_id']==NULL) {
					continue;
				}
				$uuid=uuid();
				$rec=['type' => 'NAME','first_name' => $cabis->getTag($issue['related_cabis_id'], FirstName), 'middle_name' => $cabis->getTag($issue['related_cabis_id'], MiddleName), 'last_name' => $cabis->getTag($issue['related_cabis_id'], LastName),  'cabis_id' => $issue['related_cabis_id'], 'uuid' => $uuid, 'id' => $id];
				$civilian_issues[]=$rec;
				$this->cache->save('QUEUE_'.$uuid, $rec, 30*MINUTE);
			}
		}
		
		$issues=$this->cogcIssueModel->getByCogcIdType($data['record']['id'], 'POLICE');
		if(count($issues)) {
			$uuid=uuid();
			$police_issues=['type' => 'POLICE', 'id' => $id, 'uuid' => $uuid];
			$this->cache->save('QUEUE_'.$uuid, $police_issues, 30*MINUTE);
		}
		
		$issues=$this->cogcIssueModel->getByCogcIdType($data['record']['id'], 'CRIMINAL');
		if(count($issues)) {
			foreach($issues as $issue) {
				//Don't show this, it's already been worked on
				if(in_array($issue['related_cabis_id'], $data['eib_offense_cabis_ids'])) {
					continue;
				}
				$uuid=uuid();
				$rec=['type' => 'CRIMINAL', 'first_name' => $cabis->getTag($issue['related_cabis_id'], FirstName), 'middle_name' => $cabis->getTag($issue['related_cabis_id'], MiddleName), 'last_name' => $cabis->getTag($issue['related_cabis_id'], LastName), 'cabis_id' => $issue['related_cabis_id'], 'offense' => $cabis->getTag($issue['related_cabis_id'], CriminalRecord), 'date' => $cabis->getTag($issue['related_cabis_id'], Date),'uuid' => $uuid, 'id' => $id];
				$criminal_issues[]=$rec;
				$this->cache->save('QUEUE_'.$uuid, $rec, 30*MINUTE);
			}
		}
		
		//Load offenses since we have all the CABIS Ids
		$data['offenses']= $this->subjectRecordModel->getByCabisIds($cabis_ids);
		
		
		$data['civilian_issues']=$civilian_issues;
		$data['police_issues']=$police_issues;
		$data['criminal_issues']=$criminal_issues;
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilian_queue', $data)
			. view('footer', $data);
	}
	
	function queue_resolve()
	{
		$item=$this->cache->get('QUEUE_'.$this->request->getVar('data'));
		if(!$item) {
			$this->session->setFlashdata('errorMessage', 'Missing data, no changes made. Probably you waited too long before submitting'); 
            $this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('/frontend/subject_records/civilian/queue');
		}
		if($item['type']=='NAME') {
			$old_cogc=$this->cogcModel->find($item['id']);
			$this->cogcModel->update($item['id'], ['first_name' => $item['first_name'], 'middle_name' => $item['middle_name'], 'last_name' => $item['last_name']]);
			$this->auditLogModel->insert(['user_id'=>$_SESSION['user_id'], 'data_id' => $item['id'], 'section' => 'CIVILIAN_RECORDS', 'action' => 'UPDATE', 'data_before' => json_encode(['first_name' => $old_cogc['first_name'], 'middle_name' => $old_cogc['middle_name'], 'last_name' => $old_cogc['last_name']]), 'data_after' => json_encode(['first_name' => $item['first_name'], 'middle_name' => $item['middle_name'], 'last_name' => $item['last_name']])]);
			$this->auditLogModel->insert(['user_id'=>$_SESSION['user_id'], 'data_id' => $item['id'], 'section' => 'CIVILIAN_RECORDS', 'action' => 'UPDATE', 'data_before' => '', 'data_after' => 'NAME ISSUE RESOLVED']);
			$this->cogcIssueModel->markResolved($item['id'], 'NAME');
			$this->session->setFlashdata('message', 'Correct name setting completed'); 
            $this->session->setFlashdata('messageTitle', 'Name set');
            return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$item['id']); 

		}
		if($item['type']=='POLICE') {
			$this->cogcIssueModel->markResolved($item['id'], 'POLICE');
			$this->auditLogModel->insert(['user_id'=>$_SESSION['user_id'], 'data_id' => $item['id'], 'section' => 'CIVILIAN_RECORDS', 'action' => 'UPDATE', 'data_before' => '', 'data_after' => 'POLICE ISSUE RESOLVED']);
			$this->session->setFlashdata('message', 'Police check completed'); 
            $this->session->setFlashdata('messageTitle', 'Police matters cleared');
            return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$item['id']);
		}
		
		if($item['type']=='CRIMINAL') {
			$this->cogcIssueModel->markResolved($item['id'], 'CRIMINAL');
			$this->auditLogModel->insert(['user_id'=>$_SESSION['user_id'], 'data_id' => $item['id'], 'section' => 'CIVILIAN_RECORDS', 'action' => 'UPDATE', 'data_before' => '', 'data_after' => 'POLICE ISSUE RESOLVED']);
			$this->session->setFlashdata('message', 'Criminal issue marked as completed'); 
            $this->session->setFlashdata('messageTitle', 'Criminal record completed');
            return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$item['id']);
		}
		
	}
	
	function queue_reject()
	{
		$cogc=$this->cogcModel->getByUuid($this->request->getVar('uuid'));
		if(!$cogc) {
			$this->session->setFlashdata('errorMessage', 'Unknown record'); 
            $this->session->setFlashdata('errorTitle', 'Unknown record'); 
			return redirect()->to('/frontend/subject_records/civilian/queue');
		}
		$this->cogcModel->update($cogc['id'], ['status' => 'REJECTED', 'adverse_police_notice' => $this->request->getVar('adverse_police_notice'), ]);
		$this->auditLogModel->insert(['user_id'=>$_SESSION['user_id'], 'data_id' => $cogc['id'], 'section' => 'CIVILIAN_RECORDS', 'action' => 'UPDATE', 'data_before' => json_encode(['first_name' => $cogc['first_name'], 'middle_name' => $cogc['middle_name'], 'last_name' => $cogc['last_name']]), 'data_after' => json_encode(['status' => 'REJECTED', 'adverse_police_notice' => $this->request->getVar('adverse_police_notice')])]);
		$this->session->setFlashdata('message', 'Application rejected'); 
		$this->session->setFlashdata('messageTitle', 'Application rejected');
		return redirect()->to('/frontend/subject_records/civilian/queue'); 
	}
	
	//Sends email with certificate of good conduct
	public function emailCOGC($id)
	{	
		$record=$this->cogcModel->find($id);
		$cogc_pdf=file_get_contents(base_url('/pub/forms/cogc/'.$record['uuid']));
		$file = tmpfile();
		fwrite($file, $cogc_pdf);
		$path = stream_get_meta_data($file)['uri'];
		if($record['email']) {
			$email = new Email();
			$response=$email->send($record['email'], 'Certificate of Good Conduct', 'Please find attached a copy of your Certificate of Good Conduct',NULL, $path, 'Certificate_of_Good_Conduct.pdf');
			if($response==true) {
				$this->session->setFlashdata('message', 'Certificate of Good Conduct sent to '.$record['email']); 
				$this->session->setFlashdata('messageTitle', 'Email sent'); 
				return redirect()->to('frontend/subject_records/civilian/view/'.$id);
			} else {
				$this->session->setFlashdata('errorMessage', 'Please contact administrator, failed to send email'); 
				$this->session->setFlashdata('errorTitle', 'Error sending email'); 
				return redirect()->to('frontend/subject_records/civilian/view/'.$id);
			}
				
		} else {
			$this->session->setFlashdata('errorMessage', 'No email saved for this entry'); 
			$this->session->setFlashdata('errorTitle', 'Error: Missing email'); 
			return redirect()->to('frontend/subject_records/civilian/view/'.$id);
		}
	}
	
	public function edit($id)
	{
		$data=[];
		$data['record']=$this->subjectRecordModel->find($id);
		$data['edit_subject_record']=1;

		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['record']['subject_name']=$subject['name'];
		$data['record']['case_tracking_person_id']=$subject['case_tracking_person_id'];
		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') {
				$options=$this->controllerModel->getFieldOptions($data['fields'][$n]['id']);
				if($options) {
					$data['fields'][$n]['options']=$options;
				} else {
					$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
				}
			}
		}
		
		return view('header', $data)
			. view('menu', $data)
			. view('edit_subject_record', $data)
			. view('footer', $data);
	}
	
	public function add()
	{
		$data=[];
		$data['edit_subject_record']=1;
		$data['record']=[];
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') { //Field options will either be self contained in the field or looked up
				$options=$this->controllerModel->getFieldOptions($data['fields'][$n]['id']);
				if($options) {
					$data['fields'][$n]['options']=$options;
				} else {
					$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
				}
			}
		}
		//Empty the value of the fields
		foreach ($data['fields'] as $field) {
			$data['record'][$field['db_name']] = null;
		}
		$data['record']['sentence_type']=$data['record']['sentence_units']=$data['record']['sentence_amount']=null;
		
		return view('header', $data)
			. view('menu', $data)
			. view('edit_subject_record', $data)
			. view('footer', $data);
	}
}

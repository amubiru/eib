<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use \setasign\Fpdi\Fpdf;
use \setasign\Fpdi\Fpdi;
use \chillerlan\QRCode\QRCode;

class SubjectRecordsController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $auditLogModel;
	protected $subjectRecordModel;
	protected $subjectModel;
	protected $cogcModel;
	protected $cogcIssueModel;
	protected $policeOfficerModel;
	protected $psoModel;
	protected $crudModel;
	protected $driverModel;
	protected $controllerModel;
	protected $attachmentModel;
	protected $controllerName;
	protected $methodName;


	public function initController(\CodeIgniter\HTTP\RequestInterface $request, \CodeIgniter\HTTP\ResponseInterface $response, \Psr\Log\LoggerInterface $logger)
    {
        // Do Not Edit This Line
        parent::initController($request, $response, $logger);

        $router = service('router');
		$this->controllerName  = str_replace('\\App\\Controllers\\', '', $router->controllerName());
		$this->methodName = $router->methodName();
	}

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->auditLogModel = model('App\Models\AuditLogModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->policeOfficerModel = model('App\Models\policeOfficerModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->psoModel = model('App\Models\PSOModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->controllerModel = model('App\Models\ControllerModel');
		$this->attachmentModel = model('App\Models\AttachmentModel');
		$this->auditLogModel = model('App\Models\AuditLogModel');
		$this->crudModel = model('App\Models\CrudModel');
	}
	
	//Print out the fingerprint form
	function form20($id) 
	{
		$data=[];
		$cabis=new CABIS();
		$subject=$this->subjectModel->getByCabisId($id);

		$pdf = new Fpdi();

		$pdf->AddPage(); 

		$pdf->setSourceFile(__DIR__.'/../../../images/Form20.pdf'); 
		// import page 1 
		$this->tplIdx = $pdf->importPage(1); 
		//use the imported page and place it at point 0,0; calculate width and height
		//automaticallay and adjust the page size to the size of the imported page 
		$pdf->useTemplate($this->tplIdx, 0, 0, 850, 1100, true); 

		// now write some text above the imported page 
		$pdf->SetFont('Helvetica', 'B', '30'); 
		$pdf->SetTextColor(0,0,0);
		$text_size=30;
		//Print text elements
		$name=$cabis->getTag($id, 111)." ".$cabis->getTag($id, 110);
		$pdf->SetXY(300, 153);
		$pdf->SetFont('Arial', '', $text_size);
		$pdf->Write(20, $name);
		//Output images
		//Photograph
		//Check if images exist
		if(file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag=705'))) {
			$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag=705'), 50,45,100,0,'PNG');
		
			//Fingerprints
			$xpos=20;
			$xoffset=167;
			
			foreach ([RTHUMB,RINDEX,RMIDDLE,RRING,RLITTLE] as $finger) {
				$finger_image=file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.$finger));
				$file = tmpfile();
				fwrite($file, $finger_image);
				$path = stream_get_meta_data($file)['uri'];
				if(strlen($finger_image)> 100 && exif_imagetype($path)) {
					$pdf->Image($path, $xpos,220,100,0,'PNG');
				} else {
					log_message('error', "CABIS $id, tag $finger: Invalid image");
				} 
				$xpos+=$xoffset;
			}
			
			$xpos=20;
			foreach ([LTHUMB,LINDEX,LMIDDLE,LRING,LLITTLE] as $finger) {
				$image_url=base_url('ajax/get_cabis?id='.$id.'&tag='.$finger);
				if(strlen(file_get_contents($image_url)) > 100) {
					$pdf->Image($image_url, $xpos,380, 100,0,'PNG');
				}
				$xpos+=$xoffset;
			}
			//Four fingers
			if(strlen(file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.LFOURFINGERS))) > 100) {
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.LFOURFINGERS), 70,560,180,0,'PNG');
			}
			if(strlen(file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.RFOURFINGERS))) > 100) {
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.RFOURFINGERS), 470,560,180,0,'PNG');
			}
			
			
			
			$upper_palm=file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.LUPPERPALM));
			if(strlen($upper_palm)) {
				//Create second page for palm prints
				$pdf->AddPage('P', [850,1100]);
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.LUPPERPALM), 70,100,300,0,'PNG');
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.RUPPERPALM), 450,100,300,0,'PNG');
			}
			//Not used by CABIS
			//$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.LLOWERPALM), 70,550,300,0,'PNG');
			//$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.RLOWERPALM), 450,550,300,0,'PNG');
		}
		
		$this->response->setHeader('Content-Type', 'application/pdf');
		$pdf->Output();
	}
	
	
	function interpol($id) 
	{
		$data=[];
		$cabis=new CABIS();

		$pdf = new Fpdi();

		$pdf->AddPage(); 

		$pdf->setSourceFile(__DIR__.'/../../../images/finger_print_v1.pdf'); 
		// import page 1 
		$this->tplIdx = $pdf->importPage(1); 
		//use the imported page and place it at point 0,0; calculate width and height
		//automaticallay and adjust the page size to the size of the imported page 
		$pdf->useTemplate($this->tplIdx, 0, 0, 827, 1169, true); 

		// now write some text above the imported page 
		$pdf->SetFont('Helvetica', 'B', '30'); 
		$pdf->SetTextColor(0,0,0);
		$text_size=30;
		//Print text elements
		$name=$cabis->getTag($id, FirstName)." ".$cabis->getTag($id, LastName);
		$pdf->SetXY(214, 140);
		$pdf->SetFont('Arial', '', $text_size);
		$pdf->Write(20, $cabis->getTag($id, LastName));
		$pdf->SetXY(214, 177);
		$pdf->Write(20, $cabis->getTag($id, FirstName));
		//Output images
		//Photograph
		//Check if images exist
		if(file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag=705'))) {
			$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag=705'), 595,110,100,0,'PNG');
		
			//Fingerprints
			$xpos=67;
			$xoffset=150;
			
			foreach ([RTHUMB,RINDEX,RMIDDLE,RRING,RLITTLE] as $finger) {
				$finger_image=file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.$finger));
				$file = tmpfile();
				fwrite($file, $finger_image);
				$path = stream_get_meta_data($file)['uri'];
				if(strlen($finger_image)> 100 && exif_imagetype($path)) {
					$pdf->Image($path, $xpos,465,125,0,'PNG');
				} else {
					log_message('error', "CABIS $id, tag $finger: Invalid image");
				} 
				$xpos+=$xoffset;
			}
		
			$xpos=67;
			foreach ([LTHUMB,LINDEX,LMIDDLE,LRING,LLITTLE] as $finger) {
				$image_url=base_url('ajax/get_cabis?id='.$id.'&tag='.$finger);
				if(strlen(file_get_contents($image_url)) > 100) {
					$pdf->Image($image_url, $xpos,655, 125,0,'PNG');
				}
				$xpos+=$xoffset;
			}
			//Four fingers
			if(strlen(file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.LFOURFINGERS))) > 100) {
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.LFOURFINGERS), 50,876,220,0,'PNG');
			}
			if(strlen(file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.RFOURFINGERS))) > 100) {
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.RFOURFINGERS), 540,876,220,0,'PNG');
			}
			
			
			
			$upper_palm=file_get_contents(base_url('ajax/get_cabis?id='.$id.'&tag='.LUPPERPALM));
			if(strlen($upper_palm)) {
				//Create second page for palm prints
				$pdf->AddPage('P', [827, 1169]);
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.LUPPERPALM), 70,100,300,0,'PNG');
				$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.RUPPERPALM), 450,100,300,0,'PNG');
			}
			//Not used by CABIS
			//$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.LLOWERPALM), 70,550,300,0,'PNG');
			//$pdf->Image(base_url('ajax/get_cabis?id='.$id.'&tag='.RLOWERPALM), 450,550,300,0,'PNG');
		}
		
		$this->response->setHeader('Content-Type', 'application/pdf');
		$pdf->Output();
	}
	
	//Print out the fingerprint form
	function form45a($id) 
	{
		$data=[];
		$cabis=new CABIS();
		$subjectRecord=$this->subjectRecordModel->getByCabisId($id);
		$subject=$this->subjectModel->find($subjectRecord['subject_id']);
		$criminal = $this->subjectRecordModel->getRelated($subject['cabis_id'], $subject['nin']);
		$pdf = new Fpdi();

		$pdf->AddPage(); 

		$pdf->setSourceFile(__DIR__.'/../../../images/Form45a.pdf'); 
		// import page 1 
		$this->tplIdx = $pdf->importPage(1); 
		//use the imported page and place it at point 0,0; calculate width and height
		//automaticallay and adjust the page size to the size of the imported page 
		$pdf->useTemplate($this->tplIdx, 0, 0, 1169, 827, true); 

		// now write some text above the imported page 
		$pdf->SetFont('Helvetica', 'B', '30'); 
		$pdf->SetTextColor(0,0,0);
		$text_size=30;
		//Print text elements
		//CABIS ID
		$pdf->SetXY(153, 141);
		$pdf->Write(20, $subject['cabis_id']);
		$pdf->SetXY(987, 116);
		$date=("m jS");
		$pdf->Write(20, $date);
		$pdf->SetXY(1094, 116);
		$date=("Y");
		$pdf->Write(20, $date);
		if(strlen($subject_record['crb_no'] ?? '')) {
			$pdf->SetXY(1094, 116);
			$pdf->Write(20, $date);
		}
		$pdf->SetXY(384, 188);
		$name=$cabis->getTag($id, 111)." ".$cabis->getTag($id, 110);
		$pdf->Write(20, $name);
		$pdf->SetXY(441, 210);
		$pdf->Write(20, $$subject_record['offence']);
		$pdf->SetXY(480, 234);
		if(strlen($subject_record['crb_no'] ?? '')) {
			$pdf->Write(20, $$subject_record['crb_no']);
		}
		$start=348;
		$line=0;
		$offset=15;
		foreach($criminal as $record) {
			if($record['id'] == $id) {
				continue;
			}
			switch ($record['sentence_type']) {
				case 'NOT SENTENCED YET':
					$record['sentence']="Not sentenced yet";
					break;
				case 'PRISON':
					$record['sentence']='Imprisonment for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'PROBATION':
					$record['sentence']='Probation for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'COMMUNITY SERVICE':
					$record['sentence']='Community service for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'FINE':
					$record['sentence']='Fined UGX '.$record['sentence_amount'];
					break;
				default:
					$record['sentence']=" - ";
			}
			$pdf->SetXY(60, $start+$offset*$line);
			$pdf->Write(20, $subject_record['court_place_trial'] ?? '');
			$pdf->SetXY(204, $start+$offset*$line);
			$pdf->Write(20, $subject_record['date_sentence'] ?? '');
			$pdf->SetXY(402, $start+$offset*$line);
			$pdf->Write(20, $subject_record['sentence'] ?? '');
			$pdf->SetXY(594, $start+$offset*$line);
			$pdf->Write(20, $subject_record['offence'] ?? '');
			$pdf->SetXY(879, $start+$offset*$line);
			$pdf->Write(20, $subject_record['name'] ?? '');
		}
		$this->response->setHeader('Content-Type', 'application/pdf');
		$pdf->Output();
	}

	function image($id) {
		$record=$this->subjectRecordModel->find($id);
		return $this->response->setHeader("Content-Type", $record['scan_type'])
		->setBody(base64_decode($record['scan_file']));
	}
	
	//Fill in details needed to fill in Police Certificate of Good Conduct
	public function generatePCC($id)
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other requests should keep running
		if($this->request->getVar('type')=='civilian') {
			$data['civilian_id']=$id;
			$cogc=$this->cogcModel->find($id);
			$subject=$this->subjectModel->find($cogc['subject_id']);
			$sr=$this->subjectRecordModel->getBySubjectID($subject['id']);
		} else {
			$subject=$this->subjectModel->getById($id);
		}
		$data['subject']=$subject;
		$data['subject']['id_number']=$cogc['id_number'];
		$data['subject']['prn']=$cogc['prn'];
		$data['subject']['first_name']=$cogc['first_name'];
		$data['subject']['email']=$cogc['email'];
		$data['subject']['last_name']=$cogc['last_name'];
		$data['subject']['photo']=file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705'));
		$data['subject']['force_number']=file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=3321')) ?? '';
		if($this->request->getVar('source')=='queue') {
			$data['source']='queue';
		}
		$data['type']=$this->request->getVar('type');
		$data['offenses']=$this->subjectRecordModel->getBySubjectId($subject['id'], 'PERMANENT');
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/generate_pcc', $data)
			. view('footer', $data);
		
	}
	
		//Return a completed record back to the queue
		public function requeue($id)
		{
		$data=[];
		$record=$this->cogcModel->find($id);
		$this->cogcModel->update($id, ['status' => 'QUEUE']);
		return redirect()->to('/frontend/subject_records/civilian/queue_view/'.$id);
		}
	
		public function emailPCC($id)
		{
		$data=[];
		$cabis=new CABIS();
		$barcode = new \Picqer\Barcode\BarcodeGeneratorPNG();

		$record=$this->cogcModel->find($id);
		$subject=$this->subjectModel->getById($record['subject_id']);
		$cogcs=$this->cogcModel->getBySubjectId($subject['id']);
		$cogc=end($cogcs);
		$cdata=json_decode($cogc['raw_content'], true);
		//Get all matching CABIS IDs
		$cabis_ids[]=$subject['cabis_id'];
		$cabis_records = $cabis->getMatchingCandidates($subject['cabis_id'], false);
		foreach($cabis_records as $rec) {
			$cabis_ids[]=$rec['cabis_id'];
		}
		$cabis_ids=array_unique($cabis_ids);
		
		//Load offenses since we have all the CABIS Ids
		$subjectRecords=$data['offenses']= $this->subjectRecordModel->getByCabisIds($cabis_ids);

		$subjectRecord=[];
		if(count($subjectRecords)) {
			$subjectRecord=$subjectRecords[0];
		}
		if(count($subjectRecord)) {
			switch ($subjectRecord['case_result']) {
				case 'NOT SENTENCED YET':
					$subjectRecord['result']="Not sentenced yet";
					break;
				case 'ACQUITTED':
					$subjectRecord['result']="Acquitted";
					break;
				case 'DISMISSED':
					$subjectRecord['result']="Dismissed";
					break;
				case 'SENTENCED':
					switch($subjectRecord['sentence_type']) {
						case 'CUSTODIAL':
							$subjectRecord['result']='Imprisonment for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
						break;
						case 'NON CUSTODIAL':
						switch($subjectRecord['non_custodial_sentence']) {
							case 'CAUTION':
								$subjectRecord['result']='Caution';
								break;
							case 'COMMUNITY SERVICE':
								$subjectRecord['result']='Community service for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
								break;
							case 'FINE':
								$subjectRecord['result']='Fined UGX '.$subjectRecord['sentence_amount'];
								break;
						}
						break;
					}
					break;
				default:
					$subjectRecord['result']=" - ";
			}
		}
		$record['subject_id']=$subject['cabis_id'];
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');

		$pdf = new Fpdi();

		$pdf->AddPage(); 

		$pdf->setSourceFile(__DIR__.'/../../../images/PF83.pdf'); 
		// import page 1 
		$this->tplIdx = $pdf->importPage(1); 
		//use the imported page and place it at point 0,0; calculate width and height
		//automaticallay and adjust the page size to the size of the imported page 
		$pdf->useTemplate($this->tplIdx, 0, 0, 827, 1169, true); 

		// now write some text above the imported page 
		$pdf->SetFont('Times', 'B', '40'); 
		$pdf->SetTextColor(0,0,0);
		//Text below barcode
		$yoff=90;
		$xoff=123;
		$pdf->SetXY($xoff, $yoff);
		$pdf->SetFont('Arial', 'B', '35'); 
		$pdf->Write(10,  $cabis->getTag($subject['cabis_id'], NewGroupId));
		
		$text_size='55';
		$line_height=30;	
		$pdf->SetLeftMargin(80);
		$pdf->SetRightMargin(80);
		$yoff=335;
		$xoff=142;
		$pdf->SetXY($xoff, $yoff);
		$pdf->SetTextColor(255,0,0);
		//If no PCC time, use fingerprinting date
		$date_info=date('W ', strtotime($cogc['pcc_time'] ?? $cabis->getTag($subject['cabis_id'], Date))).(date('z', strtotime($cogc['pcc_time']) ?? $cabis->getTag($subject['cabis_id'], Date))+1);
		$pdf->AddFont('Typewriter','B','typewriter-bold.php');
		$pdf->SetFont('Typewriter', 'B', '50'); 
		$pdf->Write(10, 'DFS/CI/'.$date_info.'/'.sprintf("%04d", $cogc['day_counter'] ?? 1));
		$xoff=240;
		$pdf->SetFont('Times', 'BI', '40'); 
		$pdf->SetTextColor(0,0,0);
		$pdf->SetXY($xoff, $yoff);
		$pdf->MultiCell(0, 1, date("D j, F Y"),0,'R');
		//$pdf->Write(10, date("d F, Y", strtotime($cabis->getTag($subject['cabis_id'], Date))));
		$name=$record['first_name']." ";
		$middle_name=$record['middle_name'];
		if(strlen($middle_name ?? '')) {
			$name.=$middle_name." ";
		}
		$name.=$record['last_name'];
		$pdf->SetFont('Times', 'BI', $text_size);
		$name_length=$pdf->GetStringWidth($name);
		$xoff=(827-$name_length)/2;
		$yoff=435;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $name);
		$xoff=387;
		$yoff=525;
		$pdf->SetXY($xoff, $yoff);
		if(strlen(trim($cdata['PassportNo'] ?? ''))>4) {
			$doc_number=$cdata['PassportNo'];
		} else {
			$doc_number=$cdata['RefugeeCardNo'];
		}
 		$pdf->Write($line_height, $doc_number);
		$dob_only=explode(' ', $cdata['DOB']);
		$xoff=602;
		$yoff=525;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $dob_only[0]);
		$xoff=263;
		$yoff=571;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $cdata['NIN']);
		$pdf->SetXY(449, 1075);
		$pdf->MultiCell(0, 1, 'Andrew K. Mubiru', 0, 'C');
		
		$xoff=235;
		$yoff=658;
		$pdf->SetFont('Times', 'BI', 45);
		$pdf->SetXY($xoff, $yoff);
		//Offense
		//Generate extra text
		if(count($subjectRecords) == 0) {
			$pdf->Write($line_height, 'NIL');
			$yoff=772;
			$pdf->SetXY($xoff, $yoff);
			//Result of case trial
			$pdf->Write($line_height, 'NIL');
			$yoff=833;
			$pdf->SetXY($xoff, $yoff);
			$pdf->Write($line_height, 'NIL');			
		} elseif(count($subjectRecords) == 1) {
			if(strlen($subjectRecord['crb_no']) && strlen($subjectRecord['station'])) {
				$extra_text=" vide ".$subjectRecord['station'].', '.$subjectRecord['crb_no'];
			} elseif(strlen($subjectRecord['crb_no'])) {
				$extra_text=" vide ".$subjectRecord['crb_no'];
			} elseif(strlen($subjectRecord['station'])) {
				$extra_text=" vide ".$subjectRecord['station'];
			} else {
				$extra_text='';
			}
				
			$pdf->Write($line_height, ($subjectRecord['offence'].$extra_text) ?? 'NIL');
			$yoff=772;
			$pdf->SetXY($xoff, $yoff);
			//Result of case trial
			$pdf->Write($line_height, $subjectRecord['remarks'] ?? 'NIL');
			$yoff=833;
			$pdf->SetXY($xoff, $yoff);
			//Date of sentence
			
			if(count($subjectRecord)) {
				if(strtotime($subjectRecord['date_sentence'])>strtotime('1940-01-01')) {
					$pdf->Write($line_height, date('m/d/Y', strtotime($subjectRecord['date_sentence'])));
				}
			}
		} elseif(count($subjectRecords) > 1) {
			$pdf->Write($line_height, 'See overleaf');
		}
		$yoff=897;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $record['adverse_police_notice'] ?? 'NIL');
		
		$pdf->SetFont('Times', 'I', '30');
		$pdf->SetXY(90, 1102);
		if(strtotime('2025-01-07') > strtotime($cabis->getTag($subject['cabis_id'], Date))) {
			$seq='001';
		} else {
			$seq='002';
		}
		$pdf->Write($line_height, 'eiB/DFS'.$seq.'/'.sprintf("%07d", $cogc['total_counter'] ?? 1).date("/m/d/Y", strtotime($cabis->getTag($subject['cabis_id'], Date) ?? date('Y-m-d'))));
		//$pdf->SetXY(190, 1102); 
		//$pdf->Write($line_height, date("/m/d/Y", strtotime($cabis->getTag($subject['cabis_id'], Date) ?? date('Y-m-d'))));

		//Output images
		//Photograph
		if(file_get_contents(base_url('ajax/get_cabis?id='.$record['subject_id'].'&tag=705'))) {
			$pdf->Image(base_url('ajax/get_cabis?id='.$record['subject_id'].'&tag=705'), 340,153,140,0,'PNG');
		}
		$qrCode=new QRCode();
		$pdf->Image($qrCode->render("https://upf.go.ug/public/verify-certificate/".$cogc['uuid']), 80,1010,100,0,'PNG');
		//$pdf->Image($qrCode->render(base_url('/pub/forms/cogc/'.$record['id'])), 80,960,100,0,'PNG');
		
		//Signature
		$pdf->Image(__DIR__.'/../../../images/director_signature.png', 510,980,260,0,'PNG');
		
		//Barcodes
		//Group ID Barcode
		$barcode_file=tmpfile();
		fwrite($barcode_file, $barcode->getBarcode($cabis->getTag($subject['cabis_id'], NewGroupId), $barcode::TYPE_CODE_128));
		$file_name=stream_get_meta_data($barcode_file)['uri'];
		$pdf->Image($file_name, 65,53,170,0,'PNG');
		
		//PRN barcode
		$barcode_file=tmpfile();
		fwrite($barcode_file, $barcode->getBarcode($cogc['prn'], $barcode::TYPE_CODE_128));
		$file_name=stream_get_meta_data($barcode_file)['uri'];
		$pdf->Image($file_name, 207,1075,170,0,'PNG');
		
		//If we have multiple offenses, show them on a second page
		if(count($subjectRecords) >1) {
			//Add Second page
			$pdf->AddPage('L', [827,1169]); 

			$date_pos=60;
			$offense_pos=150;
			$result_pos=600;
			$remark_pos=800;
			$xoff=20;
			$yoff=60;
			$pdf->SetFont('Times', 'B', 45);
			$pdf->SetXY($date_pos, $yoff);
			$pdf->Write($line_height, 'DATE');
			$pdf->SetXY($offense_pos, $yoff);
			$pdf->Write($line_height, 'OFFENSE');
			$pdf->SetXY($result_pos, $yoff);
			$pdf->Write($line_height, 'CASE RESULT');
			//$pdf->SetXY($remark_pos, $yoff);
			//$pdf->Write($line_height, 'REMARKS');
			$yoff+=40;
			$pdf->SetFont('Times', 'BI', 45);
			foreach($subjectRecords as $subjectRecord) {
				$pdf->SetXY($date_pos, $yoff);
				if(strtotime($subjectRecord['date_sentence'] ?? '') >strtotime('1940-01-01')) {
					$pdf->Write($line_height, date('m/d/Y', strtotime($subjectRecord['date_sentence'] ?? '')));
				}
				if(strlen($subjectRecord['crb_no']) && strlen($subjectRecord['station'])) {
					$extra_text=" vide ".$subjectRecord['crb_no'].', '.$subjectRecord['station'];
				} elseif(strlen($subjectRecord['crb_no'])) {
					$extra_text=" vide ".$subjectRecord['crb_no'];
				} elseif(strlen($subjectRecord['station'])) {
					$extra_text=" vide ".$subjectRecord['station'];
				} else {
					$extra_text='';
				}
				$pdf->SetXY($offense_pos, $yoff);
				$pdf->MultiCell($result_pos-$offense_pos-10,$line_height, ($subjectRecord['offence'].$extra_text) ?? 'NIL');
				$offense_height = $pdf->GetY() - $yoff;
				switch ($subjectRecord['case_result']) {
					case 'NOT SENTENCED YET':
						$subjectRecord['result']="Not sentenced yet";
						break;
					case 'ACQUITTED':
						$subjectRecord['result']="Acquitted";
						break;
					case 'DISMISSED':
						$subjectRecord['result']="Dismissed";
						break;
					case 'SENTENCED':
						switch($subjectRecord['sentence_type']) {
							case 'CUSTODIAL':
								$subjectRecord['result']='Imprisonment for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
							break;
							case 'NON CUSTODIAL':
							switch($subjectRecord['non_custodial_sentence']) {
								case 'CAUTION':
									$subjectRecord['result']='Caution';
									break;
								case 'COMMUNITY SERVICE':
									$subjectRecord['result']='Community service for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
									break;
								case 'FINE':
									$subjectRecord['result']='Fined UGX '.$subjectRecord['sentence_amount'];
									break;
							}
							break;
						}
						break;
					default:
						$subjectRecord['result']=" - ";
				}
				$pdf->SetXY($result_pos, $yoff);
				$pdf->MultiCell(500, $line_height, $subjectRecord['remarks']);
				$result_height = $pdf->GetY() - $yoff;
				$pdf->SetXY($remark_pos, $yoff);
				//$pdf->MultiCell(200, $line_height, $subjectRecord['remarks'] ?? '-');
				//$remark_height = $pdf->GetY() - $yoff;
				if($result_height>$offense_height) {
					$height=$result_height;
				} else {
					$height=$offense_height;
				}
				//if($remark_height>$height) {
				//	$height=$remark_height;
				//}
				$yoff=$yoff+$height+40; 
			}
		}
		$this->response->setHeader('Content-Type', 'application/pdf');
		$pdf->Output('I', 'PCC.PDF');
	}
	
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if(!$this->request->getVar('subject_id') || !$this->request->getVar('name') || !$this->request->getVar('offence')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('frontend/subject_records');
		}
		
		//Does this subject have an existing subject_id
		$subject=$this->subjectModel->getByCabisId($this->request->getVar('subject_id'));
		if($subject) {
			$subject_id=$subject['id'];
		} else {
			$subject_id=$this->subjectModel->create(['name' => $this->request->getVar('name'), 'cabis_id' => $this->request->getVar('subject_id'), 'case_tracking_person_id' => $this->request->getVar('case_tracking_person_id')]);
		}
		
		
		//Setup the proper sentence_amount
		if($this->request->getVar('sentence_type') == 'FINE') {
			$sentence_units='CURRENCY';
			$sentence_amount=$this->request->getVar('fine_amount');
		} else {
			$sentence_units=$this->request->getVar('sentence_units');
			$sentence_amount=$this->request->getVar('sentence_amount');
		}
		
		//All good add, the record
		$db_data=['subject_id' => $subject_id, 'court_place_trial' => $this->request->getVar('court_place_trial'), 'offence' => $this->request->getVar('offence'),  'sentence_type' => $this->request->getVar('sentence_type'), 'sentence_units' => $sentence_units, 'sentence_amount' => $sentence_amount,  'date_sentence' => $this->request->getVar('date_sentence'),  'remarks' => $this->request->getVar('remarks'),  'name' => $this->request->getVar('name'), 'station' => $this->request->getVar('station'), 'crb_no' => $this->request->getVar('crb_no'), 'date_arrest' => $this->request->getVar('date_arrest'), 'father' => $this->request->getVar('father'), 'aliases' => $this->request->getVar('aliases'), 'court_case_number' => $this->request->getVar('court_case_number'), 'officer_in_charge' => $this->request->getVar('officer_in_charge'), 'case_tracking_id' => $this->request->getVar('case_tracking_id'), 'source' => $this->request->getVar('source'), 'aliases' => $this->request->getVar('aliases')];
	
		
		if(!$this->request->getVar('id')) {
			//Don't create if it's a duplicate
			if($this->subjectRecordModel->isDuplicate($db_data['subject_id'], $db_data['offence'])) {
				$this->session->setFlashdata('errorMessage', 'Record is a duplicate'); 
				$this->session->setFlashdata('errorTitle', 'Duplicate record ignored'); 
				return redirect()->to('frontend/subject_records/');
			}
			$record_id=$this->subjectRecordModel->create($db_data);
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $record_id, 'section' => 'CRIMINAL RECORDS', 'action' => 'CREATE', 'data_before' => '', 'data_after' => json_encode($audit_data)]);
		} else {
			$record_id=$this->request->getVar('id');
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$before_data=$this->subjectRecordModel->find($this->request->getVar('id'));
			$subject=$this->subjectModel->find($db_data['subject_id']);
			$before_data['subject_id']=$subject['cabis_id'];
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $this->request->getVar('id'), 'section' => 'SUBJECT RECORDS', 'action' => 'UPDATE', 'data_before' => json_encode($before_data), 'data_after' => json_encode($audit_data)]);
			$this->subjectRecordModel->update($this->request->getVar('id'), $db_data);
		}
		$this->session->setFlashdata('message', 'Record saved for '.$this->request->getVar('name')); 
		$this->session->setFlashdata('messageTitle', 'Record saved'); 
		return redirect()->to('frontend/subject_records/view/'.$record_id);
	}

	
	public function index()
	{
		$data=[];
		$cr_data=$this->subjectRecordModel->findAll();
		$data['records']=[];
		$cr_data=[];
		foreach($cr_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$record['attachments'] = $this->attachmentModel->retrieve('subject_record', $record['id']);
			
			switch ($record['sentence_type']) {
				case 'NOT SENTENCED YET':
					$record['sentence']="Not sentenced yet";
					break;
				case 'PRISON':
					$record['sentence']='Imprisonment for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'PROBATION':
					$record['sentence']='Probation for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'COMMUNITY SERVICE':
					$record['sentence']='Community service for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'FINE':
					$record['sentence']='Fined UGX '.$record['sentence_amount'];
					break;
				default:
					$record['sentence']=" - ";
			}
			$data['records'][]=$record;
		}
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') {
				$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
			}
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('subject_records', $data)
			. view('footer', $data);
	}
	
	public function attachmentSubmit()
	{
		$attachment = $this->request->getFile('attachment');
		if($attachment->isValid()) {
			$type=$attachment->getMimeType();
			$filepath = WRITEPATH . 'uploads/' . $attachment->store();
			$file_content=file_get_contents($filepath);
			$post_data=['subject_id' => $this->request->getVar('subject_id'), 'link_id' => $this->request->getVar('link_id'), 'type' => $this->request->getVar('type'), 'name' => $this->request->getVar('name'), 'description' => $this->request->getVar('description'), 'file_type' => $type, 'file_content' => base64_encode($file_content)];
			$this->attachmentModel->insert($post_data);
		}
		return redirect()->to($this->request->getVar('last_url'));
	}
	
		public function search()
	{
		$data=[];
		$cr_data=$this->subjectRecordModel->search(['subject_id' => $this->request->getVar('subject_id'), 'crb_no' => $this->request->getVar('crb_no'), 'name' => $this->request->getVar('name'), 'station' => $this->request->getVar('station'), 'type' => $this->request->getVar('type'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($cr_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$record['attachments'] = $this->attachmentModel->retrieve('subject_record', $record['id']);
			switch ($record['sentence_type']) {
				case 'NOT SENTENCED YET':
					$record['sentence']="Not sentenced yet";
					break;
				case 'PRISON':
					$record['sentence']='Imprisonment for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'COMMUNITY SERVICE':
					$record['sentence']='Community service for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'PROBATION':
					$record['sentence']='Probation for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'FINE':
					$record['sentence']='Fined UGX '.$record['sentence_amount'];
					break;
				default:
					$record['sentence']=" - ";
			}
			$data['records'][]=$record;
		}
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('subject_records', $data)
			. view('footer', $data);
	}
	
	public function view($id)
	{
		$data=[];
		$data['record']=$this->subjectRecordModel->find($id);
		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['record']['case_tracking_person_id']=$subject['case_tracking_person_id'];
		$data['record']['subject_name']=$subject['name'];
		if($data['record']['case_tracking_id']) {
			$data['record']['case']=null;
			$ct = new CaseTracking();
			$data=$this->cache->get('CASETRACKING_'.'Case'.'_'.$data['record']['case_tracking_id']);
			if($data == false) {
				$data=$ct->query(['query' => ['type' => 'Case', 'id' => $data['record']['case_tracking_id']]]);
				if($data) {
					$this->cache->save('CASETRACKING_'.'Case'.'_'.$data['record']['case_tracking_id'], $data, MONTH);
					$data['record']['case']=$data[0];
				}
			} else {
				$data['record']['case']=$data[0];
			}
		}

		switch ($data['record']['sentence_type']) {
				case 'NOT SENTENCED YET':
					$data['record']['sentence']="Not sentenced yet";
					break;
				case 'PRISON':
					$data['record']['sentence']='Imprisonment for '." ".counted($data['record']['sentence_amount'], strtolower($data['record']['sentence_units']));
					break;
				case 'COMMUNITY SERVICE':
					$data['record']['sentence']='Community service for '." ".counted($data['record']['sentence_amount'], strtolower($data['record']['sentence_units']));
					break;
				case 'PROBATION':
					$data['record']['sentence']='Probation for '." ".counted($data['record']['sentence_amount'], strtolower($data['record']['sentence_units']));
					break;
				case 'FINE':
					$data['record']['sentence']='Fined UGX '.$data['record']['sentence_amount'];
					break;
				default:
					$data['record']['sentence']=" - ";
			}
		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		$data['attachments'] = $this->attachmentModel->retrieve('subject_record', $id);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') {
				$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
			}
		}
		
		return view('header', $data)
			. view('menu', $data)
			. view('subject_record', $data)
			. view('footer', $data);
	}
	
	public function edit($id)
	{
		$data=[];
		$data['record']=$this->subjectRecordModel->find($id);
		$data['edit_subject_record']=1;

		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['record']['subject_name']=$subject['name'];
		$data['record']['case_tracking_person_id']=$subject['case_tracking_person_id'];
		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') {
				$options=$this->controllerModel->getFieldOptions($data['fields'][$n]['id']);
				if($options) {
					$data['fields'][$n]['options']=$options;
				} else {
					$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
				}
			}
		}
		
		return view('header', $data)
			. view('menu', $data)
			. view('edit_subject_record', $data)
			. view('footer', $data);
	}
	
	public function attachmentAdd()
	{
		$data=[];
		$data['link_id']=$this->request->getVar('link_id');
		$data['subject_id']=$this->request->getVar('subject_id');
		$data['type']=$this->request->getVar('type');
		$data['last_url']=substr($this->request->getVar('last_url'),4); //Remove /eIB
		$data['controller']=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		return view('header', $data)
			. view('menu', $data)
			. view('add_attachment', $data)
			. view('footer', $data);
	}
	
	public function add()
	{
		$data=[];
		$data['edit_subject_record']=1;
		$data['record']=[];
		$this->controller=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		$data['fields']=$this->controllerModel->getFields($this->controller['id']);
		for($n=0; $n<count($data['fields']); $n++) {
			if($data['fields'][$n]['type']== 'option') { //Field options will either be self contained in the field or looked up
				$options=$this->controllerModel->getFieldOptions($data['fields'][$n]['id']);
				if($options) {
					$data['fields'][$n]['options']=$options;
				} else {
					$data['fields'][$n]['options']=$this->crudModel->getFieldOptions($data['fields'][$n]['db_name']);
				}
			}
		}
		//Empty the value of the fields
		foreach ($data['fields'] as $field) {
			$data['record'][$field['db_name']] = null;
		}
		$data['record']['sentence_type']=$data['record']['sentence_units']=$data['record']['sentence_amount']=null;
		
		return view('header', $data)
			. view('menu', $data)
			. view('edit_subject_record', $data)
			. view('footer', $data);
	}
	
	public function generateOtherRecords($subject_id, $type, $id) 
	{
		//Get the different records and put them into arrays
		if($type=='DRIVER') {
			$subject=$this->driverModel->find($subject_id);
		} else {
			$subject=$this->subjectModel->find($subject_id);
		}
		if($subject) {
			$criminal = $this->subjectRecordModel->getRelated($subject['cabis_id'], $subject['nin']);
			$police=$this->policeOfficerModel->getRelated($subject['cabis_id'], $subject['nin']);
			$cogc=$this->cogcModel->getRelated($subject['cabis_id'], $subject['nin']);
			//$pso=$this->psoModel->getRelated($subject['cabis_id'], $subject['nin']);
			$pso=[];
		} else {
			$criminal=[];
			$police=[];
			$cogc=[];
			$pso=[];
		}
		//Format for records is sort field, date,type,details,link
		$records=[];
		foreach($criminal as $record) {
			if($record['id']==$id && $type=='CRIMINAL') { //Don't include current record in other records
				//continue; The above was superseded by a requirement to show all records all the time
			}
			switch ($record['case_result']) {
				case 'NOT SENTENCED YET':
					$record['result']="Not sentenced yet";
					break;
				case 'ACQUITTED':
					$record['result']="Acquitted";
					break;
				case 'DISMISSED':
					$record['result']="Dismissed";
					break;
				case 'SENTENCED':
					switch($record['sentence_type']) {
						case 'CUSTODIAL':
							$record['result']='Imprisonment for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
						break;
						case 'NON CUSTODIAL':
						switch($record['non_custodial_sentence']) {
							case 'CAUTION':
								$record['result']='Caution';
								break;
							case 'COMMUNITY SERVICE':
								$record['result']='Community service for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
								break;
							case 'FINE':
								$record['result']='Fined UGX '.$record['sentence_amount'];
								break;
						}
						break;
					}
					break;
				default:
					$record['result']=" - ";
			}
				$record['date']= ($record['date_sentence'] != null) ? $record['date_sentence'] : $record['created_at'];
				$records[]=['sort'=> strtotime($record['date']), 'date' => $record['date'], 'type' => 'CRIMINAL', 'court_place_trial' => $record['court_place_trial'], 'date_sentence' => $record['date_sentence'], 'sentence' => $record['result'], 'result' => $record['result'], 'offence' => $record['offence'], 'name' => $subject['first_name'].' '.$subject['last_name'],'details' => $record['result'], 'link' => base_url('frontend/subject_records/criminal/view/'.$record['id'])];
		}
		foreach($police as $record) {
			if($record['id']==$id && $type=='POLICE') { //Don't include current record in other records
				//continue;
			}
			$records[]=['sort'=> strtotime($record['created_at']), 'date' => $record['created_at'], 'type' => 'POLICE', 'details' => "-", 'link' => base_url('frontend/subject_records/police/view/'.$record['id'])];
		}
		foreach($cogc as $record) {
			if($record['id']==$id && $type=='CIVILIAN') { //Don't include current record in other records
				//continue;
			}
			$records[]=['sort'=> strtotime($record['created_at']), 'date' => $record['created_at'], 'type' => 'CIVILIAN', 'details' => "-", 'link' => base_url('frontend/subject_records/civilian/view/'.$record['id'])];
		}
		foreach($pso as $record) {
			if($record['id']==$id && $type=='PSO') { //Don't include current record in other records
				//continue;
			}
			$records[]=['sort'=> strtotime($record['created_at']), 'date' => $record['created_at'], 'type' => 'PSO', 'details' => "-", 'link' => base_url('frontend/subject_records/pso/view/'.$record['id'])];
		}
		//Sort them in chronological order
		usort($records, function($a, $b) { return($a['sort'] - $b['sort']); });
		return($records);
	}
	
}

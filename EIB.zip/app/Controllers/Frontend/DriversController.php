<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\Email;

class DriversController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;
	protected $driverModel;
	protected $stageModel;
	protected $auditLogModel;
	protected $policeOfficerModel;
	protected $cogcModel;
	protected $subjectModel;
	protected $subjectRecordModel;

	function __construct()
	{
		$this->controller=[];
		parent::__construct();
		$this->stageModel = model('App\Models\StageModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->auditLogModel = model('App\Models\AuditLogModel');
	}
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if( !$this->request->getVar('first_name') || !$this->request->getVar('last_name')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('frontend/traffic/drivers');
		}
		
		
		//All good add, the record

		$db_data=['stage' => $this->request->getVar('stage'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'driving_license' => $this->request->getVar('driving_license'), 'nin' => $this->request->getVar('nin')];
	
		
		if(!$this->request->getVar('id')) { 
			$record_id=$this->driverModel->insert($db_data);
			
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $record_id, 'section' => 'DRIVER', 'action' => 'CREATE', 'data_before' => '', 'data_after' => json_encode($audit_data)]);
			//Submit the data to CABIS
			$reference="UD".sprintf("%06d", $record_id);
			$cabis_data=[];
			$cabis_data['textData']=[['tagNum' => '110', 'tagValue' => $this->request->getVar('last_name')],['tagNum' => '111', 'tagValue' => $this->request->getVar('first_name')],['tagNum' => '3319', 'tagValue' => 'CIVILIAN'],['tagNum' => '3320', 'tagValue' => $reference], ['tagNum' => '3326', 'tagValue' => $this->request->getVar('nin')], ['tagNum' => '3309', 'tagValue' => $this->request->getVar('nin')]];
			$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '']]; 
			$cabis = new CABIS();
			$cabis_id=$cabis->submit(json_encode($cabis_data));
			$this->driverModel->update($record_id, ['cabis_id' => $cabis_id]);
		} else {
			$record_id=$this->request->getVar('id');
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$before_data=$this->driverModel->find($this->request->getVar('id'));
			$subject=$this->subjectModel->find($db_data['subject_id']);
			$before_data['subject_id']=$subject['cabis_id'];
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $this->request->getVar('id'), 'section' => 'DRIVER', 'action' => 'UPDATE', 'data_before' => json_encode($before_data), 'data_after' => json_encode($audit_data)]);
			$this->driverModel->update($this->request->getVar('id'), $db_data);
		}
		$this->session->setFlashdata('message', 'Record saved for '.$this->request->getVar('first_name').' '.$this->request->getVar('last_name')."<br>Reference: ".$reference); 
		$this->session->setFlashdata('messageTitle', 'Record saved'); 
		return redirect()->to('frontend/traffic/drivers/view/'.$record_id);
	}

	
	public function index()
	{
		$data=[];
		$data['records']=[];
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/drivers', $data)
			. view('footer', $data);
	}
	
	
		public function search()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$driver_data=$this->driverModel->search(['cabis_id' => $this->request->getVar('cabis_id'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'driving_license' => $this->request->getVar('driving_license'), 'nin' => $this->request->getVar('nin'), 'number_plate' => $this->request->getVar('number_plate'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($driver_data as $record) {
			$record['subject_id']=$record['cabis_id'];
			$cabis_present=$cabis->getTag($record['cabis_id'], '105');
			$record['status']= ($cabis_present != null) ? "COMPLETED" : "PENDING";
			$record['attachments'] = []; //$this->attachmentModel->retrieve('subject_record', $record['id']);
			$data['records'][]=$record;
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/drivers', $data)
			. view('footer', $data);
	}
	
	public function view($id)
	{
		$data=[];
		session_write_close();
		$cabis=new CABIS();
		$data['record']=$this->driverModel->find($id);
		$subject=$this->subjectModel->getByCabisId($data['record']['cabis_id']);
		$data['subject']=$subject;
		$data['record']['subject_id']=$data['record']['cabis_id'];
		$data['cabis_present']=$cabis->getTag($data['record']['cabis_id'], '105');
		$data['record']['status']= ($data['cabis_present'] != null) ? "COMPLETED" : "PENDING";
		$data['permanent_records']= $this->subjectRecordModel->getBySubjectId($data['record']['cabis_id'], 'PERMANENT');
		$data['related_records']=$this->generateOtherRecords($id, 'TRAFFIC', $id);

		$data['attachments'] = []; //$this->attachmentModel->retrieve('subject_record', $subjectRecord['id']);
		
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/driver', $data)
			. view('footer', $data);
	}
	
	
	public function edit($id)
	{
		$data=[];
		$data['record']=$this->driverModel->find($id);
		$data['edit_police_officer']=1;

		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['record']['subject_id']=$subject['cabis_id'];
		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/edit_police_officer', $data)
			. view('footer', $data);
	}
	
	public function add()
	{
		$data=[];
		$data['record']=[];
		$stages=$this->stageModel->getStages();
		$data['stages']=[];
		foreach($stages as $stage) {
			log_message('debug', print_r($stage, true));
			$data['stages'][$stage['name']]=$stage['name'];
		}
		return view('header', $data)
			. view('menu', $data)
			. view('Traffic/edit_driver', $data)
			. view('footer', $data);
	}
}

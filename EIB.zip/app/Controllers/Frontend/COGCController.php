<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;

class COGCController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $crModel;
	protected $controllerModel;
	protected $attachmentModel;



	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->crModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->controllerModel = model('App\Models\ControllerModel');
		$this->attachmentModel = model('App\Models\AttachmentModel');
		$this->auditLogModel = model('App\Models\AuditLogModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->crudModel = model('App\Models\CrudModel');
	}

	function view($id) {
		$record=$this->cogcModel->getByUUID($id);
		return $this->response->setHeader("Content-Type", $record['scan_type'])
		->setBody(base64_decode($record['scan_file']));
	}
	
	function index()
	{
		$cogcs=$this->cogcModel->findAll();
		foreach($cogcs as $cogc) {
			$subject=$this->subjectModel->find($cogc['subject_id']);
			$cabis=new CABIS();
			$cabis_data=file_get_contents(base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=105'));
			if($cabis_data) {
				print '<a href="'.base_url('pub/cogc/view/'.$cogc['uuid']).'">'.$cogc['first_name'].' '.$cogc['last_name'].'</a><br>';
			} else {
				print $cogc['first_name'].' '.$cogc['last_name'].' PENDING<br>';
			}
		}
	}
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if(!$this->request->getVar('first_name') || !$this->request->getVar('last_name') || !$this->request->getVar('id_number')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('pub/cogc');
		}
		
		//Submit the data to CABIS and get an ID
		$uuid=uuid();
		$reference=substr($uuid, 0, 8);
		$cabis_data=[];
		$cabis_data['textData']=[['tagNum' => '110', 'tagValue' => $this->request->getVar('last_name')],['tagNum' => '111', 'tagValue' => $this->request->getVar('first_name')],['tagNum' => '3319', 'tagValue' => 'CIVIL'],['tagNum' => '3309', 'tagValue' => $this->request->getVar('prn')],['tagNum' => '3320', 'tagValue' => $reference], ['tagNum' => NINID, 'tagValue' => $this->request->getVar('id_number')], ['tagNum' => ApplicationType, 'tagValue' => 'COGC']];
		$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '']];
		$cabis_data['afisCategory'] = 2;
		$attachment = $this->request->getFile('attachment');
		$file_content='';
		if($attachment->isValid()) {
			$type=$attachment->getMimeType();
			$filepath = WRITEPATH . 'uploads/' . $attachment->store();
			$file_content=file_get_contents($filepath);
			$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue'=> base64_encode($file_content)]];
		}
		$cabis = new CABIS();
		$cabis_id=$cabis->submit(json_encode($cabis_data));
		if($cabis_id) {
			//Create the subject and subject_record
			$subject_id=$this->subjectModel->create(['name' => $this->request->getVar('first_name')." ".$this->request->getVar('last_name'), 'cabis_id' => $cabis_id, 'nin' => $this->request->getVar('id_number')]);
			$this->cogcModel->insert(['first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'phone' => $this->request->getVar('phone'), 'email' => $this->request->getVar('email'),'id_type' => $this->request->getVar('id_type'), 'prn' => $this->request->getVar('prn'), 'id_number' => $this->request->getVar('id_number'), 'issued_by' => $this->request->getVar('issued_by'), 'uuid' => $uuid, 'subject_id' => $subject_id, 'picture' => base64_encode($file_content)]);
			$this->session->setFlashdata('message', 'Data uploaded, please proceed to take fingeprints<br> PRN: '.$this->request->getVar('prn').'<br>Ref: '.$reference); 
			$this->session->setFlashdata('messageTitle', 'Success'); 
			return redirect()->to('pub/cogc');
		} else {
			$this->session->setFlashdata('errorMessage', 'Data upload failed'); 
			$this->session->setFlashdata('errorTitle', 'Failed'); 
			return redirect()->to('pub/cogc');
		}
	}

	
	public function add()
	{
		$data=[];
		
		return 
			 view('add_cogc', $data);
	}
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class LostAndFoundGeneralController extends LostAndFoundController
{
        use ResponseTrait;
        

        public function __construct()
        {
                
        }
        
}


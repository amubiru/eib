<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;
use PhpOffice\PhpSpreadsheet\IOFactory;


class Ipps extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $ippsModel;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->ippsModel = model('App\Models\IppsModel');
	}
	
	//Show the upload form
	public function upload()
	{
		$data=[];
		return view('header', $data)
			. view('menu', $data)
			. view('upload_ipps', $data)
			. view('footer', $data);

	}
	
	public function upload_submit()
	{
		$data=[];
		$records_file = $this->request->getFile('ipps_file');
		if ($records_file->hasMoved()) {
			$data['error_message'] = 'File has been moved';
			return view('header', $data)
			. view('menu', $data)
			. view('upload_ipps', $data)
			. view('footer', $data);
		}
		$filepath = WRITEPATH . 'uploads/' . $records_file->store();
		log_message('debug' , "Opening Excel file $filepath");
		$spreadsheet = IOFactory::load($filepath);
		$sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
		$rowNum=0;
		$data['errorMessage']="";
		foreach($sheetData as $row) {
			$rowNum++;
			if($rowNum == 1) { //Headings
				continue;
			}
			
			$dob=date("Y-m-d", strtotime($row['E']));
			
			$first_app=date("Y-m-d", strtotime($row['H']));
			
			$current_app=date("Y-m-d", strtotime($row['I']));

			$dbData=['employee_number' => $row['A'], 'nin' => $row['B'], 'name' => $row['C'], 'gender' => $row['D'], 'date_of_birth' => $dob, 'title' => $row['F'], 'posting' => $row['G'], 'first_application_date' => $first_app, 'current_application_date' => $current_app];
			$response=$this->ippsModel->create($dbData);
			if(array_key_exists('original', $response)) { // Duplicate
				$data['errorMessage'].="Duplicate record for ".$dbData['name']. ", NIN: {$dbData['nin']}, E No: {$dbData['employee_number']}";
			}
				
		}
		return redirect()->to('frontend/ipps_show');
		
	}
	
	public function show()
	{
		$data=[];
		$ipps_data=$this->ippsModel->getAll();
		$data['records']=[];
		foreach($ipps_data as $record) {
			$data['records'][]=$record;
		}
		return view('header', $data)
			. view('menu', $data)
			. view('ipps_data', $data)
			. view('footer', $data);
		}
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use App\Libraries\NIRA;
use App\Libraries\Email;

class UnverifiedSubjectRecordsController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;

	function __construct()
	{
		parent::__construct();
		$this->controller=[];
		$this->controller['route']='/frontend/subject_records/police';
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->unverifiedModel = model('App\Models\UnverifiedModel');
	}
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if( !$this->request->getVar('first_name') || !$this->request->getVar('last_name')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('frontend/subject_records/police');
		}
		
		//Does this subject have an existing subject_id
		$subject=$this->subjectModel->getByCabisId($this->request->getVar('cabis_id'));
		if($subject) {
			$subject_id=$subject['id'];
		} else {
			$subject_id=$this->subjectModel->insert(['name' => $this->request->getVar('first_name').' '.$this->request->getVar('last_name'), 'cabis_id' => $this->request->getVar('cabis_id')]);
		}
		
		
		//All good add, the record
		$db_data=['subject_id' => $subject_id, 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'employee_number' => $this->request->getVar('employee_number'), 'nin' => $this->request->getVar('nin')];
	
		
		if(!$this->request->getVar('id')) { 
			$record_id=$this->policeOfficerModel->insert($db_data);
			
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $record_id, 'section' => 'POLICE RECORDS', 'action' => 'CREATE', 'data_before' => '', 'data_after' => json_encode($audit_data)]);
		} else {
			$record_id=$this->request->getVar('id');
			$audit_data=$db_data;
			$audit_data['subject_id']=$this->request->getVar('subject_id');
			$before_data=$this->policeOfficerModel->find($this->request->getVar('id'));
			$subject=$this->subjectModel->find($db_data['subject_id']);
			$before_data['subject_id']=$subject['cabis_id'];
			$this->auditLogModel->insert(['created' => date('Y-m-d H:i:s'), 'user_id' => $_SESSION['user_id'], 'data_id' => $this->request->getVar('id'), 'section' => 'POLICE RECORDS', 'action' => 'UPDATE', 'data_before' => json_encode($before_data), 'data_after' => json_encode($audit_data)]);
			$this->policeOfficerModel->update($this->request->getVar('officer_id'), $db_data);
		}
		$this->session->setFlashdata('message', 'Record saved for '.$this->request->getVar('first_name').' '.$this->request->getVar('last_name')); 
		$this->session->setFlashdata('messageTitle', 'Record saved'); 
		return redirect()->to('frontend/subject_records/police/view/'.$record_id);
	}

	
	public function index()
	{
		$data=[];
		$data['records']=[];
		$data['controllerName']=$this->controllerName;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/unverified_identities', $data)
			. view('footer', $data);
	}
	
	public function attachmentSubmit()
	{
		$attachment = $this->request->getFile('attachment');
		if($attachment->isValid()) {
			$type=$attachment->getMimeType();
			$filepath = WRITEPATH . 'uploads/' . $attachment->store();
			$file_content=file_get_contents($filepath);
			$post_data=['subject_record_id' => $this->request->getVar('subject_record_id'), 'name' => $this->request->getVar('name'), 'description' => $this->request->getVar('description'), 'file_type' => $type, 'file_content' => $file_content];
			$this->attachmentModel->insert($post_data);
		}
		$router = service('router');
		$controllerName  = str_replace('\\App\\Controllers\\', '', $router->controllerName());
		return redirect()->to('/frontend/subject_records/view/'.$this->request->getVar('subject_record_id'));
	}
	
		public function search()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$subject_data=$this->unverifiedModel->search(['first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'id_number' => $this->request->getVar('id_number'),'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($subject_data as $record) {
			$record['attachments'] = []; //$this->attachmentModel->retrieve('subject_record', $record['id']);
			$data['records'][]=$record;
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/unverified_identities', $data)
			. view('footer', $data);
	}
	
	public function view($id)
	{
		$data=[];
		session_write_close();
		$data['record']=$this->unverifiedModel->find($id);
		$data['records']=$this->unverifiedModel->getRelated($id);

		$data['attachments'] = []; //$this->attachmentModel->retrieve('subject_record', $subjectRecord['id']);
		if(strlen($data['record']['id_number'] ?? '')==13) {
			$nira=new NIRA();
			$data['nin']=$nira->getPerson($data['record']['id_number']);
		}
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/unverified_identity', $data)
			. view('footer', $data);
	}
	
	
	public function edit($id)
	{
		$data=[];
		$data['record']=$this->unverifiedModel->find($id);

		//$data['files']=$this->subjectRecordModel->getAdditionalFiles($id);
		$data['files']=[];
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/edit_police_officer', $data)
			. view('footer', $data);
	}
	
	public function attachmentAdd($id)
	{
		$data=[];
		$data['subject_record_id']=$id;
		$data['controller']=$this->controllerModel->getByControllerName('Frontend\SubjectRecordsController');
		return view('header', $data)
			. view('menu', $data)
			. view('add_attachment', $data)
			. view('footer', $data);
	}
	
	public function add()
	{
		$data=[];
		$data['edit_police_officer']=1;
		$data['record']=[];
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/edit_police_officer', $data)
			. view('footer', $data);
	}
}

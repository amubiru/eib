<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\Email;
use App\Libraries\NIRA;
use App\Libraries\CaseTracking;
use App\Libraries\Utils;
use GuzzleHttp\Client;

require_once(__DIR__."/../../Libraries/YoAPI.php");

class ViewRecordController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;
	protected $driverModel;
	protected $externalDataModel;
	protected $searchModel;
	protected $policeOfficerModel;
	protected $cogcModel;
	protected $subjectModel;
	protected $trafficOffenseModel;
	protected $subjectRecordModel;

	function __construct()
	{
		$this->controller=[];
		parent::__construct();
		$this->externalDataModel = model('App\Models\ExternalDataModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->trafficOffenseModel = model('App\Models\TrafficOffenseModel');
		$this->searchModel = model('App\Models\SearchModel');
	}

	public function index()
	{
		$data=[];
		$id=$this->request->getVar('id');
		switch($this->request->getVar('type')) {
			case 'nira':
				$nira= new NIRA();
				$data['nin']=$nira->getPerson($id);
				$data['include']="SubjectRecords/nira";
				break;
			case 'license':
				$nira= new NIRA();
				$data['license']=$nira->getLicense($id);
				$data['include']="SubjectRecords/license";
				break;
			case 'vehicle':
				$nira= new NIRA();
				$data['data']=$nira->getVehicle($id);
				$data['include']="SubjectRecords/vehicle";
				break;
			case 'case_tracking':
				$ct = new CaseTracking();
				$data['data']=$ct->query(['query' => ['type' => 'Case', 'id' => $id]]);
				$data['related']=$this->getCaseRelated($data['data']);
				$data['include']="SubjectRecords/case";
				break;
			case 'case_tracking_person':
				$ct = new CaseTracking();
				$data['data']=$ct->query(['query' => ['type' => 'Person', 'id' => $id]]);
				$data['related']=$this->getCasePersonRelated($data['data']);
				$data['include']="SubjectRecords/case_person";
				break;
			case 'civilian':
				$data['data']=$this->cogcModel->find($id);
				$data['application']=json_decode($data['data']['raw_content'] ?? '');
				$data['extra']=$this->subjectModel->find($data['data']['subject_id']);
				$data['related']=$this->getCabisRelated($data['extra']['cabis_id']);
				$data['include']="SubjectRecords/civilian_search_record";
				break;
			case 'criminal':
				$data['data']=$this->subjectRecordModel->find($id);
				$data['extra']=$this->subjectModel->find($data['data']['subject_id']);
				$data['related']=$this->getCabisRelated($data['extra']['cabis_id']);
				$data['include']="SubjectRecords/criminal_search_record";
				break;
			case 'traffic':
				$ct = new CaseTracking();
				$data['data']=$ct->query(['query' => ['type' => 'Person', 'id' => $id]]);
				$data['related']=$this->getTrafficRelated($data['data']);
				$data['include']="SubjectRecords/traffic_offense";
				break;
			case 'cabis':
				$cabis = new CABIS();
				$data['data']=$cabis->getArray($id);
				$data['related']=$this->getCabisRelated($id);
				$data['include']="SubjectRecords/cabis";
				break;
		}
		return view('header', $data)
			. view('view_record', $data)
			. view('footer', $data);
	}
	
	private function getCaseRelated($data)
	{
		$related=[];
	}
	
	private function getCabisRelated($cabis_id)
	{
		$cabis= new CABIS();
		$cabis_records = $cabis->getMatchingCandidates($cabis_id, false);
		$related=[];
		foreach($cabis_records as $record) {
			$related[]=['url' => base_url('/frontend/view_record/?type=cabis&id='.$record['cabis_id']), 'date' => $cabis->getTag($record['cabis_id'], Date), 'details' => 'CABIS ID '.$record['cabis_id'].', '.($cabis->getTag($record['cabis_id'], CriminalRecord) ?? ''), 'category' => 'CABIS Record', 'identifier' => $record['first_name'].' '.$record['last_name'], 'photo' => base_url('ajax/get_cabis?id='.$record['cabis_id'].'&tag=705&thumbnail=1')];
		}
		return($related);
	}
	
	private function getTrafficRelated($data)
	{
		$related=[];
		$nira = new NIRA();
		$vehicle=$nira->getVehicle($data['number_plate']);
		if($vehicle) {
			$related[]=$this->formatVehicle($vehicle);
		}
		$person=$nira->getPerson($data['nin'] ?? $data['id_number']);
		if($person) {
			$related[]=$this->formatPerson($person);
		}
		return($related);
	}
	
	private function getCivilianRelated($data)
	{
		$related=[];
		$nira = new NIRA();

		$person=$nira->getPerson($data['id_number']);
		if($person) {
			$related[]=$this->formatPerson($person);
		}
	}
	
	private function formatVehicle($vehicle)
	{
		$entry['url']=base_url('/frontend/view_record/?type=vehicle&id='.$vehicle['MVRegNo']);
		$entry['category']='Vehicle registration';
		$entry['identifier']=$vehicle['MVRegNo'];
		$entry['details']=$vehicle['Make'].' '.$vehicle['ModelName'].' '.$vehicle['BodyDesc'].'<br>Owner: '.$vehicle['TaxPayerName'].' Phone: '.$vehicle['MobileNumber'].'<br>Vehicle purpose: '.$vehicle['VehicleClassification'];
		$entry['date']='Registration Date: '.$vehicle['DateOfRegistration'];
		$entry['photo']=false;
		return($entry);
	}
	
	private function formatPerson($entry)
	{
		$entry['url']=base_url('/frontend/view_record/?type=nira&id='.$entry['nationalId']);
		$entry['category']='National ID';
		$entry['identifier']='NIN: '.$entry['nationalId'];
		$entry['details']=$entry['givenNames'].' '.$entry['surname'];
		$entry['date']=$entry['dateOfBirth'];
		$entry['photo']=base_url('ajax/get_external_photo?token='.$_SESSION['AJAX_TOKEN'].'&source=nira&external_id='.$entry['nationalId'].'&thumbnail=1');;
		return($entry);
	}
		

}

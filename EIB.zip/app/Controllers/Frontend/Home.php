<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;


class Home extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
	}
	
	//Show the add form
	public function index()
	{
		$data=[];
		return view('header', $data)
			. view('menu', $data)
			. view('blank', $data)
			. view('footer', $data);

	}
}

<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;
use PhpOffice\PhpSpreadsheet\IOFactory;


class AuditLogController extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $auditLogModel;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->auditLogModel = model('App\Models\AuditLogModel');
		$this->userModel = model('App\Models\UserModel');
	}
	

	
	public function index()
	{
		$data=[];
		$audit_logs=$this->auditLogModel->findAll();
		$data['records']=[];
		foreach($audit_logs as $record) {
			$user = $this->userModel->find($record['user_id']);
			$record['username']=$user['name'];
			$data['records'][]=$record;
		}
		return view('header', $data)
			. view('menu', $data)
			. view('audit_logs', $data)
			. view('footer', $data);
		}
}

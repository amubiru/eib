<?php 

namespace App\Controllers\Frontend;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use App\Libraries\Email;
use App\Libraries\NIRA;

class QueueController extends \App\Controllers\Frontend\SubjectRecordsController
{

	use ResponseTrait;
	private $controller;

	function __construct()
	{
		parent::__construct();
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->psoModel = model('App\Models\PSOModel');
		$this->controller=[];
		$this->controller['route']='/frontend/subject_records/queue';
	}
	
	public function PCC()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$data=[];
		$data['records']=[];
		$records=$this->cogcModel->getUnprocessed();
		foreach($records as $record) {
			$subject=$this->subjectModel->find($record['subject_id']);
			$cabis_present=$cabis->getTag($subject['cabis_id'], '105');
			if($cabis_present) {
				$data['records'][]=$record;
			}
		}
		$data['controllerName']=$this->controllerName;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/pcc_queue', $data)
			. view('footer', $data);
	}
	
	
		public function PCCSearch()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$cogc_data=$this->cogcModel->search(['subject_id' => $this->request->getVar('subject_id'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'prn' => $this->request->getVar('prn'), 'id_number' => $this->request->getVar('id_number'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($cogc_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$cabis_present=$cabis->getTag($subject['cabis_id'], '105');
			if($cabis_present) {
				$data['records'][]=$record;
			}
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/pcc_queue', $data)
			. view('footer', $data);
	}
	
	public function PCCView($id)
	{
		$data=[];
		session_write_close();
		$cabis=new CABIS();
		$nira = new NIRA();
		
		$data['record']=$this->cogcModel->find($id);
		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['subject']=$subject;
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$data['record']['status']= ($data['cabis_present'] != null) ? "COMPLETED" : "PENDING";
		$data['permanent_records']= $this->subjectRecordModel->getBySubjectId($data['record']['subject_id'], 'PERMANENT');
		$data['cogc']=$this->cogcModel->find($id);
		$data['pcc']=$this->subjectModel->getLatestPCCBySubjectId($subject['id']);
		$data['related_records']=$this->generateOtherRecords($subject['id'], 'CIVILIAN', $id);

		$data['attachments'] = []; // = $this->attachmentModel->retrieve('subject_record', $subjectRecord['id']);
		if($data['record']['id_number']) {
			$data['nin']=$nira->getPerson($data['record']['id_number']);
		}
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilian', $data)
			. view('footer', $data);
	}
	
	public function COGC()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$data=[];
		$data['records']=[];
		$records=$this->cogcModel->getUnprocessed();
		foreach($records as $record) {
			$subject=$this->subjectModel->find($record['subject_id']);
			$cabis_present=$cabis->getTag($subject['cabis_id'], '105');
			if($cabis_present) {
				$data['records'][]=$record;
			}
		}
		$data['controllerName']=$this->controllerName;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/pcc_queue', $data)
			. view('footer', $data);
	}
	
	
		public function COGCSearch()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		$cogc_data=$this->cogcModel->search(['subject_id' => $this->request->getVar('subject_id'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'prn' => $this->request->getVar('prn'), 'id_number' => $this->request->getVar('id_number'), 'start_date' => $this->request->getVar('start_date'), 'end_date' => $this->request->getVar('end_date')]);
		$data['records']=[];
		foreach($cogc_data as $record) {
			$subject=$this->subjectModel->getById($record['subject_id']);
			$record['subject_id']=$subject['cabis_id'];
			$cabis_present=$cabis->getTag($subject['cabis_id'], '105');
			if($cabis_present) {
				$data['records'][]=$record;
			}
		}
		$data['controller']=$this->controller;
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/pcc_queue', $data)
			. view('footer', $data);
	}
	
	public function COGCView($id)
	{
		$data=[];
		session_write_close();
		$cabis=new CABIS();
		$nira = new NIRA();
		
		$data['record']=$this->cogcModel->find($id);
		$subject=$this->subjectModel->getById($data['record']['subject_id']);
		$data['subject']=$subject;
		$data['record']['subject_id']=$subject['cabis_id'];
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$data['record']['status']= ($data['cabis_present'] != null) ? "COMPLETED" : "PENDING";
		$data['permanent_records']= $this->subjectRecordModel->getBySubjectId($data['record']['subject_id'], 'PERMANENT');
		$data['cogc']=$this->cogcModel->find($id);
		$data['pcc']=$this->subjectModel->getLatestPCCBySubjectId($subject['id']);
		$data['related_records']=$this->generateOtherRecords($subject['id'], 'CIVILIAN', $id);

		$data['attachments'] = []; // = $this->attachmentModel->retrieve('subject_record', $subjectRecord['id']);
		if($data['record']['id_number']) {
			$data['nin']=$nira->getPerson($data['record']['id_number']);
		}
		
		return view('header', $data)
			. view('menu', $data)
			. view('SubjectRecords/civilian', $data)
			. view('footer', $data);
	}
	
	
	
	
}

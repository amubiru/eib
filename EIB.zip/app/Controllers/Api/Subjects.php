<?php namespace App\Controllers\Api;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;


class Subjects extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $userModel;
	protected $caseTrackingModel;
	protected $subjectModel;
	protected $subjectRecordModel;

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->caseTrackingModel = model('App\Models\CaseTrackingModel');
		helper('ecro');
	}

	//Create a subject
	public function create()
	{
		//Check if user exists
		$user = $this->userModel->getByUsername($this->request->getVar('username'));
		if($user) {
			return $this->failResourceExists("Account already exists");
		}
		$id=$this->userModel->create(array('name' => $this->request->getVar('name'), 'password' => $this->request->getVar('password'), 'username' => $this->request->getVar('username')));
		if(!$id) {
			return $this->respond("An unkown error occurred", 500);
		} else {
			return($this->respondCreated(array('id' => $id)));
		}
	}



	//Returns information about a specific subject
	public function show($reqId)
	{
		$reqSubject=$this->subjectModel->find($reqId);
		if(!$reqSubject) {
			return $this->failNotFound();
		}
		return($this->respond($reqSubject));
	}
	
	//Returns criminal records for a specific subject
	public function subject_record()
	{
		$input = $this->request->getJSON(true);
		if(!(array_key_exists('subject_id', $input) || array_key_exists('person_id', $input)) ) {
			return $this->failValidationError(json_encode(['message' => 'Missing subject_id or person_id field']));
		}
		$subject = false;
		if(array_key_exists('subject_id', $input)) {
			$subject=$this->subjectModel->getByCabisId($input['subject_id']);
		}
		if(!$subject && array_key_exists('person_id', $input)) {
			$subject=$this->subjectModel->getByPersonId($input['person_id']);
		}
		if(!$subject) {
			return $this->failNotFound(json_encode(['message' => 'Unknown subject_id or person_id']));
		}
		$records = $this->subjectRecordModel->getBySubjectId($subject['id'], 'PERMANENT');
		//If no records, return form 45, else return form 45a
		if(!count($records)) {
			return($this->respond(['form' => '45', 'subject_id' => $subject['cabis_id'], 'convictions' => []]));
		} else {
			$response=['form' => '45a', 'subject_id' => $subject['cabis_id'], 'convictions' => []];
			foreach($records as $record) {
				switch ($record['sentence_type']) {
				case 'NOT SENTENCED YET':
					$record['sentence']="Not sentenced yet";
					break;
				case 'PRISON':
					$record['sentence']='Imprisonment for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'PROBATION':
					$record['sentence']='Probation for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'COMMUNITY SERVICE':
					$record['sentence']='Community service for '." ".counted($record['sentence_amount'], strtolower($record['sentence_units']));
					break;
				case 'FINE':
					$record['sentence']='Fined UGX '.$record['sentence_amount'];
					break;
				default:
					$record['sentence']=" - ";
			}
				$response['convictions'][] = [         "place_trial" => $record['court_place_trial'],
				 "crb_no" => $record['crb_no'],
				 "date_sentenced" => $record['date_sentence'],
				 "sentence"=> $record['sentence'],
				 "offence"=> $record['offence'],
				 "remarks"=> $record['remarks'],
				 "station"=> $record['station'],
				 "name_convicted"=> $record['name']];
			 }
			 return($this->respond($response));
		}
	}

//Returns criminal records for a specific subject
	public function search()
	{
		$input = $this->request->getJSON(true);
		//Build search params
		$params='';
		$records=$this->subjectRecordModel->search($input, 'PERMANENT');
		//If no records, return form 45, else return form 45a
		if(!count($records)) {
			return($this->respond(['convictions' => []]));
		} else {
			$response=['convictions' => []];
			foreach($records as $record) {
				$response['convictions'][] = ["subject_id" => $record['cabis_id'],
				"subject_name" => $record['subject_name'],
				"place_trial" => $record['court_place_trial'],
				 "crb_no" => $record['crb_no'],
				 "date_sentenced" => $record['date_sentence'],
				 "sentence"=> $record['sentence'],
				 "offence"=> $record['offence'],
				 "remarks"=> $record['remarks'],
				 "station"=> $record['station'],
				 "name_convicted"=> $record['name']];
			 }
			 return($this->respond($response));
		}
	}
	
	//Receives a temporary criminal record
	public function submit()
	{
		$input = $this->request->getJSON(true);
		log_message('debug', print_r($input,true));
		if(!(array_key_exists('person_id', $input) && array_key_exists('case_id', $input)) ) {
			return $this->failValidationError(json_encode(['message' => 'Missing person_id or case_id field']));
		}
		
		if(!(array_key_exists('textData', $input) && array_key_exists('imageData', $input)) ) {
			return $this->failValidationError(json_encode(['message' => 'Missing textData or imageData field']));
		}
		//If this is a duplicate, return old cabis id
		$subject=$this->subjectModel->getByPersonId($input['person_id']);
		if($subject) {
			return($this->respond(['id' => $subject['cabis_id'], 'person_id' => $input['person_id']]));
		}
		
		//Add new record
		$cabis_data=$input;
		
		//Correct rotation of input image to CABIS
		$image=$cabis_data['imageData'][0]['tagValue'];
		if($image) {
			log_message('debug', 'Found CaseTracking image data');
			$file = tmpfile();
			fwrite($file, base64_decode($image));
			//TODO remove this file creation when testing is complete
			//file_put_contents("C:\Windows\TEMP\ctimage.jpg", base64_decode($image));
			$path = stream_get_meta_data($file)['uri'];
			$type=exif_imagetype($path);
			if(in_array($type, [2,6])) { //JPEG and BMP that support EXIF
				log_message('debug', "Found JPG");
				$new_image=image_fix_orientation($path);
				if($new_image!=false) {
					log_message('debug', "Found EXIF");
					$fileout = tmpfile();
					$pathout = stream_get_meta_data($fileout)['uri'];
					imagejpeg($new_image, $pathout, 90);
					$cabis_data['imageData'][0]['tagValue']=base64_encode(file_get_contents($pathout));
					//log_message('debug',"Before\n".$image);
					//log_message('debug',"After\n".$cabis_data['imageData'][0]['tagValue']);
				}
				
			}
		} 
		unset($cabis_data['person_id']);
		unset($cabis_data['case_id']);
		
		//Save NIN from Case tracking info if available
		$nin='';
		$ct=new CaseTracking();
		$person_data=$ct->query(['query' => ['type' => 'Person', 'id' => $input['person_id']]]);
			if($person_data) {
				if(is_array($person_data)) {
					if(!array_key_exists('errorCode', $person_data)) {
						$person=$person_data[0];
						if(array_key_exists('identifications', $person['details'])) {	
							foreach($person['details']['identifications'] as $id) {
								if($id['identificationType']['label'] ?? '' == 'NIN') {
									$nin=$id['identificationValue'];
									break;
								} elseif(!is_array($id['identificationType']) && $id['identificationType'] == 'nin') {
									$nin=$id['identificationValue'];
									break;
								}
							}
						}
							
					}
				}
			}
		$station="Not specified";
		$offenses="";
		$crb_no="";
		$cabis_data['textData'][]=['tagNum' => CABISCaseRelation, 'tagValue' => $person['cardDetails']['caseRelationship']['value'] ?? 'N/A'];
		$cabis_data['textData'][]=['tagNum' => CABISClassification, 'tagValue' => 'Criminal Case']; 
		$case_data=$ct->query(['query' => ['type' => 'Case', 'id' => $input['case_id']]]);
			if($case_data) {
				if(is_array($case_data)) {
					if(!array_key_exists('errorCode', $case_data)) {
						$entry=$case_data[0];
						  if(array_key_exists('offenses',  $entry['details'])) {
							  foreach($entry['details']['offenses'] as $offense) {
								  $offenses.=$offense['offenseCode']['label'].' ';
							  }
						  }
						  if(strlen($offenses)) {
							$cabis_data['textData'][]=['tagNum' => Offense, 'tagValue' => $offenses];
						 }
						 
						 if(array_key_exists('caseNumber',  $entry['details'])) { 
							 $crb_no= $entry['details']['caseNumber'];
							 $cabis_data['textData'][]=['tagNum' => CRBID, 'tagValue' => $crb_no];
						 }
						  
						  if(array_key_exists('group', $entry)) {
							  $station=$entry['group']['label'];
							  $cabis_data['textData'][]=['tagNum' => PoliceStation, 'tagValue' => $entry['group']['label']];
						  }
					}
				}
			}
		if($nin) {
			$cabis_data['textData'][]=['tagNum' => NINID, 'tagValue' => $nin];
		}
		//Iterate through records and change any array to a comma separated string
		for($n=0; $n<count($cabis_data['textData']); $n++) {
			if(is_array($cabis_data['textData'][$n]['tagValue'])) {
				$cabis_data['textData'][$n]['tagValue']=implode(',',$cabis_data['textData'][$n]['tagValue']);
			}
		}
		$cabis_data['afisCategory'] = 0;
		log_message('debug', print_r($cabis_data, true));
		$cabis_link = new CABIS();
		$cabis_id=$cabis_link->submit(json_encode($cabis_data));
		$first_name=$cabis_link->getTagFromData($cabis_data, FirstName);
		$last_name=$cabis_link->getTagFromData($cabis_data, LastName);
		$name=$first_name.' '.$last_name;
		$subject_id=$this->subjectModel->insert(['case_tracking_person_id' => $input['person_id'], 'cabis_id' => $cabis_id, 'name' => $name, 'nin' => $nin, 'first_name' => $first_name, 'last_name' => $last_name]);
		$record_id=$this->subjectRecordModel->insert(['subject_id' => $subject_id, 'case_tracking_id' => $input['case_id'], 'name' => $name, 'station' => $station, 'offence' => $offenses, 'crb_no' => $crb_no]);
		//$this->caseTrackingModel->insert(['data' => json_encode($input)]);
		
		return($this->respond(['id' => $cabis_id, 'person_id' => $input['person_id']]));
	}
	
		//Receives a temporary criminal record
	public function fix_offenses()
	{
		$ct=new CaseTracking();
		$records=$this->subjectRecordModel->findAll();
		foreach($records as $record) {
			if(strlen($record['station'] ?? '')>0) {
				continue;
			}
			$station="Not specified";
			$offenses="";
			$crb_no="";
			$case_data=$ct->query(['query' => ['type' => 'Case', 'id' => $record['case_tracking_id']]]);
				if($case_data) {
					if(is_array($case_data)) {
						if(!array_key_exists('errorCode', $case_data)) {
							$entry=$case_data[0];
							  if(array_key_exists('offenses',  $entry['details'])) {
								  foreach($entry['details']['offenses'] as $offense) {
									  $offenses.=$offense['offenseCode']['label'].' ';
								  }
							  }

							
							if(array_key_exists('caseNumber',  $entry['details'])) { 
							 $crb_no= $entry['details']['caseNumber'];
						 }
											  
							  if(array_key_exists('group', $entry)) {
								  $station=$entry['group']['label'];
							  }
						}
					}
				}
			//var_dump(['station' => $station, 'offence' => $offenses, 'crb_no' => $crb_no]);
			$this->subjectRecordModel->update($record['id'], ['station' => $station, 'offence' => $offenses, 'crb_no' => $crb_no]);
		}
		
	}
	
	
	

}

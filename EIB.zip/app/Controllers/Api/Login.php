<?php 

namespace App\Controllers\Api;

use CodeIgniter\API\ResponseTrait;


//This class checks that the user has submitted a valid token and then sets up the session user id
class Login extends \App\Controllers\BaseController
{
	use ResponseTrait;
	
	private $userModel;
	private $emailModel;
	private $smsModel;
	private $cache;

	public function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->userModel = model('App\Models\UserModel');
		$this->smsModel = model('App\Models\SmsModel');
		$this->emailModel = model('App\Models\EmailModel');
		helper('ecro');
	}
		
		//user login
	public function user()
	{
		$input = $this->request->getJSON();
		log_message('debug', 'Login '.($input->username ?? ''));
		//Check if user exists
		$user = $this->userModel->getByUsername($input->username);
		if(!$user) {
			return $this->response->setStatusCode(404)->setBody(json_encode(['message' => 'User does not exist']));
		}
		$ret=$this->userModel->login($input->username, $input->password);
		if($ret==FALSE) {
			return $this->failForbidden(json_encode(['message' => 'Credentials incorrect']));
		}
		
		$token=uuid();
		$this->cache->save('TOKEN_'.$token, ['id' => $user['id']], MINUTE*60);
	
		
		$response=array('message' => 'Logged in', 'token' => $token);
		return($this->respond($response));
	}
}

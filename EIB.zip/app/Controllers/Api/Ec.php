<?php namespace App\Controllers\Api;

use CodeIgniter\API\ResponseTrait;
use App\Libraries\CABIS;
use App\Libraries\NIRA;
use App\Libraries\Oosto;
use App\Libraries\DeepFace;
use App\Libraries\Utils;


class Ec extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $subjectModel;
	protected $subjectRecordModel;
	protected $ecModel;

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->ecModel = model('App\Models\EcModel');
		$_SESSION['AJAX_TOKEN']=uuid();
		$this->cache->save('AJAX_TOKEN_'.$_SESSION['AJAX_TOKEN'],1, 24*HOUR);
		
	}
	
	public function getVoters()
	{
		$data=[];
		$input = $this->request->getJSON(true);
		log_message('debug', print_r($input, true)); 
		
		//Do basic error checking
		if(!(array_key_exists('device_id', $input))) {
			return $this->respond(['status' => 'FAILED', 'error' => [ 'message' => 'Missing fields']]);
		}
		$newRecords=true;
		if((array_key_exists('all_records', $input))) {
			$newRecords=false;
		}
		
		$voters=$this->ecModel->getNew($input['device_id'], $newRecords);
		$output=['status' => 'SUCCESS', $data=[]];
		$cabis=new CABIS();
		foreach($voters as $voter) {
			//Check if we have CABIS data for this voter
			$first_name=$cabis->getTag($voter['cabis_id'], FirstName);
			if(!$first_name) {
				continue;
			}
			$vdata=['nin' => $voter['nin'], 'first_name' => $voter['first_name'], 'last_name' => $voter['last_name'], 'date_of_birth' => $voter['date_of_birth'], 'photos' => [['source' => 'CABIS', 'data' => base64_encode($cabis->getTag($voter['cabis_id'], 705))]], 'fingerprints' => []];
			//Add fingeprints
			foreach([[RTHUMB, 'RTHUMB'], [RINDEX, 'RINDEX'], [RMIDDLE, 'RMIDDLE'], [RRING, 'RRING'], [RLITTLE, 'RLITTLE'], [LTHUMB, 'LTHUMB'], [LINDEX, 'LINDEX'], [LMIDDLE, 'LMIDDLE'], [LRING, 'LRING'], [LLITTLE, 'LLITTLE']] as $finger) {
				$fdata=$cabis->getTag($voter['cabis_id'], $finger[0]);
				if($fdata) {
					$vdata['fingerprints'][]=['name' => $finger[1], 'data' => base64_encode($fdata)];
				}
			}
			$output['data'][] = $vdata;
		}
		return json_encode($output);
	}
	
	function index()
	{
		$data=[];
		$data['records']=[];
		//$_SESSION['AJAX_TOKEN']=uuid();
		return view('header', $data)
			. view('menu', $data)
			. view('Ec/voters', $data)
			. view('footer', $data);
	}
	
	function country()
	{
		$data=[];
		$data['records']=[];
		//$_SESSION['AJAX_TOKEN']=uuid();
		return view('Ec/country', $data);
	}
	
	function pollingStations()
	{
		$data=[];
		$data['records']=[];
		//$_SESSION['AJAX_TOKEN']=uuid();
		return view('header', $data)
			. view('menu', $data)
			. view('Ec/polling_stations', $data)
			. view('footer', $data);
	}
	
	/*
		public function check()
	{
		$nira = new NIRA;
		$input = $this->request->getJSON(true);
		$person=$nira->getPerson($input['nin'] ?? '', false);
		$voter_data=$this->ecModel->search(['nin' => $input['nin'] ?? '']);
		if(count($voter_data)) {
			$person['enrolled']=true;
		} else {
			$person['enrolled']=false;
		}
		$person['status'] = 'SUCCESS';
		return json_encode($person);
	}
	*/
	
	public function check()
	{
		$nira = new NIRA();
		log_message('debug', '1');
		$input = $this->request->getJSON(true);
		log_message('debug', json_encode($input, true));
		//Set an AJAX token
		$_SESSION['TOKEN']=uuid();
		$this->cache->save('TOKEN_'.$_SESSION['TOKEN'],'api', 1*HOUR);
		//log_message('debug', print_r($input, true));
		$person=null;
		$match_photo=$match_fingerprint=0;
		$error="000";
		//Check person
		if(strlen($input['nin'] ?? '')) {
			$person=$this->ecModel->getByNin($input['nin']);
		}
		
		if(!strlen($input['device_id'] ?? '')) {
			return $this->respond(['status' => 'FAILED', 'error' => '004', 'message' => 'Device ID not specified']);
		}
		
		if(!$person) {
			return $this->respond(['status' => 'FAILED', 'error' =>  '003', 'message' => 'Voter details not found']);
			$this->cache->save('notFound', $this->cache->get('notFound')+1, MONTH);
		}
		log_message('debug', '5');
		if($person['voted']==1) {
			return $this->respond(['status' => 'FAILED', 'error' =>  '001', 'message' => 'Person already voted']);
			$this->cache->save('alreadyVoted', $this->cache->get('alreadyVoted')+1, MONTH);
		}
		$pollingStations=['Kinanira Zone A1', 'Busanza Zone C2', 'Kyaliwajala Zone C3', 'Komamboga Dungu Zone 4','Kira Bulindo Station A5'];
		if($person['polling_station_id'] != $input['device_id'] ?? '') {
			return $this->respond(['status' => 'FAILED', 'error' =>  '002', 'message' => 'Wrong polling station', 'polling_station' =>$pollingStations[$person['polling_station_id']]]);
			$this->cache->save('incorrectPollingStation', $this->cache->get('incorrectPollingStation')+1, MONTH);
		}
		
		//Get NIRA photo
		if(strlen($input['nin'] ?? '')==14 && !(strlen($input['fingerprint'] ?? '') || strlen($input['photo'] ?? '') )) {
			$nin=$nira->getPerson($input['nin']);
			if(!strlen($nin['nationalId'] ?? '')) {
				return $this->respond(['status' => 'FAILED', 'error' =>  '003', 'message' => 'National ID details not found']);
			}
			//Else return the national ID details
			$person=$this->ecModel->getByNin($input['nin']);
			$photo_link=base_url('ajax/get_external_photo?token='.$_SESSION['TOKEN'].'&external_id='.$nin['nationalId']);
			return $this->respond(['status' => 'SUCCESS', 'error' =>  '000', 'message' => 'National ID recognized successfully', 'first_name' => $nin['givenNames'], 'last_name' => $nin['surname'], 'photo' => $photo_link, 'nin' => $nin['nationalId'], 'match_photo'=>$match_photo, 'match_fingerprint' => $match_fingerprint, 'polling_station' => '']);
		}
		
		log_message('debug', '2');
		//Get NIRA photo
		$nin=$nira->getPerson($input['nin']);
		
		//Check if we can use the fingerprint
		if($person && strlen($input['fingerprint'] ?? '')) {
			//Remove image type preamble at the beginning
			if(strstr($input['fingerprint'], 'data:image/jpeg;base64,')) {
				$input['fingerprint']=substr($input['fingerprint'], 23);
				//log_message('debug', 'Fingerprint '.substr($input['fingerprint'],0,10));
			}
			//Convert image to PNG
			log_message('debug', '3.1');
			$image = new \Imagick();
			//$image->setImageUnits(\Imagick::RESOLUTION_PIXELSPERINCH);
			//$image->setResolution(500, 500);
			
			$image->readImageBlob(base64_decode($input['fingerprint']));
			// convert the output to png
			$image->trimImage(0.1);
			$image->setImageFormat('png');
			$input['fingerprint']= $image->getImageBlob();
			//Save image and CABIS image to a file
			$submitted_fingerprint=uuid().".png";
			$cabis_fingerprint=uuid().".png";
			if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
				file_put_contents(__DIR__."\..\..\..\writable\\tmp\\$submitted_fingerprint", $input['fingerprint']);
			} else {
				file_put_contents(__DIR__."/../../../writable/tmp/$submitted_fingerprint", $input['fingerprint']);
			}
			//Get CABIS fingerprint based on what's supplied
			$finger_spec=LINDEX;
			foreach([[RTHUMB, 'RTHUMB'], [RINDEX, 'RINDEX'], [RMIDDLE, 'RMIDDLE'], [RRING, 'RRING'], [RLITTLE, 'RLITTLE'], [LTHUMB, 'LTHUMB'], [LINDEX, 'LINDEX'], [LMIDDLE, 'LMIDDLE'], [LRING, 'LRING'], [LLITTLE, 'LLITTLE']] as $finger) {
				if($input['finger'] == $finger[1]) {
					log_message('debug', "Got finger {$finger[1]}");
					$finger_spec=$finger[0];
				}
			}
	
			$fingerprint_link=base_url('ajax/get_cabis?id='.$person['cabis_id'].'&tag='.$finger_spec);
			log_message('debug', $fingerprint_link);
			$fingerprint=file_get_contents($fingerprint_link);
			if(strlen($fingerprint ?? '')>100) {
				if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
					file_put_contents(__DIR__."\..\..\..\writable\\tmp\\$cabis_fingerprint", $fingerprint);
					$cmd="\"C:\Program Files\Common Files\Oracle\Java\javapath\java.exe\" -jar ".__DIR__."\..\..\..\scripts\\fingerprint.jar ".__DIR__."\..\..\..\writable\\tmp\\$submitted_fingerprint ".__DIR__."\..\..\..\writable\\tmp\\$cabis_fingerprint";
				} else {
					file_put_contents(__DIR__."/../../../writable/tmp/$cabis_fingerprint", $fingerprint);
					$cmd="java -jar ".__DIR__."/../../../scripts/fingerprint.jar ".__DIR__."/../../../writable/tmp/$submitted_fingerprint ".__DIR__."/../../../writable/tmp/$cabis_fingerprint";
				}
				log_message('debug', $cmd);
				$return=shell_exec($cmd);
				if(strstr($return, 'MATCH')) {
					$match_fingerprint=1;
				}
			}
			//If a fingerprint but not photo has been sent stop
			if($match_fingerprint!=1 && !strlen($input['photo'] ?? '')) {
				return $this->respond(['status' => 'FAILED', 'error' =>  '005', 'message' => 'Fingerprint not verified']);
			}
		}
            
		log_message('debug', '4');
		
		//Check if we can use the photograph
		if($person && strlen($input['photo'] ?? '')) {
			//Convert photo to PNG
			//Remove image type preamble at the beginning
			if(strstr($input['photo'], 'data:image/jpeg;base64,')) {
				$input['photo']=substr($input['photo'], 23);
			}
			$image = new \Imagick();
			$image->readImageBlob(base64_decode($input['photo']));
			// convert the output to png
			$image->setImageFormat('png');
			$input['photo']= $image->getImageBlob();
			//Save image and CABIS image to a file
			$submitted_photo=uuid().".png";
			$cabis_photo=uuid().".png";
			if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
				file_put_contents(__DIR__."\..\..\..\writable\\tmp\\$submitted_photo", $input['photo']);
			} else {
				file_put_contents(__DIR__."/../../../writable/tmp/$submitted_photo", $input['photo']);
			}
			$photo_link=base_url('ajax/get_cabis?id='.$person['cabis_id'].'&tag=705');
			$photo=file_get_contents($photo_link);
			if(strlen($photo ?? '')>100) {
				
				if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
					file_put_contents(__DIR__."\..\..\..\writable\\tmp\\$cabis_photo", $photo);
					$cmd=__DIR__."\..\..\..\scripts\\face_match.bat ".__DIR__."\..\..\..\writable\\tmp\\$submitted_photo ".__DIR__."\..\..\..\writable\\tmp\\$cabis_photo";
				} else {
					file_put_contents(__DIR__."/../../../writable/tmp/$cabis_photo", $photo);
					$cmd=__DIR__."/../../../scripts/face_match.sh ".__DIR__."/../../../writable/tmp/$submitted_photo ".__DIR__."/../../../writable/tmp/$cabis_photo";
				}
				log_message('debug', $cmd);
				$return=shell_exec($cmd);
				log_message('debug', PHP_OS);
				if(strstr($return, 'MATCH')) {
					$match_photo=1;
				}
			}
			if($match_photo!=1) {
				return $this->respond(['status' => 'FAILED', 'error' =>  '005', 'message' => 'Photo not verified']);
			}
		}
		
		
		
		if($match_photo==1 || $match_fingerprint==1) {
			$this->ecModel->update($person['id'], ['voted' => 1]);
		}
		$photo_link=base_url('ajax/get_cabis?token='.$_SESSION['TOKEN'].'&id='.$person['cabis_id'].'&tag=705');
		$photo=file_get_contents($photo_link);
		log_message('debug', 'PHOTO length is '.strlen($photo ?? ''));
		if(strlen($photo ?? '')< 5000) { //Use the Oosto photo
			$photo_link=base_url('ajax/get_external_photo?token='.$_SESSION['TOKEN'].'&external_id='.$person['oosto_id']);
		}
		log_message('debug', print_r(['status' => 'SUCCESS', 'error' =>  '000', 'message' => 'Voter recognized successfully', 'first_name' => $person['first_name'], 'last_name' => $person['last_name'], 'photo' => $photo_link, 'nin' => $person['nin'], 'match_photo'=>$match_photo, 'match_fingerprint' => $match_fingerprint, 'polling_station' => $pollingStations[$person['polling_station_id']-1]], true));
		return $this->respond(['status' => 'SUCCESS', 'error' =>  '000', 'message' => 'Voter recognized successfully', 'first_name' => $person['first_name'], 'last_name' => $person['last_name'], 'photo' => $photo_link, 'nin' => $person['nin'], 'match_photo'=>$match_photo, 'match_fingerprint' => $match_fingerprint, 'polling_station' => $pollingStations[$person['polling_station_id']-1]]);
		
	}
	
	public function reset()
	{
		$this->ecModel->reset();
		return("Database reset");
	}
	
	public function enroll()
	{
		$input = $this->request->getJSON(true);
		$id=$this->ecModel->insert(['nin' => $input['nin'], 'phone' => $input['phone'], 'email' => $input['email']]);
		log_message('debug', print_r($input, true));
		return(json_encode(['status' => 'SUCCESS']));
	}
	
	public function assignBallot()
	{
		$input = $this->request->getJSON(true);
		if(empty($input['nin'])) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Empty NIN supplied']));
		}
		if(empty($input['ballot'])) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Empty ballot supplied']));
		}
		$ballot=$this->ecModel->getBallot($input['ballot']);
		if(empty($ballot)) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Unknown ballot number supplied']));
		}
		if($ballot['status'] != 'UNUSED') {
			return($this->respond(['status' => 'FAILED', 'message' => 'Ballot paper has already been used']));
		}
		$this->ecModel->updateBallot($input['ballot'], 'USED');
		return($this->respond(['status' => 'SUCCESS', 'message' => 'Ballot paper accepted']));
	}
	
	public function checkBallot()
	{
		$input = $this->request->getJSON(true);
		if(empty($input['ballot'])) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Empty ballot supplied']));
		}
		$ballot=$this->ecModel->getBallot($input['ballot']);
		if(empty($ballot)) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Unknown ballot number supplied']));
		}
		if($ballot['status'] == 'UNUSED') {
			return($this->respond(['status' => 'SUCCESS', 'message' => 'Ballot paper has not been used']));
		}
		if($ballot['status'] == 'CHECKED') {
			return($this->respond(['status' => 'SUCCESS', 'message' => 'Ballot paper has been checked']));
		}
		if($ballot['status'] == 'USED') {
			//$this->ecModel->updateBallot($input['ballot'], 'CHECKED');
			return($this->respond(['status' => 'SUCCESS', 'message' => 'Ballot paper was been successfully used by voter']));
		}
	}
		
	
	public function search()
	{
		$data=[];
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$voter_data=$this->ecModel->search(['cabis_id' => $this->request->getVar('cabis_id'), 'nin' => $this->request->getVar('nin'), 'first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'polling_station_id' => $this->request->getVar('polling_station_id')]);
		$data['records']=[];
		foreach($voter_data as $record) {
			if($record['polling_station_id']==1) {
				$record['polling_station']='Police HQ 1';
			} else {
				$record['polling_station']='Police HQ 2';
			}
			$data['records'][]=$record;
		}
		return view('header', $data)
			. view('menu', $data)
			. view('Ec/voters', $data)
			. view('footer', $data);
	}
	
	public function add()
	{
		$data=[];
		return view('header', $data)
			. view('menu', $data)
			. view('Ec/add_voter', $data)
			. view('footer', $data);
	}
	
	public function submit()
	{
		$data=[];
		//Do basic error checking
		if(!$this->request->getVar('first_name') || !$this->request->getVar('last_name') || !$this->request->getVar('nin')) {
			$this->session->setFlashdata('errorMessage', 'Missing data items, record ignored'); 
			$this->session->setFlashdata('errorTitle', 'Missing data'); 
			return redirect()->to('ec/index');
		}
		
		//Find out if person has already been registered
		$person=$this->ecModel->getByNin($this->request->getVar('nin'));
		if($person) {
			$this->session->setFlashdata('errorMessage', 'Person already registered'); 
			$this->session->setFlashdata('errorTitle', 'Duplicate'); 
			return redirect()->to('ec/index');
		}
		
		//Submit the data to CABIS and get an ID
		$reference=$this->request->getVar('nin');
		$cabis_data=[];
		$dob_fields=explode("/", $this->request->getVar('date_of_birth'));
		$dob=$dob_fields[2].'-'.$dob_fields[1].'-'.$dob_fields[0];
		$cabis_data['textData']=[['tagNum' => '110', 'tagValue' => $this->request->getVar('last_name')],['tagNum' => '111', 'tagValue' => $this->request->getVar('first_name')],['tagNum' => '3319', 'tagValue' => 'CIVIL'],['tagNum' => '3309', 'tagValue' => $this->request->getVar('nin')],['tagNum' => '3320', 'tagValue' => $this->request->getVar('nin')], ['tagNum' => NINID, 'tagValue' => $this->request->getVar('nin')], ['tagNum' => DateOfBirth, 'tagValue' => $dob]];
		$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '']]; 
		$cabis = new CABIS();
		$cabis_id=$cabis->submit(json_encode($cabis_data));
		if($cabis_id) {
			$id=$this->ecModel->insert(['first_name' => $this->request->getVar('first_name'), 'last_name' => $this->request->getVar('last_name'), 'nin' => $this->request->getVar('nin'), 'date_of_birth' => $dob, 'polling_station_id' => $this->request->getVar('polling_station_id'),'cabis_id' => $cabis_id]);
			$this->session->setFlashdata('message', 'Data uploaded, please proceed to take fingeprints<br>'); 
			$this->session->setFlashdata('messageTitle', 'Success'); 
			return redirect()->to('ec/index');
		} else {
			$this->session->setFlashdata('errorMessage', 'Data upload failed'); 
			$this->session->setFlashdata('errorTitle', 'Failed'); 
			return redirect()->to('ec/index');
		}
		
	}
	
	public function view($id)
	{
		$data=[];
		session_write_close();
		$cabis=new CABIS();
		$nira=new NIRA();
		$data['record']=$this->ecModel->find($id);
		if($data['record']['polling_station_id']==1) {
			$data['record']['polling_station']='Police HQ 1';
		} else {
			$data['record']['polling_station']='Police HQ 2';
		}
		$data['nin']=$nira->getPerson($data['record']['nin']);
		$data['cabis_present']=$cabis->getTag($data['record']['cabis_id'], '105');
		$data['record']['status']= ($data['cabis_present'] != null) ? "COMPLETED" : "PENDING";

		
		return view('header', $data)
			. view('menu', $data)
			. view('Ec/voter', $data)
			. view('footer', $data);
	}
	
	function dashboard()
	{
		$data=[];
		$data['records']=[];
		//$_SESSION['AJAX_TOKEN']=uuid();
		$data['station1Voters']=$this->ecModel->getVoters(1);
		$data['station2Voters']=$this->ecModel->getVoters(2);
		$data['station1VerifiedVoters']=$this->ecModel->getVoters(1,1);
		$data['station2VerifiedVoters']=$this->ecModel->getVoters(2,1);
		$data['alreadyVoted']=$this->cache->get('alreadyVoted') ?? 0;
		$data['notFound']=$this->cache->get('notFound') ?? 0;
		$data['incorrectPollingStation']=$this->cache->get('incorrectPollingStation') ?? 0;
		$data['femaleVoters']=$this->ecModel->getFemaleVoters();
		$data['maleVoters']=$this->ecModel->getMaleVoters();
		$data['youthVoters']=$data['middleVoters']=$data['olderVoters']=0;
		$voters=$this->ecModel->findAll();
		foreach($voters as $voter) {
			if(strlen($voter['nin'])) {
				$yob=(int) substr($voter['nin'], 2,2);
				if($yob<10) {
					$yob+=100;
				}
				if($yob<64) {
					$data['olderVoters']++;
					continue;
				}
				if($yob<94) {
					$data['middleVoters']++;
					continue;
				}
				$data['youthVoters']++;
			}
		}
		return view('header', $data)
			. view('menu', $data)
			. view('Ec/voter_dashboard', $data)
			. view('footer', $data);
	}

}

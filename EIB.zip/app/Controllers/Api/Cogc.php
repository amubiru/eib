<?php namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Libraries\CABIS;


class Cogc extends ResourceController
{

	use ResponseTrait;
	
	protected $cache;
	protected $cabisModel;
	protected $cogcModel;
	protected $subjectModel;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->cabisModel = model('App\Models\CabisModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->subjectModel = model('App\Models\SubjectModel');
	}

	//This receives the application data
	public function application()
	{
		$input = $this->request->getJSON(true);
		log_message('debug', print_r($input, true));
		//Check if this PRN has been received before
		$records=$this->cogcModel->getByPRN($input['prn']);
		if(count($records)) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Duplicate application']));
		}

		//Save the record
		$cabis_data=[];
		$cert_type='';
		$application_category='CIVILIAN';
		if(trim($input['TransactionType'])=='PSO Application') {
			$cabis_data['afisCategory'] = 1;
			$cert_type='PSO';
			$application_category='PSO';
		} else {
			$cabis_data['afisCategory'] = 2;
				if($input['Service_Type'] == 'COGC' || strstr($input['Service_Type'], 'Good Conduct')) {
				$cert_type='COGC';
			} else {
				$cert_type='PCC';
			}
		}
		$cabis_data['textData']=[['tagNum' => LastName, 'tagValue' => trim($input['LastName'])],['tagNum' => FirstName, 'tagValue' => trim($input['FirstName'])],['tagNum' => MiddleName, 'tagValue' => trim($input['MiddleName'])],['tagNum' => '3319', 'tagValue' => 'CIVIL'],['tagNum' => '3309','tagValue' => trim($input['prn'])],['tagNum' => '3320', 'tagValue' => trim($input['ApplicationNumber'])], ['tagNum' => Contact, 'tagValue' => trim($input['TelephoneNo'])], ['tagNum' => ApplicationType, 'tagValue' => $cert_type]];
		$id_type='';
		$id_number='';
		if(strlen($input['NIN'] ?? '') > 4) {
			$cabis_data['textData'][]=['tagNum' => NINID, 'tagValue' => trim($input['NIN'])];
			$id_type='NIN';
			$id_number=trim($input['NIN']);
		}
		if(($input['Gender'] ?? '') == 'Male') {
			$cabis_data['textData'][]=['tagNum' => Sex, 'tagValue' => 1];
		}
		if(($input['Gender'] ?? '') == 'Female') {
			$cabis_data['textData'][]=['tagNum' => Sex, 'tagValue' => 2];
		}
		$dob_only=explode(' ', $input['DOB']);
		$dob_parts=explode('/', $dob_only[0]);
		if(count($dob_parts)==3) {
			$date_of_birth=$dob_parts[2].'-'.$dob_parts[0].'-'.$dob_parts[1];
			$cabis_data['textData'][]=['tagNum' => DateOfBirth, 'tagValue' => $date_of_birth];
		}
		if(strlen($input['PassportNo']) > 4) {
			$cabis_data['textData'][]=['tagNum' => DocumentType, 'tagValue' => 'PASSPORT'];
			$cabis_data['textData'][]=['tagNum' => DocumentNumber, 'tagValue' => trim($input['PassportNo'])];
			if(!$id_type) {
				$id_type='PASSPORT';
				$id_number=trim($input['PassportNo']);
			}
		} elseif(strlen($input['RefugeeCardNo']) > 4) {
			$cabis_data['textData'][]=['tagNum' => DocumentType, 'tagValue' => 'REFUGEE CARD'];
			$cabis_data['textData'][]=['tagNum' => DocumentNumber, 'tagValue' => $input['RefugeeCardNo']];
			if(!$id_type) {
				$id_type='PASSPORT';
				$id_number=trim($input['RefugeeCardNo']);
			}
		}
		$cabis_data['textData'][]=['tagNum' => Nationality, 'tagValue' => $input['Nationality']];
		$cabis_data['textData'][]=['tagNum' => Address, 'tagValue' => $input['PlaceOfResidence']];
		$cabis_data['textData'][]=['tagNum' => Height, 'tagValue' => $input['Height']];
		
		$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '']];
		
		$cabis = new CABIS();
		$cabis_id=$cabis->submit(json_encode($cabis_data));
		if($cabis_id) {
			//Create the subject and subject_record
			$subject_id=$this->subjectModel->create(['name' => $input['FirstName']." ".$input['LastName'], 'first_name' => $input['FirstName'], 'last_name' => $input['LastName'], 'cabis_id' => $cabis_id, 'nin' => trim($input['NIN'])]);
			$db_data=['first_name' => trim($input['FirstName']), 'middle_name' => trim($input['MiddleName']), 'last_name' => trim($input['LastName']), 'email' => $input['EmailAddress'], 'phone' => $input['TelephoneNo'], 'id_type' => $id_type, 'id_number' => $id_number, 'prn' => trim($input['prn']), 'type' => $input['Service_Type'],'subject_id' => $subject_id, 'application_category' => $application_category, 'uuid' => uuid(), 'raw_content' => json_encode($input)];
			$this->cogcModel->insert($db_data);
			return($this->respond(['status' => 'SUCCESS', 'message' => 'Application received']));
		} else {
			return($this->respond(['status' => 'FAILED', 'message' => 'Failed to create CABIS record']));
		}
			
	}
	
	//This returns if this subject has previous data
	public function getGroupId()
	{
		$input = $this->request->getJSON(true);
		if(empty($input['group_id'])) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Empty Group ID supplied']));
		}
		
		//All new Group IDs begin with 34
		if(!preg_match("/^34/",$input['group_id'])) {
			return($this->respond(['status' => 'FAILED', 'message' => 'Invalid Group ID supplied']));
		}
		$cabis = new CABIS();
		$record=$cabis->getInfoByTag(NewGroupId, $input['group_id']);
		if(!empty($record)) {
			$ret=[];
			$ret['FirstName']=$cabis->getTagFromData($record, FirstName);
			$ret['MiddleName']=$cabis->getTagFromData($record, MiddleName);
			$ret['LastName']=$cabis->getTagFromData($record, LastName);
			$ret['Photo']=base64_encode($cabis->getTagFromData($record, FacePhoto));
			return($this->respond(['status' => 'SUCCESS', 'message' => 'Group ID exists', 'details' => $ret]));
		} else {
			return($this->respond(['status' => 'FAILED', 'message' => "Group ID {$input['group_id']} not found"]));
		}
	}

	
}

<?php namespace App\Controllers\Api;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Libraries\Oosto;
//use App\Libraries\CABIS;


class Cabis extends ResourceController
{

	use ResponseTrait;
	
	protected $cache;
	protected $cabisModel;
	protected $cogcModel;
	protected $subjectModel;


	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->cabisModel = model('App\Models\CabisModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->subjectModel = model('App\Models\SubjectModel');
	}

	//Input
	/*
	 *     + AFIS (demographics and biometrics)
        -> string fields for demographics (such as name, surname, date of birth etc..)
        -> base64 fields for biometrics (such as thumb finger, index finger, photo etc..)
    + CPN (Criminal police number)
        -> string or int field based on CPN type.
    + NIN (National ID number)
        -> string or int field based on NIN type.
    + non-criminal hits
        -> boolean data for whether criminal or noncriminal record.
        */
     //Output shows whether record created or updated
	function subject_data()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$input = $this->request->getJSON(true);
		log_message('debug', 'FROM CABIS: '.$input['subject_id']);
		//Get base record
		$base_record=['subject_id' => $input['subject_id'], 'request_id' => $input['request_id'], 'nin' => $input['nin'], 'type' => $input['type']];
		$cabis_record=$this->cabisModel->createRecord($base_record);
		//For now try to get the record from the subject id
		$subject=$this->subjectModel->getByCabisId($input['subject_id']);
		if($subject) {
			//See if this is a current Civilian record
			$cogcs=$this->cogcModel->getBySubjectId($subject['id']);
			$cogc=end($cogcs);
			if($cogc) { //Check if it is pending, if so, set it to state prints taken
				if($cogc['status']=='PENDING') {
					$this->cogcModel->update($cogc['id'], ['status' => 'FINGERPRINT', 'fingerprint_date' => date('Y-m-d H:i:s')]);
				}
			}
		}
		//Now populate the various fields
		foreach($input['afis']['demographics'] as $dmg) {
			$dmg['record_id']=$cabis_record['id'];
			$this->cabisModel->addDemographics($dmg);
		}
		//Don't save biometrics to save on space
		/*
		foreach($input['afis']['biometrics'] as $bio) {
			$bio['record_id']=$cabis_record['id'];
			$this->cabisModel->addBiometrics($bio);
		} */ 
		//Retreive record so that it is in external data
		//$cabis=new CABIS();
		//$cabis->getTag($input['subject_id'], '105');
		
		//Return response
		if($cabis_record['original_id']!=FALSE) {
			return($this->respond(['message' => 'UPDATED', 'id' => $cabis_record['id'], 'original_id' => $cabis_record['original_id']]));
		} else {
			//Create record in Ooosto
			//$image=file_get_contents(base_url('ajax/get_cabis?id='.$record['subject_id'].'&tag=705'));
			return($this->respond(['message' => 'CREATED', 'id' => $cabis_record['id'], 'original_id' => $cabis_record['id']]));
		}
	}
	
	//This receives the form that requests for an identification request
	public function identification_request()
	{
		$input = $this->request->getJSON(true);
		return($this->respond(['identification_id' =>  rand(10000,100000)]));
	}
	
	//This receives the fingeprint data
	public function submit_fingerprints()
	{
		$input = $this->request->getJSON(true);
		return($this->respond(['identification_id' => $input['identification_id'], 'status' => 'SUBMITTED']));
	}
	
	function hit()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$input = $this->request->getJSON(true);
		log_message('debug', 'HIT status: '.print_r($input, true));
		if(!(array_key_exists('cabis_id', $input) && array_key_exists('hit_id', $input) && array_key_exists('cabis_type', $input) && array_key_exists('hit_type', $input) && array_key_exists('hit', $input))) {
			return($this->respond(['message' => 'Missing fields', 'status' => 'FAILED']));
		}
		return($this->respond(['message' => 'Hit status updated', 'status' => 'SUCCESS']));
	}
	
}

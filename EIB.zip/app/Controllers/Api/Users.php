<?php namespace App\Controllers\Api;

use CodeIgniter\API\ResponseTrait;


class Users extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $userModel;

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->userModel = model('App\Models\UserModel');
		
	}

	//Create a user
	public function create()
	{
		//Check if user exists
		$user = $this->userModel->getByUsername($this->request->getVar('username'));
		if($user) {
			return $this->failResourceExists("Account already exists");
		}
		$id=$this->userModel->create(array('name' => $this->request->getVar('name'), 'password' => $this->request->getVar('password'), 'username' => $this->request->getVar('username')));
		if(!$id) {
			return $this->respond("An unkown error occurred", 500);
		} else {
			return($this->respondCreated(array('id' => $id)));
		}
	}



	//Returns information about a specific user ID
	public function show($reqId)
	{
		//Check if user exists
		$user = $this->userModel->getByToken($this->request->getHeader('token'));
		if(!$user) {
			return $this->Unauthorized();
		}
		$reqUser=$this->userModel->find($reqId);
		if(!$reqUser) {
			return $this->failNotFound();
		}
		//Sanitize data
		unset($reqUser['salt']);
		unset($reqUser['password']);
		return($this->respond($reqUser));
	}

	

}

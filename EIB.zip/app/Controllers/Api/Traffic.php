<?php namespace App\Controllers\Api;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;
use App\Libraries\CaseTracking;
use App\Libraries\NIRA;
use App\Libraries\Oosto;
use App\Libraries\Utils;
use GuzzleHttp\Client;


class Traffic extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $subjectModel;
	protected $subjectRecordModel;
	protected $driverModel;
	protected $unverifiedModel;
	protected $trafficOffenseModel;
	protected $broadcastModel;
	protected $cameraBroadcastModel;
	protected $offenseModel;

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
		$this->driverModel = model('App\Models\DriverModel');
		$this->unverifiedModel = model('App\Models\UnverifiedModel');
		$this->trafficOffenseModel = model('App\Models\TrafficOffenseModel');
		$this->broadcastModel = model('App\Models\BroadcastModel');
		$this->cameraBroadcastModel = model('App\Models\CameraBroadcastModel');
		$this->offenseModel = model('App\Models\OffenseModel');
		
	}
	
	public function criminalOffenses()
	{
		$offenses=$this->offenseModel->findAll();
		$response=['status' => 'SUCCESS', 'offenses' => $offenses];
		return $this->respond($response);
	}
	
	public function driverEnroll()
	{
		$data=[];
		$input = $this->request->getJSON(true);
		log_message('debug', print_r($input, true)); 
		//Do basic error checking
		if(!(array_key_exists('first_name', $input) && array_key_exists('last_name', $input) && array_key_exists('nin', $input) && array_key_exists('driving_license', $input) && array_key_exists('stage', $input))) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E01', 'message' => 'Missing fields']]]);
		}
		
		$drivers=$this->driverModel->search(['nin' => $input['nin']]);
		if(count($drivers)>0) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E02', 'message' => 'Already registered']]]);
		}
		$drivers=$this->driverModel->search(['driving_license' => $input['driving_license']]);
		if(count($drivers)>0) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E02', 'message' => 'Already registered']]]);
		}
		
		//All good add, the record

		$db_data=['stage' => $input['stage'], 'first_name' => $input['first_name'], 'last_name' => $input['last_name'], 'phone' => $input['phone'], 'driving_license' => $input['driving_license'], 'nin' => $input['nin'], 'number_plate' => $input['number_plate']];
			
		$record_id=$this->driverModel->insert($db_data);		
		//Submit the data to CABIS
		$reference="UD".sprintf("%06d", $record_id);
		$cabis_data=[];
		$cabis_data['textData']=[['tagNum' => '110', 'tagValue' => $input['last_name']],['tagNum' => '111', 'tagValue' => $input['first_name']],['tagNum' => '3319', 'tagValue' => 'CIVILIAN'],['tagNum' => '3320', 'tagValue' => $reference], ['tagNum' => '3326', 'tagValue' => $input['nin']], ['tagNum' => '3309', 'tagValue' => $input['nin']]];
		$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '']]; 
		$cabis = new CABIS();
		$cabis_id=$cabis->submit(json_encode($cabis_data));
		$this->driverModel->update($record_id, ['cabis_id' => $cabis_id]);
		return $this->respond(['status' => 'SUCCESS', 'driver_id' => $reference]); 
	}
	
	public function personEnroll()
	{
		$data=[];
		$nira=new NIRA();
		$input = $this->request->getJSON(true);
		log_message('debug', print_r($input, true)); 		
		//Do basic error checking
		if(!(array_key_exists('first_name', $input) && array_key_exists('last_name', $input))) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E01', 'message' => 'Missing fields']]]);
		}
		
		$linked_id=null;
		//Check if the person is already in the system so as to link the records
		//Check for photo
		if(strlen($input['photo'] ?? '')>1) {
			log_message('debug', 'Checking photo');
			$oosto = new Oosto();
			$inquiryId=$oosto->analyzeFile(base64_decode($input['photo']), 'png');
			for($count=0;$count<10;$count++) { //Wait for up to 10 seconds
				sleep(1);
				$result=$oosto->getInquiryResults($inquiryId);
				log_message('debug', print_r($result, true));
				if($result['status'] == 'DONE') {
					foreach($result['subjects'] as $oosto_subject) {
						$subject=$this->subjectModel->getByOostoId($oosto_subject['id']);
						if($subject) {
							return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E02', 'message' => 'Person is already enrolled with CABIS ID '.$subject['cabis_id']]]]);
						} else { //No subject ID, find the linked id if any
							$person=$this->unverifiedModel->getByOostoId($oosto_subject['id']);
							if($person) {
								$linked_id=$this->unverifiedModel->getFirstLink($person['id']);
								break;
							}
						}
					}
				}
			}
		}
		
		//Check the ID
		if($input['id_type']=='NIN') {
			$nin=$nira->getPerson($input['id_number']);
			if($nin) {
				$input['verified_id']=1;
			}
		}
		
		if($input['id_type']=='LICENSE') {
			$license=$nira->getLicense($input['id_number']);
			if($license) {
				$input['verified_id']=1;
			}
		}
		
		
		//All good add, the record
		if($linked_id) {
			$input['linked_id']=$linked_id;
			$input['link_type']='UNVERIFIED';
		}
		$record_id=$this->unverifiedModel->insert($input);		
		//Submit the data to Oosto
		$oosto=new Oosto();
		$oosto_id=$oosto->addSubject($input['first_name'].' '.$input['last_name'], base64_decode($input['photo']));
		$this->unverifiedModel->update($record_id, ['oosto_id' => $oosto_id]);
		return $this->respond(['status' => 'SUCCESS', 'id' => $record_id]); 
	}

	//Query information about a traffic stop
	public function query()
	{
		$nira=new NIRA();
		$cabis=new CABIS();
		
		//Set an AJAX token
		$_SESSION['AJAX_TOKEN']=uuid();
		log_message('debug', 'AJAX TOKEN '.$_SESSION['AJAX_TOKEN']);
		$this->cache->save('AJAX_TOKEN_'.$_SESSION['AJAX_TOKEN'],'api', 1*HOUR); 
		//$data = $this->request->getRawInput();
		//log_message('debug', print_r($data, true));
		$input = $this->request->getJSON(true);
		log_message('debug', print_r($input, true)); 
		if(!is_array($input)) {
			return $this->respond(['status' => 'FAILED', 'message' => 'Did not submit any data']);
		}
			
		
		$response=['status' => 'SUCCESS', 'data' => ['match' => 0, 'aliases' => []]];
		/*
		$response=['status' => 'SUCCESS', 'data' => ['match' => 1]];
		$response['data']['name'] = 'David Mugisha';
		$response['data']['cabis_id'] = '236';
		$response['data']['match'] = 1;
		$response['data']['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='."236".'&tag=705');
		$response['data']['criminal_offenses'][]=['date' => '2023-09-10',  'offense' => 'Skipped bail'];
		$response['data']['red_list']=true;
		return $this->respond($response);
		*/
		$cabis_image_search=false;
		$cabis_ids=[]; //These are CABIS IDs we will check
		//If there is a fingerprint, check it
		if(strlen($input['leftthumb'] ?? '')>10) {
			$cabis_image_search=true;
			//Remove image type preamble at the beginning
			if(strstr($input['leftthumb'], 'data:image/jpeg;base64,')) {
				$input['leftthumb']=substr($input['leftthumb'], 23);
				log_message('debug', 'Fingerprint '.substr($input['leftthumb'],0,10));
			}
		}
		
		if(strlen($input['rightthumb'] ?? '')>10) {
			$cabis_image_search=true;
			//Remove image type preamble at the beginning
			if(strstr($input['rightthumb'], 'data:image/jpeg;base64,')) {
				$input['rightthumb']=substr($input['rightthumb'], 23);
				log_message('debug', 'Fingerprint '.substr($input['rightthumb'],0,10));
			}
		}
		
		if(strlen($input['photo'] ?? '')>1) {
			log_message('debug', 'Checking photo');
			
			$input['photo']=base64_encode(Utils::sharpenImage(base64_decode($input['photo'])));
			$cabis_image_search=true;
		}
		if($cabis_image_search==true) {
			$cabis=new CABIS();
			$cabis_search_data=[];
			if(strlen($input['leftthumb'] ?? '')>10) { //Fingerprint preprocessing
			
			$file = tmpfile();
			fwrite($file, base64_decode($input['leftthumb']));
			$path = stream_get_meta_data($file)['uri'];
			$image = new \Imagick();
			$image->readImage($path);
            $image->setImageFormat("png");
            $image->setImageUnits(\Imagick::RESOLUTION_PIXELSPERINCH);
			$image->setImageResolution(500,500);
			//$image->cropImage(330,490,360,256);
			$image->trimImage(0.1);
            $png= $image->getImageBlob();
            $image->setImageFormat("tiff");
            $tiff= $image->getImageBlob();
            log_message('debug', 'PNG');
            //Save both images for review
            /*
            $save_time=date("YmdHis");
            file_put_contents(__DIR__."\\..\\..\\..\\..\\fingers\\".$save_time."_left_original.png", base64_decode($input['leftthumb']));
            file_put_contents(__DIR__."\\..\\..\\..\\..\\fingers\\".$save_time."_left.png", $png);
            file_put_contents(__DIR__."\\..\\..\\..\\..\\fingers\\".$save_time."_left.tiff", $tiff);
            */
            //log_message('debug', base64_encode($png));            
			//$cabis_response=$cabis->findFinger('RIndexFinger', base64_encode($tiff)); - No longer works
			$cabis_search_data[]=['name' => 'leftThumbFile', 'content' => $png];
		}
		if(strlen($input['rightthumb'] ?? '')>10) { //Fingerprint preprocessing
			
			$file = tmpfile();
			fwrite($file, base64_decode($input['rightthumb']));
			$path = stream_get_meta_data($file)['uri'];
			$image = new \Imagick();
			$image->readImage($path);
            $image->setImageFormat("png");
            $image->setImageUnits(\Imagick::RESOLUTION_PIXELSPERINCH);
			$image->setImageResolution(500,500);
			//$image->cropImage(330,490,360,256);
			$image->trimImage(0.1);
            $png= $image->getImageBlob();
            $image->setImageFormat("tiff");
            $tiff= $image->getImageBlob();
            log_message('debug', 'PNG');
            //Save both images for review
            /*
            $save_time=date("YmdHis");
            file_put_contents(__DIR__."\\..\\..\\..\\..\\fingers\\".$save_time."_right_original.png", base64_decode($input['rightthumb']));
            file_put_contents(__DIR__."\\..\\..\\..\\..\\fingers\\".$save_time."_right.png", $png);
            file_put_contents(__DIR__."\\..\\..\\..\\..\\fingers\\".$save_time."_right.tiff", $tiff);
            */
            //log_message('debug', base64_encode($png));            
			//$cabis_response=$cabis->findFinger('RIndexFinger', base64_encode($tiff)); - No longer works
			$cabis_search_data[]=['name' => 'rightThumbFile', 'content' => $png];
		}
		if(strlen($input['photo'] ?? '')>10) { //Photo processing
			$cabis_search_data[]=['name' => 'faceFile', 'content' => 
			base64_decode($input['photo'])];
		}
			$cabis_response=$cabis->findCandidate($cabis_search_data);
			if($cabis_response!=false) {
				if(is_array($cabis_response['matches'])) {
					if(array_key_exists(0, $cabis_response['matches'])) {
						$orig_response=$cb_response=$cabis_response['matches'][0];
						$cb_response['cabis_id']=str_replace("00000", "", $cb_response['cabis_id']);
						$cabis_ids[]=$cb_response['cabis_id'];
						$subject=$this->subjectModel->getByCabisId($cb_response['cabis_id']);
						if($subject) {
							$response['data']['red_list']=$subject['red_list'];
						}
						$response['data']['name'] = $cb_response['first_name'].' '.$cb_response['last_name'];
						$response['data']['cabis_id'] = $cb_response['cabis_id'];
						$response['data']['match'] = 1;
						$response['data']['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$orig_response['cabis_id'].'&tag=705&thumbnail=1');
						//Get aliases
						for($n=1; $n<count($cabis_response['matches']); $n++) {
							$alias=$cabis_response['matches'][$n];
							$alias['cabis_id']=str_replace("00000", "", $alias['cabis_id']);
							$cabis_ids[]=$alias['cabis_id'];
							$subject=$this->subjectModel->getByCabisId($alias['cabis_id']);
							if($alias) {
								$alias_data['name'] = $alias['first_name'].' '.$alias['last_name'];
								$alias_data['cabis_id'] = $alias['cabis_id'];
								$alias_data['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$alias['cabis_id'].'&tag=705&thumbnail=1');
								$response['data']['aliases'][]=$alias_data;
							}
						}
					}
				}
			}
		}
			if(array_key_exists('id_number', $input) && strlen($input['id_number']) > 1) {
				$drivers=$this->driverModel->search(['nin' => $input['id_number']]);
				if(count($drivers)) {
					$driver=$drivers[0];
					$subject=$this->subjectModel->getByCabisId($driver['cabis_id']);
					if($subject) {
						$response['data']['name'] = $subject['name'];
						$response['data']['cabis_id'] = $driver['cabis_id'];
						$cabis_ids[] = $driver['cabis_id'];
						$response['data']['match']++;
						$response['data']['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=705&thumbnail=1');
						$response['data']['red_list']=$subject['red_list'];
					}
				}
			}
		
	
		//Check the id_number against CABIS
		if(strlen($input['id_number'] ?? '') ==14) { //National ID number
			$cabis_record=$cabis->getInfoByTag(NINID, $input['id_number']);
			if($cabis_record) {
				$cabis_id=$cabis->getTagFromData($cabis_record, CABISID);
				if($cabis_id) {
					$cabis_ids[] = $cabis_id;
					$response['data']['match'] = 1;
				}
			}
		}
		
		//Check among subjects
		if(strlen($input['id_number'] ?? '') ==14) { //National ID number
			$id_subjects=$this->subjectModel->getByNin($input['id_number']);
			foreach($id_subjects as $subject) {
				$cabis_ids[] = $subject['cabis_id'];
				$response['data']['match'] = 1;
			}
		}
		/*
		//Check for photo
		if(strlen($input['photo'] ?? '')>1) {
			log_message('debug', 'Checking photo');
			$oosto = new Oosto();
			$inquiryId=$oosto->analyzeFile(base64_decode($input['photo']), 'png');
			for($count=0;$count<10;$count++) { //Wait for up to 10 seconds
				sleep(1);
				$result=$oosto->getInquiryResults($inquiryId);
				log_message('debug', print_r($result, true));
				if($result['status'] == 'DONE') {
					foreach($result['subjects'] as $oosto_subject) {
						$subject=$this->subjectModel->getByOostoId($oosto_subject['id']);
						if($subject) {
							$cabis_ids[]=$subject['cabis_id'];
							if($response['data']['match'] == 0) {
								$response['data']['name'] = $subject['name'];
								$response['data']['cabis_id'] = $subject['cabis_id'];
								$cabis_ids[] = $subject['cabis_id'];
								$response['data']['match'] = 1;
								$response['data']['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=705');
								$response['data']['red_list']=$subject['red_list'];
							} else {
								$response['data']['aliases'][]=['name' => $subject['name'], 'cabis_id' => $subject['cabis_id'], 'photo' => base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=705')];
							}
						} else { //No subject ID, add the person as is
							//Save image
							$uuid=uuid();
							$this->cache->save('OOSTO_IMAGE_'.$uuid, base64_decode($oosto_subject['image']), HOUR);
							$image_link=site_url('/traffic/oosto_image/'.$uuid);
							if($response['data']['match'] == 0) {
								$response['data']['name'] = $oosto_subject['name'];
								$response['data']['cabis_id'] = 0;
								$response['data']['photo']=$image_link;
								$response['data']['red_list']=false;
							} else {
								$response['data']['aliases'][]=['name' => $oosto_subject['name'], 'cabis_id' => 0, 'photo' => $image_link];
							}
						}
						$response['data']['match']++;
					}
					break;
				}
			}
		}
		*/
		/*
		if(strlen($input['photo'] ?? '')>1) {
			log_message('debug', 'Checking photo');
			
			$input['photo']=base64_encode(Utils::sharpenImage(base64_decode($input['photo'])));
			$client = new Client(['base_uri' => 'http://172.16.11.24:5001/', 'verify' => false]);
			$headers = ['Content-Type' => 'application/json'];
			$body = ['image' => $input['photo']];
			try {
				$http_response=$client->post('/recognize', ['headers' => $headers, 'json' => $body]);
			} catch (\Exception $e) {
				print $e->getMessage();
			}
			$resp=json_decode($http_response->getBody(), true);
			log_message('debug', $http_response->getBody());
			if($resp['matches'] > 0) {
				if($resp['data'][0]['distance']<0.55) {
					log_message('debug', 'Distance match');
					$id=preg_match("/([0-9]+)/", $resp[0]['id'], $matches);
					$subject=$this->subjectModel->getByCabisId($matches[1]);
					if($subject) {
						log_message('debug', 'Subject match');
						$cabis_ids[]=$subject['cabis_id'];
						if($response['data']['match'] == 0) {
							$response['data']['name'] = $subject['name'];
							$response['data']['cabis_id'] = $subject['cabis_id'];
							$cabis_ids[] = $subject['cabis_id'];
							$response['data']['match'] = 1;
							$response['data']['photo']=base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=705');
							$response['data']['red_list']=$subject['red_list'];
						} else {
							$response['data']['aliases'][]=['name' => $subject['name'], 'cabis_id' => $subject['cabis_id'], 'photo' => base_url('ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=705')];
						}
					}
					
				}
			}
			log_message('debug', print_r($resp, true));
		}
		*/
		
		//Remove duplicates from cabis_ids
		if(count($cabis_ids)) {
			$cabis_ids=array_unique($cabis_ids);
		}

		//Check for permanent criminal offenses
		$criminal_offenses=[];
		if($response['data']['match'] >0 ?? '') { // We have a CABIS ID
			foreach($cabis_ids as $check_id) {
				$records=$this->subjectRecordModel->getByCabisId($check_id, 'PERMANENT');
				foreach($records as $record) {
					$criminal_offenses[]=['date' => $record['date_sentence'], 'offense' => $record['offence']];
				}
			}
		}
		$response['data']['criminal_offenses'] = $criminal_offenses;
		
		//Check for temporary criminal offenses
		if($response['data']['match'] >0) {
			foreach($cabis_ids as $check_id) {
				$subjectRecords=$this->subjectRecordModel->getByCabisId($check_id);
				if(array_key_exists(0, $subjectRecords)) { 
				$subjectRecord=$subjectRecords[0];
				if($subjectRecord) {
					if($subjectRecord['case_tracking_id']) { //Get case tracking info
						$ct=new CaseTracking();
						$cases=$ct->query(['query' => ['type' => 'Case', 'id' => $subjectRecord['case_tracking_id']]]);
						$case_data=null;
						if($cases) {
							if(is_array($cases)) {
								if(!array_key_exists('errorCode', $cases)) {
									$case_data=$cases[0];
								}
							}
						}
						if($case_data) {
							if(array_key_exists('offenses',  $case_data['details'])) {
								  foreach($case_data['details']['offenses'] as $offense) {
									  //var_dump($offense['offenseCode']['label']);
									  $response['data']['criminal_offenses'][]=['date' => date('Y-m-d', strtotime($case_data['createdDate'])), 'offense' => $offense['offenseCode']['label'].' - TEMP'];
								  }
							  }
						  }
					  }
				  }
			  }
		  }
	  }
		
		//Check for traffic offenses
		$traffic_offenses=[];
		if(array_key_exists('id_number', $input)) {
			$offenses=$this->trafficOffenseModel->getByNinOrVehicle($input['id_number'], $input['number_plate'] ?? '');
			foreach($offenses as $offense) {
				$traffic_offenses[] = ['date' => date("Y-m-d", strtotime($offense['created_at'])), 'offense' => $offense['offense'], 'penalty' => $offense['penalty'], 'amount' => $offense['amount']];
			}
		}
		$response['data']['traffic_offenses']=$traffic_offenses;
		
		$id_number = $input['id_number'] ?? "";
		if(!$id_number) {
			$response['data']['id'] = ['id_type' => 'NOT SUPPLIED'];
		} elseif(substr($id_number, 0,1) =='C') {
			$nin_data=$nira->getPerson($id_number);
			if(!$nin_data) {
				$response['data']['id'] = ['id_type' => 'NOT FOUND'];
			} else {
				$dob_fields=explode('/', $nin_data['dateOfBirth']);
				$dob=$dob_fields[2].'-'.$dob_fields[1].'-'.$dob_fields[0];
				$response['data']['id']=['id_type' => 'NATIONAL ID', 'name' => $nin_data['givenNames'].' '.$nin_data['surname'], 'date_of_birth' => $dob, 'photo' => $nin_data['photo']];
			}
		} else {
			$license_data=$nira->getLicense($id_number);
			if(!$license_data) {
				$response['data']['id'] = ['id_type' => 'NOT FOUND'];
			} else {
				$dob_fields=explode('/', $license_data['dob']);
				$dob=$dob_fields[2].'-'.$dob_fields[1].'-'.$dob_fields[0];
				$expiry=explode("/",$license_data['permit_expiry']);
				$expiry_date=$expiry[2].'-'.$expiry[1].'-'.$expiry[0];
				$response['data']['id'] = ['id_type' => 'DRIVING LICENSE', 'name' => $license_data['offendersName'], 'date_of_birth' => $dob, 'photo' => $license_data['photo'], 'expiry' => $expiry_date, 'permit_class' => $license_data['permitClass'], 'driver_restriction' => $license_data['drive_restriction'], 'vehicle_restriction' => $license_data['vehicle_restriction']];
			}
			
		}
		
		//Get Motor Vehicle details
		$number_plate= $input['number_plate'] ?? '';
		if($number_plate) {
			$vehicle_data=$nira->getVehicle(str_replace(" ", "", $number_plate));
			log_message('debug', 'VVVV got '.print_r($vehicle_data, true));
			if(strlen($vehicle_data['ErrorDesc'] ?? '') == strlen('SUCCESS')) {
				$response['data']['match']++;
				$response['data']['vehicle'] = ['make' => $vehicle_data['Make'], 'model' => $vehicle_data['ModelName'], 'year_manufacture' => $vehicle_data['ManufactureYear'], 'chassis_no' => $vehicle_data['ChasisNo'], 'engine_no' => $vehicle_data['EngineNo'], 'color' => $vehicle_data['Color'], 'body' => $vehicle_data['BodyDesc'], 'owner_name' => $vehicle_data['TaxPayerName'], 'owner_phone' => $vehicle_data['MobileNumber']];
			} else {
				$response['data']['vehicle']=new \stdClass();
			}
		}
		
		//For testing purposes
		if(array_key_exists('id_number', $input)) {
			if($input['id_number'] == 'CM92018101XAME') {
				$response['data']['aliases']=[['cabis_id' => '250', 'name' => 'Test Paul', 'photo' => 'http://172.16.40.54/eib/ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id=250&tag=705'], ['cabis_id' => '252', 'name' => 'Chris Menya', 'photo' => 'http://172.16.40.54/eib/ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id=252&tag=705']];
		//		 $response['data']['criminal_offenses'][]=['date' => '2023-09-10',  'offense' => 'Skipped bail'];
			 }
		 }
		
		
		//	return $this->respond(['status' => 'SUCCESS', 'data' => ['name' => 'David M', 'traffic_offenses' => [['date' => '2023-09-10',  'offense' => 'S33 Using motor vehicle without insurance', 'penalty' => 'CAUTION'], ['date' => '2023-11-23',  'offense' => 'S107 Dangerous mechanical condition', 'penalty' => 'FINE']], 'criminal_offenses' => [['date' => '2023-09-10',  'offense' => 'Skipped bail']]]]);
		
		//Return bool as expected by API
		if(array_key_exists('red_list', $response['data'])) {
			if($response['data']['red_list'] ==1 ) {
				$response['data']['red_list'] = true;
			} else {
				$response['data']['red_list'] = false;
			}
		}
		log_message('debug', print_r($response, true));
		return $this->respond($response);		
	}
	
	public function oostoImage($uuid) 
	{
		return $this->cache->get('OOSTO_IMAGE_'.$uuid);
	}
	
	public function oostoImageRealtime($uuid) 
	{
		$oosto = new Oosto();
		return base64_decode($oosto->getImage($this->cache->get('OOSTO_IMAGE_'.$uuid)));
	}
	
	public function oostoVideoRealtime($uuid) 
	{
		$oosto = new Oosto();
		$video = base64_decode($oosto->getImage($this->cache->get('OOSTO_IMAGE_'.$uuid)));
		return $this->convertAndSendMkvAsMp4($video);
	}
	
function convertAndSendMkvAsMp4($mkvString) {
    // Create temporary files for input (MKV) and output (MP4)
    $inputFile = tempnam(sys_get_temp_dir(), 'input') . '.mkv';
    $outputFile = tempnam(sys_get_temp_dir(), 'output') . '.mp4';

    // Write the MKV string to the temporary input file
    file_put_contents($inputFile, $mkvString);

    // Define the ffmpeg command to transcode the MKV to MP4 using H.264 and AAC codecs
    //$command = "ffmpeg -i $inputFile -c:v libx264 -c:a aac -strict experimental -movflags faststart $outputFile";
	$command = "ffmpeg -i $inputFile -c:v libx264 -vf scale=640:360 -c:a aac -strict experimental -movflags faststart $outputFile";

    // Execute the command and capture the output
    exec($command, $output, $return_var);

    // Check if the conversion was successful
    if ($return_var !== 0) {
        // Clean up temporary files
        unlink($inputFile);
        unlink($outputFile);
        throw new Exception("ffmpeg error: Conversion failed.");
    }

    // Serve the MP4 file
    $this->sendMp4FileWithRange($outputFile);

    // Clean up temporary files after sending the MP4
    unlink($inputFile);
    unlink($outputFile);
}

function sendMp4FileWithRange($filePath) {
    if (!file_exists($filePath)) {
        header("HTTP/1.1 404 Not Found");
        exit;
    }

    $fileSize = filesize($filePath);
    $range = isset($_SERVER['HTTP_RANGE']) ? $_SERVER['HTTP_RANGE'] : null;

    // Open the file for reading
    $file = fopen($filePath, 'rb');

    if ($range) {
        // Handle the range request
        list(, $range) = explode('=', $range, 2);
        list($start, $end) = explode('-', $range);
        $start = intval($start);
        $end = $end ? intval($end) : $fileSize - 1;
        $length = $end - $start + 1;

        header('HTTP/1.1 206 Partial Content');
        header("Content-Range: bytes $start-$end/$fileSize");
        header('Content-Length: ' . $length);
    } else {
        // No range, send the entire file
        $start = 0;
        $end = $fileSize - 1;
        header('Content-Length: ' . $fileSize);
    }


    header('Content-Type: video/mp4');
    header('Accept-Ranges: bytes');
    header('Content-Disposition: inline; filename="' . basename($filePath) . '"');
    header('Cache-Control: no-cache');
    header('Pragma: no-cache');
    header('Expires: 0');

    // Move the file pointer to the start of the requested range
    fseek($file, $start);

    // Output the requested range of the file
    $bufferSize = 8192; // 8KB chunks
    while (!feof($file) && ($start <= $end)) {
        $bytesToRead = min($bufferSize, $end - $start + 1);
        $buffer = fread($file, $bytesToRead);
        echo $buffer;
        flush();
        $start += $bytesToRead;
    }

    fclose($file);
    exit;
}

function view() 
	{
		$records_json=file_get_contents('http://172.16.41.14/eib/traffic/camera_alerts?device_id='.rand(0,10000000));
		$records=json_decode($records_json, true);
		$data['alerts']=$records['alerts'];
		return view('header', $data)
			. view('view_oosto', $data)
			. view('footer', $data);
	}
	
	public function submit()
	{
		$input = $this->request->getJSON(true);
		log_message('debug', print_r($input, true)); 
		if(!(array_key_exists('id_type', $input) && array_key_exists('id_number', $input) && array_key_exists('offense', $input) && array_key_exists('penalty', $input) &&  array_key_exists('location', $input))) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E01', 'message' => 'Missing fields']]]);
		}
		$data=['first_name' => $input['first_name'], 'last_name' => $input['last_name'], 'dob' => $input['dob'], 'id_type' => $input['id_type'], 'id_number' => $input['id_number'], 'number_plate' => $input['number_plate'] ?? null, 'offense' => $input['offense'], 'penalty' => $input['penalty'], 'location' => $input['location']];
		if(array_key_exists('amount', $input)) {
			$data['amount']=$input['amount'];
		}
		$id=$this->trafficOffenseModel->insert($data);
		
			return $this->respond(['status' => 'SUCCESS', 'data' => ['id' => $id]]);
	}
	
	//Returns people from the broadcast list
	public function alerts() {
		//Set an AJAX token
		$_SESSION['AJAX_TOKEN']=uuid();
		$this->cache->save('AJAX_TOKEN_'.$_SESSION['AJAX_TOKEN'],'api', 1*HOUR); 
		$response=['status' => 'SUCCESS', 'alerts' => []];
		$device_id= $this->request->getVar('device_id') ?? '';
		if(empty($device_id)) {
			return $this->respond($response);
		}
		$alerts=$this->broadcastModel->getNew($device_id);
			if($alerts) {
				foreach($alerts as $alert) {
					$subject=$this->subjectModel->find($alert);
					$response['alerts'][]=['cabis_id' => $subject['cabis_id'], 'name' => $subject['name'], 'reason' => $subject['reason'], 'photo' => base_url('/ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=705&thumbnail=1')];
				}
		}
		return $this->respond($response);
	}
	
	//Returns people from the broadcast list who have been observed on camera
	public function cameraAlerts() {
		//Set an AJAX token
		$_SESSION['AJAX_TOKEN']=uuid();
		session_write_close();
		$oosto=new Oosto();
		$this->cache->save('AJAX_TOKEN_'.$_SESSION['AJAX_TOKEN'],'api', 1*HOUR); 
		$response=['status' => 'SUCCESS', 'alerts' => []];
		$device_id= $this->request->getVar('device_id') ?? '';
		if(empty($device_id)) {
			return $this->respond($response);
		}
		$cameras=[
		"b935d693-93e8-4192-8132-2b85d3062778",
		"62f47e90-0a95-4add-ac53-07842aa586a0",
		"940bad89-39ac-42cc-9092-f21552615b27",
		"fe55c2be-0cf5-4ca2-bed4-3e04bd68ffe5",
		"c00d2b3a-c3bc-411a-92e7-0143c6459b93"
	];
		
		$alerts=$oosto->getAlerts($cameras);
		$latest_time=$this->cache->get('CAMERA_ALERTS_'.$device_id);
		$new_latest_time='';
		$n=0;
		foreach($alerts as $alert) {
			$n++;
			if(strtotime($alert['frameTimeStamp']) > (strtotime($latest_time) ?? 0)) { //Whether to show this record
				if(strtotime($alert['frameTimeStamp']) > (strtotime($new_latest_time) ?? 0)) { //Whether to set this as the new latest time
					$new_latest_time=$alert['frameTimeStamp'];
				}
			} else {
				//continue;
			}

			$return_alert=['id' => 10, 'cabis_id' => 10, 'name' => $alert['subject']['name'], 'camera' => $alert['camera']['title'], 'time' => $alert['frameTimeStamp']];		
			//Save image
			$uuid=uuid();
			$this->cache->save('OOSTO_IMAGE_'.$uuid, $alert['subject']['image']['url'], DAY);
			$return_alert['subject_image']=site_url('/traffic/oosto_image_realtime/'.$uuid);
			
			$uuid=uuid();
			$this->cache->save('OOSTO_IMAGE_'.$uuid, $alert['images'][0]['url'], DAY);
			$return_alert['captured_image']=site_url('/traffic/oosto_image_realtime/'.$uuid);
			//Get video
			$return_alert['captured_video']=$oosto->getTrackVideoLink($alert['trackId'], $alert['frameTimeStamp']);
			$uuid=uuid().".mp4";
			$this->cache->save('OOSTO_IMAGE_'.$uuid, $return_alert['captured_video'], DAY);
			$return_alert['captured_video']=site_url('/traffic/oosto_video_realtime/'.$uuid);
			log_message('debug', "Adding alert ".print_r($return_alert, true));
			$response['alerts'][]=$return_alert;
			if($n>3) {
				break;
			}
		}
		if(strtotime($new_latest_time)) {
			$this->cache->save('CAMERA_ALERTS_'.$device_id, $new_latest_time, MONTH);
		}
		return $this->respond($response);
	}
	
	public function redlist()
	{
		$_SESSION['AJAX_TOKEN']=uuid();
		$this->cache->save('AJAX_TOKEN_'.$_SESSION['AJAX_TOKEN'],'api', 1*HOUR); 
		$response=['status' => 'SUCCESS', 'data'=>[]]; 
		$subject_data=$this->subjectModel->search(['red_list' => 1, 'broadcast' => 1]);
		foreach($subject_data as $subject) {
			$response['data'][]=['cabis_id' => $subject['cabis_id'], 'name' => $subject['name'], 'reason' => $subject['reason'], 'photo' => base_url('/ajax/get_cabis?token='.$_SESSION['AJAX_TOKEN'].'&id='.$subject['cabis_id'].'&tag=705&thumbnail=1')];
		}
		return $this->respond($response);
	}


}

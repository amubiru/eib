<?php namespace App\Controllers\Api;

use CodeIgniter\API\ResponseTrait;

use App\Libraries\CABIS;


class Police extends \App\Controllers\BaseController
{

	use ResponseTrait;
	
	protected $cache;
	protected $OAGModel;
	protected $IppsModel;
	protected $payrollModel;
	protected $subjectModel;
	protected $policeOfficerModel;

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->OAGModel = model('App\Models\OAGModel');
		$this->IppsModel = model('App\Models\IppsModel');
		$this->payrollModel = model('App\Models\PayrollModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->policeOfficerModel = model('App\Models\PoliceOfficerModel');
		
	}

	//Submits police officer to be verified at CABIS
	public function verify_submit()
	{
		$input = $this->request->getJSON(true);
		if(!(array_key_exists('nin', $input)) ) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E01', 'message' => 'NIN not specified']]]);
		}
		$subject = false;
		$officer=$this->IppsModel->findByNin($input['nin']);
		
		if(!$officer) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E02', 'message' => 'Officer is not registered in system']]]);
		}
		$names=explode(" ", trim($officer['name']));
		$first_name=$names[0];
		$last_name=$names[count($names)-1];
		
		//Check OAG for officer
		$oag=$this->OAGModel->findByEmployeeNumber($officer['employee_number']);
		if(!$oag) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E03', 'message' => 'Officer is not in OAG list']]]);
		}
		//Check Payroll for officer
		$payroll=$this->payrollModel->findByEmployeeNumber($officer['employee_number']);
		$response_data=[];
		if(!$payroll) {
			$response_data['warnings'] = ['code' => 'W01', 'message' => 'Officer is not in payroll for last month'];
		}
		//Submit data to CABIS
		$cabis_data=[];
		$cabis_data['textData']=[['tagNum' => '110', 'tagValue' => $last_name],['tagNum' => '111', 'tagValue' => $first_name],['tagNum' => '3319', 'tagValue' => 'POLICE'],['tagNum' => ForceNumber, 'tagValue' => $officer['employee_number']],['tagNum' => NINID, 'tagValue' => $officer['nin']]];
		$cabis_data['imageData']=[['tagNum' => '17101', 'tagValue' => '101']];
		
		log_message('debug', print_r($cabis_data, true));
		$cabis = new CABIS();
		$cabis_id=$cabis->submit(json_encode($cabis_data));
		log_message('debug', 'CABIS ID: '.$cabis_id);
		//Create police record
		$subject_id=$this->subjectModel->insert(['name' => $officer['name'], 'cabis_id' => $cabis_id]);

		$this->policeOfficerModel->insert(['subject_id' => $subject_id, 'first_name' => $first_name,'last_name' => $last_name,'employee_number' => $officer['employee_number'], 'nin' => $officer['nin'], 'liveness_verification' => 1]);
		//All good, return data
		$response_data['status'] = 'OK';
		$response_data['name'] = $officer['name'];
		$response_data['employee_number'] = $officer['employee_number'];
		return $this->respond($response_data); 
	}

	//Query a police officer by a variety of fields
	public function query()
	{
		// Request by David to use GET
		if($this->request->getVar('nin')) {
			$nin=$this->request->getVar('nin');
		} else {
			$input = $this->request->getJSON(true);
			if(!is_array($input)) {
				return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E01', 'message' => 'NIN or employee number not specified']]]);
			}
			if(!(array_key_exists('nin', $input) || array_key_exists('employee_num', $input) || array_key_exists('cabis', $input))) {
				return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E01', 'message' => 'NIN or employee number not specified']]]);
			}
			$nin=$input['nin'];
		}
		if(!$nin) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E01', 'message' => 'NIN not specified']]]);
		}
		$subject = false;
		$officer=$this->IppsModel->findByNin($nin);
		
		if(!$officer) {
			return $this->respond(['status' => 'FAILED', 'errors' => [['code' => 'E02', 'message' => 'Officer is not registered in system']]]);
		}
		$names=explode(" ", trim($officer['name']));
		$first_name=$names[0];
		$last_name=$names[count($names)-1];
		$officer_data=['nin'=>$officer['nin'],'employee_num' => $officer['employee_number'], 'name' => $officer['name'], 'rank' => $officer['title'], 'ipps' => $officer['ipps_no'], 'cabis_id'=> '', 'gender' => $officer['gender'], 'date_of_birth' => $officer['date_of_birth'], 'date_enlistment' => $officer['first_application_date'], 'date_current_deployment' => $officer['current_application_date'],'liveness_check_flag'=> 'N', 'oag_flag' => 'N', 'pso_flag' => 'N','payroll_flag'=> 'N'];

		//Check OAG for officer
		$oag=$this->OAGModel->findByEmployeeNumber($officer['employee_number']);
		if(!$oag) {
			$officer_data['oag_flag'] = 'Y';
		}
		//Check Payroll for officer
		$payroll=$this->payrollModel->findByEmployeeNumber($officer['employee_number']);
		$response_data=[];
		if(!$payroll) {
			$officer_data['payroll_flag'] = 'Y';
		}
		
		log_message('debug', print_r($officer_data, true));
		
		return $this->respond($officer_data); 
	}

	


}

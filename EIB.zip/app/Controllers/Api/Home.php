<?php

namespace App\Controllers\Api;

class Home extends \App\Controllers\BaseController
{
    public function index()
    {
        return view('welcome_message');
    }
}

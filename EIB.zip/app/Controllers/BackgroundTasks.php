<?php namespace App\Controllers;

use CodeIgniter\RESTful\ResourceController;
use CodeIgniter\API\ResponseTrait;
use App\Libraries\CABIS;
use App\Libraries\Email;
use App\Libraries\NIRA;
use \setasign\Fpdi\Fpdf;
use \setasign\Fpdi\Fpdi;
use \chillerlan\QRCode\QRCode;
use \PhpOffice\PhpSpreadsheet\Spreadsheet;
use \PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class BackgroundTasks extends ResourceController
{

	use ResponseTrait;
	
	protected $cache;
	protected $userModel;
	protected $cabisModel;
	protected $cogcModel;
	protected $cogcIssueModel;
	protected $subjectModel;
	protected $subjectRecordModel;

	function __construct()
	{
		$this->cache = \Config\Services::cache();
		$this->cabisModel = model('App\Models\CabisModel');
		$this->cogcModel = model('App\Models\COGCModel');
		$this->cogcIssueModel = model('App\Models\COGCIssueModel');
		$this->subjectModel = model('App\Models\SubjectModel');
		$this->subjectRecordModel = model('App\Models\SubjectRecordModel');
	}

	public function checkCertificate($prn)
	{
		
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		
		$certs=$this->cogcModel->getByPRN($prn); //Check those who were fingerprinted
		log_message('debug', 'CERTPROCESS: Found '.count($certs).' pending certificates');
		$criminal=false;
		foreach($certs as $cert) {
			$subject=$this->subjectModel->find($cert['subject_id']);
			//Confirm that this information has hit CABIS
			if(!(strlen($cabis->getTag($subject['cabis_id'], FirstName) ?? '') || strlen($cabis->getTag($subject['cabis_id'], LastName) ?? ''))) {
				print($subject['cabis_id']. ' not yet in CABIS<br>');
				log_message('debug', $subject['cabis_id']. ' not yet in CABIS');
				continue;
			}
			$criminal=false;
			//Look for criminal records
			print $subject['cabis_id']."\n";
			$cabis_records = $cabis->getMatchingCandidates($subject['cabis_id'], false);
			//Remove duplicates - using a helper function since the PHP one does not work with multi dimensional arrays
			$cabis_records = array_unique_multi($cabis_records);
			var_dump($cabis_records);
			$queue_reason='';
			$queue_type='';
			//Police
			if($cabis->getItem($subject['cabis_id'], 'afisCategory') ==1 && $cabis->getTag($subject['cabis_id'], ForceNumber)) {
				//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
			}
			foreach($cabis_records as $record) {
				if($record['category']==AFIS_CRIMINAL) {
					$queue_type='CRIMINAL';
					//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'CRIMINAL']);
					//$queue_reason=$this->addQueueReason($queue_reason, 'Criminal record CABIS: '.$record['cabis_id']);
				}
				if($record['category']==AFIS_LAW_ENFORCEMENT) {
					if($queue_type!='CRIMINAL') {
						$queue_type='POLICE';
					}
					//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
					//$queue_reason=$this->addQueueReason($queue_reason, 'Police officer CABIS: '.$record['cabis_id']);
				}
				if($cert['first_name'] != $record['first_name'] || $cert['last_name'] != $record['last_name']) {
					if(!in_array($queue_type, ['CRIMINAL','POLICE'])) {
						$queue_type='CIVILIAN';
					}
					//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'NAME']);
					//$queue_reason=$this->addQueueReason($queue_reason, 'Different names CABIS: '.$record['cabis_id'].' First name: '.$record['first_name'].' Last name: '.$record['last_name']);
				}
				
			}
			print $queue_reason;
		}
	}
	
	//Processes serially
	public function processCertificatesSingle()
	{
		//Use a cache variable to act as a lock
		$lock=$this->cache->get('CERT_LOCK');
		if($lock && getenv('CI_ENVIRONMENT') == 'production') { //Don't lock on development
			log_message('debug', 'CERTLOCK: Found Certificate Lock');
			return;
		}
		$this->cache->save('CERT_LOCK', 1, 4*MINUTE); //Update that we are using the lock
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		
		//Process certificates which have had issues resolved
		$certs=$this->cogcModel->getResolved();
		foreach($certs as $cert) {
			$this->cache->save('CERT_LOCK', 1, 4*MINUTE); //Update that we are using the lock
			$subject=$this->subjectModel->find($cert['subject_id']);
			$subjectRecords= $this->subjectRecordModel->getBySubjectId($cert['subject_id'], 'PERMANENT');
			//Confirm that this information has hit CABIS
			if(!(strlen($cabis->getTag($subject['cabis_id'], FirstName) ?? '') || strlen($cabis->getTag($subject['cabis_id'], LastName) ?? ''))) {
				log_message('debug', $subject['cabis_id']. ' not yet in CABIS');
				continue;
			}
			$counter=$this->cogcModel->incrementCounter();
			$this->cogcModel->update($cert['id'], ['pcc_time' => date('Y-m-d H:i:s'), 'cogc_time' => date('Y-m-d H:i:s'), 'status' => 'PROCESSED', 'day_counter' => $counter['day_counter'], 'total_counter' => $counter['total_counter']]);
			$pcc_file=$this->savePCC($cert['id']);
			//Should be of type COGC and no permanent record
			if($cert['type']=='COGC' && !count($subjectRecords)) {
				$cogc_file=$this->saveCOGC($cert['id']);
			}
			//Send data to IT team
			$nira =new NIRA();
			$cert_content=json_decode($cert['raw_content'], true);
			$nira->postPhoto($cert_content['ApplicationNumber'], $cert['prn'], file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705')));
			$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($pcc_file), 'PCC');
			if($cert['type']=='COGC' && !count($subjectRecords)) {
				$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($cogc_file), 'COGC');
			}
		}
		$certs=$this->cogcModel->getFingerprinted(); //Check those who were fingerprinted
		log_message('debug', 'CERTPROCESS: Found '.count($certs).' pending certificates');
		$criminal=false;
		$start_time=time();
		foreach($certs as $cert) {
			$this->cache->save('CERT_LOCK', 1, 4*MINUTE); //Update that we are using the lock
			$subject=$this->subjectModel->find($cert['subject_id']);
			$elapsed=time()-$start_time;
			log_message('debug', "CERTPROCESS: processing {$subject['cabis_id']} at $elapsed seconds");
			//Confirm that this information has hit CABIS
			if(!(strlen($cabis->getTag($subject['cabis_id'], FirstName) ?? '') || strlen($cabis->getTag($subject['cabis_id'], LastName) ?? ''))) {
				log_message('debug', $subject['cabis_id']. ' not yet in CABIS');
				continue;
			}
			$criminal=false;
			//Look for criminal records
			print $subject['cabis_id']."\n";
			$cabis_records = $cabis->getMatchingCandidates($subject['cabis_id'], false);
			//Remove duplicates - using a helper function since the PHP one does not work with multi dimensional arrays
			$cabis_records = array_unique_multi($cabis_records);
			log_message('debug', 'Got matches: for '.$subject['cabis_id']. " as " .print_r($cabis_records, true));
			$queue_reason='';
			$queue_type='';
			//Police
			if($cabis->getItem($subject['cabis_id'], 'afisCategory') ==1 && $cabis->getTag($subject['cabis_id'], ForceNumber)) {
				//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
			}
			foreach($cabis_records as $record) {
				if($record['category']==AFIS_CRIMINAL) {
					$queue_type='CRIMINAL';
					$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'CRIMINAL']);
					$queue_reason=$this->addQueueReason($queue_reason, 'Criminal record CABIS: '.$record['cabis_id']);
				}
				if($record['category']==AFIS_LAW_ENFORCEMENT) {
					if($queue_type!='CRIMINAL') {
						$queue_type='POLICE';
					}
					//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
					$queue_reason=$this->addQueueReason($queue_reason, 'Police officer CABIS: '.$record['cabis_id']);
				}
				//Check for NIRA names
				if($cert['id_type']=='NIN') {
					$nira = new NIRA();
					$nin=$nira->getPerson($cert['id_number']);
					if(strlen($nin['surname'] ?? '')) {
						if($cert['last_name'] != $nin['surname']) {
							if(!in_array($queue_type, ['CRIMINAL','POLICE'])) {
							$queue_type='CIVILIAN';
						}
						$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => null, 'type' => 'NAME']);
						$queue_reason=$this->addQueueReason($queue_reason, 'Different names NIRA: '.' First name: '.$nin['givenNames'].' Last name: '.$nin['surname']);
						}
					}
				}
				if($cert['first_name'] != $record['first_name'] || $cert['last_name'] != $record['last_name']) {
					if(!in_array($queue_type, ['CRIMINAL','POLICE'])) {
						$queue_type='CIVILIAN';
					}
					$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'NAME']);
					$queue_reason=$this->addQueueReason($queue_reason, 'Different names CABIS: '.$record['cabis_id'].' First name: '.$record['first_name'].' Last name: '.$record['last_name']);
				}
				
			}
			//Decide whether to create the certificate or to queue
			if($queue_reason) {
				$this->cogcModel->update($cert['id'], ['queue_type' => $queue_type, 'internal_notes' => $queue_reason, 'queue_reason' => $queue_reason, 'status' => 'QUEUE']);
			} else {
				$counter=$this->cogcModel->incrementCounter();
				$this->cogcModel->update($cert['id'], ['pcc_time' => date('Y-m-d H:i:s'), 'cogc_time' => date('Y-m-d H:i:s'), 'status' => 'PROCESSED', 'day_counter' => $counter['day_counter'], 'total_counter' => $counter['total_counter']]);
				$pcc_file=$this->savePCC($cert['id']);
				if($cert['type']=='COGC') {
					$cogc_file=$this->saveCOGC($cert['id']);
				}
				//Send data to IT team
				$nira =new NIRA();
				$cert_content=json_decode($cert['raw_content'], true);
				$nira->postPhoto($cert_content['ApplicationNumber'], $cert['prn'], file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705')));
				$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($pcc_file), 'PCC');
				if($cert['type']=='COGC') {
					$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($cogc_file), 'COGC');
				}
				
			}
		}
		//Delete the certificate lock to ensure that the next certificates can be processed as soon as possible
		$this->cache->delete('CERT_LOCK');
	}
	
	//Processes resolved certificates
	public function processResolvedCertificates()
	{
		//Use a cache variable to act as a lock
		$lock=$this->cache->get('CERT_RESOLVED_LOCK');
		if($lock && getenv('CI_ENVIRONMENT') == 'production') { //Don't lock on development
			log_message('debug', 'CERTLOCK: Found Certificate Lock');
		//	return;
		}
		$this->cache->save('CERT_RESOLVED_LOCK', 1, 4*MINUTE); //Update that we are using the lock
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		
		//Process certificates which have had issues resolved
		$certs=$this->cogcModel->getResolved();
		foreach($certs as $cert) {
			$this->cache->save('CERT_RESOLVED_LOCK', 1, 4*MINUTE); //Update that we are using the lock
			$subject=$this->subjectModel->find($cert['subject_id']);
			$subjectRecords= $this->subjectRecordModel->getBySubjectId($cert['subject_id'], 'PERMANENT');
			//Confirm that this information has hit CABIS
			if(!(strlen($cabis->getTag($subject['cabis_id'], FirstName) ?? '') || strlen($cabis->getTag($subject['cabis_id'], LastName) ?? ''))) {
				log_message('debug', $subject['cabis_id']. ' not yet in CABIS');
				continue;
			}
			$counter=$this->cogcModel->incrementCounter();
			$this->cogcModel->update($cert['id'], ['pcc_time' => date('Y-m-d H:i:s'), 'cogc_time' => date('Y-m-d H:i:s'), 'status' => 'PROCESSED', 'day_counter' => $counter['day_counter'], 'total_counter' => $counter['total_counter']]);
			$pcc_file=$this->savePCC($cert['id']);
			//Should be of type COGC and no permanent record
			if($cert['type']=='COGC' && !count($subjectRecords)) {
				$cogc_file=$this->saveCOGC($cert['id']);
			}
			//Send data to IT team
			$nira =new NIRA();
			$cert_content=json_decode($cert['raw_content'], true);
			$nira->postPhoto($cert_content['ApplicationNumber'], $cert['prn'], file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705')));
			$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($pcc_file), 'PCC');
			if($cert['type']=='COGC' && !count($subjectRecords)) {
				$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($cogc_file), 'COGC');
			}
		}
		$this->cache->delete('CERT_RESOLVED_LOCK'); //Update that we are done with the lock
	}
	
	//Processes 5 in parallel
	public function processCertificates()
	{
		//Use a cache variable to act as a lock
		$lock=$this->cache->get('CERT_LOCK');
		if($lock && getenv('CI_ENVIRONMENT') == 'production') { //Don't lock on development
			log_message('debug', 'CERTLOCK: Found Certificate Lock');
			return;
		}
		$this->cache->save('CERT_LOCK', 1, 4*MINUTE); //Update that we are using the lock
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		
		$certs=$this->cogcModel->getFingerprinted(); //Check those who were fingerprinted
		log_message('debug', 'CERTPROCESS: Found '.count($certs).' pending certificates');
		$criminal=false;
		$start_time=time();
		//Close database connection
		$db = \Config\Database::connect();
		$db->close();
		$maxProcesses = 5;
		$runningProcesses = 0;
		$processIds = [];
		foreach($certs as $cert) {
			$this->cache->save('CERT_LOCK', 1, 4*MINUTE); //Update that we are using the lock
			// Check if we need to wait for processes to finish
			while ($runningProcesses >= $maxProcesses) {
				foreach ($processIds as $pidKey => $pid) {
					$result = pcntl_waitpid($pid, $status, WNOHANG); // Non-blocking check

					if ($result == $pid || $result == -1) { // Process finished or error
						unset($processIds[$pidKey]);
						$runningProcesses--;
						echo "Process $pid finished. Running processes: $runningProcesses\n";
					}
				}
				sleep(1); // Sleep for a second before checking again
			}


			// Fork a new process
			$pid = pcntl_fork();

			if ($pid == -1) {
				die("Could not fork process"); // Handle errors
			} else if ($pid == 0) { // Child process
				print "Processing {$cert['id']}\n";
				$this->processCertificate($cert);
				return;
			} else { // Parent process
				$processIds[$pid] = $pid; // Store the process ID
				$runningProcesses++;
				echo "Forked process $pid. Running processes: $runningProcesses\n";
			}
			sleep(5);
		}
		//Delete the certificate lock to ensure that the next certificates can be processed as soon as possible
		$this->cache->delete('CERT_LOCK');
	}
	
	function processCertificate($cert) {
		//Use a cache variable to act as a lock
		$lock=$this->cache->get('CERT_LOCK_'.$cert['id']);
		if($lock && getenv('CI_ENVIRONMENT') == 'production') { //Don't lock on development
			log_message('debug', 'CERTLOCK: Found Certificate Lock '.$cert['id']);
			return;
		}
		$this->cache->save('CERT_LOCK_'.$cert['id'], 1, 4*MINUTE); //Update that we are using the lock
		$cabis=new CABIS();
		//Reconnect to the database to prevent fork DB issues
		$db = \Config\Database::connect('default', false);
		$db->reconnect();
		$subject=$this->subjectModel->find($cert['subject_id']);
		//Confirm that this information has hit CABIS
		if(!(strlen($cabis->getTag($subject['cabis_id'], FirstName) ?? '') || strlen($cabis->getTag($subject['cabis_id'], LastName) ?? ''))) {
			log_message('debug', $subject['cabis_id']. ' not yet in CABIS');
			return;
		}
		$criminal=false;
		//Look for other records
		print $subject['cabis_id']."\n";
		$cabis_records = $cabis->getMatchingCandidates($subject['cabis_id'], false);
		log_message('debug', 'Got matches: for '.$subject['cabis_id']. " as " .print_r($cabis_records, true));
		$queue_reason='';
		$queue_type='';
		//Police
		if($cabis->getItem($subject['cabis_id'], 'afisCategory') ==1 && $cabis->getTag($subject['cabis_id'], ForceNumber)) {
			//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
		}
		foreach($cabis_records as $record) {
			if($record['category']==AFIS_CRIMINAL) {
				$queue_type='CRIMINAL';
				$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'CRIMINAL']);
				$queue_reason=$this->addQueueReason($queue_reason, 'Criminal record CABIS: '.$record['cabis_id']);
			}
			if($record['category']==AFIS_LAW_ENFORCEMENT) {
				if($queue_type!='CRIMINAL') {
					$queue_type='POLICE';
				}
				//$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'POLICE']);
				$queue_reason=$this->addQueueReason($queue_reason, 'Police officer CABIS: '.$record['cabis_id']);
			}
			//Check for NIRA names
			if($cert['id_type']=='NIN') {
				$nira = new NIRA();
				$nin=$nira->getPerson($cert['id_number']);
				if(strlen($nin['surname'] ?? '')) {
					if($cert['last_name'] != $nin['surname']) {
						if(!in_array($queue_type, ['CRIMINAL','POLICE'])) {
						$queue_type='CIVILIAN';
					}
					$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => null, 'type' => 'NAME']);
					$queue_reason=$this->addQueueReason($queue_reason, 'Different names NIRA: '.' First name: '.$nin['givenNames'].' Last name: '.$nin['surname']);
					}
				}
			}
			if($cert['first_name'] != $record['first_name'] || $cert['last_name'] != $record['last_name']) {
				if(!in_array($queue_type, ['CRIMINAL','POLICE'])) {
					$queue_type='CIVILIAN';
				}
				$this->cogcIssueModel->insert(['cogc_id' => $cert['id'], 'related_cabis_id' => $record['cabis_id'], 'type' => 'NAME']);
				$queue_reason=$this->addQueueReason($queue_reason, 'Different names CABIS: '.$record['cabis_id'].' First name: '.$record['first_name'].' Last name: '.$record['last_name']);
			}
			
		}
		//Decide whether to create the certificate or to queue
		if($queue_reason) {
			$this->cogcModel->update($cert['id'], ['queue_type' => $queue_type, 'internal_notes' => $queue_reason, 'queue_reason' => $queue_reason, 'status' => 'QUEUE']);
		} else {
			$counter=$this->cogcModel->incrementCounter();
			$this->cogcModel->update($cert['id'], ['pcc_time' => date('Y-m-d H:i:s'), 'cogc_time' => date('Y-m-d H:i:s'), 'status' => 'PROCESSED', 'day_counter' => $counter['day_counter'], 'total_counter' => $counter['total_counter']]);
			$pcc_file=$this->savePCC($cert['id']);
			if($cert['type']=='COGC') {
				$cogc_file=$this->saveCOGC($cert['id']);
			}
			//Send data to IT team
			$nira =new NIRA();
			$cert_content=json_decode($cert['raw_content'], true);
			$nira->postPhoto($cert_content['ApplicationNumber'], $cert['prn'], file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705')));
			$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($pcc_file), 'PCC');
			if($cert['type']=='COGC') {
				$nira->postCertificate($cert_content['ApplicationNumber'], file_get_contents($cogc_file), 'COGC');
			}
			
		}
	}
	
	public function exportCertificatesCLI()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		//$certs=$this->cogcModel->getPending();
		print "Transaction No,Last Name,First Name,Middle Name,FP Date,Gender,Date of Birth,Nationality,Document Number,NIN ID,Address  and POB,Certificate Type,PRN No.,COGC No.,Offence(s),Results of Case/trail,Date (mm/dd/yy,Adverse Police Notice,Signing Officer\n";
		$formxs=$this->cabisModel->getBetween(date('Y-m-d', strtotime('-1 day')), date('Y-m-d'));
		foreach($formxs as $formx) {
			$s=$subject=$this->subjectModel->getByCabisId($formx['subject_id']);
			$res=$this->cogcModel->getBySubjectId($subject['id']);
			$c=$cert=end($res);
			if(!$c) {
				continue;
			}
			$c=json_decode($cert['raw_content'], true);
			$s=$subject=$this->subjectModel->find($cert['subject_id']);
			if($cabis->getTag($s['cabis_id'], CABISID)) {
				$txn_no=$cabis->getTag($s['cabis_id'], NewGroupId);
				$dob_parts=explode(' ', $c['DOB']);
				print $txn_no.',"'.$c['LastName'].'","'.$c['FirstName'].'","'.$c['MiddleName'].'",'.$cabis->getTag($s['cabis_id'], Date).','.$c['Gender'].','.$dob_parts[0].','.$c['Nationality'].',"'.$c['PassportNo'].'",'.$c['NIN'].',"'.$c['PlaceOfResidence'].'",'.$c['Service_Type'].','.$c['prn'].','.','.','.','.','.',Andrew Mubiru'."\n";
			}
		}
	}
	
	public function exportCertificatesDaily()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		//$certs=$this->cogcModel->getPending();
		$line_array=explode(",", "Transaction No,Last Name,First Name,Middle Name,FP Date,Gender,Date of Birth,Nationality,Document Number,NIN ID,Address  and POB,Certificate Type,PRN No.,COGC No.,Offence(s),Results of Case/trail,Date (mm/dd/yy,Adverse Police Notice,Signing Officer,Enroll Location");
		$lines=[$line_array];
		$cogcs=$this->cogcModel->getBetween(date('Y-m-d', strtotime('-1 day')), date('Y-m-d'));
		foreach($cogcs as $cogc) {
			$c=$cert=$res=$cogc;
			$s=$subject=$this->subjectModel->find($cogc['subject_id']);

			$c=json_decode($cert['raw_content'], true);
			$s=$subject=$this->subjectModel->find($cert['subject_id']);
			if($cabis->getTag($s['cabis_id'], CABISID)) {
				$txn_no=$cabis->getTag($s['cabis_id'], NewGroupId);
				$dob_parts=explode(' ', $c['DOB']);
				$doc_number='';
				if(strlen(trim($c['PassportNo'] ?? ''))>4) {
					$doc_number=$c['PassportNo'];
				} else {
					$doc_number=$c['RefugeeCardNo'];
				}
				$line_array= [$txn_no,$c['LastName'],$c['FirstName'],$c['MiddleName'],$cabis->getTag($s['cabis_id'], Date),$c['Gender'],$dob_parts[0],$c['Nationality'],$doc_number,$c['NIN'],$c['PlaceOfResidence'],$c['Service_Type'],$c['prn'],"","","","","",'Andrew Mubiru', $cabis->getTag($s['cabis_id'], EnrolLocation)];
				$lines[]=$line_array;
			}
		}
		$date=date('Y-m-d', strtotime('-1 day'));
		$save_path='/usr/local/certificates/pcc/'.$date;
		if(!is_dir($save_path)) {
			mkdir($save_path);
			chmod($save_path, 0755);
		}
		$file= $save_path.'/'.$date.'.xlsx';
		$this->csvToExcel($lines, $file);
		chmod($file, 0644);
	}
	
	
	public function exportCertificatesOLD()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		//$certs=$this->cogcModel->getPending();
		$certs=$this->cogcModel->findAll();
		$criminal=false;
		print "Transaction No,Last Name,First Name,Middle Name,FP Date,Gender,Date of Birth,Nationality,Document Number,NIN ID,Address  and POB,Certificate Type,PRN No.,COGC No.,Offence(s),Results of Case/trail,Date (mm/dd/yy,Adverse Police Notice,Signing Officer\n";
		foreach($certs as $cert) {
			$c=json_decode($cert['raw_content'], true);
			$s=$subject=$this->subjectModel->find($cert['subject_id']);
			$criminal=false;
			if($cabis->getTag($s['cabis_id'], CABISID)) {
				$txn_no=$cabis->getTag($s['cabis_id'], NewGroupId);
				$dob_parts=explode(' ', $c['DOB']);
				print $txn_no.','.$c['LastName'].','.$c['FirstName'].','.$c['MiddleName'].','.$cabis->getTag($s['cabis_id'], Date).','.$c['Gender'].','.$dob_parts[0].','.$c['Nationality'].','.$c['PassportNo'].','.$c['NIN'].','.$c['PlaceOfResidence'].','.$c['Service_Type'].','.$c['prn'].','.','.','.','.','.',Andrew Mubiru'."<br>";
			}
		}
	}
	
	public function exportCertificatesCLIOLD()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		//$certs=$this->cogcModel->getPending();
		$certs=$this->cogcModel->findAll();
		$criminal=false;
		$file=fopen(__DIR__."/../../writable/certs/certs_".date("Ymdhis").".csv", "w");
		fwrite($file, "Transaction No,Last Name,First Name,Middle Name,FP Date,Gender,Date of Birth,Nationality,Document Number,NIN ID,Address  and POB,Certificate Type,PRN No.,COGC No.,Offence(s),Results of Case/trail,Date (mm/dd/yy,Adverse Police Notice,Signing Officer\n");
		foreach($certs as $cert) {
			$c=json_decode($cert['raw_content'], true);
			$s=$subject=$this->subjectModel->find($cert['subject_id']);
			$criminal=false;
			if($cabis->getTag($s['cabis_id'], CABISID)) {
				$txn_no=$cabis->getTag($s['cabis_id'], NewGroupId);
				$dob_parts=explode(' ', $c['DOB']);
				fwrite($file, $txn_no.',"'.$c['LastName'].'","'.$c['FirstName'].'","'.$c['MiddleName'].'",'.$cabis->getTag($s['cabis_id'], Date).','.$c['Gender'].','.$dob_parts[0].','.$c['Nationality'].',"'.$c['PassportNo'].'",'.$c['NIN'].',"'.$c['PlaceOfResidence'].'",'.$c['Service_Type'].','.$c['prn'].','.','.','.','.','.',Andrew Muburu'."\n");
			}
		}
	}
	
	//Mark that these records have had their prints taken
	public function markPrints()
	{
		session_write_close(); //In case CABIS is unavailable, other services should keep running
		$cabis=new CABIS();
		//$certs=$this->cogcModel->getPending();
		$certs=$this->cogcModel->findAll();
		$criminal=false;
		foreach($certs as $cert) {
			if($cert['status'] != 'PENDING') {
				continue;
			}
			$s=$subject=$this->subjectModel->find($cert['subject_id']);
			$criminal=false;
			if($cabis->getTag($s['cabis_id'], CABISID)) {
				$this->cogcModel->update($cert['id'], ['status' => 'FINGERPRINT', 'fingerprint_date' => date('Y-m-d H:i:s')]);
			}
		}
	}
	
	public function savePCC($id)
		{
		$data=[];
		$cabis=new CABIS();
		$barcode = new \Picqer\Barcode\BarcodeGeneratorPNG();
		$cogc=$this->cogcModel->find($id);
		if(!$cogc) {
			return;
		}
		$record=$subject=$this->subjectModel->getById($cogc['subject_id']);
		
		$cdata=json_decode($cogc['raw_content'], true);
		//Get all matching CABIS IDs
		$cabis_ids[]=$subject['cabis_id'];
		$cabis_records = $cabis->getMatchingCandidates($subject['cabis_id'], false);
		foreach($cabis_records as $rec) {
			$cabis_ids[]=$rec['cabis_id'];
		}

		$cabis_ids=array_unique($cabis_ids);
		
		//Load offenses since we have all the CABIS Ids
		$subjectRecords=$data['offenses']= $this->subjectRecordModel->getByCabisIds($cabis_ids);

		$subjectRecord=[];
		if(count($subjectRecords)) {
			$subjectRecord=$subjectRecords[0];
		}
		if(count($subjectRecord)) {
			switch ($subjectRecord['case_result']) {
				case 'NOT SENTENCED YET':
					$subjectRecord['result']="Not sentenced yet";
					break;
				case 'ACQUITTED':
					$subjectRecord['result']="Acquitted";
					break;
				case 'DISMISSED':
					$subjectRecord['result']="Dismissed";
					break;
				case 'SENTENCED':
					switch($subjectRecord['sentence_type']) {
						case 'CUSTODIAL':
							$subjectRecord['result']='Imprisonment for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
						break;
						case 'NON CUSTODIAL':
						switch($subjectRecord['non_custodial_sentence']) {
							case 'CAUTION':
								$subjectRecord['result']='Caution';
								break;
							case 'COMMUNITY SERVICE':
								$subjectRecord['result']='Community service for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
								break;
							case 'FINE':
								$subjectRecord['result']='Fined UGX '.$subjectRecord['sentence_amount'];
								break;
						}
						break;
					}
					break;
				default:
					$subjectRecord['result']=" - ";
			}
		}
		$record['subject_id']=$subject['cabis_id'];
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');

		$pdf = new Fpdi();

		$pdf->AddPage(); 

		$pdf->setSourceFile(__DIR__.'/../../images/PF83.pdf'); 
		// import page 1 
		$this->tplIdx = $pdf->importPage(1); 
		//use the imported page and place it at point 0,0; calculate width and height
		//automaticallay and adjust the page size to the size of the imported page 
		$pdf->useTemplate($this->tplIdx, 0, 0, 827, 1169, true); 

		// now write some text above the imported page 
		$pdf->SetFont('Times', 'B', '40'); 
		$pdf->SetTextColor(0,0,0);
		//set position in pdf document
		//Text below barcode
		$yoff=90;
		$xoff=123;
		$pdf->SetXY($xoff, $yoff);
		$pdf->SetFont('Arial', 'B', '35'); 
		$pdf->Write(10,  $cabis->getTag($subject['cabis_id'], NewGroupId));
		
		$text_size='55';
		$line_height=30;	
		$pdf->SetLeftMargin(80);
		$pdf->SetRightMargin(80);
		$yoff=335;
		$xoff=142;
		$pdf->SetXY($xoff, $yoff);
		$pdf->SetTextColor(255,0,0);
		$date_info=date('W ').(date('z')+1);
		$pdf->AddFont('Typewriter','B','typewriter-bold.php');
		$pdf->SetFont('Typewriter', 'B', '50'); 
		$pdf->Write(10, 'DFS/CI/'.$date_info.'/'.sprintf("%04d", $cogc['day_counter']));
		$xoff=240;
		$pdf->SetFont('Times', 'BI', '40'); 
		$pdf->SetTextColor(0,0,0);
		$pdf->SetXY($xoff, $yoff);
		$pdf->MultiCell(0, 1, date("D j, F Y"),0,'R');
		//$pdf->Write(10, date("d F, Y", strtotime($cabis->getTag($subject['cabis_id'], Date))));
		$name=$cogc['first_name']." ";
		$middle_name=$cogc['middle_name'];
		if(strlen($middle_name ?? '')) {
			$name.=$middle_name." ";
		}
		$name.=$cogc['last_name'];
		$pdf->SetFont('Times', 'BI', $text_size);
		$name_length=$pdf->GetStringWidth($name);
		$xoff=(827-$name_length)/2;
		$yoff=435;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $name);
		$xoff=387;
		$yoff=525;
		$pdf->SetXY($xoff, $yoff);
		if(strlen(trim($cdata['PassportNo'] ?? ''))>4) {
			$doc_number=$cdata['PassportNo'];
		} else {
			$doc_number=$cdata['RefugeeCardNo'];
		}
 		$pdf->Write($line_height, $doc_number);
		$dob_only=explode(' ', $cdata['DOB']);
		$xoff=602;
		$yoff=525;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $dob_only[0]);
		$xoff=263;
		$yoff=571;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $cdata['NIN']);
		$pdf->SetXY(449, 1075);
		$pdf->MultiCell(0, 1, 'Andrew K. Mubiru', 0, 'C');
		
		$xoff=235;
		$yoff=658;
		$pdf->SetFont('Times', 'BI', 45);
		$pdf->SetXY($xoff, $yoff);
		//Offense
		//Generate extra text
		if(count($subjectRecords) == 0) {
			$pdf->Write($line_height, 'NIL');
			$yoff=772;
			$pdf->SetXY($xoff, $yoff);
			//Result of case trial
			$pdf->Write($line_height, 'NIL');
			$yoff=833;
			$pdf->SetXY($xoff, $yoff);
			$pdf->Write($line_height, 'NIL');			
		} elseif(count($subjectRecords) ==1) {
			if(strlen($subjectRecord['crb_no']) && strlen($subjectRecord['station'])) {
				$extra_text=" vide ".$subjectRecord['station'].', '.$subjectRecord['crb_no'];
			} elseif(strlen($subjectRecord['crb_no'])) {
				$extra_text=" vide ".$subjectRecord['crb_no'];
			} elseif(strlen($subjectRecord['station'])) {
				$extra_text=" vide ".$subjectRecord['station'];
			} else {
				$extra_text='';
			}
				
			$pdf->Write($line_height, ($subjectRecord['offence'].$extra_text) ?? 'NIL');
			$yoff=772;
			$pdf->SetXY($xoff, $yoff);
			//Result of case trial
			$pdf->Write($line_height, $subjectRecord['remarks'] ?? 'NIL');
			$yoff=833;
			$pdf->SetXY($xoff, $yoff);
			//Date of sentence
			if(count($subjectRecord)) {
				//Ignore obviously wrong dates
				if(strtotime($subjectRecord['date_sentence'])>strtotime('1940-01-01')) {
					$pdf->Write($line_height, date('m/d/Y', strtotime($subjectRecord['date_sentence'])));
				}
			}
			} elseif(count($subjectRecords) > 1) {
			$pdf->Write($line_height, 'See overleaf');
		}
		$yoff=897;
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write($line_height, $record['adverse_police_notice'] ?? 'NIL');
		
		$pdf->SetFont('Times', 'I', '30');
		$pdf->SetXY(90, 1102); 
		$pdf->Write($line_height, 'eiB/DFS002/'.sprintf("%07d", $cogc['total_counter'] ?? 1).date("/m/d/Y", strtotime($cabis->getTag($subject['cabis_id'], Date) ?? date('Y-m-d'))));
		//$pdf->SetXY(190, 1102); 
		//$pdf->Write($line_height, date("/m/d/Y", strtotime($cabis->getTag($subject['cabis_id'], Date) ?? date('Y-m-d'))));
		//Output images
		//Photograph
		if(file_get_contents(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705'))) {
			$pdf->Image(base_url('ajax/get_cabis?id='.$subject['cabis_id'].'&tag=705'), 340,153,140,0,'PNG');
		}
		$qrCode=new QRCode();
		$pdf->Image($qrCode->render("https://upf.go.ug/public/verify-certificate/".$cogc['uuid']), 80,1010,100,0,'PNG');
		//$pdf->Image($qrCode->render(base_url('/pub/forms/cogc/'.$record['id'])), 80,960,100,0,'PNG');
		
		//Signature
		$pdf->Image(__DIR__.'/../../images/director_signature.png', 510,980,260,0,'PNG');
		
		//Barcodes
		//Group ID Barcode
		$barcode_file=tmpfile();
		fwrite($barcode_file, $barcode->getBarcode($cabis->getTag($subject['cabis_id'], NewGroupId), $barcode::TYPE_CODE_128));
		$file_name=stream_get_meta_data($barcode_file)['uri'];
		$pdf->Image($file_name, 65,53,170,0,'PNG');
		
		//PRN barcode
		$barcode_file=tmpfile();
		fwrite($barcode_file, $barcode->getBarcode($cogc['prn'], $barcode::TYPE_CODE_128));
		$file_name=stream_get_meta_data($barcode_file)['uri'];
		$pdf->Image($file_name, 207,1075,170,0,'PNG');
		
		//If we have multiple offenses, show them on a second page
		if(count($subjectRecords) >1) {
			//Add Second page
			$pdf->AddPage('L', [827,1169]); 

			$date_pos=60;
			$offense_pos=150;
			$result_pos=600;
			$remark_pos=800;
			$xoff=20;
			$yoff=60;
			$pdf->SetFont('Times', 'B', 45);
			$pdf->SetXY($date_pos, $yoff);
			$pdf->Write($line_height, 'DATE');
			$pdf->SetXY($offense_pos, $yoff);
			$pdf->Write($line_height, 'OFFENSE');
			$pdf->SetXY($result_pos, $yoff);
			$pdf->Write($line_height, 'CASE RESULT');
			$pdf->SetXY($remark_pos, $yoff);
			//$pdf->Write($line_height, 'REMARKS');
			$yoff+=40;
			$pdf->SetFont('Times', 'BI', 45);
			foreach($subjectRecords as $subjectRecord) {
				$pdf->SetXY($date_pos, $yoff);
				if(strtotime($subjectRecord['date_sentence'] ?? '') >strtotime('1940-01-01')) {
					$pdf->Write($line_height, date('m/d/Y', strtotime($subjectRecord['date_sentence'] ?? '')));
				}
		
				if(strlen($subjectRecord['crb_no']) && strlen($subjectRecord['station'])) {
					$extra_text=" vide ".$subjectRecord['crb_no'].', '.$subjectRecord['station'];
				} elseif(strlen($subjectRecord['crb_no'])) {
					$extra_text=" vide ".$subjectRecord['crb_no'];
				} elseif(strlen($subjectRecord['station'])) {
					$extra_text=" vide ".$subjectRecord['station'];
				} else {
					$extra_text='';
				}
				$pdf->SetXY($offense_pos, $yoff);
				$pdf->MultiCell($result_pos-$offense_pos-10,$line_height, ($subjectRecord['offence'].$extra_text) ?? 'NIL');
				$offense_height = $pdf->GetY() - $yoff;
				switch ($subjectRecord['case_result']) {
					case 'NOT SENTENCED YET':
						$subjectRecord['result']="Not sentenced yet";
						break;
					case 'ACQUITTED':
						$subjectRecord['result']="Acquitted";
						break;
					case 'DISMISSED':
						$subjectRecord['result']="Dismissed";
						break;
					case 'SENTENCED':
						switch($subjectRecord['sentence_type']) {
							case 'CUSTODIAL':
								$subjectRecord['result']='Imprisonment for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
							break;
							case 'NON CUSTODIAL':
							switch($subjectRecord['non_custodial_sentence']) {
								case 'CAUTION':
									$subjectRecord['result']='Caution';
									break;
								case 'COMMUNITY SERVICE':
									$subjectRecord['result']='Community service for '." ".counted($subjectRecord['sentence_amount'], strtolower($subjectRecord['sentence_units']));
									break;
								case 'FINE':
									$subjectRecord['result']='Fined UGX '.$subjectRecord['sentence_amount'];
									break;
							}
							break;
						}
						break;
					default:
						$subjectRecord['result']=" - ";
				}
				$pdf->SetXY($result_pos, $yoff);
				$pdf->MultiCell(500, $line_height, $subjectRecord['remarks']);
				$result_height = $pdf->GetY() - $yoff;
				$pdf->SetXY($remark_pos, $yoff);
				//$pdf->MultiCell(200, $line_height, $subjectRecord['remarks'] ?? '-');
				//$remark_height = $pdf->GetY() - $yoff;
				if($result_height>$offense_height) {
					$height=$result_height;
				} else {
					$height=$offense_height;
				}
				//if($remark_height>$height) {
				//	$height=$remark_height;
				//}
				$yoff=$yoff+$height+40; 
			}
		}
		
		$date=date('Y-m-d');
		$save_path='/usr/local/certificates/pcc/'.$date;
		if(!is_dir($save_path)) {
			mkdir($save_path);
			chmod($save_path, 0755);
		}
		$file= $save_path.'/'.$cogc['prn'].'_PCC.pdf';
		$pdf->Output('F',$file);
		chmod($file, 0644);
		return($file);
	}
	
	public function saveCOGC($id)
	{
		$data=[];
		$cabis=new CABIS();
		$barcode = new \Picqer\Barcode\BarcodeGeneratorPNG();
		$record=$this->cogcModel->find($id);
		$cert_content=json_decode($record['raw_content'], true);
		$subject=$this->subjectModel->getById($record['subject_id']);
		$subjectRecords=$this->subjectRecordModel->getBySubjectId($record['subject_id']);
		if(count($subjectRecords)>0) {
			$subjectRecord=$subjectRecords[0];
			$record['station']=$subjectRecord['station'];
			$record['remarks']=$subjectRecord['remarks'];
		} else {
			$subjectRecord=null;
			$record['station']='';
			$record['remarks']='';
		}
		$record['subject_id']=$subject['cabis_id'];
		
		$data['cabis_present']=$cabis->getTag($subject['cabis_id'], '105');
		$record['status']= ($data['cabis_present'] != null) ? "COMPLETED" : "PENDING";

		$pdf = new Fpdi();

		$pdf->AddPage(); 

		$pdf->setSourceFile(__DIR__.'/../../images/COGC.pdf'); 
		// import page 1 
		$this->tplIdx = $pdf->importPage(1); 
		//use the imported page and place it at point 0,0; calculate width and height
		//automaticallay and adjust the page size to the size of the imported page 
		$pdf->useTemplate($this->tplIdx, 0, 0, 827, 1169, true); 

		// now write some text above the imported page 
		$pdf->SetFont('Helvetica', 'B', '30'); 
		$pdf->SetTextColor(0,0,0);
		//set position in pdf document
		$xoff=77;
		$yoff=420;
		$text_size='50';
		$line_height=30;	
		$pdf->SetLeftMargin(77);
		$pdf->SetRightMargin(80);
		$pdf->SetXY($xoff, $yoff);
		$pdf->Write(10, "Date: ".date("d F, Y", strtotime($record['created_at']))."\nTime: ".date("g:i A", strtotime($record['created_at'])));
		$yoff=480;
		$pdf->SetXY($xoff, $yoff);
		$pdf->AddFont('AppleChancery','','apple-chancery-regular.php');
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, "\n\n");
		$pdf->Write($line_height, "This is to certify that according to the criminal records maintained in Uganda. ");
		$pdf->SetFont('Helvetica', '', $text_size);
		$pdf->SetFont('', 'B', $text_size);
		$name=$record['first_name']." ";
		$middle_name=$record['middle_name'];
		if(strlen($middle_name ?? '')) {
			$name.=$middle_name." ";
		}
		$name.=$record['last_name'];
		$pdf->Write($line_height, strtoupper($name));
		$pdf->SetFont('', '', $text_size);
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, ", holder of ");
		$pdf->SetFont('Helvetica', 'B', $text_size);
		$document_type= ($record['id_type'] == 'NIN') ? "Identity Card" : "PASSPORT";
		$pdf->Write($line_height, $document_type);
		$pdf->SetFont('', '', $text_size);
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, " number ");
		$pdf->SetFont('Helvetica', 'B', $text_size);
		$pdf->Write($line_height, $record['id_number']);
		$pdf->SetFont('Helvetica', '', $text_size);
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, " issued by the ");
		$pdf->SetFont('Helvetica', 'B', $text_size);
		$pdf->Write($line_height, $record['issued_by']);
		$pdf->SetFont('Helvetica', '', $text_size);
		$text=" has never been convicted of any criminal offense or come to adverse Police notice. The information on this certificate is as of the date of issue. The certificate is issued without any alteration or erasure and it is valid for six (6) months from the date of issue.";
		$pdf->SetFont('AppleChancery', '', '60'); 
		$pdf->Write($line_height, $text);
		$yoff=1000;
		$pdf->SetXY($xoff, $yoff);
		$pdf->SetFont('Helvetica', 'B', $text_size*2/3);
		$pdf->Write(20, 'DIRECTOR INTERPOL AND INTERNATIONAL RELATIONS');
		
		//Output images
		//Photograph
		if(file_get_contents(base_url('/ajax/get_cabis?id='.$record['subject_id'].'&tag=705'))) {
			$pdf->Image(base_url('ajax/get_cabis?id='.$record['subject_id'].'&tag=705'), 620,270,150,0,'PNG');
		}
		//Application number barcode
		$barcode_file=tmpfile();
		fwrite($barcode_file, $barcode->getBarcode($cert_content['ApplicationNumber'], $barcode::TYPE_CODE_128));
		$file_name=stream_get_meta_data($barcode_file)['uri'];
		$pdf->Image($file_name, 77,1050,170,0,'PNG');
		$pdf->SetXY(77, 1065);
		$pdf->SetFont('Arial', 'B', $text_size*2/3);
		$pdf->Write(20, $cert_content['ApplicationNumber']);
		
		$qrCode=new QRCode();
		$pdf->Image($qrCode->render("https://upf.go.ug/public/verify-cogc/".$record['uuid']), 600,1000,100,0,'PNG');
		$date=date('Y-m-d');
		$save_path='/usr/local/certificates/cogc/'.$date;
		if(!is_dir($save_path)) {
			mkdir($save_path);
			chmod($save_path, 0755);
		}
		$file= $save_path.'/'.$record['prn'].'_COGC.pdf';
		$pdf->Output('F',$file);
		chmod($file, 0644);
		return($file);
	}
	
	public function pcc()
	{
		$prns=["2250001217161","2250001161789","2250001415543","2250001162350","2250001430101","2250001415340","2250001161322","2250001163172","2250001225427","2250001274042","2250001502573","2250001413844","2250001123438","2250001445495","2250000822717","2250001525326","2250001349190","2250001481970","2250001508544","2250001143259","2250001413108","2250001353967","2250001393103","2250001388648","2250001171728","2250001504712","2250001171456","2250001347287","2250001453370","2250001500082","2250001458314","2250001536851","2250001132306","2250001423215","2250001189833","2250001108030","2250001500233","2250001239680","2250001413644","2250001254062","2250001109872","2250001520676","2250001409937","2250001116600","2250001431183","2250001129813","2250001132340","2250001391176","2250001153642","2250001249994","2250001429102","2250001435681","2250001522154","2250001291144","2250001462519","2250001159346","2250001151049","2250001427848","2250001396994","2250001414241","2250001432690","2250001375637","2250001186820","2250001502221","2250001161928","2250001347443","2250001449010","2250001456096","2250001514055","2250001481479","2250001332213","2250001432740","2250001150363","2250001453114","2250001449918","2250001477673","2250001426839","2250001278315","2250001427841","2250001244310","2250001149186","2250001512206","2250001119092","2250001441242","2250001006457","2250001117889","2250001461227","2250001401373","2250001402643","2250001250417","2250001497410","2250001404895","2250001499914","2250001132238","2250001139773","2250000872109","2250001398029","2250001481038","2250001118333","2250001120970","2250001503507","2250001133069","2250001147742","2250001076830","2250001158010","2250001242304","2250001426651","2250001221407","2250001365188","2250001387038","2250001249705","2250001470640","2250001152545","2250001427089","2250001505061","2250001452626","2250001510773","2250001225749","2250001414158","2250001431190","2250001257626","2250001095971","2250001169487","2250001415466","2250001226160","2250001428301","2250001361131","2250001250645","2250000956184","2250001060621","2250001307836","2250001147457","2250001430760","2250000864689","2250001228492","2250001501076","2250001433212","2250001405175","2250001441174","2250001499491","2250001253745","2250001253073","2250001222934","2250001397896","2250001448324","2250001168140","2250001449151","2250001152506","2250001118600","2250001349024","2250001524377","2250001396012","2250001227085","2250001129584","2250001240936","2250001079330","2250001159326","2250000959532","2250001356433","2250001405373","2250001450258","2250001475586","2250001077351","2250001507710","2250001131849","2250001133441","2250001149345","2250001572186","2250001550822","2250001455298","2250001434712","2250001499597","2250001352929","2250001154284","2250001357405","2250001160226","2250001427691","2250000952258","2250001226477","2250001256303","2250001107750","2250001152922","2250001349800","2250001168664","2250001250930","2250001226842","2250001403287","2250001405102","2250001353097","2250001508091","2250001255755","2250001422360","2250001353740","2250001403246","2250001251887","2250001429584","2250001512176","2250001444118","2250001517061","2250001462413","2250001447133","2250000999398","2250001435729","2250001062322","2250001254464","2250001385312","2250001249341","2250001501246","2250001043665","2250001115192","2250001377008","2250001431499","2250001505143","2250001441746","2250001518986","2250001454699","2250000999671","2250001503139","2250001406732","2250001554067","2250001515378","2250001353294","2250001430560","2250001488243","2250001255958","2250001431593","2250001122998","2250001502076","2250001435826","2250000955078","2250001228045","2250001454855","2250001430294","2250001497456","2250001452426","2250001361878","2250001508171","2250001523321","2250001280456","2250001511316","2250001367212","2250001515683","2250001363890","2250000999742","2250001077663","2250001066236","2250001148250","2250001493677","2250001431853","2250001448987","2250001431431","2250001424066","2250001471862","2250001448430","2250001046786","2250001358478","2250001334783","2250001152005","2250001145031","2250001485812","2250001449144","2250001000022","2250001255550","2250001483110","2250001348087","2250001404347","2250001120216","2250001493588","2250001163057","2250001133015","2250001168483","2250001405480","2250001252704","2250001348710","2250001116955","2250001399407","2250001365688","2250001252330","2250001076320","2250001125465","2250001077974","2250001484138","2250001497311","2250001131262","2250001241603","2250001249761","2250001485106","2250001409356","2250001499633","2250001420996","2250001361380","2250001158778","2250001155506","2250001434031","2250001119664","2250000950991","2250001377315","2250001164315","2250001241208","2250001166180","2250001414343","2250001495337","2250001518457","2250001398017","2250001433292","2250001219211","2250001494452","2250001034479","2250001465955","2250001440500","2250001434743","2250001480240","2250001454305","2250001349142","2250001168393","2250001443558","2250001386513","2250001333217","2250001456717","2250001301574","2250001225458","2250001226174","2250001315124","2250000730041","2250001477705","2250001125709","2250001462166","2250001152070","2250001054525","2250001224337","2250001452769","2250001494462","2250001440480","2250001458729","2250001390695","2250001398565","2250001401665","2250001306101","2250001490432","2250001031649","2250001428235","2250001471456","2250001510132","2250001223409","2250001389256","2250001153480","2250001078712","2250001410070","2250001479082","2250001452748","2250001453902","2250001451825","2250001253627","2250001454415","2250001391027","2250001353549","2250001518829","2250001107317","2250001174068","2250001402078","2250000723847","2250001487296","2250001373260","2250001128214","2250001486992","2250001083334","2250001454392","2250001155727","2250001429839","2250001365268","2250001076324","2250001539005","2250001390263","2250001473760","2250001439339","2250001118307","2250001216914","2250001401448","2250001222257","2250001516968","2250001519066","2250001393491","2250001348665","2250001159306","2250001109239","2250001252676","2250001401265","2250001429403","2250001436078","2250001376428","2250001159782","2250001345602","2250001378409","2250001458791","2250001140071","2250001310565","2250001273390","2250001432583","2250001303727","2250001476959","2250001220752","2250001430394","2250001405708","2250001425617","2250001115780","2250000582968","2250001446765","2250001005762","2250001509758","2250001381255","2250001400770","2250001451395","2250001087046","2250001318332","2250001125142","2250001161095","2250001397369","2250001249060","2250001133578","2250001390779","2250001471859","2250001426846","2250001117458","2250001452261","2250001518609","2250001172847","2250001463748","2250001490071","2250001455373","2250001427384","2250001192475","2250001443677","2250001436597","2250001093666","2250001410556","2250001163311","2250001079514","2250001023046","2250001410663","2250000901225","2250001458620","2250001456990","2250001432331","2250001458465","2250001258697","2250001448845","2250001252842","2250001563316","2250001463040","2250001287964","2250001490485","2250001399677","2250001220137","2250001096063","2250001562266","2250001476322","2250001454198","2250001377640","2250001374595","2250001016678","2250001432239","2250001031459","2250001490530","2250001376836","2250001463476","2250001410100","2250001413325","2250000764986","2250001413574","2250001441848","2250001398100","2250001095582","2250001515828","2250001435711","2250001490469","2250001454154","2250001503164","2250001031862","2240018195778","2250001519500","2250001220645","2250001481661","2250001432157","2250001413473","2250001453526","2250001165339","2250001349768","2250001413271","2250001409560","2250001075520","2250001445327","2250001454018","2250001490454","2250001475289","2250001161605","2250001397943","2250001349779","2250001331402","2250001396462","2250001374402","2250001483695","2250001140430","2250001464038","2250001559055","2250001464335","2250001144104","2250001416603","2250001558770","2250001442499","2250001449552","2250001435293","2250001146600","2250001452445","2250001437208","2250001296387","2250001387734","2250001415828","2250001423043","2250001409204","2250001057073","2250001415409","2250001386119","2250001464703","2250001344008","2250001168401","2250001289867","2250001053478","2250001433991","2250001395657","2250001346203","2250001412171","2250001132003","2250001020401","2250001327818","2250001256588","2250001252682","2250001217606","2250001417202","2250001269800","2250001151352","2250001520974","2250001524532","2250001300016","2250001406308","2250001148028","2250001224377","2250001411683","2250001563276","2250001390136","2250001455810","2250001126034","2250001478646","2250001109809","2250001317633","2250001409630","2250001376040","2250001490099","2250001442087","2250001108893","2250001125013","2250001431970","2250001345198","2250001552576","2250001274441","2250001355116","2250001108397","2250001386727","2250001348753","2250000943349","2250001469886","2250001384939","2250001129395","2250001451804","2250001354372","2250001134342","2250001174236","2250001456363","2250001512933","2250001500551","2250001218446","2250001251217","2250001030528","2250001157830","2250001513902","2250001364600","2250001525030","2250000998999","2250001414091","2250001125515","2250001458450","2250001505476","2250001254831","2250001349119","2250001318013","2250001532335","2250001454152","2250001487093","2250001158974","2250001061325","2250001354867","2250001134647","2250001154186","2250001119003","2250001222239","2250001414485","2250001430138","2250001361572","2250001446595","2250001450686","2250001309172","2250001219162","2250001392450","2250001459527","2250001456937","2250001431867","2250001504643","2250001508980","2250000865453","2250001388860","2250000953078","2250001154668","2250001409359","2250001243211","2250001429220","2250001389736","2250001430491","2250001444841","2250001148090","2250001373822","2250001154071","2250000885350","2250001165138","2250001346202","2250001129112","2250001255164","2250001525125","2250001133208","2250001418729","2250001147930","2250000789116","2250001405304","2250001473248","2250001401184","2250001160016","2250001400597","2250000996273","2250001354224","2250001401815","2250000960458","2250001360712","2250001155030","2250000875312","2250001159608","2250001172197","2250001421112","2250001523320","2250001504644","2250001348870","2250001185233","2250001493768","2250000808049","2250001432162","2250001505148","2250001025260","2250001150429","2250001500701","2250001157905","2250001527661","2250001430632","2250001506286","2250001172718","2250001456250","2250001397418","2250001433396","2250001436972","2250000989725","2250001474620","2250001191577","2250001550155","2250001124740","2250001454831","2250001221372","2250001500762","2250001362362","2250001453842","2250001169160","2250001159721","2250001157872","2250001394945","2250001390727","2250001381562","2250001251515","2250001449634","2250001078310","2250001324681","2250001348560","2250001157437","2250001228162","2250001319291","2250001460473","2250001445218","2250001130216","2250001245975","2250001007132","2250001417934","2250001352662","2250001546308","2250001500126","2250001219375","2250001150326","2250001450924","2250001354536","2250001539083","2250001414090","2250001513329","2250001478415","2250001142817","2250001448353","2250001127474","2250001558573","2250001181099","2250001109307","2250001435219","2250000890434","2250000702283","2250001490143","2250001412305","2250001190376","2250001174146","2250001174773","2250001301496","2250001074865","2250001350520","2250001384944","2250001493625","2250001392207","2250001418466","2250000998249","2250000998631","2240011246153","2250001344692","2250001375887"];
		$n=0;
		return;
		foreach($prns as $prn) {
			print "$n $prn\n";
			$cogcs=$this->cogcModel->getByPRN($prn);
			$cogc=end($cogcs);
			if($cogc) {
				$this->cogcModel->update($cogc['id'], ['status' => 'PROCESSED', 'cogc_time' => date('Y-m-d')]);
			}
			//$this->savePCC($prn);
			$n++;
		}
		print "Done";
	}
	
	//Adds a queue reason if it's not been used yet
	private function addQueueReason($reason, $new_reason)
	{
		if(!strstr($reason, $new_reason)) {
			$reason.="$new_reason\n";
		}
		return($reason);
	}
	
	//Saves an Excel file of a CSV provided as an array
	private function csvToExcel($lines, $outputExcelFilePath) {
		// Create a new Spreadsheet object
		$spreadsheet = new Spreadsheet();
		$sheet = $spreadsheet->getActiveSheet();


			$row = 1;

		// Read each row of the CSV file
		foreach($lines as $data) {
			$col = 1;

			// Write each field to the Excel sheet
			foreach ($data as $field) {
				$sheet->setCellValue([$col, $row], $field);
				$col++;
			}

			$row++;
		}

		// Write the Excel file to the specified output path
		$writer = new Xlsx($spreadsheet);
		$writer->save($outputExcelFilePath);
	}
	
	//Checks recent pending COGCs and processes them if need be
	public function reviewCOGC()
	{
		$cabis=new CABIS();
		$cogcs=$this->cogcModel->getMonthUnprocessed();
		$cogcs=array_reverse($cogcs);
		foreach($cogcs as $cogc) {
			//Find out if the CABIS id was processed
			$subject=$this->subjectModel->find($cogc['subject_id']);
			$name=$cabis->getTag($subject['cabis_id'], FirstName);
			if(strlen($name ?? '')) { //Mark this record as processed
				$this->cogcModel->update($cogc['id'], ['status' => 'FINGERPRINT', 'fingerprint_date' => date('Y-m-d H:i:s')]);
				continue;
			}
			//Check if this PRN was processed elsewhere
			$record=$cabis->getInfoByTag(PRN, $cogc['prn']);
			//print $cogc['prn']."\n";
			if($record) {
				$cabis_id=$cabis->getTagFromData($record, CABISID);
				$first_name=$cabis->getTagFromData($record, FirstName);
				$last_name=$cabis->getTagFromData($record, LastName);
				print "PRN matched $cabis_id $first_name $last_name {$cogc['first_name']} {$cogc['last_name']}\n";
				$this->subjectModel->update($cogc['subject_id'], ['cabis_id' => $cabis_id]);
				$this->cogcModel->update($cogc['id'], ['status' => 'FINGERPRINT', 'fingerprint_date' => date('Y-m-d H:i:s')]);
				continue;
			}
		}
	}
	
}
